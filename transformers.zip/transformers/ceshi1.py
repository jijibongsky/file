from transformers import AutoTokenizer, AutoModel

# tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
# model = AutoModel.from_pretrained("bert-base-uncased")
# inputs = tokenizer("Hello world!", return_tensors="pt")
# outputs = model(**inputs)
# for key in outputs:
#     print(111111, key, outputs[key].shape)  # last_hidden_state [1, 5, 768]  pooler_output [1, 768]


from transformers import DistilBertTokenizerFast
import torch
from transformers import DistilBertForSequenceClassification, Trainer, TrainingArguments
from torch.utils.data import DataLoader

# /root/.cache/huggingface


device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
model = DistilBertForSequenceClassification.from_pretrained("results/checkpoint-500")
model.to(device)
model.eval()
tokenizer = DistilBertTokenizerFast.from_pretrained('distilbert-base-uncased')
train_texts = ["你叫什名字", "今天天气不错"]
train_encodings = tokenizer(train_texts, truncation=True, padding=True)
input_ids = torch.tensor(train_encodings["input_ids"]).to(device)
attention_mask = torch.tensor(train_encodings["attention_mask"]).to(device)
labels = torch.tensor([1] * input_ids.shape[0]).to(device)
print(1111, input_ids.shape)  # [2, 8]
print(2222, attention_mask.shape)  # [2, 8]
print(3333, labels.shape)  # [2]
outputs = model(input_ids, attention_mask=attention_mask, labels=labels)
print(4444, outputs.logits)
