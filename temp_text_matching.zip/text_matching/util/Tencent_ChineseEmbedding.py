from time import time


def load_vocab_embedding(filepath):
    rfile = open(filepath, 'r', encoding='utf8')
    vocab = []
    k=0
    for line in rfile:
        k += 1
        if k == 1:
            continue
        new_line = line.strip().split(" ")
        if len(new_line) == 201:
            vocab.append(new_line[0])
        else:
            print(line.strip())
    print("单词总数：", k)
    return vocab


def save_vocab_embedding(file_read, file_write, vocab):
    rfile = open(file_read, 'r', encoding='utf8')
    wfile = open(file_write, 'w', encoding='utf8')

    k = 0
    for line in rfile:
        k += 1
        if k == 1:
            continue
        if k % 100000 == 0:
            print("==", k)
        new_line = line.strip().split(" ")
        if len(new_line) == 201:
            if new_line[0] in vocab:
                wfile.write(line)
        else:
            print(line.strip())
    print("单词总数：", k)


def load_vocab(file):
    vocab = []
    rfile = open(file, 'r', encoding='utf8')
    for line in rfile:
        Tline = line.strip().split("\t")
        if len(Tline) == 2:
            vocab.append(Tline[0])
    vocab = set(vocab)
    return vocab


def save_vocab(file, vocab):
    wfile = open(file, 'w', encoding='utf8')
    for word in vocab:
        wfile.write(word + "\n")
    wfile.close()


if __name__ == '__main__':
    # begin = time()
    # root_dir = "/home/data/Tencent_ChineseEmbedding/"
    # filepath = root_dir + "Tencent_AILab_ChineseEmbedding.txt"
    # vocab = load_vocab_embedding(filepath)
    # print(time()-begin)
    #
    # file_vocab = root_dir + "vocab.txt"
    # save_vocab(file_vocab, vocab)

    begin = time()
    vocab = load_vocab("/home/sun/deep_learning/text_matching/vocab.txt")
    print(time() - begin)
    file_read = "/home/data/Tencent_ChineseEmbedding/Tencent_AILab_ChineseEmbedding.txt"
    file_write = "/home/sun/deep_learning/text_matching/Tencent_ChineseEmbedding_small.txt"
    save_vocab_embedding(file_read, file_write, vocab)
    print(time()-begin)
