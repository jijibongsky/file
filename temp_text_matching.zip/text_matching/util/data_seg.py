import jieba
import re


def jieba_fenci(sentence):
    words = jieba.cut(sentence)
    result = ""
    for w in words:
        result += w + " "
    result = re.sub(" +", " ", result)
    return result[:-1]

def fenci(read_file,write_file):

    rfile = open(read_file, 'r', encoding='utf8')
    wfile = open(write_file, 'w', encoding='utf8')
    k=0
    for line in rfile:
        k += 1
        if k == 1:
            continue
        new_line = line.strip().split("\t")
        if len(new_line) != 3:
            print(line.strip())
        else:
            sentence_one = new_line[0]
            sentence_two = new_line[1]
            sentence_one = jieba_fenci(sentence_one)
            sentence_two = jieba_fenci(sentence_two)
            wfile.write(sentence_one + "\t" + sentence_two + "\t" + new_line[2] + "\n")

root_dir = "/home/sun/deep_learning/text_matching/data/lcqmc/"


read_file = root_dir + "train.tsv"
write_file = root_dir + "train.txt"
fenci(read_file, write_file)


