import numpy as np

a = np.array([[1., 2, 3], [4, 5, 6]], dtype="float32")
b = np.zeros([2, 3], dtype="float32")
d = np.zeros([0, 3], dtype="float32")

print(a)
print(b)
print(d)

c = np.vstack((a, d, b))
print("c====", c)
