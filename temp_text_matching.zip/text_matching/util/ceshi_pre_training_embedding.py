import sys
import os
import numpy as np

root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(root_dir)

from data_helps import load_pre_training_embedding,load_vocab


vocab = load_vocab("/home/sun/deep_learning/text_matching/vocab.txt")
pre_training_embedding = load_pre_training_embedding("/home/sun/deep_learning/text_matching/Tencent_ChineseEmbedding_small.txt")

initW = np.random.uniform(-0.25, 0.25, (len(vocab), 200))
for word in pre_training_embedding:
    if word in vocab:
        index = vocab[word]
        initW[index] = pre_training_embedding[word]
# sess.run(model.embedding_weight.assign(initW))

for i in range(len(vocab)):
    print(initW[i, :])
    input()

