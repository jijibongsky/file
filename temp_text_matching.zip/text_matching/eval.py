import time
import numpy as np
import tensorflow as tf
from data_helps import load_data
from data_helps import batch_iter
from util import choose_model


import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# Model Hyperparameters
tf.flags.DEFINE_string("model_name", "rk", "model")
tf.flags.DEFINE_string("model_save_path", "runs/token/rk_0.5_0.0001_0.0005/checkpoints", "model_save_path")
tf.flags.DEFINE_integer("embedding_dim", 128, "Dimensionality of character embedding (default: 64)")
tf.flags.DEFINE_string("filter_sizes", "2,3,4", "Comma-separated filter sizes (default: '2,3')")
tf.flags.DEFINE_integer("num_filters", 128, "Number of filters per filter size (default: 64)")
tf.flags.DEFINE_integer("num_hidden", 128, "Number of hidden layer units (default: 100)")
tf.flags.DEFINE_integer("output_dim", 16, "Number of output units (default: 100)")

tf.flags.DEFINE_float("mu", 0.01, "mu")
tf.flags.DEFINE_float("l2_reg_lambda", 0.0005, "L2 regularizaion lambda (default: 0.0)")

# Data Parameter
tf.flags.DEFINE_integer("max_len_left", 24, "max document length of left input")
tf.flags.DEFINE_integer("max_len_right", 24, "max document length of right input")
tf.flags.DEFINE_integer("batch_size", 64, "Batch Size (default: 64)")

tf.flags.DEFINE_integer("seed", 123, "Random seed (default: 123)")
tf.flags.DEFINE_integer("num_checkpoints", 5, "number of checkpoints saved")
# Misc Parameters
tf.flags.DEFINE_boolean("allow_soft_placement", True, "Allow device soft device placement")
tf.flags.DEFINE_boolean("log_device_placement", False, "Log placement of ops on devices")

FLAGS = tf.flags.FLAGS
FLAGS.flag_values_dict()


def main():
    tf.logging.set_verbosity(tf.logging.INFO)
    print("Loading data...")
    x_left, x_right, y, vocab, num_pos = load_data('data/lcqmc/test.txt', FLAGS.max_len_left, FLAGS.max_len_right)

    graph = tf.Graph()
    with graph.as_default():
        session_conf = tf.ConfigProto(
        gpu_options=tf.GPUOptions(allow_growth=True),
        # gpu_options=tf.GPUOptions(per_process_gpu_memory_fraction=0.5),
        allow_soft_placement=FLAGS.allow_soft_placement,
        log_device_placement=FLAGS.log_device_placement)
        sess = tf.Session(config=session_conf)
        with sess.as_default():
            model = choose_model(FLAGS.model_name, FLAGS, vocab)
            saver = tf.train.Saver(tf.global_variables(), max_to_keep=FLAGS.num_checkpoints)
            ckpt = tf.train.get_checkpoint_state(FLAGS.model_save_path)
            saver.restore(sess, ckpt.model_checkpoint_path)

            all_weights = {v.name: v for v in tf.trainable_variables()}
            total_size = 0
            for v_name in sorted(list(all_weights)):
                v = all_weights[v_name]
                tf.logging.info("%s\tshape    %s", v.name[:-2].ljust(80),
                                str(v.shape).ljust(20))
                v_size = np.prod(np.array(v.shape.as_list())).tolist()
                total_size += v_size
            tf.logging.info("Total trainable variables size: %d", total_size)

            num_test = 0
            num_correct = 0.0
            batches = batch_iter(list(zip(x_left, x_right, y)), FLAGS.batch_size*2, 1, shuffle=False)
            for idx, batch in enumerate(batches):
                x_left_batch, x_right_batch, y_batch = zip(*batch)
                feed_dict = {
                    model.input_left: x_left_batch,
                    model.input_right: x_right_batch,
                    model.input_y: y_batch,
                    model.dropout_keep_prob: 1.0
                }
                betch_accuracy, batch_socres = sess.run([model.accuracy, model.scores], feed_dict)
                # print("pres====", pres)
                # print("pres====", pres.shape)
                num_test += len(batch_socres)
                num_correct += len(batch_socres)*betch_accuracy
            acc = num_correct/num_test
            print("test accuracy:", acc)


if __name__ == '__main__':
    main()
