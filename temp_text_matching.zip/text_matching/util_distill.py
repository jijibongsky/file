from models.L2R_distill import L2R_DISTILL
from models.L2R_distill_1 import L2R_DISTILL_1


def choose_model(model_name, input_left, input_right, dropout_keep_prob, FLAGS, vocab, scope=None):
    model = None
    if model_name == 'l2r_d':
        model = L2R_DISTILL(
            input_left=input_left,
            input_right=input_right,
            dropout_keep_prob=dropout_keep_prob,
            max_len_left=FLAGS.max_len_left,
            max_len_right=FLAGS.max_len_right,
            vocab_size=len(vocab),
            embedding_size=FLAGS.embedding_dim,
            filter_sizes=list(map(int, FLAGS.filter_sizes.split(","))),
            num_filters=FLAGS.num_filters,
            num_hidden=FLAGS.num_hidden,
            l2_reg_lambda=FLAGS.l2_reg_lambda,
            scope=scope)
    elif model_name == 'l2r_d_1':
        model = L2R_DISTILL_1(
            input_left=input_left,
            input_right=input_right,
            dropout_keep_prob=dropout_keep_prob,
            max_len_left=FLAGS.max_len_left,
            max_len_right=FLAGS.max_len_right,
            vocab_size=len(vocab),
            embedding_size=FLAGS.embedding_dim,
            filter_sizes=list(map(int, FLAGS.filter_sizes.split(","))),
            num_filters=FLAGS.num_filters,
            num_hidden=FLAGS.num_hidden,
            l2_reg_lambda=FLAGS.l2_reg_lambda,
            scope=scope)
    return model

