import time
import datetime
import numpy as np
import tensorflow as tf
from data_helps import load_data_str_pair
from data_helps import batch_iter
from util_bert import choose_model
from load_sentence_embedding import load_sentence_embedding_dict

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# Model Hyperparameters
tf.flags.DEFINE_string("model_name", "bert_dsa_si", "model")
tf.flags.DEFINE_string("model_save_path", "", "model_save_path")
tf.flags.DEFINE_string("level", "bert", "level")
tf.flags.DEFINE_integer("embedding_dim", 128, "Dimensionality of character embedding (default: 64)")
tf.flags.DEFINE_string("filter_sizes", "2,3,4", "Comma-separated filter sizes (default: '2,3')")
tf.flags.DEFINE_integer("num_filters", 128, "Number of filters per filter size (default: 64)")
tf.flags.DEFINE_integer("num_hidden", 128, "Number of hidden layer units (default: 100)")
tf.flags.DEFINE_integer("output_dim", 16, "Number of output units (default: 100)")

tf.flags.DEFINE_float("dropout_keep_prob", 0.7, "Dropout keep probability (default: 0.5)")
tf.flags.DEFINE_float("learning_rate", 0.00002, "L2 learning_rate")
tf.flags.DEFINE_float("mu", 0.01, "mu")
tf.flags.DEFINE_float("l2_reg_lambda", 0.0005, "L2 regularizaion lambda (default: 0.0)")

tf.flags.DEFINE_string("learning_rate_decay", "none", "linear_warmup_rsqrt_decay")  # linear_warmup_rsqrt_decay   noam
tf.flags.DEFINE_string("learning_rate_values", "1e-3,5e-4,25e-5", "")
tf.flags.DEFINE_string("learning_rate_boundaries", "10000,20000", "")

# Data Parameter
tf.flags.DEFINE_integer("max_len_left", 24, "max document length of left input")
tf.flags.DEFINE_integer("max_len_right", 24, "max document length of right input")
# tf.flags.DEFINE_integer("most_words", 40000, "Most number of words in vocab (default: 300000)")

# Training parameters
tf.flags.DEFINE_integer("seed", 123, "Random seed (default: 123)")
tf.flags.DEFINE_string("train_dir", "./", "Training dir root")
tf.flags.DEFINE_integer("batch_size", 64, "Batch Size (default: 64)")
tf.flags.DEFINE_integer("num_epochs", 200, "Number of training epochs (default: 200)")
tf.flags.DEFINE_float("eval_split", 0.1, "Use how much data for evaluating (default: 0.1)")
tf.flags.DEFINE_integer("display_every", 100, " ")
tf.flags.DEFINE_integer("evaluate_every", 500, "Evaluate model on dev set after this many steps (default: 100)")
tf.flags.DEFINE_integer("checkpoint_every", 2000, "Save model after this many steps (default: 100)")
tf.flags.DEFINE_integer("num_checkpoints", 5, "number of checkpoints saved")
# Misc Parameters
tf.flags.DEFINE_boolean("allow_soft_placement", True, "Allow device soft device placement")
tf.flags.DEFINE_boolean("log_device_placement", False, "Log placement of ops on devices")

FLAGS = tf.flags.FLAGS
FLAGS.flag_values_dict()
# print("\nParameters:")
# for attr, value in sorted(FLAGS.__flags.items()):
#     print("{}={}".format(attr.upper(), value))
# print("")


def get_learning_rate_decay(learning_rate, global_step, params):
    if params.learning_rate_decay in ["linear_warmup_rsqrt_decay", "noam"]:
        step = tf.to_float(global_step)
        warmup_steps = tf.to_float(params.warmup_steps)
        multiplier = params.hidden_size ** -0.5
        decay = multiplier * tf.minimum((step + 1) * (warmup_steps ** -1.5),
                                        (step + 1) ** -0.5)
        return learning_rate * decay
    elif params.learning_rate_decay == "piecewise_constant":
        return tf.train.piecewise_constant(tf.to_int32(global_step),
                                           params.learning_rate_boundaries,
                                           params.learning_rate_values)
    elif params.learning_rate_decay == "none":
        return learning_rate
    else:
        raise ValueError("Unknown learning_rate_decay")


def load_sentence_dict(data_path, max_len=None):
    train_json = os.path.join(data_path, "train.json")
    dev_json = os.path.join(data_path, "dev.json")
    test_json = os.path.join(data_path, "test.json")
    train_embedding_dict = load_sentence_embedding_dict(train_json, max_len)
    dev_embedding_dict = load_sentence_embedding_dict(dev_json, max_len)
    test_embedding_dict = load_sentence_embedding_dict(test_json, max_len)
    return train_embedding_dict, dev_embedding_dict, test_embedding_dict


def main():
    tf.logging.set_verbosity(tf.logging.INFO)
    print("Loading data...")

    x_train, y_train = load_data_str_pair('data/lcqmc/train.tsv')
    x_dev, y_dev = load_data_str_pair('data/lcqmc/dev.tsv')
    x_test, y_test = load_data_str_pair('data/lcqmc/test.tsv')

    train_embedding_dict, dev_embedding_dict, test_embedding_dict = load_sentence_dict("/home/data/text_matching/bert/sentence_pair", 10)

    with tf.Graph().as_default():
        session_conf = tf.ConfigProto(
        gpu_options=tf.GPUOptions(allow_growth=True),
        # gpu_options=tf.GPUOptions(per_process_gpu_memory_fraction=0.45),
        allow_soft_placement=FLAGS.allow_soft_placement,
        log_device_placement=FLAGS.log_device_placement)
        sess = tf.Session(config=session_conf)
        name = FLAGS.model_name
        with sess.as_default():
            model = choose_model(name, FLAGS)
            if model is None:
                print("There is no exact model=====")
                exit(1)
            # Define Training procedure
            global_step = tf.Variable(0, name="global_step", trainable=False)
            learning_rate = get_learning_rate_decay(FLAGS.learning_rate, global_step, FLAGS)
            learning_rate = tf.convert_to_tensor(learning_rate, dtype=tf.float32)
            # tf.summary.scalar("learning_rate===", learning_rate)

            optimizer = tf.train.AdamOptimizer(FLAGS.learning_rate)
            # optimizer = tf.train.RMSPropOptimizer(learning_rate=learning_rate, decay=0.9)
            grads_and_vars = optimizer.compute_gradients(model.loss)
            train_op = optimizer.apply_gradients(grads_and_vars, global_step=global_step)

            saver = tf.train.Saver(tf.global_variables(), max_to_keep=FLAGS.num_checkpoints)

            # sess.run(tf.global_variables_initializer())
            if not FLAGS.model_save_path:
                sess.run(tf.global_variables_initializer())
                print("initializing a new model")
            else:
                ckpt = tf.train.get_checkpoint_state(FLAGS.model_save_path)
                if ckpt and ckpt.model_checkpoint_path:
                    saver.restore(sess, ckpt.model_checkpoint_path)
                    print("model loaded====")
                else:
                    print("no model found")
                    exit(1)

            all_weights = {v.name: v for v in tf.trainable_variables()}
            total_size = 0
            for v_name in sorted(list(all_weights)):
                v = all_weights[v_name]
                tf.logging.info("%s\tshape    %s", v.name[:-2].ljust(80),
                                str(v.shape).ljust(20))
                v_size = np.prod(np.array(v.shape.as_list())).tolist()
                total_size += v_size
            tf.logging.info("Total trainable variables size: %d", total_size)

            # Checkpoint directory. Tensorflow assumes this directory already exists so we need to create it
            timestamp = str(int(time.time()))
            out_dir = os.path.abspath(os.path.join(FLAGS.train_dir, "runs", FLAGS.level,
                            str(FLAGS.model_name) + "_" + str(FLAGS.dropout_keep_prob) + "_" + str(FLAGS.learning_rate) + "_" + str(FLAGS.l2_reg_lambda))) #timestamp
            if not os.path.exists(out_dir):
                os.makedirs(out_dir)
            print("Writing to {}\n".format(out_dir))
            checkpoint_prefix = os.path.join(out_dir, "checkpoints", "model")

            log_dir = os.path.join(out_dir, "log.txt")
            log_file = open(log_dir, "a+", encoding="utf8")
            log_file.write("dropout_keep_prob:{}  learning_rate:{}  l2_reg_lambda:{}\n".format(FLAGS.dropout_keep_prob,FLAGS.learning_rate,FLAGS.l2_reg_lambda))

            # Summaries for loss and accuracy
            loss_summary = tf.summary.scalar("loss", model.loss)
            acc_summary = tf.summary.scalar("accuracy", model.accuracy)

            # Train Summaries
            train_summary_op = tf.summary.merge([loss_summary, acc_summary])
            train_summary_dir = os.path.join(out_dir, "summaries", "train")
            train_summary_writer = tf.summary.FileWriter(train_summary_dir, sess.graph)

            # dev Summaries
            dev_summary_op = tf.summary.merge([loss_summary, acc_summary])
            dev_summary_dir = os.path.join(out_dir, "summaries", "dev")
            dev_summary_writer = tf.summary.FileWriter(dev_summary_dir,sess.graph)

            # test Summaries
            test_summary_op = tf.summary.merge([loss_summary, acc_summary])
            test_summary_dir = os.path.join(out_dir, "summaries", "test")
            test_summary_writer = tf.summary.FileWriter(test_summary_dir, sess.graph)

            def train_step(x_batch_embedding, x_len, y_batch):
                feed_dict = {
                model.emb: x_batch_embedding,
                model.length: x_len,
                model.input_y: y_batch,
                model.dropout_keep_prob: FLAGS.dropout_keep_prob
                }
                _, Tlearning_rate, step, summaries, loss, accuracy = sess.run(
                    [train_op, learning_rate, global_step, train_summary_op, model.loss, model.accuracy],
                    feed_dict)
                train_summary_writer.add_summary(summaries, step)

                if step % FLAGS.display_every == 0:
                    time_str = datetime.datetime.now().isoformat()
                    print("{}: step {}, loss {:.4f}, acc {:.4f}".format(time_str, step, loss, accuracy))
                    log_file.write("{}: step {}, loss {:.4f}, acc {:.4f}\n".format(time_str, step, loss, accuracy))

            def dev_step(x_batch, x_len, y_batch, type):
                feed_dict = {
                    model.emb: x_batch,
                    model.length: x_len,
                    model.input_y: y_batch,
                    model.dropout_keep_prob: 1.0
                }
                if type == "dev":
                    step, summaries_dev, loss, accuracy, pres = sess.run(
                            [global_step, dev_summary_op, model.loss, model.accuracy, model.scores],
                            feed_dict)
                    dev_summary_writer.add_summary(summaries_dev, step)
                elif type == "test":
                    step, summaries_test, loss, accuracy, pres = sess.run(
                            [global_step, test_summary_op, model.loss, model.accuracy, model.scores],
                            feed_dict)
                    test_summary_writer.add_summary(summaries_test, step)
                else:
                    loss = -1
                    accuracy = 0
                    pres = []
                return loss, accuracy, pres

            def dev_whole(embedding_dict, x, y, type):
                num_test = 0
                num_correct = 0.0
                batches = batch_iter(list(zip(x, y)), FLAGS.batch_size*2, 1, shuffle=False)

                losses = []
                for batch in batches:
                    x_batch, y_batch = zip(*batch)
                    x_batch_embedding, x_len, y_batch = get_sentence_embedding(embedding_dict, x_batch, y_batch)
                    loss, accurary, pres = dev_step(x_batch_embedding, x_len, y_batch, type)
                    num_test += len(pres)
                    num_correct += len(pres)*accurary
                    losses.append(loss)
                acc = num_correct/num_test
                return np.mean(np.array(losses)), acc

            def get_sentence_embedding(train_embedding_dict, x_batch, y_batch):
                x_batch = [train_embedding_dict[sen] for sen in x_batch]
                y_batch = [label for label in y_batch]
                x_len = np.array([sen.shape[0] for sen in x_batch], dtype="int32")
                max_len = max(x_len)
                x_batch_embedding = np.array([np.vstack((sen, np.zeros([max_len-len(sen), 768], dtype="float32"))) for sen in x_batch], dtype="float32")
                y_batch_embedding = np.array(y_batch, dtype="int32")
                return x_batch_embedding, x_len, y_batch_embedding

            # Generate batches
            batches = batch_iter(list(zip(x_train, y_train)), FLAGS.batch_size, FLAGS.num_epochs)
            best_dev_acc = 0
            best_test_acc = 0
            dev_accs = []
            test_accs = []
            for batch in batches:
                x_batch, y_batch = zip(*batch)
                x_batch_embedding, x_len, y_batch = get_sentence_embedding(train_embedding_dict, x_batch, y_batch)
                train_step(x_batch_embedding, x_len, y_batch)
                current_step = tf.train.global_step(sess, global_step)
                if current_step % FLAGS.evaluate_every == 0:
                    print("\nEvaluation========:")
                    loss_dev, dev_acc = dev_whole(dev_embedding_dict, x_dev, y_dev, type="dev")
                    loss_test, test_acc = dev_whole(test_embedding_dict, x_test, y_test, type="test")
                    dev_accs.append(dev_acc)
                    test_accs.append(test_acc)
                    time_str = datetime.datetime.now().isoformat()
                    print("{}: dev-test, step: {}, dev {:.4f}, test {:.4f}".format(time_str, current_step, dev_acc, test_acc))
                    print("dev accuracy:")
                    print([round(score, 4) for score in dev_accs[-10:]])
                    print("test accuracy:")
                    print([round(score, 4) for score in test_accs[-10:]])
                    log_file.write("\nEvaluation:\n")
                    log_file.write("{}: dev-test, step: {}, dev {:.4f}, test {:.4f}\n".format(time_str, current_step, dev_acc, test_acc))
                    log_file.write("dev accuracy:\n")
                    log_file.write(str([round(score, 4) for score in dev_accs[-10:]]) + "\n")
                    log_file.write("test accuracy:\n")
                    log_file.write(str([round(score, 4) for score in test_accs[-10:]]) + "\n")

                    if dev_acc > best_dev_acc:
                        best_dev_acc = dev_acc
                        path = saver.save(sess, checkpoint_prefix, global_step=current_step)
                        log_file.write("Saved model checkpoint to {}\n".format(path))
                    if test_acc > best_test_acc:
                        best_test_acc = test_acc
                        log_file.write("best_test_acc, step{},dev acc{},test acc{}\n\n".format(current_step, dev_acc, test_acc))
                # if current_step % FLAGS.checkpoint_every == 0:
                #     path = saver.save(sess, checkpoint_prefix, global_step=current_step)
                #     print("Saved model checkpoint to {}\n".format(path))

if __name__ == '__main__':
    main()
