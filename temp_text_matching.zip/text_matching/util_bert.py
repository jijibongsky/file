from models.bert.bert_dsa import BERT_DSA
from models.bert.bert_dsa_e import BERT_DSA_E
from models.bert.bert_dsa_si import BERT_DSA_SI


def choose_model(name, FLAGS):
    model = None
    if name == "bert_dsa":
        model = BERT_DSA(
            d_1=150, d_l=75,
            k_1=3, k_2=5,
            num_layers=4, d_c=300,
            num_atttentions=8, d_o=300,
            num_iter=3, num_hidden=128,
            mu=FLAGS.mu,
            l2_reg_lambda=FLAGS.l2_reg_lambda)
    if name == "bert_dsa_e":
        model = BERT_DSA_E(
            d_1=150, d_l=75,
            k_1=3, k_2=5,
            num_layers=4, d_c=300,
            num_atttentions=8, d_o=300,
            num_iter=3, num_hidden=128,
            mu=FLAGS.mu,
            l2_reg_lambda=FLAGS.l2_reg_lambda)
    elif name == "bert_dsa_si":
        model = BERT_DSA_SI(
            d_1=150,
            d_l=75,
            k_1=3,
            k_2=5,
            num_layers=4,
            d_c=300,
            num_atttentions=8,
            d_o=300,
            num_iter=3,
            num_hidden=128,
            mu=FLAGS.mu,
            l2_reg_lambda=FLAGS.l2_reg_lambda)
    return model