import itertools
import numpy as np
import math
from collections import Counter


def pad_sentences(sentences, sequence_length, padding_word="<PAD/>"):
    padded_sentences = []
    for i in range(len(sentences)):
        sentence = sentences[i]
        if len(sentence) < sequence_length:
            num_padding = sequence_length - len(sentence)
            new_sentence = sentence + [padding_word] * num_padding
        else:
            new_sentence = sentence[:sequence_length]
        padded_sentences.append(new_sentence)
    return padded_sentences


def save_vocab(filepath, output_dir):
    # Build vocabulary
    rfile = open(filepath, 'r', encoding='utf8')
    wfile = open(output_dir, 'w', encoding='utf8')
    vocab = {}
    for line in rfile:
        new_line = line.strip().split("\t")
        for word in new_line[0].split(" "):
            if word not in vocab:
                vocab[word] = 1
            else:
                vocab[word] += 1
        for word in new_line[1].split(" "):
            if word not in vocab:
                vocab[word] = 1
            else:
                vocab[word] += 1

    wfile.write("<PAD/>" + "\t" + "0" + "\n")
    wfile.write("<UNK/>" + "\t" + "1" + "\n")
    k = 1
    for word in vocab:
        if vocab[word] > 0:
            k += 1
            # print(word,"   ",vocab[word])
            wfile.write(word + "\t" + str(k) + "\n")
        else:
            print(word, "   ", vocab[word])


def load_vocab(filepath):
    # Build vocabulary
    rfile = open(filepath, 'r', encoding='utf8')
    vocab = {}
    k = -1
    for line in rfile:
        new_line = line.strip().split("\t")
        # print("new_line===", new_line)load_data
        if len(new_line) == 2:
            k += 1
            vocab[new_line[0]] = k
        else:
            print(line.strip())
    return vocab


def build_vocab(sentences):
    # Build vocabulary
    # print("sentences========")
    # k=0
    # for sentence in sentences:
    #     k += 1
    #     if k < 10:
    #         print(sentence)
    # print(k)
    word_counts = Counter(itertools.chain(*sentences))

    # for word in word_counts:
    #     print(word)
    # for word in word_counts.most_common(50000):
    #     print(word)

    # Mapping from index to word
    vocabulary_inv = [x[0] for x in word_counts.most_common(50000)]  #     vocabulary_inv = [x[0] for x in word_counts.most_common()]
    vocabulary_inv = list(sorted(vocabulary_inv))
    vocabulary_inv.append('<UNK/>')
    # Mapping from word to index
    vocabulary = {x: i for i, x in enumerate(vocabulary_inv)}

    # print("1111111111", vocabulary)
    # print("22222222222", vocabulary_inv)
    return vocabulary


def build_input_data(data_left, data_right, label, vocab):
    vocabset = set(vocab.keys())
    out_left = np.array([[vocab[word] if word in vocabset else vocab['<UNK/>'] for word in sentence] for sentence in data_left])
    out_right = np.array([[vocab[word] if word in vocabset else vocab['<UNK/>'] for word in sentence] for sentence in data_right])
    out_y = np.array([[0, 1] if x == 1 else [1, 0] for x in label])
    return [out_left, out_right, out_y]


def load_data(filepath, max_len_left, max_len_right):
    vocab = load_vocab("/home/sun/deep_learning/text_matching/vocab.txt")

    data = list(set(open(filepath, "r", encoding='utf8').readlines()))
    data = [d.split('\t') for d in data]
    data = filter(lambda x: len(x) == 3, data)
    data_left = []
    data_right = []
    data_label = []
    for line in data:
        data_left.append(line[0].strip().split(' '))
        data_right.append(line[1].strip().split(' '))
        data_label.append(int(line[2]))

    num_pos = sum(data_label)
    data_left = pad_sentences(data_left, max_len_left)
    data_right = pad_sentences(data_right, max_len_right)

    data_left, data_right, data_label = build_input_data(data_left, data_right, data_label, vocab)

    return data_left, data_right, data_label, vocab, num_pos


def load_data_str(filepath):
    data = open(filepath, "r", encoding='utf8')
    data_left = []
    data_right = []
    data_label = []
    k = 0
    for line in data:
        k += 1
        if k == 1:
            continue
        line = line.strip()
        line = line.split("\t")
        if len(line) != 3:
            print("!!!!")
        data_left.append(line[0])
        data_right.append(line[1])
        data_label.append(int(line[2]))
    data_label = np.array([[0, 1] if x == 1 else [1, 0] for x in data_label])
    return data_left, data_right, data_label


def load_data_str_pair(filepath):
    data = open(filepath, "r", encoding='utf8')
    data_pair = []
    data_label = []
    k = 0
    for line in data:
        k += 1
        if k == 1:
            continue
        line = line.strip()
        line = line.split("\t")
        if len(line) != 3:
            print("!!!!")
        data_pair.append(line[0] + "\t" + line[1])
        data_label.append(int(line[2]))
    data_label = np.array([[0, 1] if x == 1 else [1, 0] for x in data_label])
    return data_pair, data_label


def batch_iter(all_data, batch_size, num_epochs, shuffle=True):
    data = np.array(all_data)
    data_size = len(data)
    num_batches_per_epoch = math.ceil(data_size/batch_size)
    for epoch in range(num_epochs):
        # Shuffle the data at each epoch
        if shuffle:
            shuffle_indices = np.random.permutation(np.arange(data_size))
            shuffled_data = data[shuffle_indices]
        else:
            shuffled_data = data
        for batch_num in range(num_batches_per_epoch):
            start_index = batch_num * batch_size
            end_index = min((batch_num + 1) * batch_size, data_size)
            yield shuffled_data[start_index:end_index]


def load_pre_training_embedding(file_read):
    rfile = open(file_read, 'r', encoding='utf8')
    pre_training_embedding = {}

    for line in rfile:
        new_line = line.strip().split(" ")
        if len(new_line) == 201:
            pre_training_embedding[new_line[0]] = np.array(new_line[1:])
        else:
            print(line.strip())
    return pre_training_embedding

if __name__ == '__main__':
    filepath = "/home/sun/deep_learning/text_matching/data/lcqmc/train.txt"
    output_dir = "/home/sun/deep_learning/text_matching/vocab.txt"
    # save_vocab(filepath, output_dir)
    # load_vocab(output_dir)


    # max_len_left = 24
    # max_len_right = 24
    # data_left, data_right, data_label, vocab, num_pos = load_data(filepath, max_len_left, max_len_right)
    # for word in vocab:
    #     print(word," ",vocab[word])


    # 加载与训练词典
    # pre_training_embedding = load_pre_training_embedding("/home/sun/deep_learning/text_matching/Tencent_ChineseEmbedding_small.txt")
    # print("=====", len(pre_training_embedding.keys()), pre_training_embedding.keys())
    # for key in pre_training_embedding:
    #     print("key====", pre_training_embedding[key])
    #     input()

