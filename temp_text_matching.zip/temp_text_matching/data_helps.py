import itertools
import numpy as np
import math
import os
from collections import Counter
import json


def pad_sentences(sentences, sequence_length, padding_word="[PAD]"):
    padded_sentences = []
    for i in range(len(sentences)):
        sentence = sentences[i]
        if len(sentence) < sequence_length:
            num_padding = sequence_length - len(sentence)
            new_sentence = sentence + [padding_word] * num_padding
        else:
            new_sentence = sentence[:sequence_length]
        padded_sentences.append(new_sentence)
    return padded_sentences


def save_vocab(filepath, output_dir):
    # Build vocabulary
    rfile = open(filepath, 'r', encoding='utf8')
    wfile = open(output_dir, 'w', encoding='utf8')
    vocab = {}
    for line in rfile:
        new_line = line.strip().split("\t")
        for word in new_line[0].split(" "):
            if word not in vocab:
                vocab[word] = 1
            else:
                vocab[word] += 1
        for word in new_line[1].split(" "):
            if word not in vocab:
                vocab[word] = 1
            else:
                vocab[word] += 1

    wfile.write("[PAD]" + "\t" + "0" + "\n")
    wfile.write("[UNK]" + "\t" + "1" + "\n")
    k = 1
    for word in vocab:
        if vocab[word] > 0 and len(word) > 0:
            k += 1
            # print(word,"   ",vocab[word])
            wfile.write(word + "\t" + str(k) + "\n")
        else:
            print(word, "====", vocab[word])
    wfile.close()


def load_vocab(filepath):
    # Build vocabulary
    rfile = open(filepath, 'r', encoding='utf8')
    vocab = {}
    k = -1
    for line in rfile:
        new_line = line.strip().split("\t")
        # print("new_line===", new_line)load_data
        if len(new_line) == 2:
            k += 1
            vocab[new_line[0]] = k
        else:
            print(line.strip())
    return vocab


def load_vocab_bert(filepath):
    # Build vocabulary
    rfile = open(filepath, 'r', encoding='utf8')
    vocab = {}
    k = -1
    for line in rfile:
        k += 1
        new_line = line.strip()
        vocab[new_line] = k
    return vocab


def build_vocab(sentences):
    word_counts = Counter(itertools.chain(*sentences))
    # for word in word_counts:
    #     print(word)
    # for word in word_counts.most_common(50000):
    #     print(word)
    vocabulary_inv = [x[0] for x in word_counts.most_common(50000)]
    vocabulary_inv = list(sorted(vocabulary_inv))
    vocabulary_inv.append('<UNK/>')
    vocabulary = {x: i for i, x in enumerate(vocabulary_inv)}
    return vocabulary


def build_input_data(data_left, data_right, label, vocab):
    vocabset = set(vocab.keys())
    out_left = np.array([[vocab[word] if word in vocabset else vocab['[UNK]'] for word in sentence] for sentence in data_left])
    out_right = np.array([[vocab[word] if word in vocabset else vocab['[UNK]'] for word in sentence] for sentence in data_right])
    out_y = np.array([[0, 1] if x == 1 else [1, 0] for x in label])
    return [out_left, out_right, out_y]


def load_data(filepath, max_len_left, max_len_right, bert=False):
    if bert:
        vocab = load_vocab_bert("/home/sun/deep_learning/text_matching/vocab_bert.txt")
    else:
        vocab = load_vocab("/home/sun/deep_learning/text_matching/vocab.txt")

    data = open(filepath, "r", encoding='utf8')
    data_left = []
    data_right = []
    data_label = []
    for line in data:
        line = line.strip().split("\t")
        data_left.append(line[0].split(' '))
        data_right.append(line[1].split(' '))
        data_label.append(int(line[2]))

    data_left = pad_sentences(data_left, max_len_left)
    data_right = pad_sentences(data_right, max_len_right)
    data_left, data_right, data_label = build_input_data(data_left, data_right, data_label, vocab)
    return data_left, data_right, data_label, vocab


def load_data_str(filepath):
    data = open(filepath, "r", encoding='utf8')
    data_left = []
    data_right = []
    data_label = []
    k = 0
    for line in data:
        k += 1
        if k == 1:
            continue
        line = line.strip()
        line = line.split("\t")
        if len(line) != 3:
            print("!!!!")
        data_left.append(line[0])
        data_right.append(line[1])
        data_label.append(int(line[2]))
    data_left = np.array(data_left)
    data_right = np.array(data_right)
    data_label = np.array([[0, 1] if x == 1 else [1, 0] for x in data_label])
    return data_left, data_right, data_label


def load_data_str_e(filepath, seg_path):
    def check_match_str(left_data, right_data):
        left_data = left_data.split()[1:-1]
        right_data = right_data.split()[1:-1]
        match_left = [0]
        match_rigth = [0]
        for w in left_data:
            if w in right_data:
                match_left.append(1)
            else:
                match_left.append(0)
        for w in right_data:
            if w in left_data:
                match_rigth.append(1)
            else:
                match_rigth.append(0)
        match_left.append(0)
        match_rigth.append(0)
        return match_left, match_rigth

    def load_bert_seg_dict(input_file):
        seg_dict = {}
        rfile = open(input_file, "r", encoding="utf8")
        for line in rfile:
            line = line.strip()
            line = line.split("\t")
            seg_dict[line[0]] = line[1]
        return seg_dict

    seg_dict = load_bert_seg_dict(seg_path)
    data = open(filepath, "r", encoding='utf8')
    data_left = []
    data_right = []
    data_label = []
    k = 0
    for line in data:
        k += 1
        if k == 1:
            continue
        line = line.strip()
        line = line.split("\t")
        if len(line) != 3:
            print("!!!!")
        data_left.append(line[0])
        data_right.append(line[1])
        data_label.append(int(line[2]))
    data_label = np.array([[0, 1] if x == 1 else [1, 0] for x in data_label])

    exact_match_left = []
    exact_match_right = []
    for i in range(len(data_left)):
        match_left, match_right = check_match_str(seg_dict[data_left[i]], seg_dict[data_right[i]])
        exact_match_left.append(match_left)
        exact_match_right.append(match_right)
    data_left = np.array(data_left)
    data_right = np.array(data_right)
    exact_match_left = np.array(exact_match_left)
    exact_match_right = np.array(exact_match_right)
    return data_left, exact_match_left, data_right, exact_match_right, data_label


def load_data_str_pair(filepath):
    data = open(filepath, "r", encoding='utf8')
    data_pair = []
    data_label = []
    k = 0
    for line in data:
        k += 1
        if k == 1:
            continue
        line = line.strip()
        line = line.split("\t")
        if len(line) != 3:
            print("!!!!")
        data_pair.append(line[0] + "\t" + line[1])
        data_label.append(int(line[2]))
    data_label = np.array([[0, 1] if x == 1 else [1, 0] for x in data_label])
    return data_pair, data_label


def load_data_str_pair_e(filepath, seg_path):
    def check_match_str_pair(input_data):
        input_data = input_data.strip().split("[SEP]")
        left_data = input_data[0].split()[1:]
        right_data = input_data[1].split()
        match_left = [0]
        match_rigth = [0]
        for w in left_data:
            if w in right_data:
                match_left.append(1)
            else:
                match_left.append(0)
        for w in right_data:
            if w in left_data:
                match_rigth.append(1)
            else:
                match_rigth.append(0)
        match_rigth.append(0)
        # print("left_data====", left_data)
        # print("right_data====", right_data)
        # print("match_left===", match_left)
        # print("match_rigth===", match_rigth)
        # print("match_left + match_rigth===", match_left + match_rigth)
        # input("---")
        return match_left + match_rigth

    def load_bert_seg_dict(input_file):
        seg_dict = {}
        rfile = open(input_file, "r", encoding="utf8")
        for line in rfile:
            line = line.strip()
            line = line.split("\t\t")
            seg_dict[line[0]] = line[1]
        return seg_dict

    seg_dict = load_bert_seg_dict(seg_path)
    data = open(filepath, "r", encoding='utf8')
    data_pair = []
    data_label = []
    k = 0
    for line in data:
        k += 1
        if k == 1:
            continue
        line = line.strip()
        line = line.split("\t")
        if len(line) != 3:
            print("!!!!")
        data_pair.append(line[0] + "\t" + line[1])
        data_label.append(int(line[2]))
    data_label = np.array([[0, 1] if x == 1 else [1, 0] for x in data_label])

    exact_match = []

    for i in range(len(data_pair)):
        match = check_match_str_pair(seg_dict[data_pair[i]])
        exact_match.append(match)
    data_pair = np.array(data_pair)
    exact_match = np.array(exact_match)
    return data_pair, exact_match, data_label


def batch_iter(all_data, batch_size, num_epochs, shuffle=True):
    data = np.array(all_data)
    data_size = len(data)
    num_batches_per_epoch = math.ceil(data_size/batch_size)
    for epoch in range(num_epochs):
        # Shuffle the data at each epoch
        if shuffle:
            shuffle_indices = np.random.permutation(np.arange(data_size))
            shuffled_data = data[shuffle_indices]
        else:
            shuffled_data = data
        for batch_num in range(num_batches_per_epoch):
            start_index = batch_num * batch_size
            end_index = min((batch_num + 1) * batch_size, data_size)
            yield shuffled_data[start_index:end_index]


def load_pre_training_embedding_bert(file_read):
    embedding_dict={}
    rfile = open(file_read, "r", encoding="utf8")
    for line in rfile:
        new_dict = json.loads(line.strip())
        embedding_dict[new_dict["word"]] = np.array(new_dict["embedding"])
    return embedding_dict


def load_pre_training_embedding(file_read):
    rfile = open(file_read, 'r', encoding='utf8')
    pre_training_embedding = {}
    for line in rfile:
        new_line = line.strip().split(" ")
        if len(new_line) == 201:
            pre_training_embedding[new_line[0]] = np.array(new_line[1:])
        else:
            print(line.strip())
    return pre_training_embedding


def load_teacher_scores(data_dir, T):
    def my_softmax(x, T):
        z_exp = [math.exp(i/T) for i in x]
        sum_z_exp = sum(z_exp)
        softmax = [i/sum_z_exp for i in z_exp]
        return softmax

    teachers_scores = []
    for child_file in os.listdir(data_dir):
        if child_file[-3:] != "txt":
            continue
        file = os.path.join(data_dir, child_file)
        rfile = open(file, "r", encoding="utf8")
        teachers_score=[]
        for line in rfile:
            a = [float(i) for i in line.strip().split("\t")]
            teachers_score.append(my_softmax(a, T))
        teachers_scores.append(teachers_score)
    L = len(teachers_scores)
    new_scores = []
    for i in range(len(teachers_scores[0])):
        new_score = [[], []]
        for j in range(len(teachers_scores)):
            new_score[0].append(teachers_scores[j][i][0])
            new_score[1].append(teachers_scores[j][i][1])
        new_score = [round(sum(i)/L, 6) for i in new_score]
        new_scores.append(new_score)
    return np.array(new_scores)


if __name__ == '__main__':
    filepath = "/home/sun/deep_learning/text_matching/data/lcqmc/train.txt"
    output_dir = "/home/sun/deep_learning/text_matching/vocab.txt"
    # save_vocab(filepath, output_dir)
    # load_vocab(output_dir)

    # max_len_left = 24
    # max_len_right = 24
    # data_left, data_right, data_label, vocab, num_pos = load_data(filepath, max_len_left, max_len_right)
    # for word in vocab:
    #     print(word," ",vocab[word])

    # 加载与训练词典
    # pre_training_embedding = load_pre_training_embedding("/home/sun/deep_learning/text_matching/Tencent_ChineseEmbedding_small.txt")
    # print("=====", len(pre_training_embedding.keys()), pre_training_embedding.keys())
    # for key in pre_training_embedding:
    #     print("key====", pre_training_embedding[key])
    #     input()


    load_data_str_pair_e("/home/sun/deep_learning/text_matching/data/lcqmc/dev.tsv",
                         "/home/sun/deep_learning/text_matching/data/lcqmc/dev_bert_seg_pair.tsv")
