import time
import datetime
import numpy as np
import tensorflow as tf
from data_helps import load_data
from data_helps import batch_iter
from util_distill import choose_model


import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# Model Hyperparameters
# l2r  rk   mvlstm   matchpyramid   self_attention  dsa  esim  gp_dsa
tf.flags.DEFINE_string("model_name", "l2r_d", "model")
# tf.flags.DEFINE_string("model_save_path_teacher", "runs/token/l2r_d_0.5_0.001_0.0005/checkpoints_teacher", "model_save_path")  # runs/token/l2r_d_0.5_0.001_0.0005/checkpoints_teacher
# tf.flags.DEFINE_string("model_save_path_student", "runs/token/l2r_d_0.5_0.001_0.0005/checkpoints_student", "model_save_path")  # runs/token/l2r_d_0.5_0.001_0.0005/checkpoints_student
tf.flags.DEFINE_string("model_save_path_teacher", "", "model_save_path")
tf.flags.DEFINE_string("model_save_path_student", "", "model_save_path")
tf.flags.DEFINE_string("level", "token", "level")
tf.flags.DEFINE_integer("embedding_dim", 128, "Dimensionality of character embedding (default: 64)")
tf.flags.DEFINE_string("filter_sizes", "2,3,4", "Comma-separated filter sizes (default: '2,3')")
tf.flags.DEFINE_integer("num_filters", 128, "Number of filters per filter size (default: 64)")
tf.flags.DEFINE_integer("num_hidden", 128, "Number of hidden layer units (default: 100)")
tf.flags.DEFINE_integer("output_dim", 16, "Number of output units (default: 100)")
tf.flags.DEFINE_integer("num_k", 4, "Number of k (default: 5)")

tf.flags.DEFINE_float("dropout_keep_prob", 0.5, "Dropout keep probability (default: 0.5)")
tf.flags.DEFINE_float("learning_rate", 0.001, "L2 learning_rate")
tf.flags.DEFINE_float("mu", 0.01, "mu")
tf.flags.DEFINE_float("l2_reg_lambda", 0.0005, "L2 regularizaion lambda (default: 0.0)")

tf.flags.DEFINE_string("learning_rate_decay", "none", "linear_warmup_rsqrt_decay")  # linear_warmup_rsqrt_decay  piecewise_constant  none
tf.flags.DEFINE_string("learning_rate_values", "1e-3,8e-4,6e-4", "")
tf.flags.DEFINE_string("learning_rate_boundaries", "2000,30000", "")

# Data Parameter
tf.flags.DEFINE_integer("max_len_left", 24, "max document length of left input")
tf.flags.DEFINE_integer("max_len_right", 24, "max document length of right input")

# Training parameters
tf.flags.DEFINE_integer("seed", 123, "Random seed (default: 123)")
tf.flags.DEFINE_string("train_dir", "./", "Training dir root")
tf.flags.DEFINE_integer("batch_size", 64, "Batch Size (default: 64)")
tf.flags.DEFINE_integer("num_epochs", 100, "Number of training epochs (default: 200)")
tf.flags.DEFINE_float("eval_split", 0.1, "Use how much data for evaluating (default: 0.1)")
tf.flags.DEFINE_integer("display_every", 500, " ")
tf.flags.DEFINE_integer("evaluate_every", 2000, "Evaluate model on dev set after this many steps (default: 100)")
tf.flags.DEFINE_integer("checkpoint_every", 2000, "Save model after this many steps (default: 100)")
tf.flags.DEFINE_integer("num_checkpoints", 5, "number of checkpoints saved")

FLAGS = tf.flags.FLAGS
FLAGS.flag_values_dict()


def get_learning_rate_decay(learning_rate, global_step, params, k=1):
    if params.learning_rate_decay in ["linear_warmup_rsqrt_decay", "noam"]:
        step = tf.to_float(global_step)
        warmup_steps = tf.to_float(params.warmup_steps)
        multiplier = params.hidden_size ** -0.5
        decay = multiplier * tf.minimum((step + 1) * (warmup_steps ** -1.5),
                                        (step + 1) ** -0.5)
        return learning_rate * decay
    elif params.learning_rate_decay == "piecewise_constant":
        learning_rate_boundaries = [int(i) for i in params.learning_rate_boundaries.split(",")]
        learning_rate_values = [k * float(i) for i in params.learning_rate_values.split(",")]
        return tf.train.piecewise_constant(tf.to_int32(global_step),
                                           learning_rate_boundaries,
                                           learning_rate_values)
    elif params.learning_rate_decay == "none":
        return learning_rate
    else:
        raise ValueError("Unknown learning_rate_decay")


def loss(prediction, output, l2_loss=0, l2_reg_lambda=0.0005, temperature=1):
    losses = tf.nn.softmax_cross_entropy_with_logits(logits=prediction, labels=output)
    cross_entropy = tf.reduce_mean(losses) + l2_reg_lambda * l2_loss
    predictions = tf.argmax(prediction, 1, name="predictions")
    correct_predictions = tf.equal(predictions, tf.argmax(output, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_predictions, tf.float32), name="accuracy")
    return cross_entropy, accuracy


def main():
    tf.logging.set_verbosity(tf.logging.INFO)
    print("Loading data...")
    x_left_train, x_right_train, y_train, vocab, num_pos = load_data(os.path.join(FLAGS.train_dir, 'data/lcqmc/train.txt'), FLAGS.max_len_left, FLAGS.max_len_right)
    x_left_dev, x_right_dev, y_dev, vocab, num_pos = load_data(os.path.join(FLAGS.train_dir, 'data/lcqmc/dev.txt'), FLAGS.max_len_left, FLAGS.max_len_right)
    x_left_test, x_right_test, y_test, vocab, num_pos = load_data(os.path.join(FLAGS.train_dir, 'data/lcqmc/test.txt'), FLAGS.max_len_left, FLAGS.max_len_right)
    # print("x_left_train=======", x_left_train)
    # print("x_right_train=======", x_right_train)
    # print("y_train=======", y_train)
    # print("vocab=======", vocab)

    with tf.Graph().as_default():
        name = FLAGS.model_name
        temperature = 4

        # Placeholders for input, output and dropout
        input_left = tf.placeholder(tf.int32, [None, FLAGS.max_len_left], name="input_left")
        input_right = tf.placeholder(tf.int32, [None, FLAGS.max_len_right], name="input_right")
        input_y = tf.placeholder(tf.float32, [None, 2], name="input_y")
        dropout_keep_prob = tf.placeholder(tf.float32, name="dropout_keep_prob")

        model_teacher = choose_model(name, input_left, input_right, dropout_keep_prob, FLAGS, vocab, scope="teacher")
        model_student = choose_model(name, input_left, input_right, dropout_keep_prob, FLAGS, vocab, scope="student")
        if model_teacher is None:# or model_student is None:
            print("There is no exact model=====")
            exit(1)

        y_conv_teacher = model_teacher.scores
        y_conv_teacher_soft = tf.nn.softmax(y_conv_teacher / temperature)

        y_conv_student = model_student.scores
        y_conv_student_soft = y_conv_student / temperature

        cross_entropy_teacher, accuracy_teacher = loss(y_conv_teacher, input_y, model_teacher.l2_loss, l2_reg_lambda=0.0005, temperature=1)
        student_loss1, accuracy_student = loss(y_conv_student, input_y, model_student.l2_loss, l2_reg_lambda=0.0005, temperature=1)

        student_loss2 = tf.nn.softmax_cross_entropy_with_logits(logits=y_conv_student_soft, labels=y_conv_teacher_soft)
        student_loss2 = tf.reduce_mean(student_loss2)
        cross_entropy_student = 0.5 * student_loss1 + 0.5 * student_loss2
        # cross_entropy_student = student_loss1

        print("cross_entropy_student====", cross_entropy_student)

        model_vars = tf.trainable_variables()
        var_teacher = [var for var in model_vars if 'teacher' in var.name]
        var_student = [var for var in model_vars if 'student' in var.name]

        global_step_teacher = tf.Variable(0, name="global_step_teacher", trainable=False)
        learning_rate_teacher = get_learning_rate_decay(FLAGS.learning_rate, global_step_teacher, FLAGS)
        learning_rate_teacher = tf.convert_to_tensor(learning_rate_teacher, dtype=tf.float32)
        trainer_teacher = tf.train.AdamOptimizer(learning_rate_teacher)  # FLAGS.learning_rate
        grad_teacher = trainer_teacher.compute_gradients(cross_entropy_teacher, var_teacher)
        train_step_teacher = trainer_teacher.apply_gradients(grad_teacher, global_step=global_step_teacher)

        global_step_student = tf.Variable(0, name="global_step_student", trainable=False)
        learning_rate_student = get_learning_rate_decay(1 * FLAGS.learning_rate, global_step_student, FLAGS, 1)
        learning_rate_student = tf.convert_to_tensor(learning_rate_student, dtype=tf.float32)
        trainer_student = tf.train.AdamOptimizer(learning_rate_student)
        grad_student = trainer_student.compute_gradients(cross_entropy_student, var_student)
        train_step_student = trainer_student.apply_gradients(grad_student, global_step_student)

        session_conf = tf.ConfigProto(
        gpu_options=tf.GPUOptions(allow_growth=True),
        # gpu_options=tf.GPUOptions(per_process_gpu_memory_fraction=0.3),
        allow_soft_placement=True,
        log_device_placement=False)
        sess = tf.InteractiveSession(config=session_conf)
        sess.run(tf.global_variables_initializer())
        saver_teacher = tf.train.Saver(var_teacher + [global_step_teacher], max_to_keep=3)
        saver_student = tf.train.Saver(var_student + [global_step_student], max_to_keep=10)
        # saver_teacher = tf.train.Saver(tf.global_variables(), max_to_keep=3)
        # saver_student = tf.train.Saver(tf.global_variables(), max_to_keep=10)
        out_dir = os.path.abspath(os.path.join(FLAGS.train_dir, "runs", FLAGS.level,
                                               str(FLAGS.model_name) + "_" + str(FLAGS.dropout_keep_prob) + "_" + str(
                                                   FLAGS.learning_rate) + "_" + str(FLAGS.l2_reg_lambda)))
        if not os.path.exists(out_dir):
            os.makedirs(out_dir)
        print("Writing to {}\n".format(out_dir))

        checkpoint_prefix_teacher = os.path.join(out_dir, "checkpoints_teacher", "model")
        checkpoint_prefix_student = os.path.join(out_dir, "checkpoints_student", "model")

        log_dir_teacher = os.path.join(out_dir, "log_teacher.txt")
        log_file_teacher = open(log_dir_teacher, "a+", encoding="utf8")
        log_file_teacher.write("dropout_keep_prob:{},learning_rate:{},l2_reg_lambda:{}\n".format(FLAGS.dropout_keep_prob,
                                                                                           FLAGS.learning_rate,FLAGS.l2_reg_lambda))
        log_dir_student = os.path.join(out_dir, "log_student.txt")
        log_file_student = open(log_dir_student, "a+", encoding="utf8")
        log_file_student.write("dropout_keep_prob:{},learning_rate:{},l2_reg_lambda:{}\n".format(FLAGS.dropout_keep_prob,
                                                                                           FLAGS.learning_rate,FLAGS.l2_reg_lambda))

        if not FLAGS.model_save_path_teacher:
            sess.run(tf.global_variables_initializer())
            print("initializing a new model")
        if FLAGS.model_save_path_teacher:
            ckpt = tf.train.get_checkpoint_state(FLAGS.model_save_path_teacher)
            if ckpt and ckpt.model_checkpoint_path:
                saver_teacher.restore(sess, ckpt.model_checkpoint_path)
                print("teacher_model loaded====")
            else:
                print("no model found")
                exit(1)
        if FLAGS.model_save_path_student:
            ckpt = tf.train.get_checkpoint_state(FLAGS.model_save_path_student)
            if ckpt and ckpt.model_checkpoint_path:
                saver_student.restore(sess, ckpt.model_checkpoint_path)
                print("student_model loaded====")
            else:
                print("no model found")
                exit(1)

        all_weights = {v.name: v for v in tf.trainable_variables()}
        total_size = 0
        for v_name in sorted(list(all_weights)):
            v = all_weights[v_name]
            tf.logging.info("%s\tshape    %s", v.name[:-2].ljust(80),
                            str(v.shape).ljust(20))
            v_size = np.prod(np.array(v.shape.as_list())).tolist()
            total_size += v_size
        tf.logging.info("Total trainable variables size: %d", total_size)

        def write2log(type, content):
            if type == "teacher":
                log_file_teacher.write(content)
            elif type == "student":
                log_file_student.write(content)

        def dev(x_left, x_right, y, accuracy_teacher):
            batches = batch_iter(list(zip(x_left, x_right, y)), FLAGS.batch_size*2, 1, shuffle=False)
            total_len = 0
            score = 0
            for batch in batches:
                x1_batch, x2_batch, y_batch = zip(*batch)
                feed_dict = {
                input_left: x1_batch,
                input_right: x2_batch,
                dropout_keep_prob: 1,
                input_y:y_batch
                }
                accuracy = sess.run(accuracy_teacher, feed_dict=feed_dict)
                total_len += len(x1_batch)
                score += len(x1_batch)*accuracy
            return score/total_len


        def train(type, train_step_op, saver_op, global_step, learning_rate, checkpoint_prefix, cross_entropy, accuracy, x_left_train, x_right_train, y_train, FLAGS, step=30000):
            batches = batch_iter(list(zip(x_left_train, x_right_train, y_train)), FLAGS.batch_size, FLAGS.num_epochs)
            best_acc = 0
            best_test_acc = 0
            for batch in batches:
                x1_batch, x2_batch, y_batch = zip(*batch)
                feed_dict = {
                input_left: x1_batch,
                input_right: x2_batch,
                dropout_keep_prob: FLAGS.dropout_keep_prob,
                input_y:y_batch
                }
                _, current_step, current_learning_rate = sess.run([train_step_op, global_step, learning_rate], feed_dict=feed_dict)
                # train_step_op.run(feed_dict=feed_dict)

                if current_step > step:
                    break
                if current_step % FLAGS.display_every == 0:
                    feed_dict = {
                        input_left: x1_batch,
                        input_right: x2_batch,
                        dropout_keep_prob: 1,
                        input_y: y_batch
                    }
                    train_loss, train_accuracy, current_learning_rate \
                        = sess.run([cross_entropy, accuracy, learning_rate], feed_dict=feed_dict)
                    print("train....step: {},learning_rate:{}, loss: {:.4f}, accuracy: {:.4f}".format(current_step, current_learning_rate, train_loss, train_accuracy))
                    write2log(type, "train....step: {},learning_rate:{}, loss: {:.4f}, accuracy: {:.4f}\n".format(current_step, current_learning_rate, train_loss, train_accuracy))
                if current_step % FLAGS.evaluate_every == 0:
                    if type == "student":
                        y_conv_teacher_batch = sess.run(y_conv_teacher, feed_dict=feed_dict)
                        y_conv_teacher_soft_batch = sess.run(y_conv_teacher_soft, feed_dict=feed_dict)
                        print("----")
                        for sen1, sen2 in zip(y_conv_teacher_batch[:5], y_conv_teacher_soft_batch[:5]):
                            print(sen1, "  ", sen2)
                            write2log(type, str(sen1) +  "  " + str(sen2) + "\n")
                    dev_accuracy = dev(x_left_dev, x_right_dev, y_dev, accuracy)
                    test_accuracy = dev(x_left_test, x_right_test, y_test, accuracy)
                    print("\nEvaluation:")
                    print("step: {},dev_acc: {:.4f},test_acc: {:.4f}".format(current_step, dev_accuracy, test_accuracy))
                    write2log(type, "\nEvaluation:\n")
                    write2log(type, "step: {},dev_acc: {:.4f},test_acc: {:.4f}\n".format(current_step, dev_accuracy, test_accuracy))
                    if dev_accuracy > best_acc:
                        best_acc = dev_accuracy
                        path = saver_op.save(sess, checkpoint_prefix, global_step=current_step)
                        print("Saved model checkpoint to {}\n".format(path))
                        write2log(type, "Saved model checkpoint to {}\n".format(path))
                    if test_accuracy > best_test_acc:
                        best_test_acc = test_accuracy
                        print("best_test_acc: {}\n".format(best_test_acc))
                        write2log(type, "best_test_acc: {}\n".format(best_test_acc))

        print("begin teacher")
        train("teacher", train_step_teacher, saver_teacher, global_step_teacher, learning_rate_teacher, checkpoint_prefix_teacher,
              cross_entropy_teacher, accuracy_teacher, x_left_train, x_right_train, y_train, FLAGS, 10000)
        print("begin student")
        train("student", train_step_student, saver_student, global_step_student, learning_rate_student, checkpoint_prefix_student,
              cross_entropy_student, accuracy_student, x_left_train, x_right_train, y_train, FLAGS, 10000)


if __name__ == '__main__':
    main()
