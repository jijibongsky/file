from time import time
import datetime
import numpy as np
import tensorflow as tf
from data_helps import load_data_str_e
from data_helps import batch_iter
from util_bert import choose_model
from load_sentence_embedding import load_sentence_embedding_dict

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# Model Hyperparameters
tf.flags.DEFINE_string("model_name", "bert_dsa_e", "model")
tf.flags.DEFINE_string("model_save_path", "runs/bert/result/bert_dsa_e_0.6_2e-05_0.0005/checkpoints_averaged", "model_save_path")
tf.flags.DEFINE_string("write_dir", "scores.txt", "scores")
# runs/bert/result/bert_dsa_e_0.6_2e-05_0.0005/checkpoints
tf.flags.DEFINE_integer("embedding_dim", 128, "Dimensionality of character embedding (default: 64)")
tf.flags.DEFINE_integer("num_filters", 128, "Number of filters per filter size (default: 64)")
tf.flags.DEFINE_integer("num_hidden", 128, "Number of hidden layer units (default: 100)")
tf.flags.DEFINE_integer("output_dim", 16, "Number of output units (default: 100)")

tf.flags.DEFINE_float("mu", 0.01, "mu")
tf.flags.DEFINE_float("l2_reg_lambda", 0.0005, "L2 regularizaion lambda (default: 0.0)")

# Data Parameter
tf.flags.DEFINE_integer("max_len_left", 24, "max document length of left input")
tf.flags.DEFINE_integer("max_len_right", 24, "max document length of right input")
tf.flags.DEFINE_integer("seed", 123, "Random seed (default: 123)")
tf.flags.DEFINE_integer("batch_size", 64, "Batch Size (default: 64)")
tf.flags.DEFINE_integer("num_checkpoints", 5, "number of checkpoints saved")

FLAGS = tf.flags.FLAGS
FLAGS.flag_values_dict()


def main():
    tf.logging.set_verbosity(tf.logging.INFO)
    print("Loading data...")

    x_left_test, exact_match_left_test, x_right_test, exact_match_right_test, y_test \
        = load_data_str_e('data/lcqmc/train.tsv', 'data/lcqmc/train_bert_seg.tsv')
    print("x_left_train=======", x_left_test.shape)
    print("exact_match_left_train=======", exact_match_left_test.shape)
    print("x_right_train=======", x_right_test.shape)
    print("exact_match_right_train=======", exact_match_right_test.shape)
    print("y_train=======", y_test.shape)
    embedding_dict = load_sentence_embedding_dict("/home/data/text_matching/bert/one_sentence/train.json")

    with tf.Graph().as_default():
        session_conf = tf.ConfigProto(
        gpu_options=tf.GPUOptions(allow_growth=True),
        # gpu_options=tf.GPUOptions(per_process_gpu_memory_fraction=0.5),
        allow_soft_placement=True,
        log_device_placement=False)
        sess = tf.Session(config=session_conf)
        name = FLAGS.model_name
        with sess.as_default():
            model = choose_model(name, FLAGS)
            saver = tf.train.Saver(tf.global_variables(), max_to_keep=FLAGS.num_checkpoints)
            ckpt = tf.train.get_checkpoint_state(FLAGS.model_save_path)
            saver.restore(sess, ckpt.model_checkpoint_path)

            all_weights = {v.name: v for v in tf.trainable_variables()}
            total_size = 0
            for v_name in sorted(list(all_weights)):
                v = all_weights[v_name]
                tf.logging.info("%s\tshape    %s", v.name[:-2].ljust(80),
                                str(v.shape).ljust(20))
                v_size = np.prod(np.array(v.shape.as_list())).tolist()
                total_size += v_size
            tf.logging.info("Total trainable variables size: %d", total_size)

            def get_sentence_embedding(x1_batch, x2_batch, exact_match_left_batch, exact_match_right_batch, y_batch):
                x1_batch = [embedding_dict[sen] for sen in x1_batch]
                x2_batch = [embedding_dict[sen] for sen in x2_batch]
                y_batch = [label for label in y_batch]
                x1_len = np.array([sen.shape[0] for sen in x1_batch], dtype="int32")
                x2_len = np.array([sen.shape[0] for sen in x2_batch], dtype="int32")
                max_len1 = max(x1_len)
                max_len2 = max(x2_len)
                x1_batch_embedding = np.array([np.vstack((sen, np.zeros([max_len1-len(sen), 768], dtype="float32"))) for sen in x1_batch], dtype="float32")
                x2_batch_embedding = np.array([np.vstack((sen, np.zeros([max_len2-len(sen), 768], dtype="float32"))) for sen in x2_batch], dtype="float32")
                exact_match_left_batch = np.array([sen + [0] * (max_len1 - len(sen)) for sen in exact_match_left_batch])
                exact_match_right_batch = np.array([sen + [0] * (max_len2 - len(sen)) for sen in exact_match_right_batch])
                y_batch_embedding = np.array(y_batch, dtype="int32")
                return x1_batch_embedding, x2_batch_embedding, x1_len, x2_len, exact_match_left_batch,exact_match_right_batch, y_batch_embedding

            def dev_step(x_left_batch, x_right_batch,x_left_len, x_right_len, exact_match_left_batch, exact_match_right_batch,y_batch):
                feed_dict = {
                    model.emb_left: x_left_batch,
                    model.emb_right: x_right_batch,
                    model.input_exact_match_left: exact_match_left_batch,
                    model.input_exact_match_right: exact_match_right_batch,
                    model.length_left: x_left_len,
                    model.length_right: x_right_len,
                    model.input_y: y_batch,
                    model.dropout_keep_prob: 1.0
                }
                accuracy, pres = sess.run([model.accuracy, model.scores], feed_dict)
                return accuracy, pres

            wfile = open(FLAGS.write_dir, "w", encoding="utf8")
            num_test = 0
            num_correct = 0.0
            batches = batch_iter(list(zip(x_left_test, exact_match_left_test, x_right_test, exact_match_right_test, y_test)), FLAGS.batch_size*2, 1, shuffle=False)
            k=0
            begin = time()
            for batch in batches:
                k += 1
                if k % 100 == 0:
                    print("batch:{}".format(k))
                x_left_batch, exact_match_left_batch, x_right_batch, exact_match_right_batch, y_batch = zip(*batch)
                x1_batch_embedding, x2_batch_embedding, x1_len, x2_len, exact_match_left_batch, exact_match_right_batch, y_batch \
                    = get_sentence_embedding(x_left_batch, x_right_batch, exact_match_left_batch, exact_match_right_batch, y_batch)

                accurary, pres = dev_step(x1_batch_embedding, x2_batch_embedding, x1_len, x2_len, exact_match_left_batch, exact_match_right_batch, y_batch)
                for score in pres:
                    # print(score)
                    wfile.write(str(score[0]) + "\t" + str(score[1]) + "\n")
                num_test += len(pres)
                num_correct += len(pres)*accurary
            acc = num_correct/num_test
            print("准确率：", acc)
            print("花费时间：", time()-begin)


if __name__ == '__main__':
    main()
