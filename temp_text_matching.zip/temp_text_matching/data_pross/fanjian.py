from simplified_data.langconv import Converter


# 转换繁体到简体
def cht_to_chs(line):
     line = Converter('zh-hans').convert(line)
     line.encode('utf-8')
     return line


# 转换简体到繁体
def chs_to_cht(line):
     line = Converter('zh-hant').convert(line)
     line.encode('utf-8')
     return line


print("====", cht_to_chs('把中文字符串進行繁體和簡體中文的轉換'))
print("====", chs_to_cht('把中文字符串进行繁体和简体中文的转换'))
