import json
import numpy as np


def load_dict(input_file):
    embedding_dict={}
    rfile = open(input_file, "r", encoding="utf8")
    for line in rfile:
        new_dict = json.loads(line.strip())
        embedding_dict[new_dict["word"]] = np.array(new_dict["embedding"])
    return embedding_dict


embedding_dict = load_dict("../word2vec/word.txt")
for key in embedding_dict:
    print(key, embedding_dict[key].shape)
