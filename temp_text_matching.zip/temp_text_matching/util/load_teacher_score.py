import os
import math
import numpy as np


def load_teacher_scores(data_dir, T):
    def my_softmax(x, T):
        z_exp = [math.exp(i / T) for i in x]
        sum_z_exp = sum(z_exp)
        softmax = [i/sum_z_exp for i in z_exp]
        return softmax

    teachers_scores=[]
    for child_file in os.listdir(data_dir):
        if child_file[-3:] != "txt":
            continue
        file = os.path.join(data_dir, child_file)
        rfile = open(file, "r", encoding="utf8")
        teachers_score=[]
        for line in rfile:
            a = [float(i) for i in line.strip().split("\t")]
            teachers_score.append(my_softmax(a, T))
        teachers_scores.append(teachers_score)
    L = len(teachers_scores)
    new_scores = []
    for i in range(len(teachers_scores[0])):
        new_score = [[], []]
        for j in range(len(teachers_scores)):
            new_score[0].append(teachers_scores[j][i][0])
            new_score[1].append(teachers_scores[j][i][1])
        new_score = [round(sum(i)/L, 6) for i in new_score]
        new_scores.append(new_score)
    return np.array(new_scores)


def load_label(data_dir):
    rfile = open(data_dir, "r", encoding="utf8")
    y = []
    k = 0
    for line in rfile:
        k += 1
        if k == 1:
            continue
        a = line.strip().split("\t")[2]
        y.append(int(a))
    return y


def compare(teachers_scores, y):
    teacher_labels = []
    for score in teachers_scores:
        if score[0] >= 0.5:
            teacher_labels.append(0)
        else:
            teacher_labels.append(1)
    print(len(teacher_labels) == len(y))
    num_equal = 0
    for i, j in zip(teacher_labels, y):
        if i == j:
            num_equal += 1
    print("准确率：", num_equal/len(teacher_labels))


if __name__ == "__main__":
    T = 5
    teachers_scores = load_teacher_scores("/home/sun/deep_learning/text_matching/data/teacher_scores", T)
    y = load_label("/home/sun/deep_learning/text_matching/data/lcqmc/train.tsv")
    compare(teachers_scores, y)

    a = []
    for score in teachers_scores:
        if score[0] < 0.5:
            a.append(score[0])
        # print(score)
    print(sum(a)/len(a))
