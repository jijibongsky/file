import time
import datetime
import numpy as np
import tensorflow as tf
from data_helps import load_data_str_pair_e
from data_helps import batch_iter
from util_bert import choose_model
from load_sentence_embedding import load_sentence_embedding_dict

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# Model Hyperparameters
tf.flags.DEFINE_string("model_name", "bert_dsa_si_e", "model")
tf.flags.DEFINE_string("model_save_path", "runs/bert/result/bert_dsa_si_e_0.7_2e-05_0.0005/checkpoints_averaged", "model_save_path")
tf.flags.DEFINE_string("write_dir", "predict_score.txt", "write_dir")

tf.flags.DEFINE_integer("embedding_dim", 128, "Dimensionality of character embedding (default: 64)")
tf.flags.DEFINE_string("filter_sizes", "2,3,4", "Comma-separated filter sizes (default: '2,3')")
tf.flags.DEFINE_integer("num_filters", 128, "Number of filters per filter size (default: 64)")
tf.flags.DEFINE_integer("num_hidden", 128, "Number of hidden layer units (default: 100)")
tf.flags.DEFINE_integer("output_dim", 16, "Number of output units (default: 100)")

tf.flags.DEFINE_float("dropout_keep_prob", 0.7, "Dropout keep probability (default: 0.5)")
tf.flags.DEFINE_float("learning_rate", 0.00002, "L2 learning_rate")
tf.flags.DEFINE_float("mu", 0.01, "mu")
tf.flags.DEFINE_float("l2_reg_lambda", 0.0005, "L2 regularizaion lambda (default: 0.0)")

tf.flags.DEFINE_string("learning_rate_decay", "none", "linear_warmup_rsqrt_decay")  # linear_warmup_rsqrt_decay   noam
tf.flags.DEFINE_string("learning_rate_values", "1e-3,5e-4,25e-5", "")
tf.flags.DEFINE_string("learning_rate_boundaries", "10000,20000", "")

# Data Parameter
tf.flags.DEFINE_integer("max_len_left", 24, "max document length of left input")
tf.flags.DEFINE_integer("max_len_right", 24, "max document length of right input")
# tf.flags.DEFINE_integer("most_words", 40000, "Most number of words in vocab (default: 300000)")

# Training parameters
tf.flags.DEFINE_integer("seed", 123, "Random seed (default: 123)")
tf.flags.DEFINE_string("train_dir", "./", "Training dir root")
tf.flags.DEFINE_integer("batch_size", 64, "Batch Size (default: 64)")
tf.flags.DEFINE_integer("num_epochs", 200, "Number of training epochs (default: 200)")
tf.flags.DEFINE_float("eval_split", 0.1, "Use how much data for evaluating (default: 0.1)")
tf.flags.DEFINE_integer("display_every", 100, " ")
tf.flags.DEFINE_integer("evaluate_every", 500, "Evaluate model on dev set after this many steps (default: 100)")
tf.flags.DEFINE_integer("checkpoint_every", 2000, "Save model after this many steps (default: 100)")
tf.flags.DEFINE_integer("num_checkpoints", 5, "number of checkpoints saved")
# Misc Parameters
tf.flags.DEFINE_boolean("allow_soft_placement", True, "Allow device soft device placement")
tf.flags.DEFINE_boolean("log_device_placement", False, "Log placement of ops on devices")

FLAGS = tf.flags.FLAGS
FLAGS.flag_values_dict()


def main():
    tf.logging.set_verbosity(tf.logging.INFO)
    print("Loading data...")

    x_test, exact_match_test, y_test = load_data_str_pair_e('data/lcqmc/train.tsv', 'data/lcqmc/train_bert_seg_pair.tsv')

    print("x_test=======", x_test.shape)
    print("exact_match_test=======", exact_match_test.shape)
    print("y_test=======", y_test.shape)
    embedding_dict = load_sentence_embedding_dict("/home/data/text_matching/bert/sentence_pair/train.json")

    # for key in embedding_dict:
    #     print(key, embedding_dict[key])
    # input("--")

    with tf.Graph().as_default():
        session_conf = tf.ConfigProto(
        gpu_options=tf.GPUOptions(allow_growth=True),
        # gpu_options=tf.GPUOptions(per_process_gpu_memory_fraction=0.5),
        allow_soft_placement=FLAGS.allow_soft_placement,
        log_device_placement=FLAGS.log_device_placement)
        sess = tf.Session(config=session_conf)
        name = FLAGS.model_name
        with sess.as_default():
            model = choose_model(name, FLAGS)
            saver = tf.train.Saver(tf.global_variables(), max_to_keep=FLAGS.num_checkpoints)
            ckpt = tf.train.get_checkpoint_state(FLAGS.model_save_path)
            saver.restore(sess, ckpt.model_checkpoint_path)

            all_weights = {v.name: v for v in tf.trainable_variables()}
            total_size = 0
            for v_name in sorted(list(all_weights)):
                v = all_weights[v_name]
                tf.logging.info("%s\tshape    %s", v.name[:-2].ljust(80),
                                str(v.shape).ljust(20))
                v_size = np.prod(np.array(v.shape.as_list())).tolist()
                total_size += v_size
            tf.logging.info("Total trainable variables size: %d", total_size)

            def get_sentence_embedding(x1_batch, exact_match_batch):
                x1_batch = [embedding_dict[sen] for sen in x1_batch]
                x1_len = np.array([sen.shape[0] for sen in x1_batch], dtype="int32")
                max_len1 = max(x1_len)
                x1_batch_embedding = np.array([np.vstack((sen, np.zeros([max_len1-len(sen), 768], dtype="float32"))) for sen in x1_batch], dtype="float32")
                exact_match_batch = np.array([sen + [0] * (max_len1 - len(sen)) for sen in exact_match_batch])
                return x1_batch_embedding, x1_len, exact_match_batch

            def dev_step(x_batch, x_len, exact_match_batch, y_batch):
                feed_dict = {
                    model.emb: x_batch,
                    model.input_exact_match: exact_match_batch,
                    model.length: x_len,
                    model.input_y: y_batch,
                    model.dropout_keep_prob: 1.0
                }
                accuracy, pres = sess.run([model.accuracy, model.scores],feed_dict)
                return accuracy, pres

            num_test = 0
            num_correct = 0.0
            wfile = open(FLAGS.write_dir, "w", encoding="utf8")
            batches = batch_iter(list(zip(x_test, exact_match_test, y_test)), FLAGS.batch_size*2, 1, shuffle=False) #
            for batch in batches:
                x_batch, exact_match_batch, y_batch = zip(*batch)
                x1_batch_embedding, x1_len, exact_match_batch = get_sentence_embedding(x_batch, exact_match_batch)
                accurary, pres = dev_step(x1_batch_embedding, x1_len, exact_match_batch, y_batch)
                num_test += len(pres)
                num_correct += len(pres)*accurary
                for score in pres:
                    wfile.write(str(score[0]) + "\t" + str(score[1]) + "\n")
            wfile.close()
            test_acc = num_correct/num_test
            print("test_acc===", test_acc)


if __name__ == '__main__':
    main()
