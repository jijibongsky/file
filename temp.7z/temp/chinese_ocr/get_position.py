from PIL import Image


def save_line(im, position8, index):
    # 左上角坐标（距离左边距离和上边距离），和右下角坐标（距离左边距离和上边距离）
    box = (position8[0], position8[1], position8[-2], position8[-1])
    region = im.crop(box)
    region.save("ceshi/_caijian{}.png".format(index), 'png')


if __name__ == '__main__':
    import json
    image_file = "/home/data/deep_learning/deeplearning/chinese_ocr/test_images/demo.jpg"
    im = Image.open(image_file, "r")
    fr = open("ceshi.json", "r", encoding="utf8")
    result = json.load(fr)
    for i in range(len(result)):
        term = result[str(i)]
        position8 = term[0]
        save_line(im, position8, i)


    # 以下为放缩检测的框适应原始图片(ocr.py)
    # old_shape = img_framed.shape
    # new_shape = img.shape
    # scaling_ratio = (old_shape[0]/new_shape[0], old_shape[1]/new_shape[1])
    # for key in result:
    #     term = result[key]
    #     term[0] = [int(k*scaling_ratio[0]) if k%2==1 else int(k*scaling_ratio[1]) for k in term[0]]
