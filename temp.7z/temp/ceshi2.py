from comtypes.client import CreateObject
import os


class pdfConverter:
    def __init__(self):
        # word文档转化为pdf文档时使用的格式为17
        self.wdFormatPDF = 17
        self.wdToPDF = CreateObject("Word.Application")
        # ppt文档转化为pdf文档时使用的格式为32
        self.pptFormatPDF = 32
        self.pptToPDF = CreateObject("Powerpoint.Application")
        self.pptToPDF.Visible = 1

    def wd_to_pdf(self, folder):
        # 获取指定目录下面的所有文件
        files = os.listdir(folder)
        # 获取word类型的文件放到一个列表里面
        wdfiles = [f for f in files if f.endswith((".doc", ".docx"))]
        for wdfile in wdfiles:
            # 将word文件放到指定的路径下面
            wdPath = os.path.join(folder, wdfile)
            # 设置将要存放pdf文件的路径
            pdfPath = wdPath
            # 判断是否已经存在对应的pdf文件，如果不存在就加入到存放pdf的路径内
            if pdfPath[-3:] != 'pdf':
                pdfPath = pdfPath + ".pdf"
            # 将word文档转化为pdf文件，先打开word所在路径文件，然后在处理后保存pdf文件，最后关闭
            pdfCreate = self.wdToPDF.Documents.Open(wdPath)
            pdfCreate.SaveAs(pdfPath, self.wdFormatPDF)
            pdfCreate.Close()

    def ppt_to_pdf(self, folder):
        files = os.listdir(folder)
        pptfiles = [f for f in files if f.endswith((".ppt", ".pptx"))]
        for pptfile in pptfiles:
            pptPath = os.path.join(folder, pptfile)
            pdfPath = pptPath
            if pdfPath[-3:] != 'pdf':
                pdfPath = pdfPath + ".pdf"
            pdfCreate = self.pptToPDF.Presentations.Open(pptPath)
            pdfCreate.SaveAs(pdfPath, self.pptFormatPDF)
            pdfCreate.Close()


if __name__ == "__main__":
    converter = pdfConverter()
    # converter.ppt_to_pdf("F:\PythonProject\Pacong\ppt")
    # converter.wd_to_pdf("/home/data/deep_learning/temp")
    converter.wd_to_pdf("D:\\temp")
