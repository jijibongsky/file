import comtypes.client
import time



def convert_word_to_pdf(inputFile, outputFile):
    ''' the following lines that are commented out are items that others shared with me they used when
    running loops to stop some exceptions and errors, but I have not had to use them yet (knock on wood) '''
    word = comtypes.client.CreateObject('Word.Application')
    #word.visible = True
    #time.sleep(3)
    doc = word.Documents.Open(inputFile)
    print("doc===", doc)
    doc.SaveAs(outputFile, FileFormat=17)
    doc.close()
    #word.visible = False
    word.Quit()


# File = "/home/data/deep_learning/temp/EO-SSPL/EO_575A1500-000-002_EO3_012CF1.rtf"

File = "/home/data/deep_learning/temp/22.docx"
outFile = "/home/data/deep_learning/temp22.pdf"

convert_word_to_pdf(File, outFile)
