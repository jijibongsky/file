

# data_dir = "D:\\temp\EO-SSPL\EO_575A1500-000-002_EO3_012CF1.rtf"

# data_dir = "D:\\temp\\11.docx"
data_dir = "D:\\temp\\22.docx"

# with open(data_dir, "r", encoding="utf8") as fr:
#     contents = fr.read()
#     # for a in contents:
#     #     print(a)
#     # print(contents)
#     print(type(contents))


import docx2txt
text = docx2txt.process(data_dir)
print(text)

