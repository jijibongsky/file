# coding=utf-8
# Copyright 2019/9/3 15:35 by ZTE
# Author: Kangkang Sun

import numpy as np
from PIL import Image
import cv2
from flask import Flask, render_template, request,redirect, url_for
from flask import send_file
from werkzeug.utils import secure_filename
import os
import sys
import json

root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(root_dir)
print("root_dir", root_dir)
import ocr
import ocr_en64 as ocr_en

# os.environ["CUDA_VISIBLE_DEVICES"] = "0"

UPLOAD_FOLDER = '/uploads'   # 文件存放路径
ALLOWED_EXTENSIONS = set(['jpg', 'txt'])  # 限制上传文件格式

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024


def allowed_file(filename):
    return '.' in filename and \
        filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def ocr_func(image, type_model):
    result = {}
    if type_model=="zh":
        result, image_framed = ocr.model(image)
    elif type_model=="en":
        result, image_framed = ocr_en.model(image)
    New_result = ""
    for key in result:
        New_result += result[key][1] + "\n"
    return New_result

@app.route('/OCR')
def hello_world():
    return send_file("python_web/templates/html.html")


@app.route('/upload/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        # check if the post request has the file part

        if 'file' not in request.files:
            print('No file part')
            return redirect(request.url)

        my_dict = {}
        for key in request.form:
            if key == "type_model":
                my_dict[key] = request.form[key]
        type_model = my_dict["type_model"]
        print("type_model", type_model)

        data = request.files
        file = data['file']
        filename = secure_filename(file.filename)
        image_file = os.path.join("/home/data/deep_learning/deeplearning/chinese_ocr/log", filename)
        file.save(image_file)

        image = np.array(Image.open(file).convert('RGB'))
        result = ocr_func(image, type_model)
        print("result:", result)
        return result
    else:
        print(222222222222)
    return ''


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8800)
    # image_file = "/home/data/deep_learning/deeplearning/chinese_ocr/log/111.PNG"
    # result = ocr_func(image_file)
    # print(result)
