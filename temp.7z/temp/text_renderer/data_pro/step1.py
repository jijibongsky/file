import re
import random


def cut_sentence(sentence, max_len):
    sentence_list = []
    temp = ""
    for w in sentence:
        temp += w
        if len(temp) == max_len:
            sentence_list.append(temp)
            temp = ""
    return sentence_list


def create_en_lines(data_in, data_out, max_len, len_range=None, language="zh"):
    fr = open(data_in, "r", encoding="utf8")
    fw = open(data_out, "w", encoding="utf8")
    total_lines = []
    k = 0
    for line in fr:
        k += 1
        if k % 1000000 == 0:
            print(k)
        line = line.strip()
        line = line.replace("\\", "")
        line = line.replace("/", "")
        if language == "zh":
            line = line.replace(" ", "")
        elif language == "en":
            line = re.sub(" +", " ", line)
        elif language == "en_word":
            line = re.sub(" +", " ", line)
            lines = line.split(" ")
            for a in lines:
                a = a.strip()
                fw.write(a + "\n")
            continue
        if language != "en_word":
            if len_range:
                temp_max_len=random.choice(len_range)
                lines = cut_sentence(line, max_len=temp_max_len)
            else:
                lines = cut_sentence(line, max_len)
            for sen in lines:
                if sen[0] == " " or sen[-1] == " ":
                    continue
                total_lines.append(sen)
    print(len(total_lines))

    for i in range(5):
        random.shuffle(total_lines)

    for line in total_lines:
        fw.write(line + "\n")


if __name__ == '__main__':
    data_in = "/home/data/fanyi_data/ChallengerAI2017/en.txt"
    data_out = "/home/data/deep_learning/deeplearning/text_renderer/data/corpus/ai_en_20_shuf.txt"
    create_en_lines(data_in, data_out, max_len=20, len_range=None, language="en")
