import random
import cv2
import numpy as np
import yaml
from easydict import EasyDict

from noiser import Noiser

# 模糊图像，模拟小图片放大的效果
def apply_prydown(img):
    scale = random.uniform(1, 1.5)
    height = img.shape[0]
    width = img.shape[1]
    out = cv2.resize(img, (int(width / scale), int(height / scale)), interpolation=cv2.INTER_AREA)
    return cv2.resize(out, (width, height), interpolation=cv2.INTER_AREA)

# 加入噪音
def apply_blur_on_output(img):
    def apply_gauss_blur(img, ks=None):
        if ks is None:
            ks = [7, 9, 11, 13]
        ksize = random.choice(ks)
        sigmas = [0, 1, 2, 3, 4, 5, 6, 7]
        sigma = 0
        if ksize <= 3:
            sigma = random.choice(sigmas)
        img = cv2.GaussianBlur(img, (ksize, ksize), sigma)
        return img

    def apply_norm_blur(img, ks=None):
        # kernel == 1, the output image will be the same
        if ks is None:
            ks = [2, 3]
        kernel = random.choice(ks)
        img = cv2.blur(img, (kernel, kernel))
        return img

    if random.uniform(0, 1) < 0.5:
        return apply_gauss_blur(img, [3, 5])
    else:
        return apply_norm_blur(img)

# 翻转图片的像素
def reverse_img(word_img):
    offset = np.random.randint(-10, 10)
    return 255 + offset - word_img

emboss_kernal = np.array([
    [-2, -1, 0],
    [-1, 1, 1],
    [0, 1, 2]
])

sharp_kernel = np.array([
    [-1, -1, -1],
    [-1, 9, -1],
    [-1, -1, -1]
])

# 制造浮雕特效
def apply_emboss(word_img):
    return cv2.filter2D(word_img, -1, emboss_kernal)

def apply_sharp(word_img):
    return cv2.filter2D(word_img, -1, sharp_kernel)

def load_config(filepath):
    with open(filepath, mode='r',encoding='utf-8') as f:
        # cfg = yaml.load(f.read(),Loader=yaml.FullLoader)
        cfg = yaml.load(f.read())
        cfg = EasyDict(cfg)  # 可以使得以属性的方式去访问字典的值！
    return cfg

def main(data_file_in, data_file_out, noiser):
    img = cv2.imread(data_file_in)

    img = noiser.apply(img)
    img = apply_blur_on_output(img)
    img = apply_prydown(img)

    # img = reverse_img(img)
    # img = apply_emboss(img)  # 浮雕
    # img = apply_sharp(img)  # 锋利的
    cv2.imwrite(data_file_out, img)


if __name__ == '__main__':
    cfg = load_config("default.yaml")
    noiser = Noiser(cfg)
    # for key in cfg:
    #     print(222, key, cfg[key])
    data_file_in = "/home/data/deep_learning/deeplearning/text_renderer/output/ceshi/00000000.jpg"
    data_file_out = "/home/data/deep_learning/deeplearning/text_renderer/output/ceshi/00000000.jpg.jpg"

    main(data_file_in, data_file_out, noiser)
