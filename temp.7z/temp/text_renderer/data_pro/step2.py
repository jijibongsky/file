import os
from PIL import Image
import numpy as np
from time import time
import random

def ceshi(root_dir):
    a = []
    len_dict = {}
    k = 0
    for file in os.listdir(root_dir):
        k += 1
        if file[-4:] != ".jpg" and file[-4:]!=".png":
            continue
        if k % 10000 == 0:
            print(k)
        data_file = os.path.join(root_dir, file)
        img1 = Image.open(data_file).convert("L")
        img = np.array(img1, "f")/255.0 - 0.5
        a.append(img.shape[1])
        len_a = img.shape[1]
        if len_a not in len_dict:
            len_dict[len_a] = 1
        else:
            len_dict[len_a] += 1
    print(1111, max(a))

def move_files(new_data_dir, old_data_dir):
    if not os.path.exists(new_data_dir):
        os.makedirs(new_data_dir)
    os.system("mv {} {}".format(old_data_dir + "tmp_labels.txt",new_data_dir + "tmp_labels.txt"))
    os.system("mv {} {}".format(old_data_dir + "labels.txt",new_data_dir + "labels.txt"))
    os.system("mv {} {}".format(old_data_dir, new_data_dir + "images"))


def load_voc(voc_file):
    fr_voc = open(voc_file, "r", encoding="utf8")
    words = []
    word_dict = {}
    for line in fr_voc:
        line = line.strip("\n")
        line = line.split("\t")
        if len(line)!=2:
            print("aaaaaaa", line)
            continue
        words.append(line[0])
    for i in range(len(words)):
        word_dict[words[i]] = i
    return word_dict

def create_voc_and_trian_data_zh(tmp_labels, voc_file, data_train, data_test):
    fr = open(tmp_labels, "r", encoding="utf8")
    fw_voc = open(voc_file, "w", encoding="utf8")
    char_dict = {}
    for line in fr:
        line = line.strip()
        if "\t" in line:
            print("tttttttt")
            print(line)
            print()
            continue
        line = line.split(" ")
        line = [line[0] + " ".join(line[1:])]
        picture = line[0] + ".jpg"
        sentence = line[1]

        for char in sentence:
            if char not in char_dict:
                char_dict[char]=1
            else:
                char_dict[char]+=1
    fr.close()

    char_dict = sorted(char_dict.items(), key=lambda d:d[1], reverse=True)
    for pair in char_dict:
        if pair[1]>=1:
            fw_voc.write(pair[0] + "\t" + str(pair[1]) + "\n")
    fw_voc.close()

    word_dict = load_voc(voc_file)

    fr = open(tmp_labels, "r", encoding="utf8")
    fw_trian = open(data_train, "w", encoding="utf8")
    fw_test = open(data_test, "w", encoding="utf8")
    all_data = []
    for line in fr:
        line = line.strip()
        if "\t" in line:
            print("tttttt")
            continue
        line = line.split(" ")
        line = [line[0], " ".join(line[1:])]
        picture = line[0] + ".jpg"
        sentence = line[1]
        sentence = [str(word_dict[w]) for w in sentence]
        sentence = " ".join(sentence)
        all_data.append(picture + "\t" + sentence)

    for i in range(5):
        random.shuffle(all_data)
    L = len(all_data)
    for i in range(L):
        if i <= 0.95*L:
            fw_trian.write(all_data[i] + "\n")
        else:
            fw_test.write(all_data[i] + "\n")


def create_voc_and_trian_data_en(tmp_labels, voc_file, data_train, data_test):
    fr = open(tmp_labels, "r", encoding="utf8")
    fw_voc = open(voc_file, "w", encoding="utf8")
    char_dict = {}
    for line in fr:
        line = line.strip()
        if "\t" in line:
            print("tttttttt")
            continue
        line = line.split(" ")
        # line = [line[0] + " ".join(line[1:])]
        if len(line) == 1 or (len(line) == 2 and line[1] == ""):
            print("aaaaaaaa")
            continue
        picture = line[0] + ".jpg"
        sentence = " ".join(line[1:])

        for char in sentence:
            if char not in char_dict:
                char_dict[char]=1
            else:
                char_dict[char]+=1
    fr.close()

    char_dict = sorted(char_dict.items(), key=lambda d:d[1], reverse=True)
    for pair in char_dict:
        if pair[1]>=1:
            fw_voc.write(pair[0] + "\t" + str(pair[1]) + "\n")
    fw_voc.close()

    word_dict = load_voc(voc_file)

    fr = open(tmp_labels, "r", encoding="utf8")
    fw_trian = open(data_train, "w", encoding="utf8")
    fw_test = open(data_test, "w", encoding="utf8")
    all_data = []
    for line in fr:
        line = line.strip()
        if "\t" in line:
            print("tttttt")
            continue
        line = line.split(" ")
        if len(line) == 1 or (len(line) == 2 and line[1] == ""):
            print("aaaaaaaa")
            continue
        picture = line[0] + ".jpg"
        sentence = " ".join(line[1:])
        sentence = [str(word_dict[w]) for w in sentence]
        sentence = " ".join(sentence)
        all_data.append(picture + "\t" + sentence)

    for i in range(5):
        random.shuffle(all_data)
    L = len(all_data)
    for i in range(L):
        if i <= 0.95*L:
            fw_trian.write(all_data[i] + "\n")
        else:
            fw_test.write(all_data[i] + "\n")


def create_voc_and_trian_data_en_zh(tmp_labels, voc_file, data_train, data_test):
    fr = open(tmp_labels, "r", encoding="utf8")
    fw_voc = open(voc_file, "w", encoding="utf8")
    char_dict = {}
    for line in fr:
        line = line.strip()
        if "\t" in line:
            print("tttttttt")
            continue
        line = line.split(" ")
        # line = [line[0] + " ".join(line[1:])]
        if len(line) !=2:
            print("aaaaaaaa")
            continue
        picture = line[0] + ".jpg"
        sentence = line[1]

        for char in sentence:
            if char not in char_dict:
                char_dict[char]=1
            else:
                char_dict[char]+=1
    fr.close()

    char_dict = sorted(char_dict.items(), key=lambda d:d[1], reverse=True)
    for pair in char_dict:
        if pair[1]>=1:
            fw_voc.write(pair[0] + "\t" + str(pair[1]) + "\n")
    fw_voc.close()

    word_dict = load_voc(voc_file)

    fr = open(tmp_labels, "r", encoding="utf8")
    fw_trian = open(data_train, "w", encoding="utf8")
    fw_test = open(data_test, "w", encoding="utf8")
    all_data = []
    for line in fr:
        line = line.strip()
        if "\t" in line:
            print("tttttt")
            continue
        line = line.split(" ")
        if len(line) != 2:
            print("aaaaaaaa")
            continue
        picture = line[0] + ".jpg"
        sentence = line[1]
        sentence = [str(word_dict[w]) for w in sentence]
        sentence = " ".join(sentence)
        all_data.append(picture + "\t" + sentence)

    for i in range(5):
        random.shuffle(all_data)
    L = len(all_data)
    for i in range(L):
        if i <= 0.95*L:
            fw_trian.write(all_data[i] + "\n")
        else:
            fw_test.write(all_data[i] + "\n")

def reshape_jpg(dir_in, dir_out, file, reshape=False):
    data_file_in = os.path.join(dir_in, file)
    data_file_out = os.path.join(dir_out, file)
    im = Image.open(data_file_in)
    if reshape:
        im = im.resize((420,32), Image.ANTIALIAS)
    im.save(data_file_out)

def reshape_jpgs(dir_in, dir_out):
    begin_time = time()
    k = 0
    for file in os.listdir(dir_in):
        k+=1
        if k%10000==0:
            print(k, time()-begin_time)
        reshape_jpg(dir_in, dir_out, file, reshape=False)


if __name__ == '__main__':
    root_dir = "/home/data/deep_learning/deeplearning/text_renderer/output/beifen/ai_en_20_64_560_20wan"
    # ceshi(root_dir)

    new_data_dir = "../output/beifen/ai_en_20_64_560_20wan/"
    old_data_dir = "../output/ai_en_20_64_560_20wan/"
    # move_files(new_data_dir, old_data_dir)

    tmp_labels = new_data_dir + "tmp_labels.txt"
    voc_file = new_data_dir + "char_std.txt"
    data_train = new_data_dir + "data_train.txt"
    data_test = new_data_dir + "data_test.txt"
    create_voc_and_trian_data_en(tmp_labels, voc_file, data_train, data_test)
