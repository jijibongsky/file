from PIL import ImageFont, Image, ImageDraw
import numpy as np
import cv2
import math_utils


def get_word_size(font, word):
    offset = font.getoffset(word)
    size = font.getsize(word)
    size = (size[0] - offset[0], size[1] - offset[1])
    return size


def draw_text_on_bg(word, font, bg, dim=2):
    """
    Draw word in the center of background
    :param word: word to draw
    :param font: font to draw word
    :param bg: background numpy image
    :return:
        np_img: word image
        text_box_pnts: left-top, right-top, right-bottom, left-bottom
    """
    bg_height = bg.shape[0]
    bg_width = bg.shape[1]
    pil_img = Image.fromarray(np.uint8(bg))
    draw = ImageDraw.Draw(pil_img)
    word_size = get_word_size(font, word)
    word_height = word_size[1]
    word_width = word_size[0]
    offset = font.getoffset(word)

    # print("word_size===", word_size)
    # print("offset===", offset)
    # print("word===", word)

    # Draw text in the center of bg
    text_x = int((bg_width - word_width) / 2)
    text_y = int((bg_height - word_height) / 2)

    if dim == 2:
        # word_color = self.get_word_color(bg, text_x, text_y, word_height, word_width)
        word_color = 100
        draw.text((text_x - offset[0], text_y - offset[1]), word, fill=word_color, font=font)
    else:
        # word_color = (0, 0, 0)
        word_color = (255, 255, 0)
        draw.text((text_x - offset[0], text_y - offset[1]), word, word_color, font=font)
    np_img = np.array(pil_img).astype(np.float32)

    # cv2.imwrite("/home/data/deep_learning/deeplearning/text_renderer/output/ceshi1/{}.jpg".format(word), np_img)

    text_box_pnts = [
        [text_x, text_y],
        [text_x + word_width, text_y],
        [text_x + word_width, text_y + word_height],
        [text_x, text_y + word_height]
    ]
    return np_img, text_box_pnts, word_color


def easy_draw_text_on_bg(word, font):
    img = Image.new('RGB', (300, 300), (255, 180, 0))  # 新建长宽300像素，背景色为（255,180,0）的画布对象
    print(img.size)
    draw = ImageDraw.Draw(img)  # 新建画布绘画对象
    draw.text((50, 50), word, (255, 0, 0), font=font)  # 在新建的对象 上坐标（50,50）处开始画出红色文本
    # 左上角为画布坐标（0,0）点
    img.show()
    img.save("/home/data/deep_learning/deeplearning/text_renderer/output/ceshi1/{}.jpg".format(word))


def apply_perspective_transform(img, text_box_pnts, max_x, max_y, max_z, gpu=False):
    """
    Apply perspective transform on image
    :param img: origin numpy image
    :param text_box_pnts: four corner points of text
    :param x: max rotate angle around X-axis
    :param y: max rotate angle around Y-axis
    :param z: max rotate angle around Z-axis
    :return:
        dst_img:
        dst_img_pnts: points of whole word image after apply perspective transform
        dst_text_pnts: points of text after apply perspective transform
    """

    x = math_utils.cliped_rand_norm(0, max_x)
    y = math_utils.cliped_rand_norm(0, max_y)
    z = math_utils.cliped_rand_norm(0, max_z)

    # print("x: %f, y: %f, z: %f" % (x, y, z))

    transformer = math_utils.PerspectiveTransform(x, y, z, scale=1.0, fovy=50)

    dst_img, M33, dst_img_pnts = transformer.transform_image(img, gpu)
    dst_text_pnts = transformer.transform_pnts(text_box_pnts, M33)
    return dst_img, dst_img_pnts, dst_text_pnts


if __name__ == '__main__':
    font_path = "/home/data/deep_learning/deeplearning/text_renderer/data/fonts/eng/Arial.ttf"
    font_size = 30
    word = "abcdefga"
    # word = '我们不一样'
    bg2 = np.zeros((1000, 1000)) + 255
    bg3 = Image.new('RGB', (300, 300), (255, 255, 255))
    # bg3.save("/home/data/deep_learning/deeplearning/text_renderer/output/ceshi1/{}.jpg".format(1111))
    bg3 = np.array(bg3)
    print(11111111, bg3.shape)

    font = ImageFont.truetype(font_path, font_size)
    size = get_word_size(font, word)
    # easy_draw_text_on_bg(word, font)

    # np_img, text_box_pnts, word_color = draw_text_on_bg(word, font, bg2, dim=2)
    np_img, text_box_pnts, word_color = draw_text_on_bg(word, font, bg3, dim=3)
    word_img, img_pnts_transformed, text_box_pnts_transformed = apply_perspective_transform(
        np_img, text_box_pnts, max_x=5, max_y=5, max_z=3, gpu=False)

    # cv2.imwrite("/home/data/deep_learning/deeplearning/text_renderer/output/ceshi1/{}.jpg".format(word), word_img)

    # image_path = "/home/data/deep_learning/deeplearning/text_renderer/output/ceshi1/1111.jpg"
    # bg = cv2.imdecode(np.fromfile(image_path, dtype=np.uint8), cv2.IMREAD_GRAYSCALE)
    # bg = cv2.imread(image_path)
    # print(type(bg), bg.shape)
    # print(bg)
