import re
import os
import cv2
import math
import random

def move_files(new_data_dir, old_data_dir):
    if not os.path.exists(new_data_dir):
        os.makedirs(new_data_dir)
    k=0
    for file in os.listdir(old_data_dir):
        k += 1
        if k < 100:
            old_file = old_data_dir + file
            new_file = new_data_dir + file
            os.system("cp {} {}".format(old_file, new_file))


new_data_dir = "/home/data/deep_learning/deeplearning/text_renderer/output/beifen/ai_en_20_32_280_20wan/ceshi/"
old_data_dir = "/home/data/deep_learning/deeplearning/text_renderer/output/beifen/ai_en_20_32_280_20wan/images/"
# move_files(new_data_dir, old_data_dir)

import numpy as np
# x=np.array([9,2,3,5,6,7,8,9])
# a = np.clip(x,3,8)
# print(a)

print(math.ceil(2.1))

def cliped_rand_norm(mu=0, sigma3=1):
    """
    :param mu: 均值
    :param sigma3: 3 倍标准差， 99% 的数据落在 (mu-3*sigma, mu+3*sigma)
    """
    # 标准差
    sigma = sigma3 / 3
    dst = sigma * np.random.randn() + mu
    dst = np.clip(dst, 0 - sigma3, sigma3)
    return dst

x = cliped_rand_norm(0, 3)
print(x)


