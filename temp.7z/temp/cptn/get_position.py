from PIL import Image
import numpy as np


def save_line(im, position8, index):
    # 左上角坐标（距离左边距离和上边距离），和右下角坐标（距离左边距离和上边距离）
    box = (position8[0], position8[1], position8[-4], position8[-3])
    region = im.crop(box)
    region.save("ceshi/_caijian{}.png".format(index), 'png')


if __name__ == '__main__':
    position_file = "/home/data/deep_learning/deeplearning/text_detection_ctpn/data/res/006.txt"
    fr = open(position_file, "r", encoding="utf8")
    positions = []
    for line in fr:
        line = line.strip().split(",")[:-1]
        line = tuple([int(i) for i in line])
        positions.append(line)
    image_file = "/home/data/deep_learning/deeplearning/text_detection_ctpn/data/res/006.jpg"
    im = Image.open(image_file, "r")
    # image1 = np.array(im.convert('RGB'))
    # print("image1.shape", image1.shape)
    for index, position8 in enumerate(positions):
        print("position8", position8)
        save_line(im, position8, index)


# a = [str(int(box[k]/rh)) if k % 2 == 1 else str(int(box[k]/rw)) for k in range(8)]  # 原图对应的为止
# a = [str(box[k]) for k in range(8)]  # 放缩后的图对应的位置
# line = ",".join(a)
