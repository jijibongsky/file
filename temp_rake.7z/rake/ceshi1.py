import rake

# stoppath = 'data/stoplists/SmartStoplist.txt'
# rake_object = rake.Rake(stoppath, 5, 3, 4)
# sample_file = open("data/docs/fao_test/w2167e.txt", 'r', encoding="iso-8859-1")
# text = sample_file.read()
# keywords = rake_object.run(text)
# print("Keywords:", keywords)

stoppath = 'data/中文停词.txt'
rake_object = rake.Rake(stoppath, 2, 5, 2)
data_file = "/home/data/deep_learning/key_words/myLDA/data/corpus/离婚纠纷ppl/离婚纠纷/137200000052217.txt"
sample_file = open(data_file, 'r', encoding="utf8")
text = sample_file.read()
keywords = rake_object.run(text, type="zh")
print("Keywords:", keywords)
