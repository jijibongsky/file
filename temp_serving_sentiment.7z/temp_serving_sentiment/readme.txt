启动
gunicorn -w 4 -b 192.168.2.100:4000 start_rest_service:app
gunicorn -c gconfig.py start_rest_service:app


调用
wrk -t1 -c128 -d30s -s test.lua 'http://192.168.2.100:8833/sentiment'
curl http://192.168.2.100:8833/sentiment -X POST -H '"Content-type":"application/json"'  -d '{"sentence":["今天股票涨停"]}'
