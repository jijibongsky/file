from gevent import monkey
import gevent.monkey
monkey.patch_all()
import multiprocessing
debug = True
accesslog = "log/access.log"
errorlog = "log/debug.log"
loglevel = 'debug'
bind = '192.168.2.100:8833'  #绑定与Nginx通信的端口
pidfile = 'log/gunicorn.pid'
logfile = 'log/debug.log'
# workers = multiprocessing.cpu_count() * 2 + 1
workers = 1
worker_class = 'gevent'  #默认为阻塞模式，最好选择gevent模式

# daemon = True  # 守护程序   开启后台运行
x_forwarded_for_header = 'X-FORWARDED-FOR'