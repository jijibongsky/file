wrk.method = "POST"
wrk.body = "{\"sentence\":[\"今天股票跌停\"]}"
wrk.headers["Content-Type"] = "application/json"