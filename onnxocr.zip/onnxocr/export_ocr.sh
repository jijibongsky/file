ppocr_path=$1
old_model=$2
model_save_dir=$3

wget -P $old_model/ch_lite/ https://paddleocr.bj.bcebos.com/dygraph_v2.0/ch/ch_ppocr_mobile_v2.0_cls_train.tar && tar xf $old_model/ch_lite/ch_ppocr_mobile_v2.0_cls_train.tar -C $old_model/ch_lite/
wget -P $old_model/ch_lite/ https://paddleocr.bj.bcebos.com/dygraph_v2.0/ch/ch_ppocr_mobile_v2.0_det_train.tar && tar xf $old_model/ch_lite/ch_ppocr_mobile_v2.0_det_train.tar -C $old_model/ch_lite/
wget -P $old_model/ch_lite/ https://paddleocr.bj.bcebos.com/dygraph_v2.0/ch/ch_ppocr_mobile_v2.0_rec_train.tar && tar xf $old_model/ch_lite/ch_ppocr_mobile_v2.0_rec_train.tar -C $old_model/ch_lite/

cd $ppocr_path
python3 tools/export_model.py -c configs/rec/ch_ppocr_v2.0/rec_chinese_lite_train_v2.0.yml -o Global.pretrained_model=$old_model/ch_lite/ch_ppocr_mobile_v2.0_rec_train/best_accuracy Global.load_static_weights=False Global.save_inference_dir=$model_save_dir/rec_crnn/
python3 tools/export_model.py -c configs/det/ch_ppocr_v2.0/ch_det_mv3_db_v2.0.yml -o Global.pretrained_model=$old_model/ch_lite/ch_ppocr_mobile_v2.0_det_train/best_accuracy Global.load_static_weights=False Global.save_inference_dir=$model_save_dir/det_db/
python3 tools/export_model.py -c configs/cls/cls_mv3.yml -o Global.pretrained_model=$old_model/ch_lite/ch_ppocr_mobile_v2.0_cls_train/best_accuracy Global.load_static_weights=False Global.save_inference_dir=$model_save_dir/cls/

# rm -rf ~/ch_lite
