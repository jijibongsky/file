1、安装conda环境
conda create -n onnxocr python=3.7
conda activate onnxocr

2、安装依赖包
pip install -r  PaddleOCR/requirements.txt
pip install paddlepaddle==2.0 -i https://mirror.baidu.com/pypi/simple
pip install paddle2onnx==0.5
pip install onnxruntime==1.6.0

3、模型转换成paddle的格式
sh export_ocr.sh PaddleOCR/ /home/data/deep_learning/paddle/onnxocr/ /home/data/deep_learning/paddle/onnxocr/inference_model/paddle/

4、模型转换成onnx
paddle2onnx -m /home/data/deep_learning/paddle/onnxocr/inference_model/paddle/cls/ --model_filename inference.pdmodel --params_filename inference.pdiparams -s /home/data/deep_learning/paddle/onnxocr/inference_model/onnx/cls/model.onnx --opset_version 11
paddle2onnx -m /home/data/deep_learning/paddle/onnxocr/inference_model/paddle/rec_crnn/ --model_filename inference.pdmodel --params_filename inference.pdiparams -s /home/data/deep_learning/paddle/onnxocr/inference_model/onnx/rec_crnn/model.onnx --opset_version 11
paddle2onnx -m /home/data/deep_learning/paddle/onnxocr/inference_model/paddle/det_db/ --model_filename inference.pdmodel --params_filename inference.pdiparams -s /home/data/deep_learning/paddle/onnxocr/inference_model/onnx/det_db/model.onnx --opset_version 11


5、推理
export PYTHONPATH=$PYTHONPATH:PaddleOCR/ && \
python onnx_inference/predict_system.py \
--image_dir="images/liver_function.jpg" \
--det_model_dir="./inference_model/onnx/det_db/model.onnx" \
--cls_model_dir="./inference_model/onnx/cls/model.onnx" \
--rec_model_dir="./inference_model/onnx/rec_crnn/model.onnx" \
--use_angle_cls=true \
--rec_char_dict_path PaddleOCR/ppocr/utils/ppocr_keys_v1.txt  \
--vis_font_path PaddleOCR/doc/fonts/simfang.ttf





3、模型转换成paddle的格式
sh export_ocr_server.sh PaddleOCR/ /home/data/deep_learning/paddle/onnxocr/ /home/data/deep_learning/paddle/onnxocr/inference_model/paddle_server/

4、模型转换成onnx
paddle2onnx -m /home/data/deep_learning/paddle/onnxocr/inference_model/paddle_server/cls/ \
--model_filename inference.pdmodel \
--params_filename inference.pdiparams \
-s /home/data/deep_learning/paddle/onnxocr/inference_model/onnx_server/cls/model.onnx \
--opset_version 11

paddle2onnx -m /home/data/deep_learning/paddle/onnxocr/inference_model/paddle_server/rec_crnn/ \
--model_filename inference.pdmodel \
--params_filename inference.pdiparams \
-s /home/data/deep_learning/paddle/onnxocr/inference_model/onnx_server/rec_crnn/model.onnx \
--opset_version 11

paddle2onnx -m /home/data/deep_learning/paddle/onnxocr/inference_model/paddle_server/det_db/ \
--model_filename inference.pdmodel \
--params_filename inference.pdiparams \
-s /home/data/deep_learning/paddle/onnxocr/inference_model/onnx_server/det_db/model.onnx \
--opset_version 11


5、推理
export PYTHONPATH=$PYTHONPATH:PaddleOCR/ && \
python onnx_inference/predict_system.py \
--image_dir="onnx_inference/images/liver_function.jpg" \
--det_model_dir="./inference_model/onnx_server/det_db/model.onnx" \
--cls_model_dir="./inference_model/onnx_server/cls/model.onnx" \
--rec_model_dir="./inference_model/onnx_server/rec_crnn/model.onnx" \
--use_angle_cls=true \
--rec_char_dict_path PaddleOCR/ppocr/utils/ppocr_keys_v1.txt  \
--vis_font_path PaddleOCR/doc/fonts/simfang.ttf


nvidia-docker run -it -v /home/data:/home/data nvidia/cuda:10.2-cudnn8-runtime-ubuntu18.04 /bin/bash



docker
nvidia/cuda:10.2-cudnn8-runtime-ubuntu18.04

apt-get install libsm6
apt-get install libxrender1
apt-get install libxext-dev
