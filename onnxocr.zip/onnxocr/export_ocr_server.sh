ppocr_path=$1
old_model=$2
model_save_dir=$3

cd $ppocr_path
python3 tools/export_model.py \
-c configs/rec/ch_ppocr_v2.0/rec_chinese_common_train_v2.0.yml \
-o Global.pretrained_model=$old_model/inference_model/paddle_server/older/ch_ppocr_server_v2.0_rec_pre/best_accuracy \
Global.load_static_weights=False \
Global.save_inference_dir=$model_save_dir/rec_crnn/

python3 tools/export_model.py \
-c configs/det/ch_ppocr_v2.0/ch_det_res18_db_v2.0.yml \
-o Global.pretrained_model=$old_model/inference_model/paddle_server/older/ch_ppocr_server_v2.0_det_train/best_accuracy \
Global.load_static_weights=False \
Global.save_inference_dir=$model_save_dir/det_db/

python3 tools/export_model.py \
-c configs/cls/cls_mv3.yml \
-o Global.pretrained_model=$old_model/inference_model/paddle_server/older/ch_ppocr_mobile_v2.0_cls_train/best_accuracy \
Global.load_static_weights=False \
Global.save_inference_dir=$model_save_dir/cls/

