from torch.utils.data import DataLoader
from utils.datasets import *
from old.train import hyp
import copy


def get_gt_loader(repo_file_list='/data/cityscape/VOC2007/ImageSets/Main/test_t.txt',
                  img_size=416, batch_size=32, augment=False):
    # imdb, roidb, ratio_list, ratio_index = combined_roidb(repo_name)
    # dataset = roibatchLoader(roidb, ratio_list, ratio_index, 1,
    #                          imdb.num_classes, training=True)
    # dataloader = torch.utils.data.DataLoader(dataset, batch_size=1,
    #                                          shuffle=False, num_workers=0,
    #                                          pin_memory=True)
    # return imdb, dataloader
    dataset = LoadImagesAndLabels(repo_file_list, img_size, batch_size, augment=augment, hyp=hyp)
    dataloader = DataLoader(dataset,
                            batch_size=batch_size,
                            num_workers=min(os.cpu_count(), batch_size),
                            pin_memory=True,
                            collate_fn=dataset.collate_fn)
    return dataloader


class QueryRepo:
    """
    Class to store queried examples.
    """

    def __init__(self, partial_label: 'bool' = False):
        self.pl = partial_label
        self.database = dict()
        self.metadata = dict()
        self.tcost = 0
        self.skipped_image = 0
        self.empty_image_list = []

        self.fs_database = []

        # for mix supervision
        self.weakly_labeled_set = dict()
        self.strongly_labeled_set = dict()

    def update(self, img_path: 'str', im_info: 'int', gt_boxes: 'torch.Tensor',
               num_pos: 'int', num_neg: 'int', num_outlier: 'int', cost: 'float',
               domain_label: 'int', iteration: 'int', method_name: 'str' = None,
               score=0):
        """Store the queried box.
        IMPORTANT: The label should not be mapped to target domain.
        Just remain the original index in the source domain.

        :param img_path: str, path to the image
        :param im_info:  int, 1: fully supervised; 0: partially supervised.
        :param gt_boxes:  torch.Tensor, gt boxes. class = -1 means background.
            Format: 0, class, xywh relative coord
        :param num_pos: int, number of positive (foreground) instances.
        :param num_neg: int, number of negative (background) instances.
        :param num_outlier: int, number of instances whose class is in the outlier classes.
        :param cost: float, cost of quering this example.
        :param domain_label: int, 1: source domain, 0 target domain.
        :param iteration: int, the number of the AL iteration.
        :return:
        """
        if img_path not in self.database.keys():
            # fully supervised or 1st time partially labeling
            assert len(gt_boxes) > 0
            self.database[img_path] = gt_boxes.clone()
            info = dict()
            info['sup_type'] = im_info
            info['num_pos'] = num_pos
            info['num_neg'] = num_neg
            info['num_outlier'] = num_outlier
            info['cost'] = cost
            info['domain_label'] = domain_label
            info['iteration'] = iteration
            self.metadata[img_path] = info
        else:
            # partially labeling
            assert 'our' in method_name or 'ins' in method_name
            queried_boxes = self.database[img_path]
            total_boxes = torch.cat([queried_boxes, gt_boxes], dim=0)
            self.database[img_path] = total_boxes.clone()
            # if total_boxes.shape[0] > 100 or queried_boxes.shape[0]>100:
            #     print('?')

            # update metadata
            info = self.metadata[img_path]
            info['num_pos'] += num_pos
            info['num_neg'] += num_neg
            info['num_outlier'] += num_outlier
            info['cost'] += cost
            self.metadata[img_path] = info
        self.tcost += cost

    def update_weak(self, img_path: 'str', im_info: 'int', gt_boxes: 'torch.Tensor', num_pos: 'int'):
        """NOTE: only the mix supervision methods can invoke this function.

        :param img_path:
        :param im_info:
        :param gt_boxes:
        :param num_pos:
        :return:
        """
        # assert len(gt_boxes) > 0
        self.weakly_labeled_set[img_path] = gt_boxes.clone()

    def update_strong(self, img_path: 'str'):
        """NOTE: only the mix supervision methods can invoke this function.

        :param img_path:
        :return:
        """
        assert img_path in self.weakly_labeled_set
        self.strongly_labeled_set[img_path] = self.weakly_labeled_set.pop(img_path)

    def __contains__(self, item):
        return True if item in self.database.keys() else False

    def __getitem__(self, item):
        return self.database[item].clone(), copy.copy(self.metadata[item])

    # def instances_statistic(self):
    #     """return the number of classes, instances of each class."""
    #     statistic = dict()
    #     if len(self.database) == 0:
    #         return 0, None
    #     for k in self.database.keys():
    #         boxes = self.database[k]
    #         for box in boxes:
    #             pass
    #     return len(np.unique(statistic.keys())), statistic

    def __len__(self):
        if len(self.weakly_labeled_set) == 0 and len(self.strongly_labeled_set) == 0:
            return len(self.database)
        else:
            return len(self.strongly_labeled_set)

    def get_latest_set(self):
        """Return a QueryRepo with the latest updated examples."""
        return list(self.database.keys())

    def keys(self):
        if len(self.weakly_labeled_set) == 0 and len(self.strongly_labeled_set)==0:
            return list(self.database.keys())
        else:
            return list(self.strongly_labeled_set.keys())
