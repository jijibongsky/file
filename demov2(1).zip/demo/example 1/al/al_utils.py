from al.al_algos import *
from al.al_data_loader import QueryRepo
from al.train_test_func import *
import datetime
import psutil
from queue import PriorityQueue

POS_BOX = 25.5
NEG_BOX = 1.6
OUT_BOX = 1.6
WATCH_IMAGE = 7.8
CENTER_POINT = 3


class HeapItem:
    def __init__(self, p, t):
        self.p = p
        self.t = t

    def __lt__(self, other):
        return self.p < other.p

    def __getitem__(self, idx):
        if idx == 0:
            return self.p
        else:
            return self.t

    def __getstate__(self):
        return self.p, self.t

    def __setstate__(self, state):
        self.p, self.t = state


def calc_cost(boxes):
    """box: img, class, x, y, w, h

    verifying cost if class < 0
    annotation cost otherwise
    """
    veri_boxes = boxes[boxes[:, 1] < 0]
    veri_box_amount = len(veri_boxes)
    return veri_box_amount * NEG_BOX + (len(boxes) - veri_box_amount) * POS_BOX + WATCH_IMAGE


def labeling_and_calc_partial_cost(gt_boxes, queried_box, label_map, img_size=416):
    """partially labeling examples.

    :param gt_boxes: targets from source gt dataloader. index must not be mapped to target class space
    :param queried_box: queried_boxes. After NMS. (x1, y1, x2, y2, al_score, class_conf, class)
    :param label_map: dict
    :return:
    label, cost. The class has not been mapped to target classes.
    """
    queried_gt = None
    cost = 0
    btype = []
    assert gt_boxes is not None and len(gt_boxes) > 0
    # convert to gt format
    rel_coord_qb = xyxy2xywh(queried_box[:4].unsqueeze(0)) / img_size
    # validity checking
    q_coord = rel_coord_qb[0][:4]
    q_coord[q_coord < 0] = 0
    q_coord[q_coord > 1] = 1
    rel_coord_qb[0][:4] = q_coord

    iou = bbox_iou(rel_coord_qb.squeeze(0), gt_boxes[:, 2:], x1y1x2y2=False)
    overlap_iou = bbox_overlap_iou(rel_coord_qb.squeeze(0), gt_boxes[:, 2:], x1y1x2y2=False)
    # part area quering
    queried_gt = gt_boxes[(iou > 0.3) | (overlap_iou > 0.7)]

    has_pos = False
    if len(queried_gt) > 0:
        # fg
        tgt_pos_mask = [True] * queried_gt.shape[0]
        for ti, target in enumerate(queried_gt):
            if int(target[1]) in label_map.keys():
                cost += POS_BOX
                btype.append(1)
                has_pos = True
            else:
                tgt_pos_mask[ti] = False
        queried_gt = queried_gt[tgt_pos_mask]
        if not has_pos:
            queried_gt = torch.cat((torch.tensor([[0.0, -2.0]]), rel_coord_qb.clone()), dim=1)
            cost += OUT_BOX
            btype.append(-2)
    else:
        # bg, class is -1
        queried_gt = torch.cat((torch.tensor([[0.0, -1.0]]), rel_coord_qb.clone()), dim=1)
        cost += NEG_BOX
        btype.append(-1)

    return queried_gt, cost, np.asarray(btype)


def al_mainloop(scoring_arr, src_gt_ds, queried_repo, lab_arr, unlab_arr,
                budget, method_name, iteration, src2tgt_label_map, save_res=True,
                save_root="/data/saved_al/", fold=0, save_suffix=""):
    """AL main loop"""
    # assert method_name in ['least_conf', 'random', 'mean_conf', 'LS', 'img_trans',
    #                        'ADDA', 'our_trans', 'our_incons', 'our']
    assert src2tgt_label_map is not None
    # sort by value, descending order
    scores = sorted(scoring_arr.items(), key=lambda x: x[1], reverse=True)
    total_cost = 0
    current_iteration_repo = QueryRepo()

    # save sorted scores
    with open(os.path.join(save_root, f"{method_name}_{iteration}{('_' + str(fold)) if fold>0 else ''}{save_suffix}_sorted_scores.pkl"), 'wb') as f:
        pickle.dump(scoring_arr, f)

    # labeling, calc cost
    for item in scores:  # (img_path, score)
        # get ground truth
        _, targets, _, _ = src_gt_ds.get_item_by_path(item[0])
        # Filter out outlier classes

        tgt_mask = [True] * targets.shape[0]
        for ti, target in enumerate(targets):
            if target[1] >= 0:  # non-background, non-outlier classes
                if int(target[1]) in src2tgt_label_map.keys():
                    pass  # must not map the index to the tgt domain
                else:
                    tgt_mask[ti] = False
        targets = targets[tgt_mask, :]

        # calc cost
        if sum(tgt_mask) == 0:
            unlab_arr.difference_update(item[0])
            total_cost += WATCH_IMAGE
            queried_repo.tcost += WATCH_IMAGE
            current_iteration_repo.tcost += WATCH_IMAGE
            queried_repo.skipped_image += 1
            current_iteration_repo.skipped_image += 1
            queried_repo.empty_image_list.append(item[0])
            current_iteration_repo.empty_image_list.append(item[0])
            # queried_repo.update(img_path=item[0], im_info=1, gt_boxes=[],
            #                 num_pos=0, num_neg=0, num_outlier=len(tgt_mask), cost=7.8,
            #                 domain_label=1, iteration=iteration, method_name=method_name)
            # current_iteration_repo.update(img_path=item[0], im_info=1, gt_boxes=[],
            #                     num_pos=0, num_neg=0, num_outlier=len(tgt_mask), cost=7.8,
            #                     domain_label=1, iteration=iteration, method_name=method_name)
            continue
        cost = calc_cost(targets)
        total_cost += cost

        # update repo
        queried_repo.update(img_path=item[0], im_info=1, gt_boxes=targets,
                            num_pos=len(targets), num_neg=0, num_outlier=0, cost=cost,
                            domain_label=1, iteration=iteration, method_name=method_name)

        # record queries in this iteration
        current_iteration_repo.update(img_path=item[0], im_info=1, gt_boxes=targets,
                                      num_pos=len(targets), num_neg=0, num_outlier=0, cost=cost,
                                      domain_label=1, iteration=iteration, method_name=method_name)

        # update index
        lab_arr.update(item[0])
        unlab_arr.difference_update(item[0])

        if total_cost > budget:
            break

    if save_res:
        # record queries in this iteration
        with open(os.path.join(save_root, f"{method_name}_{iteration}{('_' + str(fold)) if fold>0 else ''}{save_suffix}.pkl"), 'wb') as f:
            pickle.dump(current_iteration_repo, f)

        # record all queries until now
        with open(os.path.join(save_root, f"{method_name}_{iteration}{('_' + str(fold)) if fold>0 else ''}{save_suffix}_all.pkl"), 'wb') as f:
            pickle.dump(queried_repo, f)

        # record labeling statistic
        with open(os.path.join(save_root, f"{method_name}_{iteration}{('_' + str(fold)) if fold>0 else ''}{save_suffix}_statistic.txt"), 'w') as f:
            f.write(f"total_cost:{total_cost}, labeled image num:{len(current_iteration_repo)}")

    print(f"{method_name} labeling end. Total cost: {total_cost}\texample: {len(queried_repo)}")

    # return query_arr, cost
    return queried_repo, total_cost


def our_al_mainloop(scoring_arr, src_gt_ds, queried_repo, budget, method_name, iteration,
                    src2tgt_label_map, static_type=False, save_suffix='', save_res=True,
                    save_root="/data/saved_al/", fully_labeled_thres=4, fold=0):
    """AL main loop"""
    assert 'our' in method_name or 'ins' in method_name
    assert src2tgt_label_map is not None
    start_time = time.clock()

    # combine sort by value, descending order
    pq = PriorityQueue()  # element: (img_name, box) maxsize=budget, low means higher priority
    for k in scoring_arr.keys():
        for box in scoring_arr[k]:
            pq.put((-float(box[4]), HeapItem(k, box)), block=False)

    # scores = sorted(scoring_arr.items(), key=lambda x: x[1], reverse=True)

    typ1 = 0    # high conf
    typ2 = 0    # low conf

    total_cost = 0
    total_pos, total_neg, total_out = 0, 0, 0
    current_iteration_repo = QueryRepo()

    # labeling, calc cost
    for i in range(pq.qsize()):  # (img_path, score)
        # get ground truth
        pair = pq.get(block=False)
        item = pair[1]
        if item[0] in queried_repo.fs_database:
            # has already fully labeled
            continue
        _, targets, _, _ = src_gt_ds.get_item_by_path(item[0])

        if len(targets) == 0:   # missing GT
            continue

        # check if the query times is more than 4
        if item[0] in queried_repo:
            al_queried_boxes = queried_repo[item[0]][0]
            ar_q_num = len(al_queried_boxes)
            if ar_q_num >= fully_labeled_thres:
                # fully labeling and continue
                queried_repo.fs_database.append(item[0])
                queried_repo.database.pop(item[0])
                # sum number of queried gt
                queried_tgt_box_num = torch.sum(al_queried_boxes[:, 1] > 0)
                # static the number of target GT
                tgt_cls_num = 0
                for tid in targets:
                    if int(tid[1]) in src2tgt_label_map.keys():
                        # target class
                        tgt_cls_num += 1
                assert tgt_cls_num >= queried_tgt_box_num
                # calc cost
                total_cost += WATCH_IMAGE
                total_cost += POS_BOX * (tgt_cls_num-queried_tgt_box_num)
                continue

        if static_type:
            if item[1][5] > 0.5:
                typ1 += 1
            else:
                typ2 += 1

        # labeling
        queried_gt, cost, btype = labeling_and_calc_partial_cost(gt_boxes=targets, queried_box=item[1],
                                                                 label_map=src2tgt_label_map)

        # check if the gt is in the repo
        if item[0] in queried_repo:
            qgt_mask = [True]*len(queried_gt)
            for iq, qgt_box in enumerate(queried_gt):
                # the following code does not work when the q boxes are very close. Use IoU instead
                # if qgt_box in al_queried_boxes
                iou = bbox_iou(qgt_box[2:], al_queried_boxes[:, 2:], x1y1x2y2=False)
                if torch.max(iou) > 0.9:
                    if qgt_box[1] > 0:
                        cost -= POS_BOX
                    else:
                        cost -= NEG_BOX
                    qgt_mask[iq] = False
            if sum(qgt_mask) == 0:
                continue
            queried_gt = queried_gt[qgt_mask]
            btype = btype[qgt_mask]

        assert len(queried_gt) > 0, f'empty query is found.'

        # add cost
        total_cost += cost

        num_pos = np.sum(btype == 1)
        num_neg = np.sum(btype == -1)
        num_outlier = np.sum(btype == -2)
        total_pos += num_pos
        total_neg += num_neg
        total_out += num_outlier

        # update repo
        queried_repo.update(img_path=item[0], im_info=0, gt_boxes=queried_gt,
                            num_pos=num_pos, num_neg=num_neg, num_outlier=num_outlier, cost=cost,
                            domain_label=1, iteration=iteration, method_name=method_name, score=-pair[0])

        # record queries in this iteration
        current_iteration_repo.update(img_path=item[0], im_info=0, gt_boxes=queried_gt,
                                      num_pos=num_pos, num_neg=num_neg, num_outlier=num_outlier, cost=cost,
                                      domain_label=1, iteration=iteration, method_name=method_name, score=-pair[0])

        if total_cost > budget:
            break

        print(
            f"\rlabeling: {total_cost:0.1f}/{budget:.1f}\t\tpos num: {total_pos}\t\tneg num: {total_neg}\t\tout num: {total_out}",
            end='')
        if static_type:
            print(f"\t high conf:{typ1}\t low conf: {typ2}", end='')

    if save_res:
        # save the sorted heap
        with open(os.path.join(save_root, f"{method_name}_{iteration}"
                  f"{'' if len(save_suffix) == 0 else '_' + save_suffix}_sorted_score{('_' + str(fold)) if fold>0 else ''}.pkl"),
                  'wb') as f:
            pickle.dump(scoring_arr, f)

        # record queries in this iteration
        with open(os.path.join(save_root, f"{method_name}_{iteration}{'' if len(save_suffix)==0 else '_'+save_suffix}{('_' + str(fold)) if fold>0 else ''}.pkl"), 'wb') as f:
            pickle.dump(current_iteration_repo, f)

        # record all queries until now
        with open(os.path.join(save_root, f"{method_name}_{iteration}{'' if len(save_suffix)==0 else '_'+save_suffix}{('_' + str(fold)) if fold>0 else ''}_all.pkl"), 'wb') as f:
            pickle.dump(queried_repo, f)

        # record labeling statistic
        with open(os.path.join(save_root, f"{method_name}_{iteration}{'' if len(save_suffix)==0 else '_'+save_suffix}{('_' + str(fold)) if fold>0 else ''}_statistic.txt"), 'w') as f:
            f.write(f"pos num: {total_pos}{os.linesep}neg num: {total_neg}{os.linesep}"
                    f"out num: {total_out}{os.linesep}example: {len(current_iteration_repo)}{os.linesep}"
                    f"total_cost:{total_cost}{os.linesep}, fully_ann: {len(queried_repo.fs_database)}{os.linesep}")
            if static_type:
                f.write(f"high conf:{typ1}{os.linesep}low conf: {typ2}{os.linesep}")

    print()
    print(f"{method_name} labeling end. Total cost: {total_cost}\texample: {len(queried_repo)}\tfully_sp_exa:{len(queried_repo.fs_database)}")
    print("\nLabeling instances end in %s " % datetime.timedelta(seconds=(time.clock() - start_time)))

    # return query_arr, cost
    return queried_repo, total_cost, (total_pos, total_neg, total_out)


def statisticc_instances(label_list, src2tgt, t_gt_ds):
    """statistic the number of instances of each class in target domain."""
    statistic = dict()
    # For source domain
    for i, file in enumerate(label_list):
        try:
            with open(file.replace('image', 'label').replace('.jpg', '.txt').replace('.png', '.txt'), 'r') as f:
                l = np.array([x.split() for x in f.read().splitlines()], dtype=np.float32)
        except:
            print(f"{file} file missing")
            continue

        if l.shape[0]:
            for box in l:
                if int(box[0]) in src2tgt.keys():
                    class_ind = src2tgt[int(box[0])]
                    if class_ind not in statistic:
                        statistic[class_ind] = 1
                    else:
                        statistic[class_ind] += 1

    # For target domain
    for i, targets in enumerate(t_gt_ds.labels):
        if targets.shape[0]:
            for box in targets:
                class_ind = int(box[0])
                if class_ind not in statistic:
                    statistic[class_ind] = 1
                else:
                    statistic[class_ind] += 1

    return statistic


def al_scoring(unlab_arr, model, s_gt_ds, method_name, cocoid2vocid=None, queried_repo=None, test=False,
               acl: 'float' = 1, lab_set:'list'=None, t_gt_ds=None, number_of_classes=0, **kwargs):
    # assert method_name in ['least_conf', 'random', 'mean_conf', 'LS', 'img_trans',
    #                        'ADDA', 'our_trans', 'our_incons', 'our']

    start_time = time.clock()
    total_cand_boxes_num = 0

    skipped = 0
    scoring = dict()
    ######################################## Active Learning ###############################################
    # predict the unlabeled set
    model.eval()
    if method_name == 'margin_avg':
        assert lab_set is not None
        assert t_gt_ds is not None
        assert number_of_classes > 0
        ins_arr = statisticc_instances(lab_set, cocoid2vocid, t_gt_ds)
        classes_num = number_of_classes
        ins_num_arr = []
        for cla in range(classes_num):
            if cla in ins_arr:
                ins_num_arr.append(float(ins_arr[cla]))
            else:
                ins_num_arr.append(0)

    for i, img_path in enumerate(unlab_arr):
        if test and i > 100:
            break
        if acl < 1:
            # random skip images for speed.
            if np.random.uniform() > acl:
                skipped += 1
                continue
        imgs, targets, img_path2, _ = s_gt_ds.get_item_by_path(img_path)
        imgs = imgs.unsqueeze(0).to(device)
        # targets = targets.to(device)
        domain_label = torch.zeros(imgs.shape[0]).to(device)

        # Run model
        inf_out, train_out, da_out = model(imgs, domain_label=domain_label)  # inference and training outputs
        # Run NMS
        # class_conf, _ = inf_out[0, :, 5:].max(1)
        # max_conf = torch.max(class_conf*inf_out[0, :, 4])
        # conf_thres = 0.5 if max_conf > 0.5 else max(0.01, max_conf - 0.1)

        #  Returns detections with shape:
        #  (x1, y1, x2, y2, object_conf, class_conf, class)
        if method_name == 'LS':
            output = non_max_suppression(inf_out, conf_thres=0.3)
        elif 'margin_avg' == method_name:
            output = non_max_suppression(inf_out, conf_thres=0.5)
        else:
            output = non_max_suppression(inf_out, conf_thres=0.01)
        # while output[0] is None:
        #     conf_thres -= 0.1
        #     output = non_max_suppression(inf_out, conf_thres=max(conf_thres, 0.01))

        # scoring
        if method_name == 'margin_avg':
            # ins_arr = statisticc_instances(lab_set)
            # classes_num = len(ins_arr)
            # ins_num_arr = []
            # for cla in range(classes_num):
            #     ins_num_arr.append(float(ins_arr[cla]))
            scoring[img_path] = margin_avg_scorer(output, num_ins_class=ins_num_arr, const_numerator=classes_num+sum(ins_num_arr))
        elif 'uncertain_map' in method_name:
            if '0' in method_name:
                scale=0
            elif '2' in method_name:
                scale=2
            else:
                scale=1
            scoring[img_path] = uncertain_map(train_out, scale=scale)
        elif method_name == 'least_conf' or method_name == 'click_spvs':
            scoring[img_path] = least_confidence_scorer(inf_out)
        elif method_name == 'mean_conf':
            scoring[img_path] = uncertainty_mean_conf_scorer(output)
        elif method_name == 'random':
            scoring[img_path] = torch.tensor(random_scorer()).to(device)
        elif method_name == 'img_trans':
            scoring[img_path] = img_trans_score(da_out[0])
        elif method_name == 'ADDA':
            scoring[img_path] = AADA_scoring_example(trans_score=img_trans_score(da_out[0]),
                                                     unc_score=least_confidence_scorer(inf_out))
        elif method_name == 'LS':
            scoring[img_path] = uncertainty_LS_scoring_example(model, imgs, output, device=device)
        elif method_name == 'random_ins':
            rand_score = random_scoring_anchor_boxes(train_out)

            # get queried boxes for NMS
            if img_path in queried_repo:
                targets, metainfo = queried_repo[img_path]

                # targets in repo will contains bg and outlier and unmapped labels
                # tgt_mask = [True] * targets.shape[0]
                for ti, target in enumerate(targets):
                    if int(target[1]) in cocoid2vocid.keys():
                        target[1] = cocoid2vocid[int(target[1])]
                    else:
                        pass
                # targets = targets[tgt_mask, :]
            else:
                targets = None

            rand_cand_boxes = get_candidate_boxes(train_out, rand_score, model, gt_boxes=targets,
                                                  score_thres=0.9)
            if rand_cand_boxes[0] is not None and len(rand_cand_boxes[0]) > 0:
                scoring[img_path] = rand_cand_boxes[0]
                total_cand_boxes_num += len(rand_cand_boxes[0])
            #
            # if i % 10 == 0:
            #     print(f"\rscoring examples: {i}/{len(unlab_arr)}\t "
            #           f"cand boxes: {total_cand_boxes_num}\t "
            #           f"time elapse: {datetime.timedelta(seconds=int(time.clock() - start_time))}\t "
            #           f"ETA: {datetime.timedelta(seconds=int(len(unlab_arr) / max(i, 1) * (time.clock() - start_time)))}\t "
            #           f"skipped images: {skipped}", end='')

        # ours
        elif 'our' in method_name:
            assert cocoid2vocid is not None
            assert queried_repo is not None

            if len(kwargs) > 0:
                incons_score, trans_score, total_scores = our_scoring_anchor_boxes(train_out, da_out[1:],
                                                                                   img_da_output=da_out[0],
                                                                                   **kwargs)
            else:
                incons_score, trans_score, total_scores = our_scoring_anchor_boxes(train_out, da_out[1:],
                                                                                   img_da_output=da_out[0])
            # get queried boxes for NMS
            if img_path in queried_repo:
                targets, metainfo = queried_repo[img_path]

                # targets in repo will contains bg and outlier and unmapped labels
                # tgt_mask = [True] * targets.shape[0]
                for ti, target in enumerate(targets):
                    if int(target[1]) in cocoid2vocid.keys():
                        target[1] = cocoid2vocid[int(target[1])]
                    else:
                        pass
                # targets = targets[tgt_mask, :]
            else:
                targets = None

            # filter out low score, overlapped boxes
            if 'incons' in method_name:
                incons_cand_boxes = get_candidate_boxes(train_out, incons_score, model, gt_boxes=targets,
                                                        score_thres=0.004)
                if incons_cand_boxes[0] is not None and len(incons_cand_boxes[0]) > 0:
                    scoring[img_path] = incons_cand_boxes[0]
                    total_cand_boxes_num += len(incons_cand_boxes[0])
                # elif len(incons_cand_boxes[0]) > 100:
                #     print('Too much cand box')
            elif 'trans' in method_name:
                trans_cand_boxes = get_candidate_boxes(train_out, trans_score, model, gt_boxes=targets,
                                                       score_thres=0.45)
                if trans_cand_boxes[0] is not None and len(trans_cand_boxes[0]) > 0:
                    scoring[img_path] = trans_cand_boxes[0]
                    total_cand_boxes_num += len(trans_cand_boxes[0])
                # elif len(trans_cand_boxes[0]) > 100:
                #     print('Too much cand box')
            else:
                final_cand_boxes = get_candidate_boxes(train_out, total_scores, model, gt_boxes=targets,
                                                       score_thres=0.002)
                # update candidate set
                if final_cand_boxes[0] is not None and len(final_cand_boxes[0]) > 0:
                    scoring[img_path] = final_cand_boxes[0]
                    total_cand_boxes_num += len(final_cand_boxes[0])
                # elif len(final_cand_boxes[0]) > 100:
                #     print('Too much cand box')



        else:
            raise KeyError(f"method name {method_name} can not be recognized.")

        if i % 100 == 0:

            if 'our' in method_name or 'ins' in method_name:
                print(f"\rscoring examples: {i}/{len(unlab_arr)}\t "
                      f"cand boxes: {total_cand_boxes_num}\t "
                      f"time elapse: {datetime.timedelta(seconds=int(time.clock() - start_time))}\t "
                      f"ETA: {datetime.timedelta(seconds=int(len(unlab_arr) / max(i, 1) * (time.clock() - start_time)))}\t "
                      f"skipped images: {skipped}", end='')
            else:
                print(f"\rscoring examples: {i}/{len(unlab_arr)}\t "
                      f"time elapse: {datetime.timedelta(seconds=int(time.clock() - start_time))}\t "
                      f"ETA: {datetime.timedelta(seconds=int(len(unlab_arr) / max(i, 1) * (time.clock() - start_time)))}\t"
                      f"skipped images: {skipped}", end='')

    print()
    print(str(psutil.virtual_memory()))
    # end query
    end_time = time.clock()
    # datetime.timedelta
    print("\nScoring examples end in %s " % datetime.timedelta(seconds=(end_time - start_time)))
    return scoring


def al_scoring_our_debug(unlab_arr, model, s_gt_ds, method_name,
                         cocoid2vocid=None, queried_repo=None, test=False,
                         acl: 'float' = 1, use_new_func=False,
                         pos_ins_weight=0.05,
                         da_tradeoff=10,
                         min_area=15):
    # assert method_name in ['least_conf', 'random', 'mean_conf', 'LS', 'img_trans',
    #                        'ADDA', 'our_trans', 'our_incons', 'our']

    # for static
    # unc_ndarr = np.array([])

    start_time = time.clock()
    total_cand_boxes_num = 0

    skipped = 0
    scoring = dict()
    ######################################## Active Learning ###############################################
    # predict the unlabeled set
    model.eval()

    for i, img_path in enumerate(unlab_arr):
        if test and i > 100:
            break
        if acl < 1:
            # random skip images for speed.
            if np.random.uniform() > acl:
                skipped += 1
                continue
        imgs, targets, img_path2, _ = s_gt_ds.get_item_by_path(img_path)
        imgs = imgs.unsqueeze(0).to(device)
        # targets = targets.to(device)
        domain_label = torch.zeros(imgs.shape[0]).to(device)

        # Run model
        inf_out, train_out, da_out = model(imgs, domain_label=domain_label)  # inference and training outputs
        # Run NMS
        # class_conf, _ = inf_out[0, :, 5:].max(1)
        # max_conf = torch.max(class_conf*inf_out[0, :, 4])
        # conf_thres = 0.5 if max_conf > 0.5 else max(0.01, max_conf - 0.1)

        #  Returns detections with shape:
        #  (x1, y1, x2, y2, object_conf, class_conf, class)
        # if method_name == 'LS':
        #     output = non_max_suppression(inf_out, conf_thres=0.3)
        # else:
        #     output = non_max_suppression(inf_out, conf_thres=0.01)

        # scoring
        if not use_new_func:
            incons_score, trans_score, total_scores = our_scoring_anchor_boxes(train_out, da_out[1:],
                                                                               img_da_output=da_out[0],
                                                                               pos_ins_weight=pos_ins_weight,
                                                                               da_tradeoff=da_tradeoff)
        else:
            total_scores = our_scoring_indicator(train_out, da_out[1:],
                                                img_da_output=da_out[0],
                                                da_tradeoff=da_tradeoff)
        if 'trans' in method_name:
            total_scores = trans_score
        elif 'incons' in method_name:
            total_scores = incons_score
        elif 'unc' in method_name:
            total_scores = unc_instance_scorer(train_out)
        # for ts in incons_score:
        #     unc_ndarr = np.hstack((unc_ndarr, ts.clone().reshape(-1).cpu().numpy()))

        # get queried boxes for NMS
        if img_path in queried_repo:
            targets, metainfo = queried_repo[img_path]

            # targets in repo will contains bg and outlier and unmapped labels
            # tgt_mask = [True] * targets.shape[0]
            for ti, target in enumerate(targets):
                if int(target[1]) in cocoid2vocid.keys():
                    target[1] = cocoid2vocid[int(target[1])]
                else:
                    pass
            # targets = targets[tgt_mask, :]
        else:
            targets = None

        # filter out low score, overlapped boxes
        final_cand_boxes = get_candidate_boxes(train_out, total_scores, model, gt_boxes=targets,
                                               score_thres=0.1, store_part=True,
                                               part_array=[torch.sigmoid(train_out[i][..., 4]) for i in range(3)],
                                               min_area=min_area)
        # update candidate set
        if final_cand_boxes[0] is not None and len(final_cand_boxes[0]) > 0:
            scoring[img_path] = final_cand_boxes[0]
            total_cand_boxes_num += len(final_cand_boxes[0])

        if i % 100 == 0:
            # with open('/data/saved_model/for_sta.pkl', 'wb') as f:
            #     pickle.dump(unc_ndarr, f)

            if 'our' in method_name or 'ins' in method_name:
                print(f"\rscoring examples: {i}/{len(unlab_arr)}\t "
                      f"cand boxes: {total_cand_boxes_num}\t "
                      f"time elapse: {datetime.timedelta(seconds=int(time.clock() - start_time))}\t "
                      f"ETA: {datetime.timedelta(seconds=int(len(unlab_arr) / max(i, 1) * (time.clock() - start_time)))}\t "
                      f"skipped images: {skipped}", end='')
            else:
                print(f"\rscoring examples: {i}/{len(unlab_arr)}\t "
                      f"time elapse: {datetime.timedelta(seconds=int(time.clock() - start_time))}\t "
                      f"ETA: {datetime.timedelta(seconds=int(len(unlab_arr) / max(i, 1) * (time.clock() - start_time)))}", end='')

    print()
    print(str(psutil.virtual_memory()))
    # end query
    end_time = time.clock()
    # datetime.timedelta
    print("\nScoring examples end in %s " % datetime.timedelta(seconds=(end_time - start_time)))
    return scoring


def al_loop_click_supervision(lc_scores, budget, queried_repo, dataset_name, src_gt_ds, model, src2tgt_lab_ind,
                              lab_arr, unlab_arr, method_name, iteration, wvss=2 / 1, fold=0, save_res=True, save_root=None):
    """AL with point supervision for cost-effective panicle detection in
    cereal crops. In Plant Method 2020.
    The click supervision is coming from CVPR17.
    This method first weakly labels a set of images with the center points of objects.
    Then the image uncertainty is calculated by the inconsistency between center point and
    predicted boxes. The number of strongly labeled examples should be a half of weakly labeled ones.
    Note that, there are 3 types of aggregation methods for images scores in the reference paper,
    we use the 'mev' method which performs the best according to the experimental results
    reported by the original paper.

    The cost of each center point annotation is 3. boudning box is 25.5

    Hyperparameters:
    obj_per_img:
    CITY_VOC: 1.5, COCO: 4.26, KITTI_CITY: 16, COVID_PNEU:0.483

    Cityscapes to Kitti:
    epsilon: 29.714347171783455
    alpha: 3152.039794921875

    CITY_VOC:
    epsilon: 68.29751443862915
    alpha: 97427.5859375

    VOC_COCO:
    epsilon: 54.386591053009035
    alpha: 49101.865234375015

    COVID_PNEU:
    epsilon: 142.796240234375
    alpha: 57951.616796875

    :param lc_scores: The least confidence score of each image.
    :param budget: The total budget
    :param wvss: ratio of Weakly labeled examples VS Strongly labeled examples.
    :param obj_per_img: float, the average number of objects in the images in source domain.
    :param model: YOLOv3 model.
    :param src2tgt_lab_ind: label mapping dict
    :param queried_repo:
    :return:
    """
    lambda1 = 1
    lambda2 = 4
    if dataset_name == 'voc':
        obj_per_img = 4.26
        epsilon=54.386591053009035
        alpha=49101.865234375015
    elif dataset_name == 'kitti':
        obj_per_img = 16
        epsilon=29.714347171783455
        alpha=3152.039794921875
    elif dataset_name == 'city':
        obj_per_img = 3
        epsilon = 68.29751443862915
        alpha = 97427.5859375
    elif dataset_name == 'covid':
        obj_per_img = 1.5
        epsilon=142.796240234375
        alpha=57951.616796875
    else:
        raise ValueError(f"Unrecognized dataset name: {dataset_name}")
    # sort by value, descending order
    model.eval()
    scores = sorted(lc_scores.items(), key=lambda x: x[1], reverse=True)
    # estimate the number of examples for weakly labeling.
    nqs = budget / ((WATCH_IMAGE + CENTER_POINT*obj_per_img)*wvss + POS_BOX*obj_per_img)
    nqw = 2 * nqs
    labeling_cost = 0

    wl_cost = 0
    ############################# weak label #################################################
    wl_examples_num = 0
    labeled_point_num = 0
    # labeling, calc cost
    for item in scores:  # (img_path, score)
        # get ground truth
        _, targets, _, _ = src_gt_ds.get_item_by_path(item[0])
        # Filter out outlier classes

        tgt_mask = [True] * targets.shape[0]
        for ti, target in enumerate(targets):
            if target[1] >= 0:  # non-background, non-outlier classes
                if int(target[1]) in src2tgt_lab_ind.keys():
                    target[1] = src2tgt_lab_ind[int(target[1])]
                else:
                    tgt_mask[ti] = False
        targets = targets[tgt_mask, :]

        # calc cost
        if sum(tgt_mask) == 0:
            wl_cost += WATCH_IMAGE
            queried_repo.update_weak(img_path=item[0], im_info=1, gt_boxes=targets,
                                num_pos=len(targets))
            lab_arr.update(item[0])
            unlab_arr.difference_update(item[0])
            continue
        wl_cost += WATCH_IMAGE
        wl_cost += CENTER_POINT*len(targets)
        labeled_point_num += len(targets)

        # update repo
        queried_repo.update_weak(img_path=item[0], im_info=1, gt_boxes=targets,
                                num_pos=len(targets))

        # update index
        lab_arr.update(item[0])
        unlab_arr.difference_update(item[0])

        wl_examples_num += 1
        # if wl_examples_num > nqw:
        #     break
        if (budget-wl_cost) - (labeled_point_num/wvss)*POS_BOX < 0:
            break


    ############################# strong label #################################################
    labeling_cost += wl_cost

    # get prediction for each weakly labeled data
    wkl_data_list = list(queried_repo.weakly_labeled_set.keys())
    scores = dict()
    for img_path in wkl_data_list:
        imgs, targets, img_path2, _ = src_gt_ds.get_item_by_path(img_path)
        tgt_mask = [True] * targets.shape[0]
        for ti, target in enumerate(targets):
            if target[1] >= 0:  # non-background, non-outlier classes
                if int(target[1]) in src2tgt_lab_ind.keys():
                    target[1] = src2tgt_lab_ind[int(target[1])]
                else:
                    tgt_mask[ti] = False
        targets = targets[tgt_mask, :]
        if len(targets) == 0:
            continue
        imgs = imgs.unsqueeze(0).to(device)
        # targets = targets.to(device)
        domain_label = torch.zeros(imgs.shape[0]).to(device)

        # Run model
        with torch.no_grad():
            inf_out, _, _ = model(imgs, domain_label=domain_label)  # inference and training outputs
        # xywh(abs value)objectness + class predictions

        # get center points
        center_points = []
        class_labels = []
        if len(targets.shape) == 1:
            center_points.append((416 * targets[2], 416 * targets[3]))
            class_labels.append(targets[1])
        else:
            for tar in targets:
                center_points.append((416 * tar[2], 416 * tar[3]))
                class_labels.append(tar[1])

        # apply the RPF to filter boxes
        # 1. must contain the center point
        # 2. the distance between box center and the labeled center point is less than \epsilon
        # 3. box area is less than \alpha
        anch_boxes = inf_out[0]
        anch_boxes_xy = xywh2xyxy(anch_boxes[:, 0:4])
        ct_anchors = dict()
        for icp, cp in enumerate(center_points):
            # contain
            valid_idx = (anch_boxes_xy[:, 0] < cp[0].to('cuda:0')) * (anch_boxes_xy[:, 2] > cp[0].to('cuda:0')) * \
                        (anch_boxes_xy[:, 1] < cp[1].to('cuda:0')) * (anch_boxes_xy[:, 3] > cp[1].to('cuda:0'))
            tmp = anch_boxes[valid_idx]
            if len(tmp) == 0:
                continue
            # nearing
            valid_idx = torch.sqrt((tmp[:, 0] - cp[0].to('cuda:0'))**2 + (tmp[:, 1] - cp[1].to('cuda:0'))**2) < epsilon
            tmp = tmp[valid_idx]
            if len(tmp) == 0:
                continue
            # area
            valid_idx = (tmp[:, 2] * tmp[:, 3]) < alpha
            tmp = tmp[valid_idx]
            if len(tmp) == 0:
                continue
            ct_anchors[icp] = tmp

        if len(ct_anchors)==0:
            continue
        # calc score
        max_mv = -np.inf
        max_me = -np.inf
        for icp, cp_boxes in ct_anchors.items():
            cla_lab = class_labels[icp]
            cls_arr = cp_boxes[:, int(cla_lab) + 5]
            # 1. max-variance (mv) score
            pmean = torch.mean(cls_arr)
            mv_score = torch.sum(cls_arr - pmean)/len(cp_boxes)

            # 2. max-entropy (me) score
            interme_score = -cls_arr*torch.log2(cls_arr)-(1-cls_arr)*torch.log2(1-cls_arr)
            me_score = torch.sum(interme_score)/len(cp_boxes)

            if mv_score > max_mv:
                max_mv = mv_score
            if me_score > max_me:
                max_me = me_score

        # weighted sum
        mev_score = lambda1*max_me + lambda2*max_mv
        # record scores
        scores[img_path] = mev_score

    ################ labeling ################################################################
    # sort scores, labeling
    scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)

    # labeling, calc cost
    for item in scores:  # (img_path, score)
        objects_num = len(queried_repo.weakly_labeled_set[item[0]])
        assert objects_num > 0
        queried_repo.update_strong(item[0])
        labeling_cost += objects_num * POS_BOX

        # # update index
        # lab_arr.update(item[0])
        # unlab_arr.difference_update(item[0])

        if labeling_cost > budget:
            break

    if save_res:
        # record all queries until now
        with open(os.path.join(save_root, f"{method_name}_{iteration}{('_' + str(fold)) if fold>0 else ''}_all.pkl"), 'wb') as f:
            pickle.dump(queried_repo, f)

        # record labeling statistic
        with open(os.path.join(save_root, f"{method_name}_{iteration}{('_' + str(fold)) if fold>0 else ''}_statistic.txt"), 'w') as f:
            f.write(f"total_cost:{labeling_cost}, weakly labeled images:{wl_examples_num}, "
                    f"strongly labeled images:{len(queried_repo)}")

    print(f"{method_name} labeling end. Total cost: {labeling_cost}\tweakly labeled images:{wl_examples_num}, "
                    f"strongly labeled images:{len(queried_repo)}")
    return queried_repo, labeling_cost



