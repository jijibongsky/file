import torch.optim as optim
import torch.optim.lr_scheduler as lr_scheduler

from models_da import *
from utils.utils import *
from utils import torch_utils

hyp = {'giou': 1.582,  # giou loss gain
       'cls': 27.76,  # cls loss gain  (CE=~1.0, uCE=~20)
       'cls_pw': 1.446,  # cls BCELoss positive_weight
       'obj': 21.35,  # obj loss gain (*=80 for uBCE with 80 classes)
       'obj_pw': 3.941,  # obj BCELoss positive_weight
       'iou_t': 0.2635,  # iou training threshold
       'lr0': 0.002324,  # initial learning rate
       'lrf': -4.,  # final LambdaLR learning rate = lr0 * (10 ** lrf)
       'momentum': 0.97,  # SGD momentum
       'weight_decay': 0.0004569,  # optimizer weight decay
       'hsv_s': 0.5703,  # image HSV-Saturation augmentation (fraction)
       'hsv_v': 0.3174,  # image HSV-Value augmentation (fraction)
       'degrees': 1.113,  # image rotation (+/- deg)
       'translate': 0.06797,  # image translation (+/- fraction)
       'scale': 0.1059,  # image scale (+/- gain)
       'shear': 0.5768}  # image shear (+/- deg)


def load_model(model_path, num_classes=8):
    print("load checkpoint %s" % (model_path))
    pure_yolo = Darknet('cfg/yolov3-custom.cfg', arc='defaultpw')
    if not model_path.endswith('.pt'):
        load_darknet_weights(pure_yolo, model_path)
        model = Yolo_DA(pure_yolo)
    else:
        model = Yolo_DA(pure_yolo)
        weight_dict = torch.load(model_path)
        model.load_state_dict(weight_dict['model'])
    print('load model successfully!')
    model.nc = num_classes  # attach number of classes to model
    model.arc = 'defaultpw'  # attach yolo architecture
    model.hyp = hyp  # attach hyperparameters to model
    # model.class_weights = labels_to_class_weights(t_imdb.classes[1:], nc).to(device)  # attach class weights
    model.class_weights = torch.from_numpy(np.ones(8))
    model.yolo_layers = model.pure_yolo.yolo_layers

    return model


def train_model(model, s_dataloader, t_dataloader, optimizer=None, epochs=None, batch_size=1, accumulate=8):
    device = torch_utils.select_device(apex=False)
    if optimizer is None:
        # init optimizer
        pg0, pg1 = [], []  # optimizer parameter groups
        for k, v in dict(model.pure_yolo.named_parameters()).items():
            if 'Conv2d.weight' in k:
                pg1 += [v]  # parameter group 1 (apply weight_decay)
            else:
                pg0 += [v]  # parameter group 0
        optimizer = optim.SGD(pg0, lr=hyp['lr0'], momentum=hyp['momentum'], nesterov=True)

        pg0 = []
        for k, v in dict(model.yolo_imageDA.named_parameters()).items():
            pg0 += [v]
        optimizer.add_param_group({'params': pg0})

    scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=[round(epochs * x) for x in [0.8, 0.9]], gamma=0.1)
    scheduler.last_epoch = 0

    total_examples = len(s_dataloader)
    tgt_data_iter = iter(t_dataloader)
    if epochs is None:
        epochs = epochs
    for epoch in range(0, epochs):  # epoch ------------------------------------------------------------------
        model.train()
        # Update scheduler
        if epoch > 0:
            scheduler.step()

        for i, (imgs, im_info, targets, num_boxes,
                domain_label) in enumerate(s_dataloader):  # batch -------------------------------------------------------------
            ni = i + total_examples * epoch  # number integrated batches (since train start)
            imgs = imgs.to(device)
            # targets = targets[0]    # batch size is 1
            targets[:, :, 1] = targets[:, :, 1] - 1
            targets = targets[0]
            targets = targets.to(device)

            # get target domain data
            try:
                tgt_data = next(tgt_data_iter)
            except StopIteration:
                tgt_data_iter = iter(t_dataloader)
                tgt_data = next(tgt_data_iter)
            tgt_im_data, tgt_im_info, tgt_gt_boxes, tgt_num_boxes, tgt_domain_label = tgt_data
            tgt_im_data = tgt_im_data.to(device)
            tgt_gt_boxes[:, :, 1] = tgt_gt_boxes[:, :, 1] - 1
            tgt_gt_boxes = tgt_gt_boxes[0]
            tgt_gt_boxes = tgt_gt_boxes.to(device)
            # end load tgt data

            pred_src, pred_tgt, da_loss_src, da_loss_tgt, \
            da_output_src, da_output_tgt = model(imgs, torch.tensor([1.0]).to(device), tgt_im_data,
                                                 torch.tensor([0.0]).to(device), True, False)
            # Compute loss
            if 1:  # 1 fully supervised, 0 : patially supervised
                loss, loss_items = compute_loss(pred_src, targets, model)
            else:
                loss, loss_items = compute_partial_loss(pred_src, targets, None, model)
            if torch.isnan(loss):
                print('WARNING: nan loss detected, ending training')
                return results

            loss_tgt, loss_items_tgt = compute_loss(pred_tgt, tgt_gt_boxes, model)

            if torch.isnan(loss_tgt):
                print('WARNING: nan loss detected, ending training')
                return results

            # Scale loss by nominal batch_size of 64
            loss *= batch_size / 64
            loss_tgt *= batch_size / 64

            # Compute gradient
            (loss + loss_tgt + da_loss_src + da_loss_tgt).backward()

            # Accumulate gradient for x batches before optimizing
            if ni % accumulate == 0:
                optimizer.step()
                optimizer.zero_grad()

            print(f'\repoch: {epoch} \t example: {i}/{total_examples}', end='')
    return model


class ModelManager:
    """
    init: {'pretrain', 'ini_lab', 'last_saved'}
    """

    def __init__(self, num_classes: 'int', epochs: 'int', DA: 'bool' = True, init: 'str' = 'pretrain'):
        self.device = torch_utils.select_device(apex=False)
        pure_yolo = Darknet('cfg/yolov3-custom.cfg', arc='defaultpw').to(self.device)
        pg0, pg1 = [], []  # optimizer parameter groups
        for k, v in dict(pure_yolo.named_parameters()).items():
            if 'Conv2d.weight' in k:
                pg1 += [v]  # parameter group 1 (apply weight_decay)
            else:
                pg0 += [v]  # parameter group 0
        self.optimizer = optim.SGD(pg0, lr=hyp['lr0'], momentum=hyp['momentum'], nesterov=True)

        if init == 'pretrain':
            load_darknet_weights(pure_yolo, '/home/tangyingpeng/todal/darknet/darknet53.conv.74')

        self.model = Yolo_DA(pure_yolo).to(self.device)
        pg0 = []
        for k, v in dict(self.model.yolo_imageDA.named_parameters()).items():
            pg0 += [v]
        self.optimizer.add_param_group({'params': pg0})
        # optimizer_da = optim.SGD(pg0, lr=hyp['lr0'], momentum=hyp['momentum'], nesterov=True)
        del pg0
        if init == 'ini_lab':
            pass
        if init == 'last_saved':
            saved_pt = torch.load('weights/da_yolo_last.pt')
            self.model.load_state_dict(saved_pt['model'])
            self.start_epoch = saved_pt['epoch'] + 1
            self.optimizer.load_state_dict(saved_pt['optimizer'])
        else:
            self.start_epoch = 0

        self.scheduler = lr_scheduler.MultiStepLR(self.optimizer, milestones=[round(epochs * x) for x in [0.8, 0.9]],
                                                  gamma=0.1)
        self.scheduler.last_epoch = self.start_epoch - 1
        self.model.yolo_layers = self.model.pure_yolo.yolo_layers
        self.model.nc = num_classes  # attach number of classes to model
        self.model.arc = 'defaultpw'  # attach yolo architecture
        self.model.hyp = hyp  # attach hyperparameters to model
        # model.class_weights = labels_to_class_weights(t_imdb.classes[1:], nc).to(device)  # attach class weights
        self.model.class_weights = torch.ones(num_classes)
        self.epochs = epochs
        self.DA = DA

    def fit(self, dataloader, epochs=None):
        if epochs is None:
            epochs = self.epochs
        for epoch in range(self.start_epoch,
                           epochs):  # epoch ------------------------------------------------------------------
            model.train()
            # Update scheduler
            if epoch > 0:
                scheduler.step()

            for i, (imgs, im_info, targets, num_boxes,
                    domain_label) in dataloader:  # batch -------------------------------------------------------------
                ni = i + nb * epoch  # number integrated batches (since train start)
                imgs = imgs.to(device)
                # targets = targets[0]    # batch size is 1
                targets[:, :, 1] = targets[:, :, 1] - 1
                targets = targets[0]
                targets = targets.to(device)

                pred_src, pred_tgt, da_loss_src, da_loss_tgt, \
                da_output_src, da_output_tgt = model(imgs, torch.tensor([1.0]).to(device), tgt_im_data,
                                                     torch.tensor([0.0]).to(device), True, False)
                # Compute loss
                if 1:  # 1 fully supervised, 0 : patially supervised
                    loss, loss_items = compute_loss(pred_src, targets, model)
                else:
                    loss, loss_items = compute_partial_loss(pred_src, targets, None, model)
                if torch.isnan(loss):
                    print('WARNING: nan loss detected, ending training')
                    return results

                loss_tgt, loss_items_tgt = compute_loss(pred_tgt, tgt_gt_boxes, model)

                if torch.isnan(loss_tgt):
                    print('WARNING: nan loss detected, ending training')
                    return results

                # Scale loss by nominal batch_size of 64
                loss *= batch_size / 64
                loss_tgt *= batch_size / 64

                # Compute gradient
                (loss + loss_tgt + da_loss_src + da_loss_tgt).backward()

                # Accumulate gradient for x batches before optimizing
                if ni % accumulate == 0:
                    optimizer.step()
                    optimizer.zero_grad()
