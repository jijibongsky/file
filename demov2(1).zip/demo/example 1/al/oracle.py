from .al_data_loader import get_gt_loader
from utils.utils import wh_iou, bbox_iou

__all__ = ['instance_oracle', 'example_oracle']


def annotate(pred_box, gt_boxes):
    """

    :param pred_box: xywh, one box
    :param gt_boxes: xywh, multiple boxes
    :return: pos_ins, pos_num, neg_ins, neg_num
    """
    pos_ins = []
    neg_ins = []
    for gt_box in gt_boxes:
        iou = bbox_iou(pred_box, gt_box, x1y1x2y2=False, GIoU=False)
        if iou > 0.5:
            # label true
            pos_ins.append(gt_box)
    if len(pos_ins) == 0:
        # neg instance
        neg_ins.append(pred_box)
    return pos_ins, len(pos_ins), neg_ins, len(neg_ins)


class instance_oracle:
    def __init__(self, gt_dataloader, box_cost=26, verification_cost=1.6):
        self.cost_box = box_cost
        self.cost_verif = verification_cost
        self.gt_pool = gt_dataloader
        gt_roidb = gt_dataloader.dataset._roidb
        self.knowledge_pool = dict()
        for item in gt_roidb:
            """
            item:
            'flipped' (140219682368848) = {bool} False
            'gt_ishard' (140219682507568) = {ndarray} [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0]
            'gt_classes' (140219682507696) = {ndarray} [1 1 1 1 1 1 1 1 1 1 1 2 8 1 1 1 1 3 3 3 3 3 3]
            'boxes' (140219682425128) = {ndarray} [[ 868  402  896  512]\n ... 502]\n [1241  420 1469  576]\n [1487  387 2048  785]]
            'seg_areas' (140219682507760) = {ndarray} [       3219        3335        1950        3472        6110        7520   
            'gt_overlaps' (140219682507824) = {csr_matrix}   (0, 1)\t1.0\n  (1, 1)\t1.0\n  (2, 1)\t1.0\n  (3, 1)\t1.0\n  
            'img_id' (140221294891280) = {int} 0
            'image' (140221426417032) = {str} '/data/cityscape/VOC2007/JPEGImages/source_weimar_000102_000019_leftImg8bit.jpg'
            'width' (140221674933640) = {int} 2048
            'height' (140221426831288) = {int} 1024
            'max_classes' (140221297214448) = {ndarray} [1 1 1 1 1 1 1 1 1 1 1 2 8 1 1 1 1 3 3 3 3 3 3]
            'max_overlaps' (140221295376688) = {ndarray} [          1           1           1           1           ...]
            'need_crop' (140221295377008) = {int} 0
            """
            self.knowledge_pool[item['image']] = item

    @classmethod
    def get_name_by_id(self, image_id):
        index = self.gt_pool.ratio_index[image_id]
        return self.gt_pool._roidb[index]['image']


    def query(self, image_path, image_id, queried_boxes):
        """

        :param image_name:
        :param image_id:
        :param queried_boxes: xywh relative coord, boxes shape like [1, num, 4+1+classes]
        :return:
        """
        assert (image_path is not None or image_id is not None), "Must provide one of image_path, image_id"
        if image_id is not None:
            index = self.gt_pool.ratio_index[image_id]
            blob = self.gt_pool._roidb[index]
        else:
            blob = self.knowledge_pool['image_path']

        # qsh = queried_boxes.shape
        # annotate()
        # record cost
        # return results
        pass


class example_oracle:
    def __init__(self, knowledge_pool):
        pass


