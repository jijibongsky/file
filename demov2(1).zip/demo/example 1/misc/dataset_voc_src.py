import numpy as np
import os

data_root = "/data/voc/voc_pure_data/images"
# lab_root = "/data/cityscape/coco/labels"
setting_root = "/data/dataset/"
# source_train = '/data/cityscape/VOC2007/ImageSets/Main/train_s.txt'  # only file name, no extension
# target_train = '/data/cityscape/VOC2007/ImageSets/Main/train_t.txt'
# target_test = '/data/cityscape/VOC2007/ImageSets/Main/test_s.txt'
ext = '.jpg'


def create_src_file_list():
    with open('/data/voc/voc_pure_data/uni_train.txt', 'r') as f:
        src = f.read().splitlines(keepends=False)
    np.savetxt(os.path.join(setting_root + 'voc_src.txt'),
               [os.path.join(data_root, item + ext) for item in src], fmt='%s')
    np.random.shuffle(src)
    np.savetxt(os.path.join(setting_root + 'voc_src_ini.txt'),
               [os.path.join(data_root, item + ext) for item in src[0:1000]], fmt='%s')
    np.savetxt(os.path.join(setting_root + 'voc_src_unlab.txt'),
               [os.path.join(data_root, item + ext) for item in src[1000:]], fmt='%s')

create_src_file_list()
