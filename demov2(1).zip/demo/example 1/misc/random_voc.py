import numpy as np
import os
import sys
with open('/data/voc/voc_pure_data/uni_train.txt', 'r') as f:
    voc_data = f.read().splitlines(keepends=False)

np.random.shuffle(voc_data)
for i in range(20):
    im_path = os.path.join('/data/voc/voc_pure_data/images/', voc_data[i]+'.jpg')
    os.system(f"cp {im_path} /home/tangyingpeng/exp_res/random/")
