import pickle
import os
import torch
pt_path = '/data/saved_model/least_conf_n_17_best.pt'
chkpt = torch.load(pt_path)
print()
