from al.train_test_func import *
from al.al_data_loader import QueryRepo
from al.al_utils import al_mainloop, al_scoring, our_al_mainloop
import alipy
import prettytable as pt
import copy



VOC_COCO = {
    'pkl': '/data/saved_model/init_da_yolo_coco.pkl',
    'coco_dir': '/data/coco/images/train2014/',
    'voc_dir': '/data/voc/voc_pure_data/images/',
    'data': 'data/voc_coco.data',
    'label_map': 'data/cocoid2vocid.pkl',
    'cfg': 'cfg/yolov3-spp-voc.cfg',
}

CLASSES = 20
TOTAL_SCORE_THRES = 0.1
INCONS_SCORE_THRES = 0.1
TRANS_SCORE_THRES = 0.1
POS_INS_WEIGHT = 10
TRANS_TRANDEOFF = 0.1
TRANS_NORM = False
batch_size = 32
accumulate = 2
epochs = 20
img_size = 416
cache_images = False  # for testing
pretrain_weights = '/home/tangyingpeng/todal/darknet/darknet53.conv.74'

tb = pt.PrettyTable()
tb.field_names = ['method']+[f'class_{i}' for i in range(CLASSES)]

with open('/home/tangyingpeng/yolov3/data/cocoid2vocid.pkl', 'rb') as f:
    cocoid2vocid = pickle.load(f)


# testing only, random querying first
# with open("/data/saved_al/our_0_all.pkl", 'rb') as f:
with open("/data/saved_al/rand_pos_ins.pkl", 'rb') as f:
    our_qr = pickle.load(f)

tar_sta = [0] * CLASSES

for k in our_qr.keys():
    targets = our_qr[k][0]

    # split targets into pos, neg, outliers
    tgt_pos_mask = [False] * targets.shape[0]
    tgt_neg_mask = [False] * targets.shape[0]
    tgt_out_mask = [False] * targets.shape[0]
    for ti, target in enumerate(targets):
        if target[1] >= 0:  # non-background, non-outlier classes
            if int(target[1]) in cocoid2vocid.keys():
                # target[1] = cocoid2vocid[int(target[1])]
                # tgt_pos_mask[ti] = True
                tar_sta[cocoid2vocid[int(target[1])]] += 1
            else:
                raise ("raise exception: outlier class not equal to -2")
        elif target[1] == -1:  # neg class
            tgt_neg_mask[ti] = True
        elif target[1] == -2:  # out class
            tgt_out_mask[ti] = True
        else:
            raise (f"un-recognized class number: {target[1]}")

# print(tar_sta)
tar_sta1 = copy.copy(tar_sta)
tb.add_row(['random']+tar_sta)



# other method static

with open("/data/saved_al/our_0_all.pkl", 'rb') as f:
# with open("/data/saved_al/rand_pos_ins.pkl", 'rb') as f:
    our_qr = pickle.load(f)

tar_sta = [0] * CLASSES

for k in our_qr.keys():
    targets = our_qr[k][0]

    # split targets into pos, neg, outliers
    tgt_pos_mask = [False] * targets.shape[0]
    tgt_neg_mask = [False] * targets.shape[0]
    tgt_out_mask = [False] * targets.shape[0]
    for ti, target in enumerate(targets):
        if target[1] >= 0:  # non-background, non-outlier classes
            if int(target[1]) in cocoid2vocid.keys():
                # target[1] = cocoid2vocid[int(target[1])]
                # tgt_pos_mask[ti] = True
                tar_sta[cocoid2vocid[int(target[1])]] += 1
            else:
                raise ("raise exception: outlier class not equal to -2")
        elif target[1] == -1:  # neg class
            tgt_neg_mask[ti] = True
        elif target[1] == -2:  # out class
            tgt_out_mask[ti] = True
        else:
            raise (f"un-recognized class number: {target[1]}")

tb.add_row(['our']+tar_sta)
# tb.add_row(['diff']+[tar_sta1[i]-tar_sta[i] for i in range(CLASSES)])
tb.add_row(['ini']+[1023, 1003, 1576, 1187, 2183, 808, 4119, 1146, 4205, 1075, 1256, 1495, 1010, 1077, 19520, 1464, 1210, 972, 812, 965])

print(tb.get_string(fields=['method']+[f'class_{i}' for i in range(11)]))
print(tb.get_string(fields=['method']+[f'class_{i+11}' for i in range(9)]))