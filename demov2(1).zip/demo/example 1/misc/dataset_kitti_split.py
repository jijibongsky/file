"""
label space of KITTI as target domain:

Car (Car + Van)
Truck
Person (Pedestrian + Person_sitting)
Rider (Cyclist)
Train (Tram)
"""

import os
import numpy as np

data_root = "/data/download/kitti/training/image_2"
lab_root = "/data/download/kitti/training/label_2"
setting_root = "/data/dataset/"


def create_src_file_list():
    files = os.listdir(data_root)
    np.savetxt(os.path.join(setting_root, 'kitti_src.txt'),
               [os.path.join(data_root, fi.split('.')[0] + '.png') for fi in files], fmt="%s")


# create_src_file_list()

def filter(arr):
    lab_id = int(arr[0])
    if lab_id in [3, 4]:
        return 2
    elif lab_id == 0:
        return 0
    elif lab_id == 2:
        return 1
    elif lab_id == 5:
        return 3
    elif lab_id == 6:
        return 4
    else:
        return None


def create_tgt_labels(output_label_dir):
    ori_files = os.listdir(lab_root)
    for f in ori_files:
        labs = np.loadtxt(os.path.join(lab_root, f))
        if labs.ndim == 1:
            labs = labs.reshape((1, -1))
        # filter classes
        val_lab = []
        for lab in labs:
            after_filter = filter(lab)
            if after_filter is not None:
                lab[0] = after_filter
                val_lab.append(lab)

        if len(val_lab) > 0:
            np.savetxt(os.path.join(output_label_dir, f),
                       val_lab, fmt='%s')

# create_tgt_labels("/data/download/kitti/tgt_labels")


def split_for_tgt_dataset(label_dir, ini_size, test_size, output_prefix, output_dir, img_root, ext='.jpg'):
    ori_files = np.asarray(os.listdir(label_dir))
    assert ini_size + test_size < len(ori_files)
    # perm = np.arange(len(ori_files))
    np.random.shuffle(ori_files)
    np.savetxt(os.path.join(output_dir, output_prefix+'ini.txt'), [os.path.join(img_root, item.split('.')[0]+ext) for item in ori_files[0:ini_size]], fmt='%s')
    np.savetxt(os.path.join(output_dir, output_prefix + 'test.txt'), [os.path.join(img_root, item.split('.')[0]+ext) for item in ori_files[ini_size:ini_size+test_size]], fmt='%s')


# split_for_tgt_dataset("/data/download/kitti/tgt_labels", 1000, 5000, "kitti_tgt_", output_dir=setting_root, img_root="/data/download/kitti/tgt_images", ext='.png')


def split_for_src_dataset(label_dir, ini_size, output_prefix, output_dir, img_root, ext='.jpg'):
    ori_files = np.asarray(os.listdir(label_dir))
    assert ini_size < len(ori_files)
    # perm = np.arange(len(ori_files))
    np.random.shuffle(ori_files)
    np.savetxt(os.path.join(output_dir, output_prefix+'ini.txt'), [os.path.join(img_root, item.split('.')[0]+ext) for item in ori_files[0:ini_size]], fmt='%s')
    np.savetxt(os.path.join(output_dir, output_prefix + 'unlab.txt'), [os.path.join(img_root, item.split('.')[0]+ext) for item in ori_files[ini_size:]], fmt='%s')


split_for_src_dataset("/data/download/kitti/tgt_labels", 1000, "kitti_src_", output_dir=setting_root, img_root="/data/download/kitti/training/image_2/", ext='.png')

