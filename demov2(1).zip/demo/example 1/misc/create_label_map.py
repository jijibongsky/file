import pickle

kitti2sim = dict()
city2kitti = dict()
voc2city = dict()

kitti2sim[0] = 0
city2kitti[2] = 0
city2kitti[0] = 2
city2kitti[1] = 3
city2kitti[3] = 1
city2kitti[5] = 4

# with open('../data/kitti2sim.pkl', 'wb') as f:
#     pickle.dump(kitti2sim, f)
# with open('../data/city2kitti.pkl', 'wb') as f:
#     pickle.dump(city2kitti, f)

voc2city[14] = 0
voc2city[6] = 1
voc2city[5] = 2
voc2city[18] = 3
voc2city[13] = 4
voc2city[1] = 5

with open('../data/voc2city.pkl', 'wb') as f:
    pickle.dump(voc2city, f)
