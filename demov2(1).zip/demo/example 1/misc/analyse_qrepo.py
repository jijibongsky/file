import pickle
import numpy as np

repo_path = '/data/saved_al/our_incons_6_all.pkl'

with open(repo_path, 'rb') as f:
    repo = pickle.load(f)

total_example = len(repo)
boxes_num_list = []
larger_than_5 = 0
klist = repo.keys()

for k in klist:
    d, m = repo[k]
    boxes_num = len(d)
    boxes_num_list.append(boxes_num)
    if boxes_num > 5:
        larger_than_5 += 1

print(larger_than_5)
print(f"{larger_than_5/total_example:.2f}")
ht = np.histogram(boxes_num_list, bins=[1,2,3,4,5])
print(ht)
