import os
root_dir = '/data/voc/voc_pure_data'
voc07_train = open(os.path.join(root_dir, 'trainval.txt'), 'r')
voc07_test = open(os.path.join(root_dir, 'test.txt'), 'r')
voc12_train = open(os.path.join(root_dir, 'train_val.txt'), 'r')

with open(os.path.join(root_dir, 'uni_train.txt'), 'w') as f:
    f.writelines(voc07_train.readlines())
    t12 = voc12_train.readlines()
    t12 = [line.split()[0]+os.linesep for line in t12]
    f.writelines(t12)

