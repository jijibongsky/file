import os
import numpy as np

label_root = "/data/download/SIM10K/VOC2012/ori_labels"
setting_root = "/data/dataset/"


def keep_car(label_dir, out_dir):
    """Filter out other labels except car"""
    ori_files = os.listdir(label_dir)
    for f in ori_files:
        labs = np.loadtxt(os.path.join(label_dir, f))
        if labs.ndim == 1:
            labs = labs.reshape((1, -1))
        mask = labs[:, 0] == 0
        labs = labs[mask]

        # write
        if len(labs) > 0:
            np.savetxt(os.path.join(out_dir, f), labs, fmt='%.2f')


keep_car("/data/download/SIM10K/VOC2012/ori_labels", "/data/download/SIM10K/VOC2012/labels")


def split_dataset(label_dir, ini_size, test_size, output_prefix, output_dir, img_root):
    ori_files = np.asarray(os.listdir(label_dir))
    assert ini_size + test_size < len(ori_files)
    # perm = np.arange(len(ori_files))
    np.random.shuffle(ori_files)
    np.savetxt(os.path.join(output_dir, output_prefix+'ini.txt'), [os.path.join(img_root, item.split('.')[0]+'.jpg') for item in ori_files[0:ini_size]], fmt='%s')
    np.savetxt(os.path.join(output_dir, output_prefix + 'test.txt'), [os.path.join(img_root, item.split('.')[0]+'.jpg') for item in ori_files[ini_size:ini_size+test_size]], fmt='%s')


# split_dataset(label_root, 1000, 5000, 'sim_tgt_', '/data/dataset', img_root="/data/download/SIM10K/VOC2012/images/")
