import os
import numpy as np
import pickle
from matplotlib import pyplot as plt
import operator

name_arr = ['least_conf', 'random', 'mean_conf', 'LS', 'img_trans', 'ADDA', 'our_trans', 'our_incons', 'our']
# data_root = f'C:\\Users\\tangy\\3D Objects\\plot\\exp_res\\voc'
data_root = '/data/saved_model'
repo_root = '/data/saved_al'
start_point = 0.356
budget_rate = np.array([0.0015] * 100)
budget_arr = 25.5 * 349525 * budget_rate


def smooth(a, WSZ):
    # a: NumPy 1-D array containing the data to be smoothed
    # WSZ: smoothing window size needs, which must be odd number,
    # as in the original MATLAB implementation
    out0 = np.convolve(a, np.ones(WSZ, dtype=int), 'valid') / WSZ
    r = np.arange(1, WSZ - 1, 2)
    start = np.cumsum(a[:WSZ - 1])[::2] / r
    stop = (np.cumsum(a[:-WSZ:-1])[::2] / r)[::-1]
    return np.concatenate((start, out0, stop))


def read_map_file(fname):
    with open(fname, 'r') as fi:
        results = fi.read().splitlines(keepends=False)
        results = np.asarray([result[1:-1].split(',') for result in results], dtype=float)
    return results


def get_cost_from_repo_file(fname):
    total_cost = 0
    with open(fname, 'rb') as fi:
        repo = pickle.load(fi)
    for key in repo.keys():
        total_cost += repo[key][1]['cost']
    return total_cost


def get_one_point(method_name, iteration, method_suffix=None):
    i = iteration
    if 'our' in method_name:
        map_dir = os.path.join(data_root,
                               f"{method_name}_{i}_saved_map{'_' + method_suffix if method_suffix is not None else ''}.txt")
    else:
        map_dir = os.path.join(data_root, f"{method_name}_n_{i}_saved_map.txt")
    repo_dir = os.path.join(repo_root, f"{method_name}_{i}.pkl")
    train_res = read_map_file(map_dir)
    # cost = get_cost_from_repo_file(repo_dir)
    cost = 0
    return np.max(train_res[:, 2]), cost


def plot_train_res(method_arr, iteration=0):
    fig, ax = plt.subplots(2, 4, figsize=(14, 7))
    ax = ax.ravel()
    title = ['precision', 'recall', 'mAP', 'F1', 'IoU loss', 'obj loss', 'cls loss']
    for mth in method_arr:
        assert mth in name_arr, f'un-known method {mth}'
        map_dir = os.path.join(data_root, f"{mth}_{iteration}_saved_map.txt")
        train_res = read_map_file(map_dir)
        for i in range(7):
            ax[i].plot(np.arange(train_res.shape[0]), train_res[:, i])
            ax[i].set_title(title[i])
            ax[i].legend()
    fig.tight_layout()
    fig.savefig('train_res.png', dpi=200)


def plot_specific_train_res(fname_list):
    fig, ax = plt.subplots(2, 4, figsize=(14, 7))
    ax = ax.ravel()
    title = ['precision', 'recall', 'mAP', 'F1', 'IoU loss', 'obj loss', 'cls loss']
    for fname in fname_list:
        train_res = read_map_file(os.path.join(data_root, fname))
        for i in range(7):
            ax[i].plot(np.arange(train_res.shape[0]), train_res[:, i], label=fname)
            ax[i].set_title(title[i])
            if i == 0:
                ax[i].legend()

    fig.tight_layout()
    fig.savefig('train_res.png', dpi=200)


def get_specific_train_res(fname_list, sort=True):
    # title = ['precision', 'recall', 'mAP', 'F1', 'IoU loss', 'obj loss', 'cls loss']
    res = dict()
    for fname in fname_list:
        train_res = read_map_file(os.path.join(data_root, fname))
        bp = np.max(train_res[:, 2])
        res[fname] = bp
    if sort:
        sorted_x = sorted(res.items(), key=operator.itemgetter(1), reverse=True)
        for pair in sorted_x:
            print(pair)
    else:
        for k, v in res.items():
            print(k, v)


def plot_lc(method_arr: 'list', end_iteration: 'int' = 10):
    fig, ax = plt.subplots()
    for mth in method_arr:
        # assert mth in name_arr, f'un-known method {mth}'
        x, y = [0], [start_point]
        cost_x = 0
        for it in range(end_iteration):
            mmap, cost = get_one_point(mth, it)
            cost_x += budget_arr[it]
            x.append(cost_x)
            y.append(mmap)
        ax.plot(x, y, label=mth)
        ax.legend()
    fig.tight_layout()
    fig.savefig('lc.png', dpi=200)


def plot_lc_suf(method_arr: list, suffix_arr: list, end_iteration: int = 10, isSmooth: bool = True):
    plt.rc('axes', labelsize=22)  # fontsize of the x and y labels
    plt.rc('xtick', labelsize=14)  # fontsize of the tick labels
    plt.rc('ytick', labelsize=14)  # fontsize of the tick labels
    fig, ax = plt.subplots()

    for mth_id, mth in enumerate(method_arr):
        # assert mth in name_arr, f'un-known method {mth}'
        x, y = [0], [start_point]
        cost_x = 0
        for it in range(end_iteration):
            if isSmooth:
                if (it+1) % 2 != 0:
                    cost_x += budget_arr[it]
                    continue
            mmap, cost = get_one_point(mth, it, suffix_arr[mth_id])
            cost_x += budget_arr[it]
            x.append(cost_x)
            y.append(mmap)

        # if isSmooth:
        #     y = smooth(y, 3)
        print(mth, suffix_arr[mth_id])
        print(str(list(x))[1:-1])
        print(str(list(y))[1:-1])

        ax.plot(x, y, label=methods_label[mth_id],
                linewidth=methods_linewodth[mth_id],
                color=methods_color[mth_id],
                linestyle=methods_lstyle[mth_id],
                marker=methods_marker[mth_id],
                markersize=7 if 'our' in mth else 5

                )
        ax.legend()
    agca = plt.gca()  # 获取当前图像的坐标轴信息
    agca.xaxis.get_major_formatter().set_powerlimits((0, 2))

    plt.xlabel("cost")
    plt.ylabel("mAP")
    fig.tight_layout()
    fig.savefig('lc_voc.png', dpi=200)
    fig.show()


def plot_hist_for_one_iter(method_arr: 'list', iteration: 'int' = 0):
    fig = plt.figure()
    for mth in method_arr:
        assert mth in name_arr, f'un-known method {mth}'
        mmap, cost = get_one_point(mth, iteration)

        plt.bar(mth, mmap)
        plt.xlabel("Method name")
        plt.ylabel("mAP")
        # plt.title("bar chart")

    # plt.bar('da0.5', 0.55)
    # plt.bar('da2', 0.603)
    # plt.bar('da5', 0.61)
    # plt.bar('da0.1', 0.598)

    plt.savefig('lc_hist.png')


def plot_hist(arr, tight=True):
    fig = plt.figure()
    values_arr = []
    for mth in arr:
        values_arr.append(mth[1])
        plt.bar(mth[0], mth[1])
        plt.xlabel("Method name")
        plt.ylabel("mAP")

    # plt.ylim([0.549, 0.62])
    if tight:
        delta = (max(values_arr) - min(values_arr)) / 20
        plt.ylim([min(values_arr) - delta, max(values_arr) + delta])
    plt.savefig('lc_hist.png')


def table_for_one_iter(method_arr: 'list', iteration: 'int' = 0):
    qn = dict()
    for mth in method_arr:
        # assert mth in name_arr, f'un-known method {mth}'
        mmap, cost = get_one_point(mth, iteration)

        qn[mth] = mmap

    # qn['da0.5'] = 0.55
    # qn['da2'] = 0.603
    # qn['da5'] = 0.61
    # qn['da0.1'] = 0.598

    sorted_x = sorted(qn.items(), key=operator.itemgetter(1), reverse=True)
    return sorted_x


def table_for_one_iter_with_fname(fname_arr: 'list'):
    qn = dict()
    for fname in fname_arr:
        train_res = read_map_file(os.path.join(data_root, fname))
        # cost = get_cost_from_repo_file(repo_dir)
        qn[fname] = np.max(train_res[:, 2])

    # qn['da0.5'] = 0.55
    # qn['da2'] = 0.603
    # qn['da5'] = 0.61
    # qn['da0.1'] = 0.598

    sorted_x = sorted(qn.items(), key=operator.itemgetter(1), reverse=True)
    return sorted_x


methods_res = ['our', 'our_incons', 'our_trans', 'least_conf',
               'LS', 'ADDA', 'img_trans', 'uncertain_map', 'margin_avg', 'random']
methods_label = ['QBox', 'QBox-Inconsistency', 'QBox-Transferability',
                 'Least Confidence', 'Localization  Stability',
                 'AADA', 'Image Transferability', 'uncertain_map', 'margin_avg', 'Random']

methods_res = ['our', 'our_incons', 'our_trans', 'least_conf',
               'LS', 'ADDA', 'img_trans', 'margin_avg', 'random']
methods_label = ['QBox', 'QBox-Inconsistency', 'QBox-Transferability',
                 'Least Confidence', 'Localization  Stability',
                 'AADA', 'Image Transferability', 'margin_avg', 'Random']

methods_linewodth = [2.8, 2.2, 1.7, 1.7,
                     1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.7]
methods_lstyle = ['-', ':', '-.',
                  '--', '--',
                  '--', '--', '--', '--', '-']
methods_color = ['#F71E35', '#F71E35', '#F71E35',
                 '#274c5e', '#0080ff',
                 '#bf209f', '#79bd9a', '#4013af', 'gray', 'black']
methods_marker = ["D", "d", "d",
                  "^", "^",
                  "o", "o", "^", "^", "o"]

plot_lc_suf(
    method_arr=methods_res,
    suffix_arr=[None]+[None]*9,
    end_iteration=18,
    isSmooth=True)

# plot_lc_suf(
#     method_arr=['our','our','our'],
#     suffix_arr=[None, 'dat01', 'dat10'],
#     end_iteration=18,
#     isSmooth=True)

