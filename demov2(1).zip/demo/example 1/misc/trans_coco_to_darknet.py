# import os
# COCO_DIR = '/data/coco/'
# FLIST_FNAME = 'trainvalno5k.txt'
#
# with open(os.path.join(COCO_DIR, FLIST_FNAME), 'r') as f:
#     ori_file_list = f.read().splitlines()
#
# mod_list = [os.path.split(file)[1].split('.')[0]+os.linesep for file in ori_file_list]
# with open(os.path.join(COCO_DIR, 'trainvalno5k_fn.txt'), 'w') as f:
#     f.writelines(mod_list)

import os
COCO_DIR = '/data/coco/'
FLIST_FNAME = 'trainvalno5k.txt'

# with open(os.path.join(COCO_DIR, FLIST_FNAME), 'r') as f:
#     ori_file_list = f.read().splitlines()
ori_file_list = os.listdir('/data/coco/labels/val2014/')

mod_list = [os.path.split(file)[1].split('.')[0]+os.linesep for file in ori_file_list]
with open(os.path.join(COCO_DIR, '5k_fn.txt'), 'w') as f:
    f.writelines(mod_list)
