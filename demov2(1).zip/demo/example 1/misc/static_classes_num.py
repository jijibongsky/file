from al.train_test_func import *
from al.al_data_loader import QueryRepo

VOC_COCO = {
    'pkl': '/data/saved_model/init_da_yolo_coco.pkl',
    'coco_dir': '/data/coco/images/train2014/',
    'voc_dir': '/data/voc/voc_pure_data/images/',
    'data': '../data/voc_coco.data',
    'label_map': '../data/cocoid2vocid.pkl',
    'cfg': '../cfg/yolov3-spp-voc.cfg',
}

CLASSES = 20
TOTAL_SCORE_THRES = 0.1
INCONS_SCORE_THRES = 0.1
TRANS_SCORE_THRES = 0.1
POS_INS_WEIGHT = 10
TRANS_TRANDEOFF = 0.1
TRANS_NORM = False
batch_size = 32
accumulate = 2
epochs = 20
img_size = 416
cache_images = False
pretrain_weights = '/home/tangyingpeng/todal/darknet/darknet53.conv.74'

with open(VOC_COCO['label_map'], 'rb') as f:
    cocoid2vocid = pickle.load(f)

# load data
_, s_gt_ds, s_gt_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='source_train', img_size=416,
                                        batch_size=batch_size,
                                        rect=False, img_weights=False, cache_images=False, shuffle=False,
                                        augment=False, data_root=VOC_COCO['coco_dir'])
nc, t_gt_ds, t_gt_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='target_train', img_size=416,
                                         batch_size=batch_size,
                                         rect=False, img_weights=False, cache_images=cache_images, shuffle=False,
                                         augment=True, data_root=VOC_COCO['voc_dir'])
# _, test_ds, test_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='valid', img_size=416, batch_size=batch_size,
#                                         rect=False, img_weights=False, cache_images=False, shuffle=False,
#                                         augment=False, data_root=VOC_COCO['voc_dir'])

# load init lab_unlab
with open('../data/coco_init_lab.txt', 'r') as f:
    init_lab = f.read().splitlines(keepends=False)
with open('../data/coco_init_unlab.txt', 'r') as f:
    init_unlab = f.read().splitlines(keepends=False)

ini_src_ds = LoadImagesAndLabelsByImgFiles(
    img_files=init_lab,
    img_size=img_size,
    batch_size=batch_size,
    augment=True,
    hyp=hyp,  # augmentation hyperparameters
    rect=False,  # rectangular training
    image_weights=False,
    cache_images=cache_images
)

# Dataloader
ini_dataloader = torch.utils.data.DataLoader(ini_src_ds,
                                             batch_size=batch_size,
                                             num_workers=0,
                                             shuffle=False,  # Shuffle=True unless rectangular training is used
                                             pin_memory=True,
                                             collate_fn=ini_src_ds.collate_fn,
                                             drop_last=False)

tar_sta = [0] * CLASSES

for _, targets, paths, _ in t_gt_dl:
    for ti, target in enumerate(targets):
        tar_sta[int(target[1])] += 1

print('target domain label')
print(tar_sta)

for _, targets, paths, _ in ini_dataloader:
    tgt_mask = [True] * targets.shape[0]
    for ti, target in enumerate(targets):
        if target[1] >= 0:  # non-background, non-outlier classes
            if int(target[1]) in cocoid2vocid.keys():
                tar_sta[cocoid2vocid[int(target[1])]] += 1
            else:
                tgt_mask[ti] = False

print(tar_sta)
