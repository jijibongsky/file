import pickle
import matplotlib.pyplot as plt
import os
import operator


method_arr=['least_conf', 'random', 'mean_conf', 'LS', 'img_trans', 'ADDA', 'our']
qn = dict()

for met in method_arr:
    if not os.path.exists(f"/data/saved_al/{met}_0.pkl"):
        continue
    with open(f"/data/saved_al/{met}_0.pkl", 'rb') as f:
        queried_repo = pickle.load(f)

    # from utils.datasets import ConvertRepo2Dataset
    # from al.train_test_func import hyp
    # print(len(queried_repo))
    # updated_lab_ds = ConvertRepo2Dataset(query_repo=queried_repo, img_size=416, batch_size=32,
    #                                      augment=False, hyp=hyp, rect=False, image_weights=False, cache_images=False)

    qn[f'{met}'] = len(queried_repo)

print(qn)
# plot
fig = plt.figure()

sorted_x = sorted(qn.items(), key=operator.itemgetter(1), reverse=True)

for i, (k, v) in enumerate(sorted_x):
    plt.bar(k, v)
    plt.xlabel("Method name")
    plt.ylabel("queried count")
    # plt.title("bar chart")

plt.ylim([3500, 8000])
plt.savefig('hist.png')

