import torch
a = torch.eye(4)

print(a)
b = [True]*len(a)

for i, tens in enumerate(a):
    if int(tens[1]) == 1:
        b[i] = False
    else:
        tens[1] = 10

a = a[b, :]
print(a)
