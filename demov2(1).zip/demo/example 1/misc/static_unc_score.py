import pickle
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

with open('/data/saved_model/for_sta.pkl', 'rb') as f:
    score = pickle.load(f)

# print(score.describe())
print(stats.describe(score))

hist = np.histogram(score, bins=20, range=(0.01, 1.0))
# hist_dist = stats.histogram(hist, numbins=20, defaultlimits=(0.01, 1))
print(hist)

X = np.linspace(0.01, 1.0, 100)
plt.title("inconsistency scores static")
plt.hist(score, range=(0.1, 1.0), bins=10)
# plt.plot(X, hist_dist.pdf(X), label='PDF')
# plt.plot(X, hist_dist.cdf(X), label='CDF')
plt.show()
