with open('../data/voc.names', 'r') as f:
    voc_labels = f.read().splitlines()
with open('../data/real_coco.names', 'r') as f:
    coco_labels = f.read().splitlines()
with open('../data/voc_coco_label_map.txt', 'r') as f:
    voc_coco_map = f.read().splitlines()

voc_name2id = dict()
coco_name2id = dict()
voc2coco = dict()
coco2voc = dict()

for i, lab in enumerate(voc_labels):
    voc_name2id[lab] = i
for i, lab in enumerate(coco_labels):
    coco_name2id[lab] = i
for i, lab in enumerate(voc_coco_map):
    labs = lab.split(' ', 1)
    voc2coco[labs[0]] = labs[1]
    coco2voc[labs[1]] = labs[0]

# map voc label index to coco
vocid2cocoid = dict()
for i, lab in enumerate(voc_labels):
    if lab in voc2coco.keys():
        vocid2cocoid[voc_name2id[lab]] = coco_name2id[voc2coco[lab]]
    else:
        vocid2cocoid[voc_name2id[lab]] = coco_name2id[lab]
print(vocid2cocoid)

import pickle
with open('../data/vocid2cocoid.pkl', 'wb') as f:
    pickle.dump(vocid2cocoid, f)



# map voc label index to coco
cocoid2vocid = dict()
for i, lab in enumerate(coco_labels):
    if lab in coco2voc.keys():
        cocoid2vocid[coco_name2id[lab]] = voc_name2id[coco2voc[lab]]
    elif lab in voc_name2id.keys():
        cocoid2vocid[coco_name2id[lab]] = voc_name2id[lab]
print(cocoid2vocid)

import pickle
with open('../data/cocoid2vocid.pkl', 'wb') as f:
    pickle.dump(cocoid2vocid, f)

