import os
import numpy as np
import pickle
from matplotlib import pyplot as plt
import matplotlib.ticker as plticker
import re
import copy
from al.train_test_func import *

dataset = 'voc'
methods_res = ['our', 'our_incons', 'our_trans', 'least_conf',
               'LS', 'ADDA', 'img_trans', 'uncertain_map', 'margin_avg', 'click_spvs' ,'random']
methods_label = ['QBox', 'QBox-Inconsistency', 'QBox-Transferability',
                 'Least Confidence', 'Localization  Stability',
                 'AADA', 'Image Transferability', 'uncertain_map', 'margin_avg', 'click_spvs', 'Random']
methods_res = ['least_conf',
               'LS', 'ADDA', 'img_trans', 'uncertain_map', 'margin_avg', 'click_spvs' ,'random']
methods_label = ['Least Confidence', 'Localization  Stability',
                 'AADA', 'Image Transferability', 'uncertain_map', 'margin_avg', 'click_spvs', 'Random']
methods_linewodth = [2.8, 2.2, 1.7, 1.7,
                     1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.7]
methods_lstyle = ['-', ':', '-.',
                  '--', '--',
                  '--', '--', '--', '--', '--', '-']
methods_color = ['#F71E35', '#F71E35', '#F71E35',
                 '#274c5e', '#0080ff',
                 '#bf209f', '#79bd9a', '#4013af', 'gray', '#679b00', 'black']
methods_marker = ["D", "d", "d",
                  "^", "^",
                  "o", "o", "^", "^", "^", "o"]

if dataset == 'voc':
    dataset_config = VOC_COCO
elif dataset == 'sim':
    dataset_config = SIM_KITTI
elif dataset == 'kitti':
    dataset_config = KITTI_CITY
elif dataset == 'city':
    dataset_config = CITY_VOC
elif dataset == 'xray':
    dataset_config = RSNA_CXR
elif dataset == 'covid':
    dataset_config = COVID_PNEU
else:
    raise ValueError("dataset must in ['voc', 'sim', 'kitti', 'city']")
budget_rate = np.array([dataset_config['budget']] * 100)
budget_arr = 25.5 * 349525 * budget_rate

with open(os.path.join('/home/tangyingpeng/yolov3', dataset_config['label_map']), 'rb') as f:
    src2tgt_labelmap = pickle.load(f)

_, s_gt_ds, s_gt_dl = get_gt_dataloader(data=os.path.join('/home/tangyingpeng/yolov3', dataset_config['data']), data_item='source_train', img_size=416,
                                        batch_size=32,
                                        rect=False, img_weights=False, cache_images=False, shuffle=False,
                                        augment=True, data_root=dataset_config['src_dir'], fold=0)
gt_boxes = dict(zip([os.path.basename(lf) for lf in s_gt_ds.label_files], s_gt_ds.labels))


def get_target_instance_num(mth, it, suffix, fold=0):
    global dataset
    repo_dir = os.path.join(f"/data/saved_al{'_'+dataset if dataset != 'voc' else ''}", f"{mth}_{it}{'_' + suffix if suffix is not None else ''}_all.pkl")
    if 'our' in mth:
        return get_box_target_instance_num(repo_dir)
    elif 'click' in mth:
        return get_click_target_instance_num(repo_dir)
    else:
        return get_fs_target_instance_num(repo_dir)


def get_fs_target_instance_num(repo_path):
    global src2tgt_labelmap, gt_boxes
    with open(repo_path, 'rb') as f:
        repo = pickle.load(f)
    pos_ins_num = sum([repo.metadata[k]['num_pos'] for k in repo.database.keys()])
    examples_num = len(repo.database) + repo.skipped_image
    # out_num = 0
    # for k in repo.database.keys():
    #     targets = gt_boxes[os.path.splitext(os.path.basename(k))[0] + '.txt']
    #     all_out = True
    #     for ti, target in enumerate(targets):
    #         if int(target[0]) in src2tgt_labelmap.keys():
    #             all_out = False
    #     if all_out is True:
    #         out_num += 1
    cost = pos_ins_num * 25.5 + examples_num * 7.8
    return pos_ins_num, repo.skipped_image, examples_num, cost


def get_click_target_instance_num(repo_path):
    global src2tgt_labelmap, gt_boxes
    with open(repo_path, 'rb') as f:
        repo = pickle.load(f)
    ins_num = 0
    out_num = 0
    wk_num = 0
    # fs
    for k in repo.strongly_labeled_set.keys():
        targets = gt_boxes[os.path.splitext(os.path.basename(k))[0] + '.txt']
        for ti, target in enumerate(targets):
            if int(target[0]) in src2tgt_labelmap.keys():
                ins_num += 1
    # ws
    for k in repo.weakly_labeled_set.keys():
        targets = gt_boxes[os.path.splitext(os.path.basename(k))[0] + '.txt']
        all_out = True
        for ti, target in enumerate(targets):
            if int(target[0]) in src2tgt_labelmap.keys():
                wk_num += 1
                all_out = False
        if all_out is True:
            out_num += 1
    wk_num += ins_num
    examples_num = len(repo.strongly_labeled_set) + len(repo.weakly_labeled_set)
    return ins_num, out_num, examples_num, 7.8 * examples_num + 3 * wk_num + 25.5 * ins_num


def get_box_target_instance_num(repo_path):
    global src2tgt_labelmap, gt_boxes
    with open(repo_path, 'rb') as f:
        repo = pickle.load(f)
    ins_num = 0
    out_num = 0
    # cost = 0
    # fs
    for k in repo.fs_database:
        targets = gt_boxes[os.path.splitext(os.path.basename(k))[0]+'.txt']
        all_out = True
        for ti, target in enumerate(targets):
            if int(target[0]) in src2tgt_labelmap.keys():
                ins_num += 1
                all_out = False
        if all_out is True:
            out_num += 1
    # box
    for k in repo.database.keys():
        queried_boxes = repo.database[k]
        pos_ins_num = int(torch.sum(queried_boxes[:, 1] >= 0))
        ins_num += pos_ins_num
        # cost += (len(queried_boxes) - pos_ins_num) * 1.6
        # statistic out
        targets = gt_boxes[os.path.splitext(os.path.basename(k))[0] + '.txt']
        all_out = True
        for ti, target in enumerate(targets):
            if int(target[0]) in src2tgt_labelmap.keys():
                all_out = False
        if all_out is True:
            out_num += 1
    examples_num = len(repo.fs_database) + len(repo.database)
    return ins_num, out_num, examples_num, 0


def plot_ins_num(method_arr: 'list', suffix_arr: 'list', end_iteration: 'int' = 10,
            isSmooth=True, legend=False, use_accurate_cost=False, budget_array=None,
            smooth_r=2, smooth_st=0, fold=0, plot_type='pos_ins'):
    global dataset, start_point

    # plt.rc('font', size=SMALL_SIZE)  # controls default text sizes
    plt.rc('axes', titlesize=16)  # fontsize of the axes title
    plt.rc('axes', labelsize=22)  # fontsize of the x and y labels
    plt.rc('xtick', labelsize=14)  # fontsize of the tick labels
    plt.rc('ytick', labelsize=14)  # fontsize of the tick labels
    plt.rc('legend', fontsize=8)  # legend fontsize
    # plt.rc('figure', titlesize=BIGGER_SIZE)  # fontsize of the figure title

    fig, ax = plt.subplots()
    for mth_id, mth in enumerate(method_arr):
        if use_accurate_cost:
            budget_arr = []
            cost_cur = 0
            for i in range(end_iteration):
                with open(f"/data/saved_al_{dataset}/{mth}_{i}{'_'+str(fold) if fold > 0 else ''}_statistic.txt", 'r') as sf:
                    string_info = sf.read()
                # extract cost
                if 'our' in mth:
                    gp = re.findall(r'total_cost:(.*?)\n', string_info)
                else:
                    gp = re.findall(r'total_cost:(.*?),', string_info)

                budget_arr += [float(gp[0])]
        else:
            budget_arr = budget_array

        # assert mth in name_arr, f'un-known method {mth}'
        x, y = [0], [start_point]
        cost_x = 0
        for it in range(end_iteration):
            # if isSmooth and dataset == 'city':
            #     if it % 2 != 0:
            #         continue
            if isSmooth:
                if (it + smooth_st) % smooth_r != 0 and it != 0:
                    cost_x += budget_arr[it]
                    continue
            pos_ins, out_ins, examples_num, cost_real = get_target_instance_num(mth, it, suffix_arr[mth_id], fold=fold)
            cost_x += budget_arr[it]
            if 'our' in mth:
                x.append(cost_x)
            else:
                x.append(cost_real)
            if plot_type == 'number of target objects':
                y.append(pos_ins)
            elif plot_type == 'number of examples':
                y.append(examples_num)
            elif plot_type == 'number of outlier objects':
                y.append(out_ins)
            else:
                raise ValueError("plot_type parameter must be one of ['pos_ins', 'exa_num', 'out_ins']")
        # smooth:
        # y = np.asarray(y)
        # x = np.asarray(x)
        # if isSmooth:
        #     y = smooth(y, 3)
        print(dataset, mth)
        print(suffix_arr[mth_id])
        print(str(list(x))[1:-1])
        print(str(list(y))[1:-1])

        # ax.plot(x, y, label=mth if suffix_arr[mth_id] is None else mth + f'_{suffix_arr[mth_id]}',
        #         linewidth=3 if 'our' in mth else 1.5)
        ax.plot(x, y, label=methods_label[mth_id],
                linewidth=methods_linewodth[mth_id],
                color=methods_color[mth_id],
                linestyle=methods_lstyle[mth_id],
                marker=methods_marker[mth_id],
                markersize=7 if 'our' in mth else 5
                )
        if dataset == "kitti" or legend:
            ax.legend()
    plt.xlabel("cost")
    plt.ylabel(plot_type)

    if dataset == 'city':
        loc = plticker.MultipleLocator(base=30000)  # this locator puts ticks at regular intervals
        ax.xaxis.set_major_locator(loc)
        agca = plt.gca()  # 获取当前图像的坐标轴信息
        agca.xaxis.get_major_formatter().set_powerlimits((0, 2))
    elif dataset == 'kitti':
        loc = plticker.MultipleLocator(base=150000)  # this locator puts ticks at regular intervals
        ax.xaxis.set_major_locator(loc)
        agca = plt.gca()  # 获取当前图像的坐标轴信息
        agca.xaxis.get_major_formatter().set_powerlimits((0, 2))
    else:
        agca = plt.gca()  # 获取当前图像的坐标轴信息
        agca.xaxis.get_major_formatter().set_powerlimits((0, 2))

    fig.tight_layout()
    fig.savefig(f'{plot_type}_{dataset}{"_"+str(fold) if fold > 0 else ""}.png', dpi=200)
    fig.show()

"""
1. pos ins num
2. examples without any instances in target classes
3. total examples
"""

start_point = 0
# plot_ins_num(method_arr=methods_res,
#              suffix_arr=[None] + [None] * (len(methods_res) - 1),
#              end_iteration=18, isSmooth=True, legend=True,
#              budget_array=budget_arr, use_accurate_cost=False,
#              plot_type='out_ins')

for pt in ['pos_ins', 'exa_num', 'out_ins']:
    plot_ins_num(method_arr=methods_res,
            suffix_arr=[None] + [None] * (len(methods_res)-1),
            end_iteration=18, isSmooth=True, legend=True,
            budget_array=budget_arr, use_accurate_cost=True,
            plot_type=pt)

