from al.train_test_func import *
from al.al_utils import HeapItem
from queue import PriorityQueue
from collections import OrderedDict

dataset_config = CITY_VOC

setting_root = "/data/dataset/"
TOTAL_SCORE_THRES = 0.1
INCONS_SCORE_THRES = 0.1
TRANS_SCORE_THRES = 0.1
POS_INS_WEIGHT = 10
TRANS_TRANDEOFF = 0.1
TRANS_NORM = False
batch_size = 32
accumulate = 2
epochs = 50
nc = dataset_config['nc']
img_size = 416
cache_images = True  # False for testing
pretrain_weights = '/home/tangyingpeng/todal/darknet/darknet53.conv.74'

q_iter = 5

output_dir = "/home/tangyingpeng/exp_res/vis_qbox"
# empty the dir
shutil.rmtree(output_dir)
os.mkdir(output_dir)

###################### qbox #####################################################
os.mkdir(os.path.join(output_dir, 'qbox'))
with open(f"/data/saved_al_city/our_{q_iter}_da01_sorted_score.pkl", 'rb') as f:
    scoring_arr = pickle.load(f)
with open(f"/data/saved_al_city/our_{q_iter}_da01_all.pkl", 'rb') as f:
    repo = pickle.load(f)

# sort
# combine sort by value, descending order
pq = PriorityQueue()  # element: (img_name, box) maxsize=budget, low means higher priority
for k in scoring_arr.keys():
    for box in scoring_arr[k]:
        pq.put((-float(box[4]), HeapItem(k, box)), block=False)

# pick the top 20 for visualization
forvis = OrderedDict()
for i in range(200):
    # 0: image path 1: box (x1, y1, x2, y2, al_score, class_conf, class)
    pair = pq.get(block=False)
    item = pair[1]
    if item[0] in repo.fs_database:
        continue
    if item[0] not in forvis.keys():
        forvis[item[0]] = item[1].unsqueeze(0)
    else:
        forvis[item[0]] = torch.cat([forvis[item[0]], item[1].unsqueeze(0)], dim=0)
print()

ini_src_ds = LoadImagesAndLabelsByImgFiles(
    img_files=list(forvis.keys()),
    img_size=img_size,
    batch_size=batch_size,
    augment=False,
    hyp=hyp,  # augmentation hyperparameters
    rect=False,  # rectangular training
    image_weights=False,
    cache_images=cache_images
)
i = 0
for img_path, qboxes in forvis.items():
    img, gt, _, _ = ini_src_ds.get_item_by_path(img_path)
    plot_qb_in_image(imgs=img, targets=qboxes, paths=None, fname=f"{output_dir}/qbox/{i}_{img_path.split('/')[-1]}")
    i+=1
    # print()

###################### aada #####################################################
os.mkdir(os.path.join(output_dir, 'aada'))
with open(f"/data/saved_al_city/ADDA_{q_iter}_sorted_scores.pkl", 'rb') as f:
    scoring_arr = pickle.load(f)
scores = sorted(scoring_arr.items(), key=lambda x: x[1], reverse=True)
for it, item in enumerate(scores):  # (img_path, score)
    # get ground truth
    img_name = item[0]
    shutil.copy(item[0], os.path.join(output_dir, 'aada', str(it)+"_"+img_name.split('/')[-1]))
    if it>50:
        break

###################### least_conf #####################################################
os.mkdir(os.path.join(output_dir, 'lc'))
with open(f"/data/saved_al_city/least_conf_{q_iter}_sorted_scores.pkl", 'rb') as f:
    scoring_arr = pickle.load(f)
scores = sorted(scoring_arr.items(), key=lambda x: x[1], reverse=True)
for it, item in enumerate(scores):  # (img_path, score)
    # get ground truth
    img_name = item[0]
    shutil.copy(item[0], os.path.join(output_dir, 'lc', str(it)+"_"+img_name.split('/')[-1]))
    if it>50:
        break

###################### img_trans #####################################################
os.mkdir(os.path.join(output_dir, 'img_trans'))
with open(f"/data/saved_al_city/img_trans_{q_iter}_sorted_scores.pkl", 'rb') as f:
    scoring_arr = pickle.load(f)
scores = sorted(scoring_arr.items(), key=lambda x: x[1], reverse=True)
for it, item in enumerate(scores):  # (img_path, score)
    # get ground truth
    img_name = item[0]
    shutil.copy(item[0], os.path.join(output_dir, 'img_trans', str(it)+"_"+img_name.split('/')[-1]))
    if it>50:
        break
