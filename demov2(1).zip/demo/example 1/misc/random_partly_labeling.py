"""
Randomly query  boxex form an image to construct
a partly labeled dataset for model training debugging.

pos : neg : out = 5 : 2 : 1
"""

import argparse
from al.al_utils import *
import alipy

parser = argparse.ArgumentParser()
parser.add_argument('--posw', type=float, default=1.0)  # 500200 batches at bs 16, 117263 images = 273 epochs
parser.add_argument('--test-query', action='store_true', help='only test query')
opt = parser.parse_args()
posw = opt.posw

VOC_COCO = {
    'pkl': '/data/saved_model/init_da_yolo_coco.pkl',
    'coco_dir': '/data/coco/images/train2014/',
    'voc_dir': '/data/voc/voc_pure_data/images/',
    'data': '../data/voc_coco.data',
    'label_map': '../data/cocoid2vocid.pkl',
    'cfg': '../cfg/yolov3-spp-voc.cfg',
}

SELECTION_PROB = 0.6
TOTAL_SCORE_THRES = 0.1
INCONS_SCORE_THRES = 0.1
TRANS_SCORE_THRES = 0.1
POS_INS_WEIGHT = 10
TRANS_TRANDEOFF = 0.1
TRANS_NORM = False
batch_size = 32
accumulate = 2
epochs = 20
img_size = 416
cache_images = False  # for testing
pretrain_weights = '/home/tangyingpeng/todal/darknet/darknet53.conv.74'

with open(VOC_COCO['label_map'], 'rb') as f:
    cocoid2vocid = pickle.load(f)

# load data
_, s_gt_ds, s_gt_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='source_train', img_size=416,
                                        batch_size=batch_size,
                                        rect=False, img_weights=False, cache_images=False, shuffle=False,
                                        augment=False, data_root=VOC_COCO['coco_dir'])
nc, t_gt_ds, t_gt_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='target_train', img_size=416,
                                         batch_size=batch_size,
                                         rect=False, img_weights=False, cache_images=cache_images, shuffle=False,
                                         augment=True, data_root=VOC_COCO['voc_dir'])
_, test_ds, test_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='valid', img_size=416, batch_size=batch_size,
                                        rect=False, img_weights=False, cache_images=False, shuffle=False,
                                        augment=False, data_root=VOC_COCO['voc_dir'])

# load init lab_unlab
with open('../data/coco_init_lab.txt', 'r') as f:
    init_lab = f.read().splitlines(keepends=False)
with open('../data/coco_init_unlab.txt', 'r') as f:
    init_unlab = f.read().splitlines(keepends=False)

# start pipeline
unlab_len = len(init_unlab)

queried_repo = QueryRepo(partial_label=False)
name_arr = ['our', 'our_incons', 'our_trans', 'random_ins']
ini_point = 0.45  # 20 epoch, using voc 07+12 train val, without data augmentation
# init lab unlab score
for name in name_arr:
    exec(name + '_l_set' + ' = alipy.index.IndexCollection(init_lab)')
    exec(name + '_ul_set' + '= alipy.index.IndexCollection(init_unlab)')
    exec(name + '_lc' + ' = [[0, ini_point]]')
    exec(f"{name}_qr = QueryRepo(partial_label=False)")

# 26 per instance, 80,000+ images, 608695 instances. 349525 in target classes. 7.5 instances per img in average
budget_rate = np.array([0.05] * 5 + [0.1] * 3 + [0.15] * 2)
budget_arr = 25.5 * 349525 * budget_rate

budget = budget_arr[0]

perm = np.random.permutation(unlab_len)

# randomly select 2 gt of an image to label
# rand poi ins repo
queried_repo = QueryRepo()
cost = 0

# static
skipped_img = 0
img_progress = 0
qpos = 0
qneg = 0
qout = 0
avg_ins_per_img = 0

# load model
# model, optimizer, res = load_voc_model(pt_path=f'/data/saved_model/none_best.pt',
#                                        cfg='../cfg/yolov3-spp-voc.cfg',
#                                        parallel=False, init_group=False)
model, optimizer=init_model()
model.eval()
with torch.no_grad():
    for img_id in perm:
        img_progress += 1

        imgs, targets, paths, _ = s_gt_ds[img_id]

        imgs = imgs.unsqueeze(0).to(device)
        # targets = targets.to(device)
        domain_label = torch.zeros(imgs.shape[0]).to(device)
        # Run model
        inf_out, train_out, da_out = model(imgs, domain_label=domain_label)  # inference and training outputs
        inf_out = inf_out.to("cpu")

        # split targets into pos, neg, outliers
        tgt_pos_mask = [False] * targets.shape[0]
        # tgt_neg_mask = [False] * targets.shape[0]
        tgt_out_mask = [False] * targets.shape[0]
        for ti, target in enumerate(targets):
            if int(target[1]) in cocoid2vocid.keys():
                # target[1] = cocoid2vocid[int(target[1])]
                tgt_pos_mask[ti] = True
            else:
                tgt_out_mask[ti] = True
        # targets = targets.to(device)

        pos_num = sum(tgt_pos_mask)
        out_num = sum(tgt_out_mask)

        if pos_num == 0 or out_num == 0:
            skipped_img += 1
            continue

        # begin selection
        take_or_not = True
        while take_or_not:
            box_type = np.random.rand()
            if box_type < 1/8:
                qout += 1
                box_type = -2   # out
            elif box_type >= 3/8:
                qpos += 1
                box_type = 1    # pos
            else:
                qneg += 1
                box_type = -1   # neg

            # take box
            if box_type == 1:
                selected_labels = np.random.permutation(pos_num)
                q_box = targets[tgt_pos_mask][selected_labels[0]]
                cost += 25.5
                # update repo
                queried_repo.update(img_path=paths, im_info=0, gt_boxes=q_box.unsqueeze(0),
                                    num_pos=1, num_neg=0, num_outlier=0, cost=25.5,
                                    domain_label=1, iteration=0, method_name='rand_pos_ins', score=0)
                pos_num -= 1
            elif box_type == -2:
                selected_labels = np.random.permutation(out_num)
                q_box = targets[tgt_out_mask][selected_labels[0]]
                cost += 1.6
                q_box[1] = -2
                # update repo
                queried_repo.update(img_path=paths, im_info=0, gt_boxes=q_box.unsqueeze(0),
                                    num_pos=0, num_neg=0, num_outlier=1, cost=1.6,
                                    domain_label=1, iteration=0, method_name='rand_pos_ins', score=0)
                out_num -= 1
            else:
                selected_labels = np.random.permutation(inf_out.shape[1])
                for id in selected_labels:
                    # make sure this is an background
                    selected_box = inf_out[0][id]
                    # calc iou
                    # convert to gt format
                    rel_coord_qb = xyxy2xywh(selected_box[:4].unsqueeze(0)) / img_size
                    iou = bbox_iou(rel_coord_qb.squeeze(0), targets[:, 2:], x1y1x2y2=False)
                    if torch.sum(iou > 0.5) > 0:
                        continue
                    else:
                        queried_gt = torch.cat((torch.tensor([[0.0, -1.0]]), rel_coord_qb.clone()), dim=1)
                        break
                cost += 1.6
                queried_repo.update(img_path=paths, im_info=0, gt_boxes=queried_gt,
                                    num_pos=0, num_neg=1, num_outlier=0, cost=1.6,
                                    domain_label=1, iteration=0, method_name='rand_pos_ins', score=0)

            if pos_num == 0 or out_num == 0:
                break

            take_or_not = np.random.rand()
            if take_or_not < SELECTION_PROB:
                take_or_not = True
            else:
                break

        # end selection
        if cost > budget:
            break

        if img_progress % 10 == 0:
            print(f"\r{cost:.2f}/{budget}\t\t{img_progress}\tqpos={qpos}\tqneg={qneg}\tqout={qout}\tskipped_img={skipped_img}\tavg_ins_per_img:{(qpos+qneg+qout)/(img_progress-skipped_img):.2f}", end='')

# save
# record queries in this iteration
with open(f"/data/saved_al/rand_pos_ins.pkl", 'wb') as f:
    pickle.dump(queried_repo, f)
