import cv2
import os
import numpy as np
from skimage.measure import label, regionprops
import matplotlib.pyplot as plt

vis =True
root_dir = "/data/download/SYN/RAND_CITYSCAPES/GT/LABELS/"
mask_flist = os.listdir(root_dir)
# wo: void, sky, road, sidewalk, fence, terrain, Wall, Lanemarking
# valid: Building, Vegetation, Pole, Car, Traffic sign, Pedestrian, Bicycle, Motorcycle, Parking-slot, Road-work
# Traffic light, Rider, Truck, Bus, Train
instances_idl = [2, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 19, 20]

for mask_f in mask_flist:
    src = cv2.imread(os.path.join(root_dir, mask_f), cv2.IMREAD_UNCHANGED)
    id_mask = src[:, :, 2]
    # lmask = label(id_mask)
    for iid in instances_idl:
        binary_mask = np.asarray(id_mask == iid, dtype=int)
        binary_mask_lab = label(binary_mask)
        rp = regionprops(binary_mask_lab)

        if vis:
            fig, (ax1, ax2) = plt.subplots(1, 2)
            img = cv2.imread(os.path.join("/data/download/SYN/RAND_CITYSCAPES/RGB", mask_f))
            img_ori = img.copy()
            for rpit in rp:
                print(rpit.bbox)
                cv2.rectangle(img, (rpit.bbox[1], rpit.bbox[0], rpit.bbox[3], rpit.bbox[2]),
                              (255, 0, 0), 2)
            ax1.imshow(img_ori)
            ax2.imshow(img)
            # plt.show()
            plt.savefig("test_box.png")
            print()
