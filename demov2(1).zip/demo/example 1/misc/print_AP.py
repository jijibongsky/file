import os
import numpy as np
import pickle
from matplotlib import pyplot as plt
import matplotlib.ticker as plticker
import re
import copy

methods_res = ['our', 'our_incons', 'our_trans', 'least_conf',
               'LS', 'ADDA', 'img_trans', 'uncertain_map', 'margin_avg', 'click_spvs' ,'random']
methods_label = ['QBox', 'QBox-Incons.', 'QBox-Trans.',
                 'Least Conf.', 'Local. Stability',
                 'AADA', 'Image Transf.', 'Uncertain Map', 'Margin Average', 'Center Click', 'Random']


def get_one_dataset_AP(dataset, end_iter, suffix_arr, fold=0, smooth=False):
    global methods_label, methods_res
    if dataset != 'voc':
        data_root = f'/data/saved_model_{dataset}'
        repo_root = f'/data/saved_al_{dataset}'
    else:
        data_root = f'/data/saved_model'
        repo_root = f'/data/saved_al'
    class_fn = f"{dataset}{'_tgt' if dataset != 'voc' else ''}.names"
    with open('/home/tangyingpeng/yolov3/data/'+class_fn, 'r') as f:
        class_arr = f.read().splitlines()

    data_mat = np.zeros((len(class_arr), len(methods_label)))
    for mth_id, mth in enumerate(methods_res):
        method_suffix = suffix_arr[mth_id]
        method_mat = np.zeros((len(class_arr), end_iter))
        for it in range(end_iter):
            if smooth and it % 2 != 0 and it != 0:
                continue
            if 'our' in mth:
                map_dir = os.path.join(data_root, f"{mth}_{it}_saved_map{'_' + method_suffix if method_suffix is not None else ''}{'_' + str(fold) if fold > 0 else ''}_aps.txt")
            else:
                map_dir = os.path.join(data_root, f"{mth}_n_{it}_saved_map{'_' + str(fold) if fold > 0 else ''}_aps.txt")

            with open(map_dir, 'r') as fi:
                results = fi.read().splitlines(keepends=False)
                results = np.asarray([result[1:-1].split() for result in results], dtype=float)

            mAP = np.mean(results, axis=1)
            best_it = np.argmax(mAP)
            # record results
            method_mat[:, it] = results[best_it, :]

        if smooth:
            # omit skipped iter
            max_col_val = np.max(method_mat, axis=0)
            non_skipped_mask = (max_col_val != 0)
            method_mat = method_mat[:, non_skipped_mask]
        # record mean AP
        data_mat[:, mth_id] = np.mean(method_mat, axis=1)
    return data_mat


def print_tex(dataset, data_mat):
    global methods_label, methods_res
    class_fn = f"{dataset}{'_tgt' if dataset != 'voc' else ''}.names"
    with open('/home/tangyingpeng/yolov3/data/'+class_fn, 'r') as f:
        class_arr = f.read().splitlines()

    assert data_mat.shape[0] == len(class_arr)
    assert data_mat.shape[1] == len(methods_res)
    bold_idx = np.argmax(data_mat, axis=1)

    # latex codes
    print("""\\begin{tabular}{c|ccccccccccc}
    \\toprule
    \hline
    & [1]& [2]& [3]& [4]& [5]& [6]& [7]& [8]& [9]& [10]& [11] \\\\
    \hline""")

    for id, val in enumerate(bold_idx):
        print(f"\t{class_arr[id]} ", end='')
        for col in range(data_mat.shape[1]):
            if col != val:
                print(f"& {data_mat[id][col]*100:.1f} ", end='')
            else:
                print('& \\textbf{'+ f"{data_mat[id][col]*100:.1f}"+'} ', end='')
        print('\\\\')

          
    print("""\t\hline
    \\bottomrule
\end{tabular}
    """
    )


for dataset in ['kitti', 'city', 'voc']:
# for dataset in ['voc']:
    if dataset == 'voc':
        suffix_arr = [None] * len(methods_res)
    else:
        suffix_arr = ['da01'] + [None] * (len(methods_res)-1)

    data_mat = get_one_dataset_AP(dataset, end_iter=18 if dataset=='kitti' else 16, suffix_arr=suffix_arr)
    print('#'*10 + f" {dataset} "+'#'*10)
    print_tex(dataset, data_mat)
