"""
label space of CITY as target domain:

person(person, rider)
car (car, truck)
bus
train
motorcycle
bicycle
"""

import numpy as np
import os

data_root = "/data/cityscape/coco/images"
lab_root = "/data/cityscape/coco/labels"
setting_root = "/data/dataset/"
source_train = '/data/cityscape/VOC2007/ImageSets/Main/train_s.txt'  # only file name, no extension
target_train = '/data/cityscape/VOC2007/ImageSets/Main/train_t.txt'
target_test = '/data/cityscape/VOC2007/ImageSets/Main/test_s.txt'
ext = '.jpg'


def create_src_file_list():
    with open(source_train, 'r') as f:
        src_t = f.read().splitlines(keepends=False)
    with open(target_train, 'r') as f:
        tgt_t = f.read().splitlines(keepends=False)
    with open(target_test, 'r') as f:
        tgt_test = f.read().splitlines(keepends=False)
    # np.savetxt(os.path.join(setting_root + 'city_src.txt'),
    #            [os.path.join(data_root, item + ext) for item in src_t + tgt_t], fmt='%s')
    # all_src = src_t + tgt_t
    # np.random.shuffle(all_src)
    # np.savetxt(os.path.join(setting_root + 'city_src_ini.txt'),
    #            [os.path.join(data_root, item + ext) for item in all_src[0:1000]], fmt='%s')
    # np.savetxt(os.path.join(setting_root + 'city_src_unlab.txt'),
    #            [os.path.join(data_root, item + ext) for item in all_src[1000:]], fmt='%s')
    np.savetxt(os.path.join(setting_root + 'city_tgt_test.txt'),
               [os.path.join(data_root, item + ext) for item in tgt_test], fmt='%s')
    np.random.shuffle(tgt_t)
    np.savetxt(os.path.join(setting_root + 'city_tgt_ini.txt'),
               [os.path.join(data_root, item + ext) for item in tgt_t[0:1000]], fmt='%s')
    # np.random.shuffle(src_t)
    # np.savetxt(os.path.join(setting_root + 'city_tgt_test.txt'),
    #            [os.path.join(data_root, item + ext) for item in tgt_test], fmt='%s')


# create_src_file_list()

def filter(arr):
    """map src to tgt"""
    lab_id = int(arr[0])
    if lab_id == 0:
        return 0
    elif lab_id == 2:
        return 1
    elif lab_id == 4:
        return 2
    elif lab_id == 5:
        return 3
    elif lab_id == 6:
        return 4
    elif lab_id == 7:
        return 5
    else:
        return None


def create_tgt_labels(output_label_dir):
    ori_files = os.listdir(lab_root)
    for f in ori_files:
        labs = np.loadtxt(os.path.join(lab_root, f))
        if labs.ndim == 1:
            labs = labs.reshape((1, -1))
        # filter classes
        val_lab = []
        for lab in labs:
            after_filter = filter(lab)
            if after_filter is not None:
                lab[0] = after_filter
                val_lab.append(lab)

        if len(val_lab) > 0:
            np.savetxt(os.path.join(output_label_dir, f),
                       val_lab, fmt='%s')


# create_tgt_labels("/data/cityscape/coco/labels_tgt")


def filter_tgt_file_list():
    with open(os.path.join(setting_root + 'city_tgt_test.txt')) as f:
        tt = f.read().splitlines(keepends=False)
    with open(os.path.join(setting_root + 'city_tgt_ini.txt')) as f:
        ti = f.read().splitlines(keepends=False)
    city_test = np.asarray(tt)
    city_ini = np.asarray(ti)
    valid_files = os.listdir('/data/cityscape/coco/labels_tgt')
    val_mask = [True]*len(city_test)
    for i, item in enumerate(city_test):
        if item.split('/')[-1].replace('jpg', 'txt') not in valid_files:
            val_mask[i] = False
    city_test = city_test[val_mask]

    val_mask = [True] * len(city_ini)
    for i, item in enumerate(city_ini):
        if item.split('/')[-1].replace('jpg', 'txt') not in valid_files:
            val_mask[i] = False
    city_ini = city_ini[val_mask]

    print(len(city_ini))
    print(len(city_test))
    city_ini = list(city_ini)
    city_test = list(city_test)

    for i in range(len(city_ini)):
        city_ini[i] = city_ini[i].replace('/images/', '/images_tgt/')
        if city_ini[i][-4:] != '.jpg':
            city_ini[i] += '.jpg'
    for i in range(len(city_test)):
        city_test[i] = city_test[i].replace('/images/', '/images_tgt/')
        if city_test[i][-4:] != '.jpg':
            city_test[i] += '.jpg'

    np.savetxt(os.path.join(setting_root + 'city_tgt_test.txt'), city_test, fmt='%s')
    np.savetxt(os.path.join(setting_root + 'city_tgt_ini.txt'), city_ini, fmt='%s')


create_src_file_list()
filter_tgt_file_list()
