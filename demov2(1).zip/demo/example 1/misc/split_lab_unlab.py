import numpy as np
import os


def split_lab(dataset, lab_num, dataset_name):
    total_num = len(dataset)
    idx = np.arange(total_num)
    np.random.shuffle(idx)

    ini_lab = open(f'{dataset_name}_init_lab.txt', 'w')
    ini_unlab = open(f'{dataset_name}_init_unlab.txt', 'w')

    for i in idx:
        if i < round(lab_num):
            ini_lab.write(dataset.img_files[i] + os.linesep)
        else:
            ini_unlab.write(dataset.img_files[i] + os.linesep)

    ini_lab.close()
    ini_unlab.close()

from al.train_test_func import get_gt_dataloader

VOC_COCO = {
    'pkl': '/data/saved_model/init_da_yolo_coco.pkl',
    'coco_dir': '/data/coco/images/train2014/',
    'voc_dir': '/data/voc/voc_pure_data/images/',
    'data': '/home/tangyingpeng/yolov3/data/voc_coco.data',
    'label_map': '/home/tangyingpeng/yolov3/data/cocoid2vocid.pkl',
    'cfg': '/home/tangyingpeng/yolov3/cfg/yolov3-spp-voc.cfg',
}

TOTAL_SCORE_THRES = 0.1
INCONS_SCORE_THRES = 0.1
TRANS_SCORE_THRES = 0.1
POS_INS_WEIGHT = 10
TRANS_TRANDEOFF = 0.1
TRANS_NORM = False
batch_size = 32
accumulate = 2
epochs = 20
img_size = 416
pretrain_weights = '/home/tangyingpeng/todal/darknet/darknet53.conv.74'

_, s_gt_ds, s_gt_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='source_train', img_size=416,
                                        batch_size=batch_size,
                                        rect=False, img_weights=False, cache_images=False, shuffle=False,
                                        augment=False, data_root=VOC_COCO['coco_dir'])
nc, t_gt_ds, t_gt_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='target_train', img_size=416,
                                         batch_size=batch_size,
                                         rect=False, img_weights=False, cache_images=False, shuffle=False,
                                         augment=False, data_root=VOC_COCO['voc_dir'])

split_lab(s_gt_ds, 1000, 'coco')
split_lab(t_gt_ds, 1000, 'voc')

