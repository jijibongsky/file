# with open('/data/cityscape/VOC2007/ImageSets/Main/train_s.txt', 'r') as f:
#     a = f.read().splitlines()
# with open('/data/cityscape/VOC2007/ImageSets/Main/train_t.txt', 'r') as f:
#     b = f.read().splitlines()
#
# print(len(a) == len(b), a[0] == b[0])
#
import pickle
import torch
from al.train_test_func import hyp
from utils.datasets import ConvertRepo2Dataset

with open(f"/data/saved_al/our_trans_{1}_all.pkl", 'rb') as f:
    queried_repo = pickle.load(f)
updated_lab_ds = ConvertRepo2Dataset(query_repo=queried_repo, img_size=416, batch_size=32,
                                     augment=False, hyp=hyp, rect=False, image_weights=False, cache_images=False)
# Dataloader
q_dataloader = torch.utils.data.DataLoader(updated_lab_ds,
                                           batch_size=32,
                                           num_workers=0,
                                           shuffle=False,  # Shuffle=True unless rectangular training is used
                                           pin_memory=True,
                                           collate_fn=updated_lab_ds.collate_fn,
                                           drop_last=False)

q_iter = iter(q_dataloader)
batch = next(q_iter)
print()
