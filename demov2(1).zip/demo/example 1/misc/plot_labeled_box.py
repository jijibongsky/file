from al.train_test_func import *
from al.al_data_loader import QueryRepo
from al.al_utils import al_mainloop, al_scoring, our_al_mainloop
import alipy

TOTAL_SCORE_THRES = 0.1
INCONS_SCORE_THRES = 0.1
TRANS_SCORE_THRES = 0.1
POS_INS_WEIGHT = 10
TRANS_TRANDEOFF = 0.1
TRANS_NORM = False
batch_size = 32
accumulate = 2
epochs = 20
img_size = 416
cache_images = False  # for testing
pretrain_weights = '/home/tangyingpeng/todal/darknet/darknet53.conv.74'

# with open('/home/tangyingpeng/yolov3/data/cocoid2vocid.pkl', 'rb') as f:
#     cocoid2vocid = pickle.load(f)

# # testing only
_, test_ds, t_gt_dl = get_gt_dataloader(data='../data/xray.data', data_item='target_train', img_size=416, batch_size=batch_size,
                                        rect=False, img_weights=False, cache_images=False, shuffle=False,
                                        augment=False, data_root=None)

# with open("/data/dataset/cxr_src.txt", 'r') as f:
#     init_lab = f.read().splitlines()
#
# t_gt_ds = LoadImagesAndLabelsByImgFiles(
#     img_files=init_lab,
#     img_size=img_size,
#     batch_size=batch_size,
#     augment=True,
#     hyp=hyp,  # augmentation hyperparameters
#     rect=False,  # rectangular training
#     image_weights=False,
#     cache_images=False
# )
# # Dataloader
# t_gt_dl = torch.utils.data.DataLoader(t_gt_ds,
#                                      batch_size=batch_size,
#                                      num_workers=4,
#                                      shuffle=False,  # Shuffle=True unless rectangular training is used
#                                      pin_memory=True,
#                                      collate_fn=t_gt_ds.collate_fn)

q_iter = iter(t_gt_dl)

for i in range(100):
    imgs, targets, paths, _ = next(q_iter)
    # # split targets into pos, neg, outliers
    # tgt_pos_mask = [False] * targets.shape[0]
    # tgt_neg_mask = [False] * targets.shape[0]
    # tgt_out_mask = [False] * targets.shape[0]
    # for ti, target in enumerate(targets):
    #     if target[1] >= 0:  # non-background, non-outlier classes
    #         if int(target[1]) in cocoid2vocid.keys():
    #             target[1] = cocoid2vocid[int(target[1])]
    #             tgt_pos_mask[ti] = True
    #         else:
    #             raise ("raise exception: outlier class not equal to -2")
    #     elif target[1] == -1:  # neg class
    #         tgt_neg_mask[ti] = True
    #     elif target[1] == -2:  # out class
    #         tgt_out_mask[ti] = True
    #     else:
    #         raise (f"un-recognized class number: {target[1]}")

    # targets = targets.to(device)

    plot_images(imgs=imgs, targets=targets, paths=paths, fname='test_batch0.jpg')

