import os
import numpy as np
import pickle
from matplotlib import pyplot as plt
import matplotlib.ticker as plticker
import re
import copy

def smooth(a, WSZ):
    # a: NumPy 1-D array containing the data to be smoothed
    # WSZ: smoothing window size needs, which must be odd number,
    # as in the original MATLAB implementation
    out0 = np.convolve(a, np.ones(WSZ, dtype=int), 'valid') / WSZ
    r = np.arange(1, WSZ - 1, 2)
    start = np.cumsum(a[:WSZ - 1])[::2] / r
    stop = (np.cumsum(a[:-WSZ:-1])[::2] / r)[::-1]
    return np.concatenate((start, out0, stop))


def read_map_file(fname):
    with open(fname, 'r') as fi:
        results = fi.read().splitlines(keepends=False)
        results = np.asarray([result[1:-1].split(',') for result in results], dtype=float)
    return results


def get_cost_from_repo_file(fname):
    """passing a path to a specific *current repo*"""
    # with open(fname, 'rb') as f:
    #     repo = pickle.load(f)
    # return repo.tcost
    return None


def get_one_point(method_name, iteration, method_suffix, fold=0):
    i = iteration
    if 'our' in method_name:
        map_dir = os.path.join(data_root,
                               f"{method_name}_{i}_saved_map{'_' + method_suffix if method_suffix is not None else ''}{'_'+str(fold) if fold > 0 else ''}.txt")
    else:
        map_dir = os.path.join(data_root, f"{method_name}_n_{i}_saved_map{'_'+str(fold) if fold > 0 else ''}.txt")
    repo_dir = os.path.join(repo_root, f"{method_name}_{i}.pkl")
    train_res = read_map_file(map_dir)
    cost = get_cost_from_repo_file(repo_dir)
    return np.max(train_res[:, 2]), cost
    # return train_res[-1, 2], cost


def get_start_point(dataset_st, folds_arr=None):
    # get start point
    res = []
    if folds_arr is None:
        folds_arr = [0]
    for fold in folds_arr:
        train_res = read_map_file(f'/data/saved_model/small_{dataset_st}{"_"+str(fold) if fold > 0 else ""}.txt')
        mmap = np.max(train_res[:, 2])
        res.append(mmap)
    return np.mean(res)


def plot_lc(method_arr: 'list', suffix_arr: 'list', end_iteration: 'int' = 10,
            isSmooth=True, legend=False, use_accurate_cost=False, budget_array=None,
            smooth_r=2, smooth_st=0, fold=0):
    global dataset, start_point

    # plt.rc('font', size=SMALL_SIZE)  # controls default text sizes
    # plt.rc('axes', titlesize=16)  # fontsize of the axes title
    plt.rc('axes', labelsize=22)  # fontsize of the x and y labels
    plt.rc('xtick', labelsize=14)  # fontsize of the tick labels
    plt.rc('ytick', labelsize=14)  # fontsize of the tick labels
    plt.rc('legend', fontsize=11)  # legend fontsize
    # plt.rc('figure', titlesize=BIGGER_SIZE)  # fontsize of the figure title

    fig, ax = plt.subplots()
    for mth_id, mth in enumerate(method_arr):
        if use_accurate_cost:
            budget_arr = []
            cost_cur = 0
            for i in range(end_iteration):
                with open(f"/data/saved_al{'_'+dataset if dataset != 'voc' else ''}/{mth}_{i}{'_'+str(fold) if fold > 0 else ''}{'fast' if (mth == 'uncertain_map' and i>=15 and dataset=='voc') else ''}_statistic.txt", 'r') as sf:
                    string_info = sf.read()
                # extract cost
                if 'our' in mth:
                    gp = re.findall(r'total_cost:(.*?)\n', string_info)
                else:
                    gp = re.findall(r'total_cost:(.*?),', string_info)

                budget_arr += [float(gp[0])]
        else:
            budget_arr = budget_array

        # assert mth in name_arr, f'un-known method {mth}'
        x, y = [0], [start_point]
        cost_x = 0
        for it in range(end_iteration):
            # if isSmooth and dataset == 'city':
            #     if it % 2 != 0:
            #         continue
            if isSmooth:
                if (it + smooth_st) % smooth_r != 0 and it != 0:
                    cost_x += budget_arr[it]
                    continue
            mmap, _ = get_one_point(mth, it, suffix_arr[mth_id], fold=fold)
            cost_x += budget_arr[it]
            x.append(cost_x)
            y.append(mmap)
        # smooth:
        # y = np.asarray(y)
        # x = np.asarray(x)
        # if isSmooth:
        #     y = smooth(y, 3)
        print(dataset, mth)
        print(suffix_arr[mth_id])
        print(str(list(x))[1:-1])
        print(str(list(y))[1:-1])

        # ax.plot(x, y, label=mth if suffix_arr[mth_id] is None else mth + f'_{suffix_arr[mth_id]}',
        #         linewidth=3 if 'our' in mth else 1.5)
        ax.plot(x, y, label=methods_label[mth_id],
                linewidth=methods_linewodth[mth_id],
                color=methods_color[mth_id],
                linestyle=methods_lstyle[mth_id],
                marker=methods_marker[mth_id],
                markersize=7 if 'our' in mth else 5
                )
        if dataset == "kitti" or legend:
            ax.legend()
    plt.xlabel("cost")
    plt.ylabel("mAP")
    # ax.set_aspect(1./ax.get_data_ratio(), adjustable='box')

    if dataset == 'city':
        loc = plticker.MultipleLocator(base=30000)  # this locator puts ticks at regular intervals
        ax.xaxis.set_major_locator(loc)
        agca = plt.gca()  # 获取当前图像的坐标轴信息
        agca.xaxis.get_major_formatter().set_powerlimits((0, 2))
    elif dataset == 'kitti':
        loc = plticker.MultipleLocator(base=150000)  # this locator puts ticks at regular intervals
        ax.xaxis.set_major_locator(loc)
        agca = plt.gca()  # 获取当前图像的坐标轴信息
        agca.xaxis.get_major_formatter().set_powerlimits((0, 2))
    elif dataset == 'voc':
        agca = plt.gca()  # 获取当前图像的坐标轴信息
        agca.xaxis.get_major_formatter().set_powerlimits((0, 2))
    else:
        loc = plticker.MultipleLocator(base=5000)  # this locator puts ticks at regular intervals
        ax.xaxis.set_major_locator(loc)
        agca = plt.gca()  # 获取当前图像的坐标轴信息
        agca.xaxis.get_major_formatter().set_powerlimits((0, 2))

    fig.tight_layout()
    fig.savefig(f'lc_{dataset}{"_"+str(fold) if fold > 0 else ""}.png', dpi=200, bbox_inches='tight')
    fig.show()


def plot_lc_multi_folds(method_arr: 'list', suffix_arr: 'list', folds:'int'=10, end_iteration: 'int' = 10,
            isSmooth=True, legend=False, use_accurate_cost=False, budget_array=None, smooth_r=2, smooth_st=0,
            skip_arr=()):
    global dataset, start_point

    # plt.rc('font', size=SMALL_SIZE)  # controls default text sizes
    # plt.rc('axes', titlesize=16)  # fontsize of the axes title
    # plt.rc('axes', labelsize=22)  # fontsize of the x and y labels
    # plt.rc('xtick', labelsize=14)  # fontsize of the tick labels
    # plt.rc('ytick', labelsize=14)  # fontsize of the tick labels
    # plt.rc('legend', fontsize=8)  # legend fontsize
    # plt.rc('figure', titlesize=BIGGER_SIZE)  # fontsize of the figure title

    # fig, ax = plt.subplots()
    # start_point = get_start_point(dataset, folds)

    from alipy.experiment.experiment_analyser import ExperimentAnalyser

    analyser = ExperimentAnalyser('cost')
    for mth_id, mth in enumerate(method_arr):
        method_multi_folds_res = []
        for fold in range(folds):
            if fold in skip_arr:
                continue
            # get budget arr
            if use_accurate_cost:
                budget_arr = []
                cost_cur = 0
                for i in range(end_iteration):
                    with open(f"/data/saved_al_{dataset}/{mth}_{i}{'_'+str(fold) if fold > 0 else ''}_statistic.txt", 'r') as sf:
                        string_info = sf.read()
                    # extract cost
                    if 'our' in mth:
                        gp = re.findall(r'total_cost:(.*?)\n', string_info)
                    else:
                        gp = re.findall(r'total_cost:(.*?),', string_info)

                    budget_arr += [float(gp[0])]
            else:
                budget_arr = budget_array

            # assert mth in name_arr, f'un-known method {mth}'
            one_fold_curve = []
            cost_x = 0
            for it in range(end_iteration):
                # if isSmooth and dataset == 'city':
                #     if it % 2 != 0:
                #         continue
                if isSmooth:
                    if (it + smooth_st) % smooth_r != 0 and it != 0:
                        cost_x += budget_arr[it]
                        continue
                mmap, _ = get_one_point(mth, it, suffix_arr[mth_id], fold=fold)
                cost_x += budget_arr[it]
                one_fold_curve.append((cost_x, mmap))
            method_multi_folds_res.append(copy.copy(one_fold_curve))

        analyser.add_method(method_name=mth, method_results=method_multi_folds_res)
    plt = analyser.plot_learning_curves(show=False, plot_interval=85000/11, std_area=False, start_point=start_point)
    return plt



def plot_hyper_param_lc(suffix_arr: 'list', budget_array: 'list',
                        end_iteration: 'int' = 1, legend=False,
                        use_accurate_cost=True):
    global dataset

    # plt.rc('font', size=SMALL_SIZE)  # controls default text sizes
    # plt.rc('axes', titlesize=16)  # fontsize of the axes title
    plt.rc('axes', labelsize=22)  # fontsize of the x and y labels
    plt.rc('xtick', labelsize=14)  # fontsize of the tick labels
    plt.rc('ytick', labelsize=14)  # fontsize of the tick labels
    plt.rc('legend', fontsize=8)  # legend fontsize
    # plt.rc('figure', titlesize=BIGGER_SIZE)  # fontsize of the figure title

    fig, ax = plt.subplots()
    for mth_id, mth in enumerate(suffix_arr):
        if use_accurate_cost:
            budget_arr = []
            cost_cur = 0
            for i in range(end_iteration):
                with open(f"/data/saved_al{'_' + dataset if dataset != 'voc' else ''}/{mth}_{i}_statistic.txt", 'r') as sf:
                    string_info = sf.read()
                # extract cost
                if 'our' in mth:
                    gp = re.findall(r'total_cost:(.*?)\n', string_info)
                else:
                    gp = re.findall(r'total_cost:(.*?),', string_info)

                budget_arr += [float(gp[0])]
        else:
            budget_arr = budget_array

        # assert mth in name_arr, f'un-known method {mth}'
        x, y = [0], [start_point]
        cost_x = 0
        for it in range(end_iteration):
            mmap, cost = get_one_point('our', it, mth)
            cost_x += budget_arr[it]
            x.append(cost_x)
            y.append(mmap)
        print(dataset, mth)
        print(suffix_arr[mth_id])
        print(str(list(x))[1:-1])
        print(str(list(y))[1:-1])

        ax.plot(x, y, label=mth if mth is not None else 'our',
                )
        if dataset == "kitti" or legend:
            ax.legend()
    plt.xlabel("cost")
    plt.ylabel("mAP")

    fig.tight_layout()
    fig.savefig(f'lc_{dataset}.png', dpi=200)
    fig.show()

def print_auc(suffix_arr: 'list', budget_array: 'list',
                end_iteration: 'int' = 10,
                use_accurate_cost=False, plot_flag=False,
              isSmooth = True, smooth_st=0, smooth_r=2):
    global dataset

    param_label = ['$\eta$=0.1', '$\eta$=1', '$\eta$=10']
    methods_color = ['#F71E35', '#6f2108', '#e77e4d']
    methods_marker = ["D", "d", "^"]
    # plt.rc('font', size=SMALL_SIZE)  # controls default text sizes
    # plt.rc('axes', titlesize=16)  # fontsize of the axes title
    plt.rc('axes', labelsize=22)  # fontsize of the x and y labels
    plt.rc('xtick', labelsize=14)  # fontsize of the tick labels
    plt.rc('ytick', labelsize=14)  # fontsize of the tick labels
    plt.rc('legend', fontsize=16)  # legend fontsize
    # plt.rc('figure', titlesize=BIGGER_SIZE)  # fontsize of the figure title

    fig, ax = plt.subplots()
    for mth_id, mth in enumerate(suffix_arr):
        if use_accurate_cost:
            budget_arr = []
            cost_cur = 0
            for i in range(end_iteration):
                with open(f"/data/saved_al{'_' + dataset if dataset != 'voc' else ''}/our_{i}_statistic.txt", 'r') as sf:
                    string_info = sf.read()
                # extract cost
                if 'our' in mth:
                    gp = re.findall(r'total_cost:(.*?)\n', string_info)
                else:
                    gp = re.findall(r'total_cost:(.*?),', string_info)

                budget_arr += [float(gp[0])]
        else:
            budget_arr = budget_array

        # assert mth in name_arr, f'un-known method {mth}'
        x, y = [0], [start_point]
        cost_x = 0
        for it in range(end_iteration):
            if isSmooth:
                if (it + smooth_st) % smooth_r != 0 and it != 0:
                    cost_x += budget_arr[it]
                    continue
            mmap, cost = get_one_point('our', it, mth)
            cost_x += budget_arr[it]
            x.append(cost_x)
            y.append(mmap)
        if plot_flag:
            ax.plot(x, y, label=param_label[mth_id],
                    linewidth=2.2,
                    color=methods_color[mth_id],
                    linestyle='-' if mth_id < 2 else '-.',
                    marker=methods_marker[mth_id],
                    markersize=7
                    )
            # if dataset == "kitti":
            ax.legend()
        else:
            print(dataset, mth)
            x = np.array(x)
            y = np.array(y)
            auc = x/x.max() * y
            # print(auc)
            print(sum(auc))
    plt.xlabel("cost")
    plt.ylabel("mAP")

    if dataset == 'city':
        loc = plticker.MultipleLocator(base=30000)  # this locator puts ticks at regular intervals
        ax.xaxis.set_major_locator(loc)
        agca = plt.gca()  # 获取当前图像的坐标轴信息
        agca.xaxis.get_major_formatter().set_powerlimits((0, 2))
    elif dataset == 'kitti':
        loc = plticker.MultipleLocator(base=150000)  # this locator puts ticks at regular intervals
        ax.xaxis.set_major_locator(loc)
        agca = plt.gca()  # 获取当前图像的坐标轴信息
        agca.xaxis.get_major_formatter().set_powerlimits((0, 2))
    elif dataset == 'voc':
        agca = plt.gca()  # 获取当前图像的坐标轴信息
        agca.xaxis.get_major_formatter().set_powerlimits((0, 2))
    else:
        loc = plticker.MultipleLocator(base=5000)  # this locator puts ticks at regular intervals
        ax.xaxis.set_major_locator(loc)
        agca = plt.gca()  # 获取当前图像的坐标轴信息
        agca.xaxis.get_major_formatter().set_powerlimits((0, 2))

    fig.tight_layout()
    fig.savefig(f'ps_{dataset}.png', dpi=200, bbox_inches='tight')
    fig.show()


methods_res = ['our', 'our_incons', 'our_trans', 'least_conf',
               'LS', 'ADDA', 'img_trans', 'uncertain_map', 'margin_avg', 'click_spvs' ,'random']
methods_label = ['QBox', 'QBox-Inconsistency', 'QBox-Transferability',
                 'Least Confidence [33]', 'Localization  Stability [20]',
                 'AADA [39]', 'Image Transferability', 'Uncertain Map [2]', 'Margin Average [3]', 'Center Click [7]', 'Random']
methods_linewodth = [2.8, 2.2, 1.7, 1.7,
                     1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.7]
methods_lstyle = ['-', ':', '-.',
                  '--', '--',
                  '--', '--', '--', '--', '--', '-']
methods_color = ['#F71E35', '#F71E35', '#F71E35',
                 '#274c5e', '#0080ff',
                 '#bf209f', '#79bd9a', '#4013af', 'gray', '#679b00', 'black']
methods_marker = ["D", "d", "d",
                  "^", "^",
                  "o", "o", "^", "^", "^", "o"]

############## KITTI ############################
dataset = 'kitti'
data_root = f'/data/saved_model_{dataset}'
repo_root = f'/data/saved_al_{dataset}'
start_point = 0.308 if dataset == 'kitti' else 0.0975
budget_rate = np.array([0.005 if dataset == 'kitti' else 0.0011] * 100)
budget_arr = 25.5 * 349525 * budget_rate

plot_lc(method_arr=methods_res,
        suffix_arr=['da01'] + [None] * (len(methods_res)-1),
        end_iteration=18, isSmooth=True, legend=True,
        budget_array=budget_arr, use_accurate_cost=True)

# print_auc(suffix_arr=['da01', None, 'da10'], budget_array=budget_arr, end_iteration=18, plot_flag=True)

############# CITY ############################

dataset = 'city'
data_root = f'/data/saved_model_{dataset}'
repo_root = f'/data/saved_al_{dataset}'
start_point = 0.308 if dataset == 'kitti' else 0.0975
budget_rate = np.array([0.005 if dataset == 'kitti' else 0.0011] * 100)
budget_arr = 25.5 * 349525 * budget_rate

plot_lc(method_arr=methods_res,
        suffix_arr=[None] + [None] * (len(methods_res)-1),
        end_iteration=16, isSmooth=True, legend=False, smooth_st=0,
        budget_array=budget_arr, use_accurate_cost=True)

# print_auc(suffix_arr=['da01', None, 'da10'], budget_array=budget_arr, end_iteration=16, plot_flag=True)

# ############# VOC ############################

dataset = 'voc'
data_root = '/data/saved_model'
repo_root = '/data/saved_al'
start_point = 0.356
budget_rate = np.array([0.0015] * 100)
budget_arr = 25.5 * 349525 * budget_rate

plot_lc(method_arr=methods_res,
        suffix_arr=['da01'] + [None] * (len(methods_res)-1),
        end_iteration=16, isSmooth=True, legend=False, smooth_st=0,
        budget_array=budget_arr, use_accurate_cost=True)

# print_auc(suffix_arr=['da01', None, 'da10'], budget_array=budget_arr, end_iteration=16, plot_flag=True)

############# COVID ############################

# methods_res = ['our', 'our_incons', 'our_trans', 'least_conf',
#                'LS', 'ADDA', 'img_trans', 'uncertain_map', 'margin_avg', 'click_spvs' ,'random']
# methods_label = ['QBox', 'QBox-Inconsistency', 'QBox-Transferability',
#                  'Least Confidence', 'Localization  Stability',
#                  'AADA', 'Image Transferability', 'uncertain_map', 'margin_avg', 'click_spvs', 'Random']
# # methods_res = ['our', 'our_incons', 'least_conf',
# #                'LS', 'ADDA', 'img_trans', 'uncertain_map', 'margin_avg', 'click_spvs' ,'random']
# # methods_label = ['QBox', 'our_incons',
# #                  'Least Confidence', 'Localization  Stability',
# #                  'AADA', 'Image Transferability', 'uncertain_map', 'margin_avg', 'click_spvs', 'Random']
#
# dataset = 'covid'
# data_root = f'/data/saved_model_{dataset}'
# repo_root = f'/data/saved_al_{dataset}'
# start_point = 0.698
# budget_rate = np.array([(25.5*2 + 7.8) * 5 / 349525 / 25.5] * 100)
# budget_arr = 25.5 * 349525 * budget_rate
#
# for fff in range(10):
#     plot_lc(method_arr=methods_res,
#             suffix_arr=['da01']+[None] * (len(methods_res)-1),
#             end_iteration=30, isSmooth=False, smooth_r=3, smooth_st=0,
#             legend=True, budget_array=budget_arr,
#             use_accurate_cost=True, fold=fff)

########################################################

'''
# methods_res = ['our', 'our_incons', 'our_trans', 'least_conf',
#                'LS', 'ADDA', 'img_trans', 'uncertain_map', 'margin_avg', 'click_spvs' ,'random']
# methods_label = ['QBox', 'QBox-Inconsistency', 'QBox-Transferability',
#                  'Least Confidence', 'Localization  Stability',
#                  'AADA', 'Image Transferability', 'Uncertain Map', 'Margin Average', 'Center Click', 'Random']
# methods_res = ['our', 'our_incons', 'least_conf',
#                'LS', 'ADDA', 'img_trans', 'uncertain_map', 'margin_avg', 'click_spvs', 'random']
# methods_label = ['QBox', 'QBox-Inconsistency',
#                  'Least Confidence', 'Localization  Stability',
#                  'AADA', 'Image Transferability', 'Uncertain Map', 'Margin Average', 'Center Click', 'Random']

all_fold = set(range(10))
# valid_fold = set((0,1,3,5,8))
# # valid_fold = set((1,3,5))
# valid_fold = all_fold
dataset = 'covid'
data_root = f'/data/saved_model_{dataset}'
repo_root = f'/data/saved_al_{dataset}'
start_point = get_start_point(dataset, all_fold)
budget_rate = np.array([(25.5*2 + 7.8) * 5 / 349525 / 25.5] * 100)
budget_arr = 25.5 * 349525 * budget_rate

# [2,4,6,7,9],[0,2,4,6,7,8,9]
ali_plot = plot_lc_multi_folds(method_arr=methods_res,
                suffix_arr=['old_param']+[None] * (len(methods_res)-1),
                end_iteration=23, isSmooth=False, smooth_r=2, smooth_st=0,
                legend=True, budget_array=budget_arr,
                use_accurate_cost=True, folds=9, skip_arr=[])

# convert the plot style
# extract plot data
xdata_arr = []
ydata_arr = []
ali_plt_data = ali_plot.gca()
lines = ali_plt_data.lines
for i, line in enumerate(lines):
    xdata = line.get_xdata()
    ydata = line.get_ydata()
    xdata_arr.append(xdata)
    ydata_arr.append(ydata)
ali_plot.show()

# set style
plt.rc('axes', labelsize=22)  # fontsize of the x and y labels
plt.rc('xtick', labelsize=14)  # fontsize of the tick labels
plt.rc('ytick', labelsize=14)  # fontsize of the tick labels
plt.rc('legend', fontsize=9)  # legend fontsize
# plt.rc('figure', titlesize=BIGGER_SIZE)  # fontsize of the figure title

fig, ax = plt.subplots()
# ali_plt_data = ali_plot.gca()
# lines = ali_plt_data.lines
for i, line in enumerate(xdata_arr):
    xdata = xdata_arr[i]
    ydata = ydata_arr[i]

    ax.plot(xdata, ydata, label=methods_label[i],
            linewidth=methods_linewodth[i],
            color=methods_color[i],
            linestyle=methods_lstyle[i],
            marker=methods_marker[i],
            markersize=7 if 'our' in methods_res[i] else 5
            )
    ax.legend()
plt.xlabel("cost")
plt.ylabel("mAP")
loc = plticker.MultipleLocator(base=20000)  # this locator puts ticks at regular intervals
ax.xaxis.set_major_locator(loc)
agca = plt.gca()  # 获取当前图像的坐标轴信息
agca.xaxis.get_major_formatter().set_powerlimits((0, 2))
fig.tight_layout()
fig.savefig(f'lc_{dataset}_avg.png', dpi=200)
fig.show()
'''

############## parameter selection ############################
# dataset = 'covid'
# data_root = f'/data/saved_model_{dataset}'
# repo_root = f'/data/saved_al_{dataset}'
# start_point = 0.698
# budget_rate = np.array([(25.5*2 + 7.8) * 5 / 349525 / 25.5] * 100)
# budget_arr = 25.5 * 349525 * budget_rate
#
# # 'ste3', 'ste5', 'clsw05', 'clsw15', 'boxrw08', 'boxrw12',
# plot_hyper_param_lc(
#         suffix_arr=['novel', 'ste5', None
#                     ],
#         end_iteration=30,
#         legend=True)
