"""Statistic the epsilon and alpha for each dataset.
epsilon: the 20th percentile of minimum distances between any two objects.
alpha: the 90th percentile of areas of bounding boxes.

epsilon and alpha are used to perform Region Proposal Filtering for click supervision method.
"""

from al.train_test_func import *
import itertools

dataset = 'voc'

if dataset == 'voc':
    dataset_config = VOC_COCO
elif dataset == 'sim':
    dataset_config = SIM_KITTI
elif dataset == 'kitti':
    dataset_config = KITTI_CITY
elif dataset == 'city':
    dataset_config = CITY_VOC
elif dataset == 'xray':
    dataset_config = RSNA_CXR
elif dataset == 'covid':
    dataset_config = COVID_PNEU
else:
    raise ValueError("dataset must in ['voc', 'sim', 'kitti', 'city']")

# voc src
data_dict = parse_data_cfg(os.path.join('/home/tangyingpeng/yolov3', dataset_config['data']))
train_path = data_dict['source_train']
with open(train_path, 'r') as f:
    flist = f.read().splitlines()

# label dict
with open(os.path.join('/home/tangyingpeng/yolov3', dataset_config['label_map']), 'rb') as f:
    src2tgt_labelmap = pickle.load(f)

if dataset == 'voc':
    # dataset_obj = LoadImagesAndLabels(train_path,
    #                                   416,
    #                                   32,
    #                                   augment=True,
    #                                   hyp=hyp,  # augmentation hyperparameters
    #                                   rect=False,  # rectangular training
    #                                   image_weights=False,
    #                                   cache_images=False,
    #                                   DATA_ROOT='/data/coco/images/train2014/',
    #                                   data_type='voc',
    #                                   dbg=True,
    #                                   valid_lab=list(src2tgt_labelmap.keys())
    #                                   )
    with open(os.path.join('/home/tangyingpeng/yolov3', 'misc/coco_init_lab.txt'), 'r') as f:
        init_lab = f.read().splitlines(keepends=False)
else:
    with open(os.path.join('/data/dataset', dataset_config['src'] + '_src_ini.txt'), 'r') as f:
        init_lab = f.read().splitlines(keepends=False)
dataset_obj = LoadImagesAndLabelsByImgFiles(
    img_files=init_lab,
    img_size=416,
    batch_size=32,
    augment=True,
    hyp=hyp,  # augmentation hyperparameters
    rect=False,  # rectangular training
    image_weights=False,
    cache_images=False,
    dbg=True,
    valid_lab=list(src2tgt_labelmap.keys())
)


################### statistic #############################


def get_arae(boxes, img_size=416):
    """xywh"""
    mat = np.array(boxes)
    coord = mat[:, 1:]
    x1 = coord[:, 0] - coord[:, 2] / 2
    y1 = coord[:, 1] - coord[:, 3] / 2
    x2 = coord[:, 0] + coord[:, 2] / 2
    y2 = coord[:, 1] + coord[:, 3] / 2
    return (x2 - x1) * (y2 - y1) * 416 * 416


def get_dist(boxes):
    """get distance between each two objects."""
    mat = np.array(boxes)
    cent_pt = mat[:, 1:3]
    comb = itertools.combinations(cent_pt, r=2)
    return [np.linalg.norm(pair[0]-pair[1], ord=2) for pair in comb]


valid_lab_id = list(src2tgt_labelmap.keys())
labs = dataset_obj.labels

area_set = []
dist_set = []
for i in labs:
    # get valid labels
    valid_labs = []
    for lab in i:
        if lab[0] in valid_lab_id:
            valid_labs.append(lab)

    if len(valid_labs) == 0:
        continue
    # get area of each bbox
    areas = get_arae(valid_labs)
    area_set += list(areas)

    # get distance between objects
    if len(valid_labs) < 2:
        continue
    dists = get_dist(valid_labs)
    dist_set += dists

# get percentile
epsilon = np.percentile(dist_set, 20)
alpha = np.percentile(area_set, 10)

# print('epsilon:', epsilon*416)
print('alpha:', alpha)
