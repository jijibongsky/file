import os
import numpy as np

#################### source ######################################
ini_size = 100
dir = "/data/download/CXR8/images_merged/"
flist = os.listdir(dir)
with open("/data/dataset/cxr_src.txt", 'w') as f:
    for fname in flist:
        f.write(os.path.join(dir, fname) + os.linesep)

with open("/data/dataset/cxr_src_ini.txt", 'w') as f:
    for i in np.arange(ini_size):
        fname = flist[i]
        f.write(os.path.join(dir, fname) + os.linesep)

with open("/data/dataset/cxr_src_unlab.txt", 'w') as f:
    for i in np.arange(ini_size, len(flist)):
        fname = flist[i]
        f.write(os.path.join(dir, fname) + os.linesep)


#################### target #######################################

dir = "/data/download/RSNA/images_all"
lab_dir = "/data/download/RSNA/labels_all"
# create_ini_set
ini_size = 100
test_size = 1000
flist = os.listdir(lab_dir)
np.random.shuffle(flist)
test_set = dict()
with open("/data/dataset/rsna_tgt_ini.txt", 'w') as f:
    for i in range(ini_size):
        f.write(os.path.join(dir, flist[i].split('.')[0] + '.png' + os.linesep))
        test_set[flist[i].split('.')[0] + '.png'] = 0

with open("/data/dataset/rsna_tgt_test.txt", 'w') as f:
    for i in np.arange(ini_size, ini_size + test_size):
        f.write(os.path.join(dir, flist[i].split('.')[0] + '.png' + os.linesep))
        test_set[flist[i].split('.')[0] + '.png'] = 0

# aflist = os.listdir(dir)
# valid_count=0
# with open("/data/dataset/rsna_tgt_test.txt", 'w') as f:
#     for i in range(len(aflist)):
#         if valid_count >= test_size:
#             break
#         if aflist[i] not in test_set:
#             valid_count += 1
#             f.write(os.path.join(dir, aflist[i]+os.linesep))
