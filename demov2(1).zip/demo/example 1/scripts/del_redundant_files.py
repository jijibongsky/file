import os
import numpy as np
pth = '/data/saved_model_rsna'
method_arr = ['ADDA_n_', 'img_trans_n_', 'random_n_', 'LS_n_']
sufix = '_best.pt'
flist = os.listdir(pth)
for i in np.arange(21, 50):
    for mth in method_arr:
        file_name = mth + str(i) + sufix
        if file_name in flist:
            os.remove(os.path.join(pth, file_name))
