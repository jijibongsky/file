import os, json
from tqdm import tqdm
import random
import cv2
import pandas
from skimage.measure import label, regionprops
from skimage import color

# class_file_path = '/data/download/RSNA/stage_2_train_labels.csv'
#
# # retrieve the labels of the segmented images.
# rsna_data_dir = '/home/tangyingpeng/covid_data/rsna_seg/ori_data'
#
# lab_csv = pandas.read_csv(class_file_path)
# data_list = os.listdir(rsna_data_dir)
#
# normal = []
# pneumonia = []
#
# for fn in data_list:
#     row = lab_csv[lab_csv['patientId']==fn]
#     if row['Target'].values[0] == 0:
#         normal.append(fn)
#     else:
#         pneumonia.append(fn)
#
# print('normal:', len(normal))
# print('pneumonia:', len(pneumonia))
# # write file
# with open('/home/tangyingpeng/covid_data/rsna_seg/normal.txt', 'w') as f:
#     for item in normal:
#         f.write(item+os.linesep)
# with open('/home/tangyingpeng/covid_data/rsna_seg/pneumonia.txt', 'w') as f:
#     for item in pneumonia:
#         f.write(item+os.linesep)

########################################################################################################
#
# def plot_one_box(x, img, color=None, label=None, line_thickness=None, save_name='default.jpg'):
#     # Plots one bounding box on image img
#     tl = line_thickness or round(0.002 * (img.shape[0] + img.shape[1]) / 2) + 1  # line thickness
#     color = color or [random.randint(0, 255) for _ in range(3)]
#     c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
#     cv2.rectangle(img, c1, c2, color, thickness=tl)
#     if label:
#         tf = max(tl - 1, 1)  # font thickness
#         t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
#         c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
#         cv2.rectangle(img, c1, c2, color, -1)  # filled
#         cv2.putText(img, label, (c1[0], c1[1] - 2), 0, tl / 3, [225, 255, 255], thickness=tf, lineType=cv2.LINE_AA)
#     cv2.imwrite(save_name, img)
#
#
# # convert the mask to bbox
# rsna_mask_dir = '/home/tangyingpeng/covid_data/rsna_seg/masks'
# output_dir = '/home/tangyingpeng/covid_data/rsna_seg/labels'
#
# mask_list = os.listdir(rsna_mask_dir)
# mapping = pandas.read_csv('/home/tangyingpeng/covid_data/rsna_seg/train.csv')
# with open('/home/tangyingpeng/covid_data/rsna_seg/normal.txt', 'r') as f:
#     normal_flist = f.read().splitlines()
# with open('/home/tangyingpeng/covid_data/rsna_seg/pneumonia.txt', 'r') as f:
#     abnormal_flist = f.read().splitlines()
#
# for f in mask_list:
#     fname = mapping[mapping['label'] == f]['image'].values[0].replace('.png', '')
#     mask = cv2.imread(os.path.join(rsna_mask_dir, f))
#     h, w = mask.shape[0:2]
#     binary_mask = mask[:, :, 0]
#     labeled_region = label(binary_mask, background=0, return_num=False, connectivity=2)
#
#     # image_label_overlay = color.label2rgb(labeled_region, image=mask, bg_label=0, bg_color=(125, 125, 125))
#     # cv2.imwrite('temp.jpg', image_label_overlay)  # ok
#
#     regions = regionprops(labeled_region, coordinates='xy')
#
#     # filter out bbox whose w or h is less than 10 pixels
#     regions = [item for item in regions if (item.bbox[3]-item.bbox[1]>50 and item.bbox[2]-item.bbox[0]>50)]
#
#     # box = regions[0].bbox   # y1x1y2x2
#     # xyxy = (box[1], box[0], box[3], box[2])
#     # plot_one_box(xyxy, image_label_overlay)
#
#     if len(regions) != 2:
#         # # check validity
#         # box = regions[0].bbox   # y1x1y2x2
#         # xyxy = (box[1], box[0], box[3], box[2])
#         # plot_one_box(xyxy, mask)
#         print(f)
#         continue
#
#     # generate label files
#     # print(f"write to f{os.path.join(output_dir, f.replace('_mask.png', '.txt'))}...")
#     with open(os.path.join(output_dir, fname+'.txt'), 'w') as lf:
#         for reg in regions:
#             box = reg.bbox
#             assert 0 <= box[1] / w <= 1
#             assert 0 <= box[0] / h <= 1
#             assert 0 <= box[3] / w <= 1
#             assert 0 <= box[2] / h <= 1
#             x1 = box[1] / w
#             y1 = box[0] / h
#             x2 = box[3] / w
#             y2 = box[2] / h
#             x = (x1+x2)/2
#             y = (y1+y2)/2
#             wv = x2-x1
#             hv = y2-y1
#
#             # label
#
#             if fname in normal_flist:
#                 lf.write(f"2 {x} {y} {wv} {hv}{os.linesep}")
#             elif fname in abnormal_flist:
#                 lf.write(f"1 {x} {y} {wv} {hv}{os.linesep}")
#             else:
#                 raise ValueError(f"unrecognize file {fname}")


####################################################################################################

from shutil import copyfile

# create file list
img_mask_mapping_path = '/home/tangyingpeng/covid_data/rsna_seg/train.csv'
rsna_data_dir = '/home/tangyingpeng/covid_data/rsna_seg/ori_data'
labels_dir = '/home/tangyingpeng/covid_data/rsna_seg/labels'
output_dir = '/home/tangyingpeng/covid_data/rsna_seg/images'
# mapping = pandas.read_csv(img_mask_mapping_path)

lab_flist = os.listdir(labels_dir)
for lab in lab_flist:
    # data_path = mapping[mapping['label']==lab.replace('txt','png')]['image'].values[0]
    # cp to the image dir
    ori_path = os.path.join(rsna_data_dir, lab.replace('.txt', ''), 'image.png')
    copyfile(ori_path, os.path.join(output_dir, lab.replace('txt', 'png')))
