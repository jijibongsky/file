from al.train_test_func import *

dataset = 'voc'

if dataset == 'voc':
    dataset_config = VOC_COCO
elif dataset == 'sim':
    dataset_config = SIM_KITTI
elif dataset == 'kitti':
    dataset_config = KITTI_CITY
elif dataset == 'city':
    dataset_config = CITY_VOC
elif dataset == 'xray':
    dataset_config = RSNA_CXR
elif dataset == 'covid':
    dataset_config = COVID_PNEU
else:
    raise ValueError("dataset must in ['voc', 'sim', 'kitti', 'city']")


# voc src
data_dict = parse_data_cfg(os.path.join('/home/tangyingpeng/yolov3', dataset_config['data']))
train_path = data_dict['source_train']
with open(train_path, 'r') as f:
    flist = f.read().splitlines()
# label dict
with open(os.path.join('/home/tangyingpeng/yolov3', dataset_config['label_map']), 'rb') as f:
    src2tgt_labelmap = pickle.load(f)

if dataset == 'voc':
    dataset = LoadImagesAndLabels(train_path,
                                  416,
                                  32,
                                  augment=True,
                                  hyp=hyp,  # augmentation hyperparameters
                                  rect=False,  # rectangular training
                                  image_weights=False,
                                  cache_images=False,
                                  DATA_ROOT='/data/coco/images/train2014/',
                                  data_type='voc',
                                  dbg=True,
                                  valid_lab=list(src2tgt_labelmap.keys())
                                  )
else:
    updated_lab_ds = LoadImagesAndLabelsByImgFiles(
        img_files=flist,
        img_size=416,
        batch_size=32,
        augment=True,
        hyp=hyp,  # augmentation hyperparameters
        rect=False,  # rectangular training
        image_weights=False,
        cache_images=False,
        dbg=True,
        valid_lab=list(src2tgt_labelmap.keys())
    )