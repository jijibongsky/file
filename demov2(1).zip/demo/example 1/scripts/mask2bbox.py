import cv2
import os
import numpy as np
import random
from skimage.measure import label, regionprops
from skimage.morphology import closing, square
from skimage import color

mask_dir = '/home/tangyingpeng/covid_data/shenzhen/ChinaSet_AllFiles/mask/mask'
output_dir = '/home/tangyingpeng/covid_data/shenzhen/ChinaSet_AllFiles/labels'
# mask_dir = '/home/tangyingpeng/covid_data/XLSor/aug_mask/'
# output_dir = '/home/tangyingpeng/covid_data/XLSor/aug_bbox/'


def plot_one_box(x, img, color=None, label=None, line_thickness=None, save_name='default.jpg'):
    # Plots one bounding box on image img
    tl = line_thickness or round(0.002 * (img.shape[0] + img.shape[1]) / 2) + 1  # line thickness
    color = color or [random.randint(0, 255) for _ in range(3)]
    c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
    cv2.rectangle(img, c1, c2, color, thickness=tl)
    if label:
        tf = max(tl - 1, 1)  # font thickness
        t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        cv2.rectangle(img, c1, c2, color, -1)  # filled
        cv2.putText(img, label, (c1[0], c1[1] - 2), 0, tl / 3, [225, 255, 255], thickness=tf, lineType=cv2.LINE_AA)
    cv2.imwrite(save_name, img)


flist = os.listdir(mask_dir)
for f in flist:
    mask = cv2.imread(os.path.join(mask_dir, f))
    h, w = mask.shape[0:2]
    binary_mask = mask[:, :, 0]
    labeled_region = label(binary_mask, background=0, return_num=False, connectivity=2)

    # image_label_overlay = color.label2rgb(labeled_region, image=mask, bg_label=0, bg_color=(125, 125, 125))
    # cv2.imwrite('temp.jpg', image_label_overlay)  # ok

    regions = regionprops(labeled_region, coordinates='xy')

    # filter out bbox whose w or h is less than 50 pixels
    regions = [item for item in regions if (item.bbox[3]-item.bbox[1]>50 and item.bbox[2]-item.bbox[0]>50)]

    if len(regions) != 2:
        # # check validity
        # box = regions[0].bbox   # y1x1y2x2
        # xyxy = (box[1], box[0], box[3], box[2])
        # plot_one_box(xyxy, mask)
        print(f)
        continue

    # generate label files
    print(f"write to f{os.path.join(output_dir, f.replace('_mask.png', '.txt'))}...")
    with open(os.path.join(output_dir, f.replace('_mask.png', '.txt')), 'w') as lf:
        for reg in regions:
            box = reg.bbox
            assert 0 <= box[1] / w <= 1
            assert 0 <= box[0] / h <= 1
            assert 0 <= box[3] / w <= 1
            assert 0 <= box[2] / h <= 1
            x1 = box[1] / w
            y1 = box[0] / h
            x2 = box[3] / w
            y2 = box[2] / h
            x = (x1+x2)/2
            y = (y1+y2)/2
            wv = x2-x1
            hv = y2-y1

            lf.write(f"{2 if f.split('_')[2]=='0' else 1} {x} {y} {wv} {hv}{os.linesep}")
