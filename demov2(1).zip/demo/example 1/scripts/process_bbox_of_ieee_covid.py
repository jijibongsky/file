import os, json
from tqdm import tqdm
import random
import cv2

label_space = dict()
with open(
        "/home/tangyingpeng/covid_data/covid-chestxray-dataset/annotations/imageannotation_ai_lung_bounding_boxes.json",
        'r') as f:
    labels = json.load(f)

images_info = labels['images']
anno = labels['annotations']

# create image id 2 file name
id2fname = dict()
id2imginfo = dict()
for i in images_info:
    id2fname[i['id']] = i['file_name']
    id2imginfo[i['id']] = i

# write to YOLO format
label_id = []
# statistic
image_num = dict()
class_dist = dict()
output_dir = '/home/tangyingpeng/covid_data/covid-chestxray-dataset/labels'
for i in range(len(anno)):
    id = anno[i]['image_id']
    img_name = id2fname[id]
    image_h = id2imginfo[id]['height']
    image_w = id2imginfo[id]['width']
    # image = cv2.imread(os.path.join('/home/tangyingpeng/covid_data/covid-chestxray-dataset/images', img_name))
    box = anno[i]['bbox']  # x1y1wh

    if 'attributes' not in anno[i].keys():
        continue
    dbg = anno[i]['attributes']
    if 'Finding' not in dbg.keys():
        continue
    if anno[i]['attributes']['View'][0] == 'L':
        print('L')
    # assert the modality is X-Ray and View is PA or a AP
    if anno[i]['attributes']['Modality'][0] != 'X-Ray':
        continue
    if 'AP' not in anno[i]['attributes']['View'][0] and 'PA' not in anno[i]['attributes']['View'][0]:
        # print(anno[i]['attributes']['View'][0])
        continue

    # labels
    class_arr = anno[i]['attributes']['Finding']
    for cla in class_arr:
        if cla not in label_id:
            label_id.append(cla)

    # statistic
    if id not in image_num.keys():
        for cla in class_arr:
            if cla not in class_dist.keys():
                class_dist[cla] = 1
            else:
                class_dist[cla] += 1
        image_num[id] = 1

    x1 = box[0] / image_w
    y1 = box[1] / image_h
    x2 = (box[0] + box[2]) / image_w
    y2 = (box[1] + box[3]) / image_h
    assert 0 <= x1 <= 1
    assert 0 <= x2 <= 1
    assert 0 <= y1 <= 1
    assert 0 <= y2 <= 1
    x = (x1 + x2) / 2
    y = (y1 + y2) / 2
    wv = x2 - x1
    hv = y2 - y1

    # write file
    with open(os.path.join(output_dir, img_name.replace(img_name.split('.')[-1], 'txt')), 'a') as f:
        if 'COVID-19' in class_arr:
            f.write(f"0 {x} {y} {wv} {hv}{os.linesep}")
        elif 'No Finding' in class_arr:
            f.write(f"2 {x} {y} {wv} {hv}{os.linesep}")
        else:
            f.write(f"1 {x} {y} {wv} {hv}{os.linesep}")

print(label_id)
print(len(image_num))
for i in class_dist.items():
    print(i[1], '\t', i[0])



# # check validaty
# def plot_one_box(x, img, color=None, label=None, line_thickness=None, save_name='default.jpg'):
#     # Plots one bounding box on image img
#     tl = line_thickness or round(0.002 * (img.shape[0] + img.shape[1]) / 2) + 1  # line thickness
#     color = color or [random.randint(0, 255) for _ in range(3)]
#     c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
#     cv2.rectangle(img, c1, c2, color, thickness=tl)
#     if label:
#         tf = max(tl - 1, 1)  # font thickness
#         t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
#         c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
#         cv2.rectangle(img, c1, c2, color, -1)  # filled
#         cv2.putText(img, label, (c1[0], c1[1] - 2), 0, tl / 3, [225, 255, 255], thickness=tf, lineType=cv2.LINE_AA)
#     cv2.imwrite(save_name, img)
#
# for i in range(len(anno)):
#     id = anno[i]['image_id']
#     img_name = id2fname[id]
#     image_h = images_info[id-1]['height']
#     image_w = images_info[id-1]['width']
#     image = cv2.imread(os.path.join('/home/tangyingpeng/covid_data/covid-chestxray-dataset/images', img_name))
#     box = anno[i]['bbox']   # x1y1wh
#     # xyxy = box    # xyxy nope
#     # xyxy = (box[1], box[0], box[3], box[2])   # yxyx
#     # xyxy = box[0] - box[2]/2, box[1] - box[3]/2, box[0] + box[2]/2, box[1] + box[3]/2     # xywh
#     # xyxy = box[2] - box[0] / 2, box[3] - box[1] / 2, box[2] + box[0] / 2, box[3] + box[1] / 2   # whxy
#     # xyxy = box[2], box[1], box[0], box[3]
#     # xyxy = box[1], box[2], box[0], box[3]
#     xyxy = box[0], box[1], box[0]+box[2], box[1]+box[3]
#     plot_one_box(xyxy, image)
