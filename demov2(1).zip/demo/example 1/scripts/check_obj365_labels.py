import os, json
from tqdm import tqdm

label_space = dict()
with open("/data/object365/step3_objects365_v1_train_release.json", 'r') as f:
    odgt_data = [json.loads(i) for i in tqdm(f.readlines(), desc='Loading...')]
    # odgt_data = [i for i in odgt_data if check(i)]
    # odgt_data = {i['nori_id'].replace(',', '_')+'.jpg':i for i in odgt_data}
label_space = odgt_data[0]['categories']
for i in label_space:
    print(i['name'], end=' ')
