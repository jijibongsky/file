import os
import shutil
import tqdm

src_dir = '/data/saved_al_covid/'
output_dir = '/data/our_bk_530/saved_al_covid/'
flist = os.listdir(src_dir)

for fn in tqdm.tqdm(flist):
    if 'our' in fn:
        shutil.copyfile(os.path.join(src_dir, fn), os.path.join(output_dir, fn))

src_dir = '/data/saved_al_kitti/'
output_dir = '/data/our_bk_530/saved_al_kitti/'
flist = os.listdir(src_dir)

for fn in tqdm.tqdm(flist):
    if 'our' in fn:
        shutil.copyfile(os.path.join(src_dir, fn), os.path.join(output_dir, fn))

src_dir = '/data/saved_al_city/'
output_dir = '/data/our_bk_530/saved_al_city/'
flist = os.listdir(src_dir)

for fn in tqdm.tqdm(flist):
    if 'our' in fn:
        shutil.copyfile(os.path.join(src_dir, fn), os.path.join(output_dir, fn))

src_dir = '/data/saved_al/'
output_dir = '/data/our_bk_530/saved_al/'
flist = os.listdir(src_dir)

for fn in tqdm.tqdm(flist):
    if 'our' in fn:
        shutil.copyfile(os.path.join(src_dir, fn), os.path.join(output_dir, fn))
