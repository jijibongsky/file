import os
import numpy as np

# mask_dir = '/home/tangyingpeng/covid_data/pretrain/ChinaSet_AllFiles/mask/mask'
# output_dir = '/home/tangyingpeng/covid_data/pretrain/ChinaSet_AllFiles/labels'
#
# # create file list
# with open('/data/dataset/shenzhen_all.txt', 'w') as f:
#     fl = os.listdir(mask_dir)
#     for fn in fl:
#         f.write(fn+os.linesep)

################################ create bbox file for each mask file ######################
# import shutil
# data_dir = '/home/tangyingpeng/covid_data/XLSor/images_aug/'
# bbox_dir = '/home/tangyingpeng/covid_data/XLSor/aug_bbox/'
# output_dir = '/home/tangyingpeng/covid_data/XLSor/labels_aug'
#
# data_list = os.listdir(data_dir)
# for fn in data_list:
#     image_idx, aug_idx = fn.split('_')
#     # aug_idx = aug_idx[0]
#     bbox_fn = os.path.join(bbox_dir, image_idx+'_mask.txt')
#     tgt_fn = os.path.join(output_dir, fn.split('.')[0]+'.txt')
#
#     shutil.copyfile(bbox_fn, tgt_fn)
###############################################################################################

# # create pretrain data file
# data_dir = '/home/tangyingpeng/covid_data/XLSor/images_aug/'
# data_list = os.listdir(data_dir)
# with open("/data/dataset/xls_pretrain.txt", 'w') as f:
#     for fn in data_list:
#         f.write(os.path.join(data_dir, fn)+os.linesep)


####################################################################################################


# with open("/data/dataset/xls_pretrain.txt", 'w') as f:
#     for fn in data_list:
#         f.write(os.path.join(data_dir, fn)+os.linesep)



# # check if any label txt file has more than 2 bboxes.
# check_dir = '/home/tangyingpeng/covid_data/XLSor/aug_bbox/'
# flist = os.listdir(check_dir)
# for fname in flist:
#     with open(os.path.join(check_dir, fname), 'r') as f:
#         a = f.read().splitlines()
#     if len(a)!=2:
#         print('error', fname)



# import torch
# import pickle
# with open('/data/saved_model/covid_xls_pretrain.pt', 'rb') as f:
#     pf = torch.load(f)
# with open('/data/saved_model/covid_xls_pretrain.pkl', 'wb') as f:
#     pickle.dump(pf, f)


# import pickle
# output_path = '/home/tangyingpeng/yolov3/data/covid_label.pkl'
# label_map = dict()
# label_map[0] = 0
# label_map[1] = 1
# with open(output_path, 'wb') as f:
#     pickle.dump(label_map, f)

# mask_dir = '/home/tangyingpeng/covid_data/shenzhen/ChinaSet_AllFiles/images'
# output_dir = '/home/tangyingpeng/covid_data/shenzhen/ChinaSet_AllFiles/labels'
# lab_flist = os.listdir(output_dir)
# with open('/data/dataset/shenzhen_all.txt', 'w') as f:
#     for lab in lab_flist:
#         f.write(os.path.join(mask_dir, lab.replace('txt', 'png'))+os.linesep)

#
# fdir = '/data/saved_al_covid/'
# flist = os.listdir(fdir)
# for fl in flist:
#     if fl.startswith('covid_our_trans'):
#         os.rename(os.path.join(fdir, fl), os.path.join(fdir, fl.replace('covid_', '')))

# with open('/data/dataset/pneu_src_unlab.txt', 'r') as f:
#     new = f.read().splitlines()
# with open('/data/dataset/pneu_src_unlab_1.txt', 'r') as f:
#     old = f.read().splitlines()
# # for id, i in enumerate(new):
# #     # print(i ==old[id])
# #     print(i, '\t', old[id])
# print(len(new), len(old))
# c = set(new) & set(old)
# print(len(c))

#========================= 25 ==========================
# seed_arr = list(range(10))
i=0
while True:
    seed_arr = list(range(10))
    np.random.seed(i)
    np.random.shuffle(seed_arr)
    five_folds = seed_arr[:5]
    if set((0,1,3,5,8)) == set(five_folds):
        print(i)
        print(five_folds)
        break
    i += 1

