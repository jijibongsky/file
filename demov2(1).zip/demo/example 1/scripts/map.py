import pickle

cxr2rsna = dict()

cxr2rsna[6] = 0


with open('../data/cxr2rsna.pkl', 'wb') as f:
    pickle.dump(cxr2rsna, f)
