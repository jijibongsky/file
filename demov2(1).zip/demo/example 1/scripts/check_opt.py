import pickle
import os

fname = 'our_27_saved_opt.pkl'
root = '/data/core_data/saved_model_city'

with open(os.path.join(root, fname), 'rb') as f:
    opt = pickle.load(f)

print(opt)
