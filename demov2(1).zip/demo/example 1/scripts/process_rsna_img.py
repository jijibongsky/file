# import os
# root_dir = "/data/download/RSNA/images_all"
# for f in os.listdir(root_dir):
#     os.rename(os.path.join(root_dir, f), os.path.join(root_dir, f.replace('.dcm', '')))

import os
import numpy as np
import cv2
from al.train_test_func import plot_one_box, xywh2xyxy

lab_file = '/data/download/RSNA/stage_2_train_labels.csv'

# read csv files
with open(lab_file, 'r') as f:
    lines = f.read().splitlines()

label_dict = dict()
unique_lab = 0
# lines.pop(0)
for line in lines:
    items = line.split(',')
    if items[-1]=='1':
        label_dict[items[0]] = items[1:-1]

# write files
tar_dir = "/data/download/RSNA/images_all/"
tar_lab_dir = "/data/download/RSNA/labels_all/"

for fi in label_dict.keys():
    with open(os.path.join(tar_lab_dir, fi + '.txt'), 'w') as f:
        coord = label_dict[fi]
        # note that the coord is x_min, y_min, w, h
        class_ind = 0
        # get image size
        im = cv2.imread(os.path.join(tar_dir, fi+'.png'))
        h, w, c = im.shape
        x = float(coord[0]) / w
        y = float(coord[1]) / h
        wc = float(coord[2]) / w
        hc = float(coord[3]) / h
        x = x+wc/2
        y = y+hc/2

        # plot one box
        # box = xywh2xyxy(np.array([[x,y,wc,hc]]))
        # plot_one_box(box, im)

        f.write(f"{class_ind} {x} {y} {wc} {hc}{os.linesep}")
    print(f"processing {fi}...")


