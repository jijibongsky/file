import os
import shutil
import tqdm
src_dir = '/data/saved_model/'
output_dir = '/data/our_bk_530/saved_model/'
flist = os.listdir(src_dir)

for fn in tqdm.tqdm(flist):
    if 'our' in fn and os.path.splitext(fn)[1] == '.txt':
        shutil.copyfile(os.path.join(src_dir, fn), os.path.join(output_dir, fn))
