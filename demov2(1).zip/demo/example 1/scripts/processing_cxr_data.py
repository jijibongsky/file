import pickle
import os
import numpy as np
from shutil import copyfile
import cv2
from al.train_test_func import plot_one_box

bbox_file = "/data/download/CXR8/images/BBox_List_2017.csv"

# read csv files
with open(bbox_file, 'r') as f:
    lines = f.read().splitlines()

label_dict = dict()
lmap = dict()
unique_lab = 0
lines.pop(0)
for line in lines:
    items = line.split(',')
    temp_dict = dict()
    temp_dict['class'] = items[1]
    if items[1] not in lmap:
        lmap[items[1]] = unique_lab
        unique_lab += 1
    temp_dict['coord'] = [it for it in items[2:]]
    label_dict[items[0]] = temp_dict

# copy files to target dir
src_dir = "/data/download/CXR8/images/"
tar_dir = "/data/download/CXR8/images_merged/"
tar_lab_dir = "/data/download/CXR8/labels_merged/"
for i in np.arange(1, 13):
    sub_folder = os.path.join(src_dir, "images_" + str(i).zfill(3), 'images')
    files = os.listdir(sub_folder)
    for fi in files:
        if fi in label_dict:
            # copy to the tar dir
            copyfile(os.path.join(src_dir, sub_folder, fi), os.path.join(tar_dir, fi))
            # write label file
            with open(os.path.join(tar_lab_dir, fi.split('.')[0] + '.txt'), 'w') as f:
                label_item = label_dict[fi]
                class_ind = lmap[label_item['class']]
                # get image size
                im = cv2.imread(os.path.join(src_dir, sub_folder, fi))
                h, w, c = im.shape
                coord = label_item['coord']
                x = float(coord[0]) / w
                y = float(coord[1]) / h
                wc = float(coord[2]) / w
                hc = float(coord[3]) / h

                # also x_min y_min
                x = x + wc / 2
                y = y + hc / 2

                # plot
                # point1 = float(coord[0]), float(coord[1])
                # plot_one_box()

                f.write(f"{class_ind} {x} {y} {wc} {hc}{os.linesep}")
            print(f"processing {fi}...")
