import os
import numpy as np
from utils.utils import init_seeds


def create_covid_setting_files(rand_seed=0, fold=0):
    init_seeds(seed=rand_seed)

    ####################################################################################################
    # # create covid data file
    data_dir = '/home/tangyingpeng/covid_data/covid-chestxray-dataset/images'
    labels_dir = '/home/tangyingpeng/covid_data/covid-chestxray-dataset/labels'
    data_list = os.listdir(data_dir)
    lab_list = os.listdir(labels_dir)
    # collect covid file names
    covid_fl = []
    non_covid_fl = []
    normal_flist = []
    abnormal_flist = []
    for i, fn in enumerate(lab_list):
        # find idx in data_list
        didx = 0
        for jd, j in enumerate(data_list):
            if fn.replace('.txt', '') in j:
                didx = jd
                break

        # add list
        with open(os.path.join(labels_dir, fn), 'r') as f:
            labs = f.read().splitlines()
        if labs[0][0] == '0':
            # covid
            covid_fl.append(os.path.join(data_dir, data_list[didx]))
        elif labs[0][0] == '0':
            # normal
            normal_flist.append(os.path.join(data_dir, data_list[didx]))
        else:
            non_covid_fl.append(os.path.join(data_dir, data_list[didx]))

    # shenzhen dataset
    # shenzhen_img_dir = '/home/tangyingpeng/covid_data/shenzhen/ChinaSet_AllFiles/images'
    # non_covid_fl += [os.path.join(shenzhen_img_dir, fn) for fn in os.listdir(shenzhen_img_dir)]

    # read rsna file list
    rsna_img_dir = '/home/tangyingpeng/covid_data/rsna_seg/images'
    with open('/home/tangyingpeng/covid_data/rsna_seg/normal.txt', 'r') as f:
        nfl = f.read().splitlines()
    with open('/home/tangyingpeng/covid_data/rsna_seg/pneumonia.txt', 'r') as f:
        abnfl = f.read().splitlines()
    # read labels_list
    rsna_lab_flist = os.listdir('/home/tangyingpeng/covid_data/rsna_seg/labels')
    for rsna_fname in rsna_lab_flist:
        woext = rsna_fname.replace('.txt', '')
        if woext in nfl:
            normal_flist.append(os.path.join(rsna_img_dir, woext+'.png'))
        elif woext in abnfl:
            abnormal_flist.append(os.path.join(rsna_img_dir, woext+'.png'))
    # with open('/home/tangyingpeng/covid_data/rsna_seg/normal.txt', 'r') as f:
    #     normal_flist += [os.path.join(rsna_img_dir, fnl+'.png') for fnl in f.read().splitlines()]
    # with open('/home/tangyingpeng/covid_data/rsna_seg/pneumonia.txt', 'r') as f:
    #     abnormal_flist = [os.path.join(rsna_img_dir, fnl+'.png') for fnl in f.read().splitlines()]

    np.random.shuffle(covid_fl)
    np.random.shuffle(non_covid_fl)
    np.random.shuffle(normal_flist)
    np.random.shuffle(abnormal_flist)

    # 'src': 'covid',
    # 'tgt': 'pneu',

    # tgt_train
    with open(f'/data/dataset/covid_tgt_ini{"_"+str(fold) if fold > 0 else ""}.txt', 'w') as f:
        for i in np.arange(10):
            f.write(covid_fl[i]+os.linesep)
        for i in np.arange(50):
            f.write(abnormal_flist[i] + os.linesep)

    # tgt_test
    with open(f'/data/dataset/covid_tgt_test{"_"+str(fold) if fold > 0 else ""}.txt', 'w') as f:
        for i in np.arange(start=10, stop=50):
            f.write(covid_fl[i]+os.linesep)
        for i in np.arange(start=50, stop=250):
            f.write(abnormal_flist[i] + os.linesep)

    # src
    with open(f'/data/dataset/pneu_src{"_"+str(fold) if fold > 0 else ""}.txt', 'w') as f:
        for i in np.arange(start=50, stop=len(covid_fl)):
            f.write(covid_fl[i]+os.linesep)
        for i in np.arange(start=250, stop=len(abnormal_flist)):
            f.write(abnormal_flist[i] + os.linesep)
        for i in np.arange(start=0, stop=len(non_covid_fl)):
            f.write(non_covid_fl[i] + os.linesep)
        for i in np.arange(start=0, stop=len(normal_flist)):
            f.write(normal_flist[i] + os.linesep)

    # src_ini
    with open(f'/data/dataset/pneu_src_ini{"_"+str(fold) if fold > 0 else ""}.txt', 'w') as f:
        for i in np.arange(start=50, stop=60):
            f.write(covid_fl[i]+os.linesep)
        for i in np.arange(start=250, stop=265):
            f.write(abnormal_flist[i] + os.linesep)
        for i in np.arange(start=0, stop=5):
            f.write(non_covid_fl[i] + os.linesep)

    # src_unlabel
    with open(f'/data/dataset/pneu_src_unlab{"_"+str(fold) if fold > 0 else ""}.txt', 'w') as f:
        for i in np.arange(start=60, stop=len(covid_fl)):
            f.write(covid_fl[i]+os.linesep)
        for i in np.arange(start=265, stop=len(abnormal_flist)):
            f.write(abnormal_flist[i] + os.linesep)
        for i in np.arange(start=5, stop=len(non_covid_fl)):
            f.write(non_covid_fl[i] + os.linesep)
        for i in np.arange(start=0, stop=100):
            f.write(normal_flist[i] + os.linesep)


random_seeds = [ 3979596, 16253940, 77204617, 61062847, 43002735, 92774230,
65365938, 24359929,  9861244, 76364882, 40458118, 83275338,
92097020, 71878236, 82099743, 54629107, 61091022,  3141954,
79765045, 31850997]
for ifold in np.arange(10, 30):
    create_covid_setting_files(rand_seed=random_seeds[ifold-10], fold=ifold)
# create_covid_setting_files(rand_seed=0, fold=0)
