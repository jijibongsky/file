from al.train_test_func import *
from al.al_utils import al_mainloop, al_scoring
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--dataset', type=str, default='voc', help="['voc', 'kitti', 'city']")
parser.add_argument('--ins-gain', type=float, default=5.0)
parser.add_argument('--no-da', action='store_true')
parser.add_argument('--save-name', type=str, default='', help='name of the saved file')
opt = parser.parse_args()
assert opt.dataset in ['voc', 'kitti', 'city']

VOC_COCO = {
    'pkl': '/data/saved_model/init_da_yolo_coco.pkl',
    'coco_dir': '/data/coco/images/train2014/',
    'voc_dir': '/data/voc/voc_pure_data/images/',
    'data': 'data/voc_coco.data',
    'label_map': 'data/cocoid2vocid.pkl',
    'cfg': 'cfg/yolov3-spp-voc.cfg',
}

TOTAL_SCORE_THRES = 0.1
INCONS_SCORE_THRES = 0.1
TRANS_SCORE_THRES = 0.1
batch_size = 32
accumulate = 2
epochs = 50
img_size = 416
pretrain_weights = '/home/tangyingpeng/todal/darknet/darknet53.conv.74'

# init model
model, optimizer = init_model(pkl_path=f'/data/saved_model/init_da_yolo_{opt.dataset}.pkl',
                              cfg=f'cfg/yolov3-spp-{opt.dataset}.cfg')

with open(VOC_COCO['label_map'], 'rb') as f:
    cocoid2vocid = pickle.load(f)

# load data
_, s_gt_ds, s_gt_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='source_train', img_size=416,
                                        batch_size=batch_size,
                                        rect=False, img_weights=False, cache_images=True, shuffle=False,
                                        augment=False, data_root=VOC_COCO['coco_dir'])
# nc, t_gt_ds, t_gt_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='target_train', img_size=416,
#                                          batch_size=batch_size,
#                                          rect=False, img_weights=False, cache_images=True, shuffle=False,
#                                          augment=True, data_root=VOC_COCO['voc_dir'])
_, test_ds, test_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='valid', img_size=416, batch_size=batch_size,
                                        rect=False, img_weights=False, cache_images=True, shuffle=False,
                                        augment=False, data_root=VOC_COCO['voc_dir'])


with open('misc/voc_init_lab.txt', 'r') as f:
    init_lab = f.read().splitlines(keepends=False)

nc=20

t_gt_ds = LoadImagesAndLabelsByImgFiles(
    img_files=init_lab,
    img_size=img_size,
    batch_size=batch_size,
    augment=True,
    hyp=hyp,  # augmentation hyperparameters
    rect=False,  # rectangular training
    image_weights=False,
    cache_images=True
)

# Dataloader
t_gt_dl = torch.utils.data.DataLoader(t_gt_ds,
                                     batch_size=batch_size,
                                     num_workers=4,
                                     shuffle=False,  # Shuffle=True unless rectangular training is used
                                     pin_memory=True,
                                     collate_fn=t_gt_ds.collate_fn)
# split dataset
# from misc.split_lab_unlab import split_lab
# split_lab(s_gt_ds, rate=0.05)

# load init lab_unlab
with open('misc/coco_init_lab.txt', 'r') as f:
    init_lab = f.read().splitlines(keepends=False)
with open('misc/coco_init_unlab.txt', 'r') as f:
    init_unlab = f.read().splitlines(keepends=False)

# calc initial performance point
ini_dataset = LoadImagesAndLabelsByImgFiles(
    img_files=init_lab,
    img_size=img_size,
    batch_size=batch_size,
    augment=True,
    hyp=hyp,  # augmentation hyperparameters
    rect=False,  # rectangular training
    image_weights=False,
    cache_images=True
)

# Dataloader
ini_dataloader = torch.utils.data.DataLoader(ini_dataset,
                                             batch_size=batch_size,
                                             num_workers=0,
                                             shuffle=False,  # Shuffle=True unless rectangular training is used
                                             pin_memory=True,
                                             collate_fn=ini_dataset.collate_fn)

model, best_ap = train_mix(model=model, optimizer=optimizer, dataloader=ini_dataloader, tgt_dataloader=t_gt_dl,
                           start_epoch=0, epochs=50, nc=nc, batch_size=batch_size, da_switch=not opt.no_da,
                           src2tgt_label_map=cocoid2vocid, save_epoch=[50], notest=False, test_dl=test_dl,
                           ins_gain=opt.ins_gain, best_save_name=f'/data/saved_model/small.pt',
                           save_prefix='saved_ckpt_al_',
                           saved_map_dir=f'/data/saved_model/small{opt.save_name}.txt')

# model, optimizer, res = load_voc_model(pt_path='/data/saved_model/voc_only_start_point.pt',
#                 cfg='cfg/yolov3-spp-coco.cfg')
# with torch.no_grad():
#     results, maps = test(model,
#              dataloader=test_dl,
#              nc=nc,
#              batch_size=batch_size,
#              img_size=img_size,
#              iou_thres=0.5,
#              conf_thres=0.1,
#              nms_thres=0.5,
#              data_root=VOC_COCO['voc_dir'])   # results[2] map
#
# print(results[2])

exit()
