Active learning for object detection example.
We use YOLOv3 model, VOC07+12 and COCO 2014 datasets.

## Main requirements

* **torch == 1.2.0**
* **torchvision == 0.4.0**
* **Python 3.7**

## Environmental settings

This repository is developed and tested under python **3.7** Ubuntu **16.04.5 LTS**. The CUDA nad CUDNN version is **10.0.130** and **7.5.0** respectively. We use **two NVIDIA 1080ti GPU cards** for training and testing. Note that the program is written for multiple cards, and the batch size is fixed as 32, so make sure your server has **at least two cards**, and the sum of the GPU memory is larger than 22GB.

## Pretrain models

The weights of pretrained model (darknet53 weights) can be downloaded by the script in weights/download_yolov3_weights.sh

## Usage

1. Following the [guidelines](preparation.md) to prepare the data and config files. **Note that the data split and other setting files used in the experiments are already put into the 'cfg', 'data' and 'data_split' folder.**

2. Run the active learning main loop (train/test/eval).

```bash
python al_pipeline_cmp_parser.py --method least_conf
```

## Running time

It takes about 5.5 hours of CPU process time (i.e., time.clock()) to evalute 81,081 images in COCO dataset based on current release version (batch size is 1 when predicting for the unlabeled data).

The training speed is about 0.5 batch/second for two 1080ti graphic cards and 32 batch size.

## Results

![lc](exp_imgs/lc.png)

## 中文说明

本案例展示了如何在目标检测任务中应用主动学习技术做样本选择。主要算法调用在`al_pipeline_cmp_parser.py`文件中，算法流程与通用主动学习类似，主要包括数据集划分，计算模型初始性能，进入主动学习循环（查询->更新模型->保存中间结果）等。面向深度学习的主动学习与传统主动学习代码主要有以下几点不同

- 需要预训练初始模型并保存，用于做第一轮样本选择
- 未标记样本需要单独实例化一个Dataset对象。在样本选择时需要模型以eval模式传入，对未标记样本进行预测
- 待主动学习算法挑选完毕后，将挑选样本加入到标记集合中，这一步可以以新的样本列表重新建一个Dataset对象，或更新现有的标记数据的Dataset对象
- 用标记数据更新模型

要运行本代码，需要大量准备工作。首先按要求安装环境，下载Yolov3的与训练权重，VOC07+12，及COCO 2014数据集。具体操作流程请参考preparation.md文件。

## `al_pipeline_cmp_parser`代码结构

- 46-80行建立初始标记数据集，未标记数据集与测试数据集的dataloader
- 107行读取在初始标记集合上预训练好的模型
- 139-147行是主动学习的部分，需要将dataloader，模型作为参数传入
- 151行之后是将更新后的标记数据重新创建一个dataloader对象，并用之更新模型（与一般目标检测模型训练代码无异）

## 主动选择部分

- `al/al_algos.py`文件中定义了部分目标检测的样本选择策略，它们通常需要模型预测值作为输入，并返回该样本的信息量分值。
- `al/al_utils`文件中的`al_scoring`函数定义了主动学习的主要流程，基本包括以下几个步骤：从dataloader中取出无标记数据，模型对数据进行预测，调用特定主动学习选择策略计算分值，汇总所有样本分值并排序，返回选择的样本。
