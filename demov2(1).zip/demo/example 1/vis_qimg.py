from al.train_test_func import *
from al.al_data_loader import QueryRepo
from al.al_utils import al_mainloop, al_scoring, al_loop_click_supervision
from scripts.create_covid_setting import create_covid_setting_files
import alipy
import argparse
import warnings

valid_methods = ['click_spvs', 'uncertain_map', 'margin_avg', 'our', 'our_incons', 'our_trans', 'least_conf',
               'LS', 'ADDA', 'img_trans', 'random']

parser = argparse.ArgumentParser()
parser.add_argument('--dataset', type=str, default='voc', help="['voc', 'kitti', 'sim', 'city']")
parser.add_argument('--method', type=str, help='name of the method')
parser.add_argument('--start-iter', type=int, default=0)
parser.add_argument('--end-iter', type=int, default=8)
parser.add_argument('--only-query', action='store_true')
parser.add_argument('--skip-query', action='store_true')
parser.add_argument('--acl', type=float, default=1.0)
parser.add_argument('--folds', type=int, default=1)
parser.add_argument('--start-fold', type=int, default=0)
opt = parser.parse_args()
opt.dataset = 'city'
if opt.dataset == 'voc':
    dataset_config = VOC_COCO
elif opt.dataset == 'sim':
    dataset_config = SIM_KITTI
elif opt.dataset == 'kitti':
    dataset_config = KITTI_CITY
elif opt.dataset == 'city':
    dataset_config = CITY_VOC
elif opt.dataset == 'xray':
    dataset_config = RSNA_CXR
elif opt.dataset == 'covid':
    dataset_config = COVID_PNEU
else:
    raise ValueError("dataset must in ['voc', 'sim', 'kitti', 'city']")

setting_root = "/data/dataset/"
TOTAL_SCORE_THRES = 0.1
INCONS_SCORE_THRES = 0.1
TRANS_SCORE_THRES = 0.1
batch_size = 32
accumulate = 2
epochs = 50
img_size = 416
nc = dataset_config['nc']
pretrain_weights = '/home/tangyingpeng/todal/darknet/darknet53.conv.74'

augmentation = True  # for testing
cache_images = True

with open(dataset_config['label_map'], 'rb') as f:
    src2tgt_labelmap = pickle.load(f)


for ifold, fold in enumerate(np.arange(start=opt.start_fold, stop=opt.folds)):
    if opt.folds > 1:
        assert opt.dataset == 'covid'
        opt.end_iter = 30
    if fold >= 10:
        init_seeds(seed=random_seeds_covid[fold - 10])
    else:
        init_seeds(seed=fold)
    # create_covid_setting_files(rand_seed=fold)
    # load data
    _, s_gt_ds, s_gt_dl = get_gt_dataloader(data=dataset_config['data'], data_item='source_train', img_size=416,
                                            batch_size=batch_size,
                                            rect=False, img_weights=False, cache_images=True, shuffle=False,
                                            augment=False, data_root=dataset_config['src_dir'], fold=fold)
    _, test_ds, test_dl = get_gt_dataloader(data=dataset_config['data'], data_item='valid', img_size=416, batch_size=batch_size,
                                            rect=False, img_weights=False, cache_images=True, shuffle=False,
                                            augment=False, data_root=dataset_config['tgt_dir'], fold=fold)

    # load init lab_unlab
    with open(os.path.join(setting_root, dataset_config['tgt']+f'_tgt_ini{"_"+str(fold) if fold > 0 else ""}.txt'), 'r') as f:
        init_lab = f.read().splitlines(keepends=False)

    t_gt_ds = LoadImagesAndLabelsByImgFiles(
        img_files=init_lab,
        img_size=img_size,
        batch_size=batch_size,
        augment=True,
        hyp=hyp,  # augmentation hyperparameters
        rect=False,  # rectangular training
        image_weights=False,
        cache_images=True
    )

    # Dataloader
    t_gt_dl = torch.utils.data.DataLoader(t_gt_ds,
                                         batch_size=batch_size,
                                         num_workers=4,
                                         shuffle=False,  # Shuffle=True unless rectangular training is used
                                         pin_memory=True,
                                         collate_fn=t_gt_ds.collate_fn)

    # load init lab_unlab
    with open(os.path.join(setting_root, dataset_config['src']+f'_src_ini{"_"+str(fold) if fold > 0 else ""}.txt'), 'r') as f:
        init_lab = f.read().splitlines(keepends=False)
    with open(os.path.join(setting_root, dataset_config['src']+f'_src_unlab{"_"+str(fold) if fold > 0 else ""}.txt'), 'r') as f:
        init_unlab = f.read().splitlines(keepends=False)

    # start pipeline
    unlab_len = len(init_unlab)

    # assert opt.method in ['least_conf', 'random', 'mean_conf', 'LS', 'img_trans', 'ADDA', 'our_trans', 'our_incons', 'our']

    l_set = alipy.index.IndexCollection(init_lab)
    ul_set = alipy.index.IndexCollection(init_unlab)
    queried_repo = QueryRepo(partial_label=False)

    # 25.5 per instance, 80,000+ images, 608695 instances. 7.5 instances per img in average,
    # 349525 instances in target classes, 4.4 instances per image
    budget_rate = np.array([dataset_config['budget']] * 100)
    budget_arr = 25.5 * 349525 * budget_rate

    # query 10 batches
    name_arr = [opt.method]

    # load ini model
    # model, optimizer = init_model(pkl_path=dataset_config['pkl'],
    #                               cfg=dataset_config['cfg'])
    model, optimizer, _ = load_voc_model(pt_path=f'/data/saved_model/small_{dataset_config["tgt"]}{"_"+str(fold) if fold > 0 else ""}.pt',
                                           cfg=f'cfg/yolov3-spp-{dataset_config["tgt"]}.cfg',
                                           parallel=True, parallel_port=6666, init_group=True if ifold==0 else False)

    for i in np.arange(opt.start_iter, opt.end_iter):
        for name in name_arr:
            # print(name)
            # if i > 0 and opt.start_iter > 0:
            #     with open(f"/data/saved_al_{dataset_config['tgt']}/{name}_{i - 1}_all.pkl", 'rb') as f:
            #         queried_repo = pickle.load(f)
            #     assert len(queried_repo) > 0
            #     # update unlab and lab arr
            #     with warnings.catch_warnings():
            #         warnings.simplefilter("ignore")
            #         l_set.update(queried_repo.keys())
            #         ul_set.difference_update(queried_repo.keys())
            #
            #     # load last round model
            #     model, optimizer, res = load_voc_model(pt_path=f'/data/saved_model_{dataset_config["tgt"]}/{name}_n_{i-1}_best.pt',
            #                                            cfg=dataset_config['cfg'],
            #                                            parallel=True, init_group=False)
            #     if res == 0:
            #         exit()
            #     print(f"model and queried repo of iteration {i-1} has been loaded.")

            if opt.skip_query:
                with open(f"/data/saved_al_{dataset_config['tgt']}/{name}_{i}_all.pkl", 'rb') as f:
                    queried_repo = pickle.load(f)
                # model, optimizer, _ = load_voc_model(pt_path=f'/data/saved_model/small_{dataset_config["tgt"]}.pt',
                #                                      cfg=f'cfg/yolov3-spp-{dataset_config["tgt"]}.cfg',
                #                                      parallel=True, parallel_port=6666, init_group=True)
                opt.skip_query = False
            else:
                model.eval()
                with torch.no_grad():
                    scores = al_scoring(unlab_arr=ul_set, model=model, s_gt_ds=s_gt_ds,
                                        method_name=name, cocoid2vocid=src2tgt_labelmap, queried_repo=queried_repo,
                                        acl=opt.acl, lab_set=l_set, t_gt_ds=t_gt_ds, number_of_classes=nc)
                if name == 'click_spvs':
                    queried_repo, total_cost = al_loop_click_supervision(lc_scores=scores, budget=budget_arr[i],
                                                                         queried_repo=queried_repo,
                                                                         dataset_name=opt.dataset, src_gt_ds=s_gt_ds,
                                                                         model=model, src2tgt_lab_ind=src2tgt_labelmap,
                                                                         lab_arr=l_set, unlab_arr=ul_set,
                                                                         save_root=f"/data/saved_al_{dataset_config['tgt']}",
                                                                         method_name=name, iteration=str(i), fold=fold
                                                                         )
                else:
                    queried_repo, total_cost = al_mainloop(scoring_arr=scores, src_gt_ds=s_gt_ds, lab_arr=l_set,
                                                           unlab_arr=ul_set, save_res=False,
                                                           budget=budget_arr[i], queried_repo=queried_repo, method_name=name,
                                                           iteration=str(i), src2tgt_label_map=src2tgt_labelmap,
                                                           save_root=f"/data/saved_al_{dataset_config['tgt']}", fold=fold)
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    l_set.update(queried_repo.keys())
                    ul_set.difference_update(queried_repo.keys())

            # train/test model
            # calc initial performance point
            updated_lab_ds = LoadImagesAndLabelsByImgFiles(
                img_files=queried_repo.keys() + init_lab,
                img_size=img_size,
                batch_size=batch_size,
                augment=True,
                hyp=hyp,  # augmentation hyperparameters
                rect=False,  # rectangular training
                image_weights=False,
                cache_images=True
            )
            # Dataloader
            ini_dataloader = torch.utils.data.DataLoader(updated_lab_ds,
                                                         batch_size=batch_size,
                                                         num_workers=0,
                                                         shuffle=False,  # Shuffle=True unless rectangular training is used
                                                         pin_memory=True,
                                                         collate_fn=updated_lab_ds.collate_fn,
                                                         drop_last=False)

            model, best_ap = train_mix(model=model, optimizer=optimizer, dataloader=ini_dataloader, tgt_dataloader=t_gt_dl,
                                       start_epoch=0, epochs=epochs, nc=nc, batch_size=batch_size, da_switch=True,
                                       src2tgt_label_map=src2tgt_labelmap, save_epoch=tuple(), notest=True, test_dl=test_dl,
                                       ins_gain=5, best_save_name=f'/data/saved_model_{dataset_config["tgt"]}/{name}_n_{i}_best.pt',
                                       save_prefix='saved_ckpt_al_', save_pt=True,
                                       saved_map_dir=f'/data/saved_model_{dataset_config["tgt"]}/{name}_n_{i}_saved_map{("_" + str(fold)) if fold>0 else ""}.txt')
