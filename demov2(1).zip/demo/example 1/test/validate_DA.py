from al.train_test_func import *


def train_mix_cityscape(model, optimizer, dataloader, tgt_dataloader,
                        start_epoch, epochs, nc, batch_size, da_switch,
                        train_target=True, img_da=True, ins_da=True, class_weights=None,
                        notest=True, test_dl=None):
    # scheduler = lr_scheduler.LambdaLR(optimizer, lr_lambda=lf)
    scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=[round(epochs * x) for x in [0.8, 0.9]], gamma=0.1)
    scheduler.last_epoch = start_epoch - 1

    # Start training
    model.nc = nc  # attach number of classes to model
    model.arc = arc  # attach yolo architecture
    model.hyp = hyp  # attach hyperparameters to model
    model_info(model, report='summary')  # 'full' or 'summary'
    maps = np.zeros(nc)  # mAP per class
    if class_weights is not None:
        model.class_weights = class_weights
    results = (0, 0, 0, 0, 0, 0, 0)  # 'P', 'R', 'mAP', 'F1', 'val GIoU', 'val Objectness', 'val Classification'
    t0 = time.time()
    print('Starting %s for %g epochs...' % ('training', epochs))
    for epoch in range(start_epoch, epochs):  # epoch ------------------------------------------------------------------
        model.train()
        # print(('\n' + '%10s' * 12) % (
        #     'Epoch', 'gpu_mem', 'GIoU', 'obj', 'cls', 'total', 'img_DA', 'ms13_DA', 'ms26_DA', 'ms52_DA', 'targets',
        #     'img_size'))

        # training (source first)
        src_iter = iter(dataloader)
        nb = len(dataloader)
        tgt_iter = iter(tgt_dataloader)
        nbt = len(tgt_dataloader)
        end_src = False
        end_tgt = False

        print(f"running epoch {epoch + 1}...")
        batch_count = 0
        src_total_batch = nb
        tgt_total_batch = nbt

        # model.class_weights = labels_to_class_weights(dataset.labels, nc).to(device)  # attach class weights
        # mloss = torch.zeros(8).to(device)  # mean losses
        # pbar = tqdm(enumerate(dataloader), total=nb)  # progress bar
        ######################### SOURCE DOMAIN ##########################################
        while batch_count <= max(nb, nbt):
            batch_count += 1
            if batch_count <= nb:
                try:
                    imgs, targets, paths, _ = next(src_iter)
                except StopIteration:
                    end_src = True
            if batch_count <= nb:
                imgs = imgs.to(device)
                # assert src2tgt_label_map is not None
                # tgt_mask = [True] * targets.shape[0]
                # for ti, target in enumerate(targets):
                #     if target[1] >= 0:  # non-background, non-outlier classes
                #         if int(target[1]) in src2tgt_label_map.keys():
                #             target[1] = src2tgt_label_map[int(target[1])]
                #         else:
                #             tgt_mask[ti] = False
                # targets = targets[tgt_mask, :]
                targets = targets.to(device)

                # Run model
                domain_label = torch.ones(imgs.shape[0]).to(device)
                pred, da_pred, da_lab = model(imgs, domain_label=domain_label)
                # return order: img, scale13, 26, 52

                # Compute detection loss
                # print(imgs.shape)
                # print(targets.shape)
                # print(pred[0].shape)
                loss, loss_items = compute_loss(pred, targets, model)
                # Scale loss by nominal batch_size of 64
                # loss *= batch_size / 64

                if da_switch:
                    # compute DA loss
                    mask_list = build_obj_target_mask(targets, batch_size=imgs.shape[0])
                    for da_i in range(len(da_pred)):
                        base_prob1 = F.log_softmax(da_pred[da_i], dim=1)
                        total_da_loss = None
                        if da_i > 0:  # instance DA
                            # custom function to filter out non-object loss
                            # DA_img_loss_cls1 = F.nll_loss(base_prob1, da_lab[da_i], reduce=False, reduction='None')  # bs, scale, scale
                            # total_da_loss = torch.sum(DA_img_loss_cls1*(mask_list[da_i - 1].to(device))) / torch.sum(mask_list[da_i - 1]).to(device)
                            # MASK loss for each example. Only retain the object grid
                            total_da_loss = F.nll_loss(base_prob1, mask_list[da_i - 1].long().to(device),
                                                       ignore_index=0, reduction='mean')
                            if not ins_da:
                                total_da_loss *= 0
                            else:
                                total_da_loss *= 5
                        else:  # image level DA
                            total_da_loss = F.nll_loss(base_prob1, da_lab[da_i], reduction='mean')
                            if len(targets) == 0 or (not img_da):
                                total_da_loss *= 0
                            else:
                                total_da_loss *= 5
                            # total_da_loss2 = F.nll_loss(base_prob1, da_lab[da_i], reduce=False)
                            # tp = torch.sum(total_da_loss2)    # equal

                        loss += total_da_loss
                        loss_items = torch.cat((loss_items, total_da_loss.reshape(1))).detach()
                else:
                    for da_i in range(len(da_pred)):
                        base_prob1 = F.log_softmax(da_pred[da_i], dim=1)
                        total_da_loss = F.nll_loss(base_prob1, da_lab[da_i])
                        loss += total_da_loss * 0
                        loss_items = torch.cat((loss_items, total_da_loss.reshape(1) * 0)).detach()

                if not torch.isfinite(loss):
                    print('WARNING: non-finite loss, ending training ', loss_items)
                    return results

                # Compute gradient
                loss.backward()

            ######################### TARGET DOMAIN ##########################################
            if batch_count <= nbt:
                try:
                    imgs, targets, paths, _ = next(tgt_iter)
                except StopIteration:
                    end_tgt = True
            if batch_count <= nbt:
                imgs = imgs.to(device)
                targets = targets.to(device)

                # Run model
                domain_label = torch.zeros(imgs.shape[0]).to(device)
                pred, da_pred, da_lab = model(imgs, domain_label=domain_label)
                # return order: img, scale13, 26, 52

                # Compute detection loss
                # print(imgs.shape)
                # print(targets.shape)
                # print(pred[0].shape)
                loss, loss_items = compute_loss(pred, targets, model)
                # Scale loss by nominal batch_size of 64
                if not train_target:
                    loss *= 0

                if da_switch:
                    # compute DA loss
                    mask_list = build_obj_target_mask(targets, batch_size=imgs.shape[0])
                    for da_i in range(len(da_pred)):
                        base_prob1 = F.log_softmax(da_pred[da_i], dim=1)
                        total_da_loss = None
                        if da_i > 0:  # instance DA
                            # custom function to filter out non-object loss
                            # DA_img_loss_cls1 = F.nll_loss(base_prob1, da_lab[da_i], reduce=False, reduction='None')  # bs, scale, scale
                            # total_da_loss = torch.sum(DA_img_loss_cls1*(mask_list[da_i - 1].to(device))) / torch.sum(mask_list[da_i - 1]).to(device)
                            # MASK loss for each example. Only retain the object grid
                            total_da_loss = F.nll_loss(base_prob1, (1 - mask_list[da_i - 1]).long().to(device),
                                                       ignore_index=1,
                                                       reduction='mean')
                            if not ins_da:
                                total_da_loss *= 0
                            else:
                                total_da_loss *= 5
                        else:  # image level DA
                            total_da_loss = F.nll_loss(base_prob1, da_lab[da_i], reduction='mean')
                            if not img_da:
                                total_da_loss *= 0
                            else:
                                total_da_loss *= 5
                            # total_da_loss2 = F.nll_loss(base_prob1, da_lab[da_i], reduce=False)
                            # tp = torch.sum(total_da_loss2)    # equal

                        loss += total_da_loss
                        loss_items = torch.cat((loss_items, total_da_loss.reshape(1))).detach()
                else:
                    for da_i in range(len(da_pred)):
                        base_prob1 = F.log_softmax(da_pred[da_i], dim=1)
                        total_da_loss = F.nll_loss(base_prob1, da_lab[da_i])
                        loss += total_da_loss * 0
                        loss_items = torch.cat((loss_items, total_da_loss.reshape(1) * 0)).detach()

                if not torch.isfinite(loss):
                    print('WARNING: non-finite loss, ending training ', loss_items)
                    return results

                # Compute gradient
                loss.backward()
                # Accumulate gradient for x batches before optimizing
                # if ni % accumulate == 0:

            optimizer.step()
            optimizer.zero_grad()

            # print progress
            print("\rsource data: %.3f\t target data: %.3f" % (
            min(1.0, batch_count / src_total_batch), min(1.0, batch_count / tgt_total_batch)), end='')

        # Update scheduler
        scheduler.step()

        if not notest:
            assert test_dl is not None
            with torch.no_grad():
                results, maps = test(model,
                                     dataloader=test_dl,
                                     nc=nc,
                                     batch_size=batch_size,
                                     img_size=416,
                                     iou_thres=0.5,
                                     conf_thres=0.1,
                                     nms_thres=0.5)  # results[2] map
    return model


batch_size = 16

# load data
_, s_gt_ds, s_gt_dl = get_gt_dataloader(data='data/coco.data', data_item='source_train', img_size=416,
                                        batch_size=batch_size,
                                        rect=False, img_weights=False, cache_images=True, shuffle=False,
                                        augment=True, data_root='/data/cityscape/coco/images')
nc, t_gt_ds, t_gt_dl = get_gt_dataloader(data='data/coco.data', data_item='target_train', img_size=416,
                                         batch_size=batch_size,
                                         rect=False, img_weights=False, cache_images=False, shuffle=False,
                                         augment=True, data_root='/data/cityscape/coco/images', num_worker=0)
_, test_ds, test_dl = get_gt_dataloader(data='data/coco.data', data_item='valid', img_size=416, batch_size=batch_size,
                                        rect=False, img_weights=False, cache_images=True, shuffle=False,
                                        augment=False, data_root='/data/cityscape/coco/images')

class_weights = labels_to_class_weights(s_gt_ds.labels, nc).to(device)  # attach class weights



# if os.path.exists('/data/saved_model/init_da_yolo.pkl'):
with open('/data/saved_model/init_da_yolo.pkl', 'rb') as f:
    pf = pickle.load(f)
model = pf['model']
optimizer = pf['optimizer']

# Initialize distributed training
if torch.cuda.device_count() > 1:
    dist.init_process_group(backend='nccl',  # 'distributed backend'
                            init_method='tcp://127.0.0.1:3456',  # distributed training init method
                            world_size=1,  # number of nodes for distributed training
                            rank=0)  # distributed training node rank
    model = torch.nn.parallel.DistributedDataParallel(model, find_unused_parameters=True)
    model.yolo_layers = model.module.yolo_layers  # move yolo layer indices to top level

# da
model = train_mix_cityscape(model=model, optimizer=optimizer, dataloader=s_gt_dl, tgt_dataloader=t_gt_dl,
                            start_epoch=0, epochs=50, nc=nc, batch_size=batch_size, da_switch=True,
                            train_target=False, img_da=True, ins_da=True, notest=False, test_dl=test_dl,
                            class_weights=None)

with torch.no_grad():
    results, maps = test(model,
                         dataloader=test_dl,
                         nc=nc,
                         batch_size=batch_size,
                         img_size=416,
                         iou_thres=0.5,
                         conf_thres=0.001,
                         nms_thres=0.5,
                         data_root='/data/cityscape/coco/images')  # results[2] map

# print(results)
# exit()

with open('cityscape_val_da.txt', 'w') as f:
    f.write(f'da: {results[2]}\n')


# #######################################################################################
# # if os.path.exists('/data/saved_model/init_da_yolo.pkl'):
# with open('/data/saved_model/init_da_yolo.pkl', 'rb') as f:
#     pf = pickle.load(f)
# model = pf['model']
# optimizer = pf['optimizer']
#
# # ins da only
# model = train_mix_cityscape(model=model, optimizer=optimizer, dataloader=s_gt_dl, tgt_dataloader=t_gt_dl,
#                             start_epoch=0, epochs=50, nc=nc, batch_size=batch_size, da_switch=True,
#                             train_target=False, img_da=False, ins_da=True, notest=False, test_dl=test_dl)
#
# with torch.no_grad():
#     results, maps = test(model,
#                          dataloader=test_dl,
#                          nc=nc,
#                          batch_size=batch_size,
#                          img_size=416,
#                          iou_thres=0.5,
#                          conf_thres=0.01,
#                          nms_thres=0.5,
#                          data_root='/data/cityscape/coco/images')  # results[2] map
#
# with open('cityscape_val_da.txt', 'a') as f:
#     f.write(f'ins da only: {results[2]}\n')


#######################################################################################
# # if os.path.exists('/data/saved_model/init_da_yolo.pkl'):
# with open('/data/saved_model/init_da_yolo.pkl', 'rb') as f:
#     pf = pickle.load(f)
# model = pf['model']
# optimizer = pf['optimizer']

# # img da only
# model = train_mix_cityscape(model=model, optimizer=optimizer, dataloader=s_gt_dl, tgt_dataloader=t_gt_dl,
#                             start_epoch=0, epochs=50, nc=nc, batch_size=batch_size, da_switch=True,
#                             train_target=False, img_da=True, ins_da=False, notest=False, test_dl=test_dl)
#
# with torch.no_grad():
#     results, maps = test(model,
#                          dataloader=test_dl,
#                          nc=nc,
#                          batch_size=batch_size,
#                          img_size=416,
#                          iou_thres=0.5,
#                          conf_thres=0.01,
#                          nms_thres=0.5,
#                          data_root='/data/cityscape/coco/images')  # results[2] map
#
# with open('cityscape_val_da.txt', 'a') as f:
#     f.write(f'img da only: {results[2]}\n')
#
#
# #######################################################################################
# # if os.path.exists('/data/saved_model/init_da_yolo.pkl'):
# with open('/data/saved_model/init_da_yolo.pkl', 'rb') as f:
#     pf = pickle.load(f)
# model = pf['model']
# optimizer = pf['optimizer']
#
# # woda
# model = train_mix_cityscape(model=model, optimizer=optimizer, dataloader=s_gt_dl, tgt_dataloader=t_gt_dl,
#                             start_epoch=0, epochs=50, nc=nc, batch_size=batch_size, da_switch=False,
#                             train_target=False, img_da=False, ins_da=False, notest=False, test_dl=test_dl)
#
# with torch.no_grad():
#     results, maps = test(model,
#                          dataloader=test_dl,
#                          nc=nc,
#                          batch_size=batch_size,
#                          img_size=416,
#                          iou_thres=0.5,
#                          conf_thres=0.01,
#                          nms_thres=0.5,
#                          data_root='/data/cityscape/coco/images')  # results[2] map
#
# with open('cityscape_val_da.txt', 'a') as f:
#     f.write(f'woda: {results[2]}\n')
