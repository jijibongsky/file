from al.al_data_loader import QueryRepo
from utils.datasets import ConvertRepo2Dataset
import pickle
import torch

with open("/data/saved_al/our_0_all.pkl", 'rb') as f:
    our_qr = pickle.load(f)

hyp = {'giou': 1.582,  # giou loss gain
       'cls': 27.76,  # cls loss gain  (CE=~1.0, uCE=~20)
       'cls_pw': 1.446,  # cls BCELoss positive_weight
       'obj': 21.35,  # obj loss gain (*=80 for uBCE with 80 classes)
       'obj_pw': 3.941,  # obj BCELoss positive_weight
       #  'obj_pw': 1,
       'iou_t': 0.2635,  # iou training threshold
       # 'lr0': 0.002324,  # initial learning rate (SGD=1E-3, Adam=9E-5)
       'lr0': 9e-5,  # initial learning rate (SGD=1E-3, Adam=9E-5)
       'lrf': -4.,  # final LambdaLR learning rate = lr0 * (10 ** lrf)
       'momentum': 0.97,  # SGD momentum
       'weight_decay': 0.0004569,  # optimizer weight decay
       'hsv_s': 0.5703,  # image HSV-Saturation augmentation (fraction)
       'hsv_v': 0.3174,  # image HSV-Value augmentation (fraction)
       'degrees': 1.113,  # image rotation (+/- deg)
       'translate': 0.06797,  # image translation (+/- fraction)
       'scale': 0.1059,  # image scale (+/- gain)
       'shear': 0.5768}  # image shear (+/- deg)

updated_lab_ds = ConvertRepo2Dataset(query_repo=our_qr,img_size=416,
                                     batch_size=32,augment=True, hyp=hyp,
                                     rect=False,image_weights=False, cache_images=False)

# Dataloader
q_dataloader = torch.utils.data.DataLoader(updated_lab_ds,
                                           batch_size=32,
                                           num_workers=0,
                                           shuffle=False,  # Shuffle=True unless rectangular training is used
                                           pin_memory=True,
                                           collate_fn=updated_lab_ds.collate_fn,
                                           drop_last=False)

# updated_lab_ds.get_item_by_path('/data/coco/images/train2014/COCO_train2014_000000528832.jpg')

for i in range(10):
    qi = iter(q_dataloader)
    end_q = False
    j = 0
    while not end_q:
        try:
            j+=1
            if (j)/len(qi) == 1:
                print('now')
            ima, tar, path, _ = next(qi)
            if len(tar) == 0:
                print('wtf')
            print(f"\r{(j)/len(qi):.2f}", end='')
        except StopIteration:
            end_q = True

