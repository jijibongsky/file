import torch
from al.al_data_loader import QueryRepo
from utils.datasets import ConvertRepo2Dataset
from al.train_test_func import get_gt_dataloader, hyp

_, test_ds, test_dl = get_gt_dataloader(data='/home/tangyingpeng/yolov3/data/voc_coco.data', data_item='valid', img_size=416, batch_size=1,
                                        rect=False, img_weights=False, cache_images=False, shuffle=False,
                                        augment=False, data_root='/data/voc/voc_pure_data/images/')

qr = QueryRepo()
val=dict()

t_iter = iter(test_dl)
imgs, targets, paths, _ = next(t_iter)
targets[:, 1] = -1

qr.update(img_path=paths[0], im_info=1, gt_boxes=targets,
          num_pos=0, num_neg=0, num_outlier=0, cost=0,
          domain_label=1, iteration=0, method_name='ddd')
val[paths[0]] = targets

imgs, targets, paths, _ = next(t_iter)

qr.update(img_path=paths[0], im_info=1, gt_boxes=targets,
          num_pos=0, num_neg=0, num_outlier=0, cost=0,
          domain_label=1, iteration=0, method_name='ddd')
val[paths[0]] = targets

imgs, targets, paths, _ = next(t_iter)

qr.update(img_path=paths[0], im_info=1, gt_boxes=targets,
          num_pos=0, num_neg=0, num_outlier=0, cost=0,
          domain_label=1, iteration=0, method_name='ddd')
val[paths[0]] = targets

qds = ConvertRepo2Dataset(query_repo=qr, batch_size=2, rect=False, augment=True, hyp=hyp)
# Dataloader
qdl = torch.utils.data.DataLoader(qds,
                                  batch_size=1,
                                  num_workers=0,
                                  shuffle=False,  # Shuffle=True unless rectangular training is used
                                  pin_memory=True,
                                  collate_fn=qds.collate_fn)

t_iter = iter(qdl)

while True:
    try:
        imgs, targets, paths, _ = next(t_iter)
    except StopIteration:
        break

    print('get batch.')
    for i, path in enumerate(paths):
        print(targets)
        print(val[path])
        # assert targets == val[path]
        print(qds.get_item_by_path(path)[1])

print('test ok')
