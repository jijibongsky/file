from al.train_test_func import *
from al.al_data_loader import QueryRepo
from al.al_utils import al_mainloop, al_scoring, our_al_mainloop
import alipy
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--ptw-ini', type=float, default=0.1)
parser.add_argument('--ptw-max', type=float, default=0.8)
parser.add_argument('--ptw-end-epoch', type=float, default=0.1)
parser.add_argument('--clsw', type=float, default=0.3)
parser.add_argument('--st-thres', type=float, default=0.001)

parser.add_argument('--posinsw', type=float, default=2.0)
parser.add_argument('--objw', type=float, default=10.0)
parser.add_argument('--save-name', type=str, default='', help='name of the saved file')

parser.add_argument('--no-da', action='store_true')
parser.add_argument('--no-ini', action='store_true')
parser.add_argument('--neg-cls-loss', action='store_true')
parser.add_argument('--border-neg', action='store_true')
parser.add_argument('--cache-img', action='store_true')
opt = parser.parse_args()

VOC_COCO = {
    'pkl': '/data/saved_model/init_da_yolo_coco.pkl',
    'coco_dir': '/data/coco/images/train2014/',
    'voc_dir': '/data/voc/voc_pure_data/images/',
    'data': 'data/voc_coco.data',
    'label_map': 'data/cocoid2vocid.pkl',
    'cfg': 'cfg/yolov3-spp-voc.cfg',
}

TOTAL_SCORE_THRES = 0.1
INCONS_SCORE_THRES = 0.1
TRANS_SCORE_THRES = 0.1
POS_INS_WEIGHT = 10
TRANS_TRANDEOFF = 0.1
TRANS_NORM = False
batch_size = 32
accumulate = 2
epochs = 20
img_size = 416
cache_images = opt.cache_img  # False for testing
pretrain_weights = '/home/tangyingpeng/todal/darknet/darknet53.conv.74'

with open(VOC_COCO['label_map'], 'rb') as f:
    cocoid2vocid = pickle.load(f)

# load data
_, s_gt_ds, s_gt_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='source_train', img_size=416,
                                        batch_size=batch_size,
                                        rect=False, img_weights=False, cache_images=False, shuffle=False,
                                        augment=False, data_root=VOC_COCO['coco_dir'])
nc, t_gt_ds, t_gt_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='target_train', img_size=416,
                                         batch_size=batch_size,
                                         rect=False, img_weights=False, cache_images=cache_images, shuffle=False,
                                         augment=True, data_root=VOC_COCO['voc_dir'])
_, test_ds, test_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='valid', img_size=416, batch_size=batch_size,
                                        rect=False, img_weights=False, cache_images=False, shuffle=False,
                                        augment=False, data_root=VOC_COCO['voc_dir'])

# load init lab_unlab
with open('data/coco_init_lab.txt', 'r') as f:
    init_lab = f.read().splitlines(keepends=False)
with open('data/coco_init_unlab.txt', 'r') as f:
    init_unlab = f.read().splitlines(keepends=False)

# start pipeline
unlab_len = len(init_unlab)

queried_repo = QueryRepo(partial_label=False)
name_arr = ['our', 'our_incons', 'our_trans']
ini_point = 0.45  # 20 epoch, using voc 07+12 train val, without data augmentation
# init lab unlab score
for name in name_arr:
    exec(name + '_l_set' + ' = alipy.index.IndexCollection(init_lab)')
    exec(name + '_ul_set' + '= alipy.index.IndexCollection(init_unlab)')
    exec(name + '_lc' + ' = [[0, ini_point]]')
    exec(f"{name}_qr = QueryRepo(partial_label=False)")

# 26 per instance, 80,000+ images, 608695 instances. 349525 in target classes. 7.5 instances per img in average
budget_rate = np.array([0.05] * 5 + [0.1] * 3 + [0.15] * 2)
budget_arr = 25.5 * 349525 * budget_rate

name_arr = ['our']
first_flag = True
parallel = True
# query 10 batches
for name in name_arr:
    for i in range(10):
        print(name)
        # load last round model
        if first_flag:
            model, optimizer, res = load_voc_model(pt_path=f'/data/saved_model/{name}_{i - 1}_best.pt',
                                                   cfg='cfg/yolov3-spp-voc.cfg',
                                                   parallel=parallel, init_group=True)
            first_flag = False
        else:
            model, optimizer, res = load_voc_model(pt_path=f'/data/saved_model/{name}_{i - 1}_best.pt',
                                                   cfg='cfg/yolov3-spp-voc.cfg',
                                                   parallel=parallel, init_group=False)
        model.eval()

        # eval unlab and query
        # exec(f"queried_repo={name}_qr")
        # with torch.no_grad():
        #     scores = al_scoring(unlab_arr=our_ul_set,
        #                         model=model, s_gt_ds=s_gt_ds,
        #                         method_name=name,
        #                         cocoid2vocid=cocoid2vocid,
        #                         queried_repo=queried_repo,
        #                         test=False,
        #                         acl=1)

        # testing only
        # with open(f"/data/saved_al/{name}_0_all.pkl", 'rb') as f:
        #     our_qr = pickle.load(f)
        with open(f"/data/saved_al/rand_pos_ins.pkl", 'rb') as f:
            our_qr = pickle.load(f)

        # exec("queried_repo, total_cost, num_stat = our_al_mainloop(scoring_arr=scores, src_gt_ds=s_gt_ds, "
        #      "budget=budget_arr[i], queried_repo=queried_repo, method_name='" +
        #      name + "',iteration=" + str(i) + ", src2tgt_label_map=cocoid2vocid" + ")")
        # exec(f"{name}_qr=queried_repo")

        # train/test model
        exec(f"updated_lab_ds = ConvertRepo2Dataset(query_repo={name}_qr,img_size=img_size,batch_size=batch_size,augment=True,hyp=hyp,rect=False,image_weights=False,cache_images={cache_images})")
        ini_src_ds = LoadImagesAndLabelsByImgFiles(
            img_files=init_lab[0:50] if opt.no_ini else init_lab,
            img_size=img_size,
            batch_size=batch_size,
            augment=True,
            hyp=hyp,  # augmentation hyperparameters
            rect=False,  # rectangular training
            image_weights=False,
            cache_images=cache_images
        )

        # Dataloader
        q_dataloader = torch.utils.data.DataLoader(updated_lab_ds,
                                                   batch_size=batch_size,
                                                   num_workers=0,
                                                   shuffle=False,  # Shuffle=True unless rectangular training is used
                                                   pin_memory=True,
                                                   collate_fn=updated_lab_ds.collate_fn,
                                                   drop_last=False)

        # Dataloader
        ini_dataloader = torch.utils.data.DataLoader(ini_src_ds,
                                                     batch_size=batch_size,
                                                     num_workers=0,
                                                     shuffle=False,  # Shuffle=True unless rectangular training is used
                                                     pin_memory=True,
                                                     collate_fn=ini_src_ds.collate_fn,
                                                     drop_last=False)

        # with torch.no_grad():
        #     results, maps = test(model,
        #                          dataloader=test_dl,
        #                          nc=nc,
        #                          batch_size=batch_size,
        #                          img_size=416,
        #                          iou_thres=0.5,
        #                          conf_thres=0.1,
        #                          nms_thres=0.5)  # results[2] map

        with open(f"/data/saved_model/{name}_{i}_saved_map{('_'+opt.save_name) if opt.save_name else ''}.pkl", 'wb') as optf:
            pickle.dump(opt, optf)
        # saved_map_dir=f'/datas/saved_model/{name}_{i}_saved_map_{int(opt.ptw_ini*100)}_{int(opt.ptw_max*100)}_{int(opt.ptw_end_epoch*100)}.txt',
        model, best_ap = train_mix_partial(model=model, optimizer=optimizer, dataloader=ini_dataloader,
                                           queried_dataloader=q_dataloader, tgt_dataloader=t_gt_dl,
                                           start_epoch=0, epochs=50, nc=nc, batch_size=batch_size, da_switch=not opt.no_da,
                                           src2tgt_label_map=cocoid2vocid, save_epoch=tuple(), notest=False,
                                           test_dl=test_dl,
                                           ins_gain=5, best_save_name=f'/data/saved_model/{name}_{i}_best.pt',
                                           save_prefix='saved_ckpt_al_',
                                           saved_map_dir=f"/data/saved_model/{name}_{i}_saved_map{('_'+opt.save_name) if opt.save_name else ''}.txt",
                                           verbose=True, part_loss_weight_ini=opt.ptw_ini, part_loss_weight_max=opt.ptw_max,
                                           part_loss_weight_update_end_epoch=opt.ptw_end_epoch,
                                           cls_weight=opt.clsw, calc_neg_cls_loss=opt.neg_cls_loss,
                                           obj_weight=opt.objw, self_training_thres=opt.st_thres,
                                           border_neg=opt.border_neg)

        exec(name + '_lc' + '.append([total_cost, best_ap])')
        # same lc
        exec(f"print({name}_lc)")
        exec(f"np.savetxt('/data/saved_al/{name}_{i}_lc.txt', {name}_lc)")
        print(name, total_cost, best_ap)

for name in name_arr:
    exec(f"print({name}_lc)")


