from al.train_test_func import *
from al.al_data_loader import QueryRepo
from al.al_utils import al_mainloop, al_scoring, our_al_mainloop, al_scoring_our_debug
from utils.datasets import ConvertRepo2Dataset
import alipy
import argparse

parser = argparse.ArgumentParser()
# sudo /home/tangyingpeng/anaconda3/bin/python our_method_test_ini_mode.py --clsw 3  --save-name c_clsw3 --neg-cls-loss --border-neg --cache-img
# parser.add_argument('--ptw-ini', type=float, default=0.1)
# parser.add_argument('--ptw-max', type=float, default=0.8)
parser.add_argument('--ptw-ini', type=float, default=1.0)
parser.add_argument('--ptw-max', type=float, default=1.0)
parser.add_argument('--ptw-end-epoch', type=float, default=0.1)
parser.add_argument('--clsw', type=float, default=0.5)
parser.add_argument('--st-thres', type=float, default=0.001)

parser.add_argument('--posinsw', type=float, default=3.91)
parser.add_argument('--objw', type=float, default=40)
parser.add_argument('--save-name', type=str, default='', help='name of the saved file')

parser.add_argument('--no-da', action='store_true')
parser.add_argument('--no-ini', action='store_true')
parser.add_argument('--all-img-da', action='store_true')
parser.add_argument('--pair', action='store_true')
parser.add_argument('--neg-cls-loss', action='store_true')
parser.add_argument('--border-neg', action='store_true')
parser.add_argument('--cache-img', action='store_true')

# al para
parser.add_argument('--debug-al', action='store_true')
parser.add_argument('--method', type=str, help='name of the method')
parser.add_argument('--start-iter', type=int, default=0)
parser.add_argument('--end-iter', type=int, default=10)
parser.add_argument('--pos-ins-weight', type=float, default=0.05)
parser.add_argument('--da-tradeoff', type=float, default=0.5)
parser.add_argument('--acl', type=float, default=1.0)
parser.add_argument('--skip-query', action='store_true')
parser.add_argument('--al-save-name', type=str, default='', help='name of the al saved file')

opt = parser.parse_args()

opt.neg_cls_loss = True
opt.border_neg = True
opt.cache_img = True

VOC_COCO = {
    'pkl': '/data/saved_model/init_da_yolo_coco.pkl',
    'coco_dir': '/data/coco/images/train2014/',
    'voc_dir': '/data/voc/voc_pure_data/images/',
    'data': 'data/voc_coco.data',
    'label_map': 'data/cocoid2vocid.pkl',
    'cfg': 'cfg/yolov3-spp-voc.cfg',
}

TOTAL_SCORE_THRES = 0.1
INCONS_SCORE_THRES = 0.1
TRANS_SCORE_THRES = 0.1
POS_INS_WEIGHT = 10
TRANS_TRANDEOFF = 0.1
TRANS_NORM = False
batch_size = 32
accumulate = 2
epochs = 20
img_size = 416
cache_images = opt.cache_img  # False for testing
pretrain_weights = '/home/tangyingpeng/todal/darknet/darknet53.conv.74'

with open(VOC_COCO['label_map'], 'rb') as f:
    cocoid2vocid = pickle.load(f)

# load data
_, s_gt_ds, s_gt_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='source_train', img_size=416,
                                        batch_size=batch_size,
                                        rect=False, img_weights=False, cache_images=False, shuffle=False,
                                        augment=False, data_root=VOC_COCO['coco_dir'])
nc, t_gt_ds, t_gt_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='target_train', img_size=416,
                                         batch_size=batch_size,
                                         rect=False, img_weights=False, cache_images=cache_images, shuffle=False,
                                         augment=True, data_root=VOC_COCO['voc_dir'])
_, test_ds, test_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='valid', img_size=416, batch_size=batch_size,
                                        rect=False, img_weights=False, cache_images=False, shuffle=False,
                                        augment=False, data_root=VOC_COCO['voc_dir'])

# load init lab_unlab
with open('data/coco_init_lab.txt', 'r') as f:
    init_lab = f.read().splitlines(keepends=False)
with open('data/coco_init_unlab.txt', 'r') as f:
    init_unlab = f.read().splitlines(keepends=False)

# start pipeline
unlab_len = len(init_unlab)

assert 'our' in opt.method

ini_point = 0.5916
l_set = alipy.index.IndexCollection(init_lab)
ul_set = alipy.index.IndexCollection(init_unlab)
lc = [[0, ini_point]]
queried_repo = QueryRepo(partial_label=False)

# 26 per instance, 80,000+ images, 608695 instances. 7.5 instances per img in average
budget_rate = np.array([0.05] * 5 + [0.1] * 3 + [0.15] * 2)
budget_arr = 25.5 * 349525 * budget_rate

# load ini model
model, optimizer, _ = load_voc_model(pt_path='/data/select_pd_para/re_test_ini_best.pt',
                                     cfg='cfg/yolov3-spp-voc.cfg',
                                     parallel=True, parallel_port=6666, init_group=True)

for i in np.arange(opt.start_iter, opt.end_iter):
    name = opt.method
    # load last round model
    if i > 0:
        with open(f"/data/saved_al/{name}_{i - 1}_all.pkl", 'rb') as f:
            queried_repo = pickle.load(f)
        assert len(queried_repo) > 0
        # load last round model
        model, optimizer, _ = load_voc_model(pt_path=f'/data/saved_model/{name}_{i - 1}_best.pt',
                                             cfg='cfg/yolov3-spp-voc.cfg',
                                             parallel=True, init_group=False)
        print(f"model and queried repo of iteration {i - 1} has been loaded.")

    if opt.skip_query:
        with open(f"/data/saved_al/{name}_{i}_all.pkl", 'rb') as f:
            queried_repo = pickle.load(f)
        opt.skip_query = False
    else:
        model.eval()

        func_ul_set = ul_set
        with torch.no_grad():

            scores = al_scoring_our_debug(unlab_arr=func_ul_set,
                                        model=model, s_gt_ds=s_gt_ds,
                                        method_name=name,
                                        cocoid2vocid=cocoid2vocid,
                                        queried_repo=queried_repo,
                                        test=False,
                                        acl=opt.acl,
                                        pos_ins_weight=opt.pos_ins_weight,
                                        da_tradeoff=opt.da_tradeoff)

        queried_repo, total_cost, num_stat = our_al_mainloop(scoring_arr=scores, src_gt_ds=s_gt_ds, budget=budget_arr[i],
                                                             queried_repo=queried_repo, method_name=name, iteration=str(i),
                                                             src2tgt_label_map=cocoid2vocid, static_type=True,
                                                             save_suffix=opt.al_save_name)

        if opt.debug_al:
            exit()
        # with open(f"/data/saved_al/rand_pos_ins.pkl", 'rb') as f:
        #     our_qr = pickle.load(f)

    updated_lab_ds = ConvertRepo2Dataset(query_repo=queried_repo, img_size=img_size, batch_size=batch_size,
                                         augment=True, hyp=hyp, rect=False, image_weights=False, cache_images=True)
    ini_src_ds = LoadImagesAndLabelsByImgFiles(
        img_files=init_lab[0:50] if opt.no_ini else init_lab,
        img_size=img_size,
        batch_size=batch_size,
        augment=True,
        hyp=hyp,  # augmentation hyperparameters
        rect=False,  # rectangular training
        image_weights=False,
        cache_images=cache_images
    )

    # Dataloader
    q_dataloader = torch.utils.data.DataLoader(updated_lab_ds,
                                               batch_size=batch_size,
                                               num_workers=0,
                                               shuffle=False,  # Shuffle=True unless rectangular training is used
                                               pin_memory=True,
                                               collate_fn=updated_lab_ds.collate_fn,
                                               drop_last=False)

    # Dataloader
    ini_dataloader = torch.utils.data.DataLoader(ini_src_ds,
                                                 batch_size=batch_size,
                                                 num_workers=0,
                                                 shuffle=False,  # Shuffle=True unless rectangular training is used
                                                 pin_memory=True,
                                                 collate_fn=ini_src_ds.collate_fn,
                                                 drop_last=False)

    with open(f"/data/select_pd_para/{name}_{i}_saved_opt{('_' + opt.save_name) if opt.save_name else ''}.pkl",
              'wb') as optf:
        pickle.dump(opt, optf)

    # load init model
    model, optimizer = init_model(pkl_path=f'/data/saved_model/init_da_yolo_voc.pkl',
                                  cfg='cfg/yolov3-spp-voc.cfg',
                                  parallel=True, init_group=False)

    model, best_ap = train_mix_partial(model=model, optimizer=optimizer, dataloader=ini_dataloader,
                                       queried_dataloader=q_dataloader, tgt_dataloader=t_gt_dl,
                                       start_epoch=0, epochs=50, nc=nc, batch_size=batch_size,
                                       da_switch=not opt.no_da,
                                       src2tgt_label_map=cocoid2vocid, save_epoch=tuple(), notest=False,
                                       test_dl=test_dl,
                                       ins_gain=5,
                                       best_save_name=f'/data/saved_model/{name}_{i}_best.pt',
                                       save_prefix='saved_ckpt_al_',
                                       saved_map_dir=f"/data/saved_model/{name}_{i}_saved_map{('_' + opt.save_name) if opt.save_name else ''}.txt",
                                       verbose=False, part_loss_weight_ini=opt.ptw_ini,
                                       part_loss_weight_max=opt.ptw_max,
                                       part_loss_weight_update_end_epoch=opt.ptw_end_epoch,
                                       cls_weight=opt.clsw, calc_neg_cls_loss=opt.neg_cls_loss,
                                       obj_weight=opt.objw, self_training_thres=opt.st_thres,
                                       border_neg=opt.border_neg)

    # lc.append([total_cost, best_ap])
    # # same lc
    # print(lc)
    # np.savetxt(f'/data/saved_al/{name}_{i}_lc.txt', lc)
    # print(name, total_cost, best_ap)

