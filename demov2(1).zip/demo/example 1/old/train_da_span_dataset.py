import argparse
import time
import pickle

import torch.distributed as dist
import torch.optim as optim
import torch.optim.lr_scheduler as lr_scheduler

from old import test
from models_da import *
from utils.datasets import *
from utils.utils import *

mixed_precision = True
try:  # Mixed precision training https://github.com/NVIDIA/apex
    from apex import amp
except:
    mixed_precision = False  # not installed

# Hyperparameters (j-series, 50.5 mAP yolov3-320) evolved by @ktian08 https://github.com/ultralytics/yolov3/issues/310
hyp = {'giou': 1.582,  # giou loss gain
       'cls': 27.76,  # cls loss gain  (CE=~1.0, uCE=~20)
       'cls_pw': 1.446,  # cls BCELoss positive_weight
       'obj': 21.35,  # obj loss gain (*=80 for uBCE with 80 classes)
       'obj_pw': 3.941,  # obj BCELoss positive_weight
       'iou_t': 0.2635,  # iou training threshold
       # 'lr0': 0.002324,  # initial learning rate (SGD=1E-3, Adam=9E-5)
       'lr0': 9e-5,  # initial learning rate (SGD=1E-3, Adam=9E-5)
       'lrf': -4.,  # final LambdaLR learning rate = lr0 * (10 ** lrf)
       'momentum': 0.97,  # SGD momentum
       'weight_decay': 0.0004569,  # optimizer weight decay
       'hsv_s': 0.5703,  # image HSV-Saturation augmentation (fraction)
       'hsv_v': 0.3174,  # image HSV-Value augmentation (fraction)
       'degrees': 1.113,  # image rotation (+/- deg)
       'translate': 0.06797,  # image translation (+/- fraction)
       'scale': 0.1059,  # image scale (+/- gain)
       'shear': 0.5768}  # image shear (+/- deg)


def train():
    src_img_dir = opt.source_img_dir
    tgt_img_dir = opt.target_img_dir
    SAVED_FILE_NAME = opt.output_results
    is_target_only = opt.target_only
    is_target_training = not opt.no_target_training
    da_switch = opt.da
    cfg = opt.cfg
    data = opt.data
    img_size = opt.img_size
    epochs = 1 if opt.prebias else opt.epochs  # 500200 batches at bs 16, 117263 images = 273 epochs
    batch_size = opt.batch_size
    accumulate = opt.accumulate  # effective bs = batch_size * accumulate = 16 * 4 = 64
    weights = opt.weights  # initial training weights

    with open(opt.src_to_tgt_label_map, 'rb') as f:
        cocoid2vocid = pickle.load(f)

    if 'pw' not in opt.arc:  # remove BCELoss positive weights
        hyp['cls_pw'] = 1.
        hyp['obj_pw'] = 1.

    # Initialize
    init_seeds()
    wdir = 'weights' + os.sep  # weights dir
    last = wdir + 'last.pt'
    best = wdir + 'best.pt'
    multi_scale = opt.multi_scale

    if multi_scale:
        img_sz_min = round(img_size / 32 / 1.5) + 1
        img_sz_max = round(img_size / 32 * 1.5) - 1
        img_size = img_sz_max * 32  # initiate with maximum multi_scale size
        print('Using multi-scale %g - %g' % (img_sz_min * 32, img_size))

    # Configure run
    data_dict = parse_data_cfg(data)
    tgt_train_path = data_dict['target_train']
    src_train_path = data_dict['source_train']
    nc = int(data_dict['classes'])  # number of classes

    # Remove previous results
    for f in glob.glob('*_batch*.jpg') + glob.glob(SAVED_FILE_NAME):
        os.remove(f)

    start_epoch = 0
    best_fitness = 0.
    # check for pkl file
    if os.path.exists('/data/saved_model/init_da_yolo_coco.pkl'):
        with open('/data/saved_model/init_da_yoloc_coco.pkl', 'rb') as f:
            pf = pickle.load(f)
        model = pf['model']
        optimizer = pf['optimizer']
    else:
        # Initialize model
        model = Darknet(cfg, arc=opt.arc).to(device)

        # Optimizer
        pg0, pg1 = [], []  # optimizer parameter groups
        for k, v in dict(model.named_parameters()).items():
            if 'Conv2d.weight' in k:
                pg1 += [v]  # parameter group 1 (apply weight_decay)
            else:
                pg0 += [v]  # parameter group 0

        optimizer = optim.Adam(pg0, lr=hyp['lr0'])
        optimizer.add_param_group({'params': pg1})
        # optimizer = AdaBound(pg0, lr=hyp['lr0'], final_lr=0.1)
        # optimizer = optim.SGD(pg0, lr=hyp['lr0'], momentum=hyp['momentum'], nesterov=True)
        # optimizer.add_param_group({'params': pg1, 'weight_decay': hyp['weight_decay']})  # add pg1 with weight_decay
        del pg0, pg1

        cutoff = -1  # backbone reaches to cutoff layer
        if weights.endswith('.pt'):  # pytorch format
            # possible weights are 'last.pt', 'yolov3-spp.pt', 'yolov3-tiny.pt' etc.
            if opt.bucket:
                os.system('gsutil cp gs://%s/last.pt %s' % (opt.bucket, last))  # download from bucket
            chkpt = torch.load(weights, map_location=device)

            # load model
            if opt.transfer:
                chkpt['model'] = {k: v for k, v in chkpt['model'].items() if model.state_dict()[k].numel() == v.numel()}
                model.load_state_dict(chkpt['model'], strict=False)
            else:
                model.load_state_dict(chkpt['model'])

            # load optimizer
            if chkpt['optimizer'] is not None:
                optimizer.load_state_dict(chkpt['optimizer'])
                best_fitness = chkpt['best_fitness']

            # load results
            if chkpt.get('training_results') is not None:
                with open(SAVED_FILE_NAME, 'w') as file:
                    file.write(chkpt['training_results'])  # write results.txt

            start_epoch = chkpt['epoch'] + 1
            del chkpt

        elif len(weights) > 0:  # darknet format
            # possible weights are 'yolov3.weights', 'yolov3-tiny.conv.15',  'darknet53.conv.74' etc.
            cutoff = load_darknet_weights(model, weights)

        if opt.transfer or opt.prebias:  # transfer learning edge (yolo) layers
            nf = int(model.module_defs[model.yolo_layers[0] - 1]['filters'])  # yolo layer size (i.e. 255)

            for p in optimizer.param_groups:
                # lower param count allows more aggressive training settings: i.e. SGD ~0.1 lr0, ~0.9 momentum
                p['lr'] *= 100
                if p.get('momentum') is not None:  # for SGD but not Adam
                    p['momentum'] *= 0.9

            for p in model.parameters():
                if opt.prebias and p.numel() == nf:  # train (yolo biases)
                    p.requires_grad = True
                elif opt.transfer and p.shape[0] == nf:  # train (yolo biases+weights)
                    p.requires_grad = True
                else:  # freeze layer
                    p.requires_grad = False

        tp_dict = dict()
        tp_dict['model'] = model
        tp_dict['optimizer'] = optimizer
        with open('/data/saved_model/init_da_yoloc_coco.pkl', 'wb') as f:
            pickle.dump(tp_dict, f)

    # add DA module
    # if da_switch:
    #     optimizer.add_param_group({'params': model.featmapDA_scale13.parameters()})
    #     optimizer.add_param_group({'params': model.featmapDA_scale26.parameters()})
    #     optimizer.add_param_group({'params': model.featmapDA_scale52.parameters()})
    #     optimizer.add_param_group({'params': model.featmapDA_img.parameters()})

    # Scheduler https://github.com/ultralytics/yolov3/issues/238
    # lf = lambda x: 1 - x / epochs  # linear ramp to zero
    # lf = lambda x: 10 ** (hyp['lrf'] * x / epochs)  # exp ramp
    # lf = lambda x: 1 - 10 ** (hyp['lrf'] * (1 - x / epochs))  # inverse exp ramp
    # scheduler = lr_scheduler.LambdaLR(optimizer, lr_lambda=lf)
    scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=[round(opt.epochs * x) for x in [0.8, 0.9]], gamma=0.1)
    scheduler.last_epoch = start_epoch - 1

    # # Plot lr schedule
    # y = []
    # for _ in range(epochs):
    #     scheduler.step()
    #     y.append(optimizer.param_groups[0]['lr'])
    # plt.plot(y, label='LambdaLR')
    # plt.xlabel('epoch')
    # plt.ylabel('LR')
    # plt.tight_layout()
    # plt.savefig('LR.png', dpi=300)

    # Mixed precision training https://github.com/NVIDIA/apex
    if mixed_precision:
        model, optimizer = amp.initialize(model, optimizer, opt_level='O1', verbosity=0)

    # Initialize distributed training
    if torch.cuda.device_count() > 1:
        dist.init_process_group(backend='nccl',  # 'distributed backend'
                                init_method='tcp://127.0.0.1:7777',  # distributed training init method
                                world_size=1,  # number of nodes for distributed training
                                rank=0)  # distributed training node rank
        model = torch.nn.parallel.DistributedDataParallel(model, find_unused_parameters=True)
        model.yolo_layers = model.module.yolo_layers  # move yolo layer indices to top level

    # Dataset
    target_dataset = LoadImagesAndLabels(tgt_train_path,
                                         img_size,
                                         batch_size,
                                         augment=False,
                                         hyp=hyp,  # augmentation hyperparameters
                                         rect=opt.rect,  # rectangular training
                                         image_weights=opt.img_weights,
                                         cache_images=False if opt.prebias else opt.cache_images,
                                         DATA_ROOT=tgt_img_dir)

    # Dataloader
    tgt_dataloader = torch.utils.data.DataLoader(target_dataset,
                                                 batch_size=batch_size,
                                                 num_workers=min(os.cpu_count(), batch_size),
                                                 shuffle=not opt.rect,
                                                 # Shuffle=True unless rectangular training is used
                                                 pin_memory=True,
                                                 collate_fn=target_dataset.collate_fn)

    if not is_target_only:
        # Dataset
        dataset = LoadImagesAndLabels(src_train_path,
                                      img_size,
                                      batch_size,
                                      augment=False,
                                      hyp=hyp,  # augmentation hyperparameters
                                      rect=opt.rect,  # rectangular training
                                      image_weights=opt.img_weights,
                                      cache_images=False if opt.prebias else opt.cache_images,
                                      DATA_ROOT=src_img_dir)

        # Dataloader
        dataloader = torch.utils.data.DataLoader(dataset,
                                                 batch_size=batch_size,
                                                 num_workers=min(os.cpu_count(), batch_size),
                                                 shuffle=not opt.rect,
                                                 # Shuffle=True unless rectangular training is used
                                                 pin_memory=True,
                                                 collate_fn=dataset.collate_fn)


    # Start training
    model.nc = nc  # attach number of classes to model
    model.arc = opt.arc  # attach yolo architecture
    model.hyp = hyp  # attach hyperparameters to model
    model_info(model, report='summary')  # 'full' or 'summary'
    maps = np.zeros(nc)  # mAP per class
    results = (0, 0, 0, 0, 0, 0, 0)  # 'P', 'R', 'mAP', 'F1', 'val GIoU', 'val Objectness', 'val Classification'
    t0 = time.time()
    print('Starting %s for %g epochs...' % ('prebias' if opt.prebias else 'training', epochs))
    for epoch in range(start_epoch, epochs):  # epoch ------------------------------------------------------------------
        model.train()
        print(('\n' + '%10s' * 12) % (
        'Epoch', 'gpu_mem', 'GIoU', 'obj', 'cls', 'total', 'img_DA', 'ms13_DA', 'ms26_DA', 'ms52_DA', 'targets',
        'img_size'))

        # Freeze backbone at epoch 0, unfreeze at epoch 1 (optional)
        # freeze_backbone = False
        # if freeze_backbone and epoch < 10:
        #     for name, p in model.module.named_parameters():
        #         # for name, p in model.named_parameters():
        #         if int(name.split('.')[1]) < cutoff:  # if layer < 75
        #             p.requires_grad = False if epoch == 0 else True

        # Update image weights (optional)
        # if dataset.image_weights:
        #     w = model.class_weights.cpu().numpy() * (1 - maps) ** 2  # class weights
        #     image_weights = labels_to_image_weights(dataset.labels, nc=nc, class_weights=w)
        #     dataset.indices = random.choices(range(dataset.n), weights=image_weights, k=dataset.n)  # rand weighted idx

        # training (source first)
        if not is_target_only:
            nb = len(dataloader)
            # model.class_weights = labels_to_class_weights(dataset.labels, nc).to(device)  # attach class weights

            mloss = torch.zeros(8).to(device)  # mean losses
            pbar = tqdm(enumerate(dataloader), total=nb)  # progress bar
            ######################### SOURCE DOMAIN ##########################################
            for i, (imgs, targets, paths, _) in pbar:  # batch -------------------------------------------------------------
                ni = i + nb * epoch  # number integrated batches (since train start)

                imgs = imgs.to(device)
                tgt_mask = [True] * targets.shape[0]
                for ti, target in enumerate(targets):
                    if int(target[1]) in cocoid2vocid.keys():
                        target[1] = cocoid2vocid[int(target[1])]
                    else:
                        tgt_mask[ti] = False
                targets = targets[tgt_mask, :]
                targets = targets.to(device)

                # Run model
                domain_label = torch.ones(imgs.shape[0]).to(device)
                pred, da_pred, da_lab = model(imgs, domain_label=domain_label)
                # return order: img, scale13, 26, 52

                # Compute detection loss
                # print(imgs.shape)
                # print(targets.shape)
                # print(pred[0].shape)
                loss, loss_items = compute_loss(pred, targets, model)
                # Scale loss by nominal batch_size of 64
                loss *= batch_size / 64

                if da_switch:
                # compute DA loss
                    mask_list = build_obj_target_mask(targets, batch_size=imgs.shape[0])
                    for da_i in range(len(da_pred)):
                        base_prob1 = F.log_softmax(da_pred[da_i], dim=1)
                        total_da_loss = None
                        if da_i > 0:  # instance DA
                            # custom function to filter out non-object loss
                            # DA_img_loss_cls1 = F.nll_loss(base_prob1, da_lab[da_i], reduce=False, reduction='None')  # bs, scale, scale
                            # total_da_loss = torch.sum(DA_img_loss_cls1*(mask_list[da_i - 1].to(device))) / torch.sum(mask_list[da_i - 1]).to(device)
                            # MASK loss for each example. Only retain the object grid
                            total_da_loss = F.nll_loss(base_prob1, mask_list[da_i-1].long().to(device), ignore_index=0, reduction='mean')
                        else:  # image level DA
                            total_da_loss = F.nll_loss(base_prob1, da_lab[da_i], reduction='mean')
                            # total_da_loss2 = F.nll_loss(base_prob1, da_lab[da_i], reduce=False)
                            # tp = torch.sum(total_da_loss2)    # equal

                        loss += total_da_loss
                        loss_items = torch.cat((loss_items, total_da_loss.reshape(1))).detach()
                else:
                    for da_i in range(len(da_pred)):
                        base_prob1 = F.log_softmax(da_pred[da_i], dim=1)
                        total_da_loss = F.nll_loss(base_prob1, da_lab[da_i])
                        loss += total_da_loss*0
                        loss_items = torch.cat((loss_items, total_da_loss.reshape(1)*0)).detach()

                if not torch.isfinite(loss):
                    print('WARNING: non-finite loss, ending training ', loss_items)
                    return results

                # Compute gradient
                if mixed_precision:
                    with amp.scale_loss(loss, optimizer) as scaled_loss:
                        scaled_loss.backward()
                else:
                    loss.backward()

                # Accumulate gradient for x batches before optimizing
                if ni % accumulate == 0:
                    optimizer.step()
                    optimizer.zero_grad()

                # Print batch results
                mloss = (mloss * i + loss_items) / (i + 1)  # update mean losses
                mem = torch.cuda.memory_cached() / 1E9 if torch.cuda.is_available() else 0  # (GB)
                s = ('%10s' * 2 + '%10.3g' * 10) % (
                    '%g/%g' % (epoch, epochs - 1), '%.3gG' % mem, *mloss, len(targets), img_size)
                pbar.set_description(s)

        ######################### TARGET DOMAIN ##########################################
        print('start target data.')

        nbt = len(tgt_dataloader)
        mloss = torch.zeros(8).to(device)  # mean losses
        pbar = tqdm(enumerate(tgt_dataloader), total=nbt)  # progress bar

        for i, (imgs, targets, paths, _) in pbar:  # batch -------------------------------------------------------------
            ni = i + nbt * epoch  # number integrated batches (since train start)

            imgs = imgs.to(device)
            # send to device
            targets = targets.to(device)

            # Run model
            domain_label = torch.zeros(imgs.shape[0]).to(device)
            pred, da_pred, da_lab = model(imgs, domain_label=domain_label)
            # return order: img, scale13, 26, 52

            # Compute detection loss
            loss, loss_items = compute_loss(pred, targets, model)
            # Scale loss by nominal batch_size of 64
            if is_target_training:
                loss *= batch_size / 64
            else:
                loss *= 0

            if da_switch:
                # compute DA loss
                mask_list = build_obj_target_mask(targets, batch_size=imgs.shape[0])
                for da_i in range(len(da_pred)):
                    base_prob1 = F.log_softmax(da_pred[da_i], dim=1)
                    total_da_loss = None
                    if da_i > 0:  # instance DA
                        # MASK loss for each example. Only retain the object grid
                        total_da_loss = F.nll_loss(base_prob1, (1-mask_list[da_i - 1]).long().to(device), ignore_index=1,
                                                   reduction='mean')
                        # print(total_da_loss)
                    else:  # image level DA
                        total_da_loss = F.nll_loss(base_prob1, da_lab[da_i], reduction='mean')
                    loss += total_da_loss
                    loss_items = torch.cat((loss_items, total_da_loss.reshape(1))).detach()
            else:
                for da_i in range(len(da_pred)):
                    base_prob1 = F.log_softmax(da_pred[da_i], dim=1)
                    total_da_loss = F.nll_loss(base_prob1, da_lab[da_i])
                    loss += total_da_loss*0
                    loss_items = torch.cat((loss_items, total_da_loss.reshape(1))).detach()

            if not torch.isfinite(loss):
                print('WARNING: non-finite loss, ending training ', loss_items)
                return results

            # Compute gradient
            if mixed_precision:
                with amp.scale_loss(loss, optimizer) as scaled_loss:
                    scaled_loss.backward()
            else:
                loss.backward()

            # Accumulate gradient for x batches before optimizing
            if ni % accumulate == 0:
                optimizer.step()
                optimizer.zero_grad()

            # Print batch results
            mloss = (mloss * i + loss_items) / (i + 1)  # update mean losses
            mem = torch.cuda.memory_cached() / 1E9 if torch.cuda.is_available() else 0  # (GB)
            s = ('%10s' * 2 + '%10.3g' * 10) % (
                '%g/%g' % (epoch, epochs - 1), '%.3gG' % mem, *mloss, len(targets), img_size)
            pbar.set_description(s)
            # end batch ------------------------------------------------------------------------------------------------

        # Update scheduler
        scheduler.step()

        # Process epoch results
        final_epoch = epoch + 1 == epochs
        if opt.prebias:
            print_model_biases(model)
        else:
            # Calculate mAP (always test final epoch, skip first 10 if opt.nosave)
            if not (opt.notest or (opt.nosave and epoch < 10)) or final_epoch:
                with torch.no_grad():
                    results, maps = test.test(cfg,
                                              data,
                                              batch_size=batch_size,
                                              img_size=opt.img_size,
                                              model=model,
                                              conf_thres=0.001 if final_epoch and epoch > 0 else 0.1,  # 0.1 for speed
                                              save_json=False,
                                              data_root=tgt_img_dir)

        # Write epoch results
        with open(SAVED_FILE_NAME, 'a') as file:
            file.write(s + '%10.3g' * 7 % results + '\n')  # P, R, mAP, F1, test_losses=(GIoU, obj, cls)

        # Write Tensorboard results
        if tb_writer:
            x = list(mloss) + list(results)
            titles = ['GIoU', 'Objectness', 'Classification', 'Train loss',
                      'Precision', 'Recall', 'mAP', 'F1', 'val GIoU', 'val Objectness', 'val Classification']
            for xi, title in zip(x, titles):
                tb_writer.add_scalar(title, xi, epoch)

        # Update best mAP
        fitness = results[2]  # mAP
        if fitness > best_fitness:
            best_fitness = fitness

        # Save training results
        save = (not opt.nosave) or ((not opt.evolve) and final_epoch)
        if save:
            with open(SAVED_FILE_NAME, 'r') as file:
                # Create checkpoint
                chkpt = {'epoch': epoch,
                         'best_fitness': best_fitness,
                         'training_results': file.read(),
                         'model': model.module.state_dict() if type(
                             model) is nn.parallel.DistributedDataParallel else model.state_dict(),
                         'optimizer': None if final_epoch else optimizer.state_dict()}

            # Save last checkpoint
            torch.save(chkpt, last)
            if opt.bucket:
                os.system('gsutil cp %s gs://%s' % (last, opt.bucket))  # upload to bucket

            # Save best checkpoint
            if best_fitness == fitness:
                torch.save(chkpt, best)

            # Save backup every 10 epochs (optional)
            # if epoch > 0 and epoch % 10 == 0:
            #     torch.save(chkpt, wdir + 'backup%g.pt' % epoch)

            # Delete checkpoint
            del chkpt

        # end epoch ----------------------------------------------------------------------------------------------------

    # Report time
    # plot_results()  # save as results.png
    print('%g epochs completed in %.3f hours.\n' % (epoch - start_epoch + 1, (time.time() - t0) / 3600))
    dist.destroy_process_group() if torch.cuda.device_count() > 1 else None
    torch.cuda.empty_cache()
    return results


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs', type=int, default=50)  # 500200 batches at bs 16, 117263 images = 273 epochs
    parser.add_argument('--batch-size', type=int, default=16)  # effective bs = batch_size * accumulate = 16 * 4 = 64
    parser.add_argument('--accumulate', type=int, default=4, help='batches to accumulate before optimizing')
    parser.add_argument('--cfg', type=str, default='cfg/yolov3-spp-coco.cfg', help='cfg file path')
    parser.add_argument('--data', type=str, default='data/coco.data', help='*.data file path')
    parser.add_argument('--multi-scale', action='store_true', help='adjust (67% - 150%) img_size every 10 batches')
    parser.add_argument('--img-size', type=int, default=416, help='inference size (pixels)')
    parser.add_argument('--rect', action='store_true', help='rectangular training')
    parser.add_argument('--resume', action='store_true', help='resume training from last.pt')
    parser.add_argument('--transfer', action='store_true', help='transfer learning')
    parser.add_argument('--nosave', action='store_true', help='only save final checkpoint')
    parser.add_argument('--notest', action='store_true', help='only test final epoch')
    parser.add_argument('--evolve', action='store_true', help='evolve hyperparameters')
    parser.add_argument('--bucket', type=str, default='', help='gsutil bucket')
    parser.add_argument('--img-weights', action='store_true', help='select training images by weight')
    parser.add_argument('--cache-images', action='store_true', help='cache images for faster training')
    parser.add_argument('--weights', type=str, default='/home/tangyingpeng/todal/darknet/darknet53.conv.74',
                        help='initial weights')  # i.e. weights/darknet.53.conv.74
    parser.add_argument('--arc', type=str, default='defaultpw', help='yolo architecture')  # defaultpw, uCE, uBCE
    parser.add_argument('--prebias', action='store_true', help='transfer-learn yolo biases prior to training')
    parser.add_argument('--var', type=float, help='debug variable')
    parser.add_argument('--output-results', type=str, default='results/results_da.txt', help='The path for saving output results.')
    parser.add_argument('--source-img-dir', type=str, default='/data/cityscape/coco/images',
                        help="The path of images. The label path should be obtained by replacing 'images' with 'labels' in the path")
    parser.add_argument('--target-img-dir', type=str, default='/data/cityscape/coco/images',
                        help="The path of images. The label path should be obtained by replacing 'images' with 'labels' in the path")
    parser.add_argument('--da', action='store_true', help='Whether activate domain adaptation.')
    parser.add_argument('--target-only', action='store_true', help='Whether to train the model with target data only.')
    parser.add_argument('--no-target-training', action='store_true', help='Whether to train the model with target data only.')
    parser.add_argument('--src-to-tgt-label_map', type=str, default='data/cocoid2vocid.pkl', help='dict that map target label index to source label index.')

    opt = parser.parse_args()
    opt.weights = 'weights/last.pt' if opt.resume else opt.weights
    print(opt)
    device = torch_utils.select_device(apex=mixed_precision)

    tb_writer = None
    if not opt.evolve:  # Train normally
        try:
            # Start Tensorboard with "tensorboard --logdir=runs", view at http://localhost:6006/
            from torch.utils.tensorboard import SummaryWriter

            tb_writer = SummaryWriter()
        except:
            pass

        if opt.prebias:
            train()  # transfer-learn yolo biases for 1 epoch
            create_backbone('weights/last.pt')  # saved results as backbone.pt
            opt.weights = 'weights/backbone.pt'  # assign backbone
            opt.prebias = False  # disable prebias

        train()  # train normally

    else:  # Evolve hyperparameters (optional)
        opt.notest = True  # only test final epoch
        opt.nosave = True  # only save final checkpoint
        if opt.bucket:
            os.system('gsutil cp gs://%s/evolve.txt .' % opt.bucket)  # download evolve.txt if exists

        for _ in range(100):  # generations to evolve
            if os.path.exists('evolve.txt'):  # if evolve.txt exists: select best hyps and mutate
                # Get best hyperparameters
                x = np.loadtxt('evolve.txt', ndmin=2)
                x = x[fitness(x).argmax()]  # select best fitness hyps
                for i, k in enumerate(hyp.keys()):
                    hyp[k] = x[i + 7]

                # Mutate
                init_seeds(seed=int(time.time()))
                s = [.15, .15, .15, .15, .15, .15, .15, .00, .02, .20, .20, .20, .20, .20, .20, .20]  # sigmas
                for i, k in enumerate(hyp.keys()):
                    x = (np.random.randn(1) * s[i] + 1) ** 2.0  # plt.hist(x.ravel(), 300)
                    hyp[k] *= float(x)  # vary by sigmas

            # Clip to limits
            keys = ['lr0', 'iou_t', 'momentum', 'weight_decay', 'hsv_s', 'hsv_v', 'translate', 'scale']
            limits = [(1e-4, 1e-2), (0.00, 0.70), (0.60, 0.98), (0, 0.001), (0, .9), (0, .9), (0, .9), (0, .9)]
            for k, v in zip(keys, limits):
                hyp[k] = np.clip(hyp[k], v[0], v[1])

            # Train mutation
            results = train()

            # Write mutation results
            print_mutation(hyp, results, opt.bucket)

            # Plot results
            # plot_evolution_results(hyp)
