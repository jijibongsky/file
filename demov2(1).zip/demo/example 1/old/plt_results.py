from utils.utils import plot_results, plot_specific_results

# plot_results()
plot_specific_results('saved_ini_ponit_woaug.txt')
