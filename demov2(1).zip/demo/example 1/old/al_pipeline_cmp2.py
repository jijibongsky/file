from al.train_test_func import *
from al.al_data_loader import QueryRepo
from al.al_utils import al_mainloop, al_scoring, our_al_mainloop
import alipy

VOC_COCO = {
    'pkl': '/data/saved_model/init_da_yolo_coco.pkl',
    'coco_dir': '/data/coco/images/train2014/',
    'voc_dir': '/data/voc/voc_pure_data/images/',
    'data': 'data/voc_coco.data',
    'label_map': 'data/cocoid2vocid.pkl',
    'cfg': 'cfg/yolov3-spp-voc.cfg',
}

TOTAL_SCORE_THRES = 0.1
INCONS_SCORE_THRES = 0.1
TRANS_SCORE_THRES = 0.1
batch_size = 32
accumulate = 2
epochs = 20
img_size = 416
augmentation = True    # for testing
cache_images = True
pretrain_weights = '/home/tangyingpeng/todal/darknet/darknet53.conv.74'

with open(VOC_COCO['label_map'], 'rb') as f:
    cocoid2vocid = pickle.load(f)

# load data
_, s_gt_ds, s_gt_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='source_train', img_size=416,
                                        batch_size=batch_size,
                                        rect=False, img_weights=False, cache_images=False, shuffle=False,
                                        augment=False, data_root=VOC_COCO['coco_dir'])
nc, t_gt_ds, t_gt_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='target_train', img_size=416,
                                         batch_size=batch_size,
                                         rect=False, img_weights=False, cache_images=cache_images, shuffle=False,
                                         augment=augmentation, data_root=VOC_COCO['voc_dir'])
_, test_ds, test_dl = get_gt_dataloader(data=VOC_COCO['data'], data_item='valid', img_size=416, batch_size=batch_size,
                                        rect=False, img_weights=False, cache_images=cache_images, shuffle=False,
                                        augment=False, data_root=VOC_COCO['voc_dir'])

# load init lab_unlab
with open('data/coco_init_lab.txt', 'r') as f:
    init_lab = f.read().splitlines(keepends=False)
with open('data/coco_init_unlab.txt', 'r') as f:
    init_unlab = f.read().splitlines(keepends=False)

# start pipeline
unlab_len = len(init_unlab)

# init query repo
# model, optimizer, res = load_voc_model(pt_path='/data/saved_model/saved_ckpt_20.pt',
#                                        cfg='cfg/yolov3-spp-voc.cfg',
#                                        parallel=False)
# # with torch.no_grad():
#     results, maps = test(model,
#              dataloader=test_dl,
#              nc=nc,
#              batch_size=batch_size,
#              img_size=img_size,
#              iou_thres=0.5,
#              conf_thres=0.1,
#              nms_thres=0.5,
#              data_root=VOC_COCO['voc_dir'])   # results[2] map

queried_repo = QueryRepo(partial_label=False)

name_arr = ['least_conf', 'random', 'mean_conf', 'LS', 'img_trans', 'ADDA', 'our_trans', 'our_incons', 'our']
ini_point = 0.45  # 20 epoch, using voc 07+12 train val, without data augmentation
# init lab unlab score
for name in name_arr:
    exec(name + '_l_set' + ' = alipy.index.IndexCollection(init_lab)')
    exec(name + '_ul_set' + '= alipy.index.IndexCollection(init_unlab)')
    exec(name + '_lc' + ' = [[0, ini_point]]')
    exec(f"{name}_qr = QueryRepo(partial_label=False)")

# 26 per instance, 80,000+ images, 608695 instances. 7.5 instances per img in average
budget_rate = np.array([0.05] * 5 + [0.1] * 3 + [0.15] * 2)
budget_arr = 26 * 349525 * budget_rate

# # testing our method
# # load last round model
# i=0
# name='our'
# model, optimizer, res = load_voc_model(pt_path=f'/data/saved_model/{name}_{i-1}_best.pt',
#                                        cfg='cfg/yolov3-spp-voc.cfg',
#                                        parallel=True)
# model.eval()
#
# scores_f, scores2_inc, scores3_trans = al_scoring(unlab_arr=our_ul_set, model=model, s_gt_ds=s_gt_ds, method_name=name, cocoid2vocid=cocoid2vocid, queried_repo=queried_repo)
# exec("queried_repo, total_cost = our_al_mainloop(scoring_arr=scores, src_gt_ds=s_gt_ds, "
#      "budget=budget_arr[i], queried_repo=queried_repo, method_name='" +
#      name + "',iteration="+str(i)+", src2tgt_label_map=cocoid2vocid"+")")

first_flag=True
# query 10 batches
name_arr = ['img_trans', 'ADDA', 'LS']
for i in range(10):
    for name in name_arr:
        print(name)
        # load last round model
        if first_flag:
            model, optimizer, res = load_voc_model(pt_path=f'/data/saved_model/{name}_{i}_best.pt',
                                                   cfg='cfg/yolov3-spp-voc.cfg',
                                                   parallel=True, parallel_port=666, init_group=True)
            first_flag=False
        else:
            model, optimizer, res = load_voc_model(pt_path=f'/data/saved_model/{name}_{i}_best.pt',
                                                   cfg='cfg/yolov3-spp-voc.cfg',
                                                   parallel=True, init_group=False)

        # load (repo)
        if res == 1:  # model loaded
            # try:
            with open(f"/data/saved_al/{name}_{i}_all.pkl", 'rb') as f:
                exec(f"{name}_qr = pickle.load(f)")
            exec(f"assert len({name}_qr)>0")
            # update unlab and lab arr
            exec(f"{name}_l_set.update({name}_qr.keys())")
            exec(f"{name}_ul_set.difference_update({name}_qr.keys())")

            print(f"methods {name} in iteration {0} has already done. skip.")
            continue
            # except FileNotFoundError:
            #     print(f"methods {name} in iteration {0}: model has been found, but not query repository. Start querying with last round model.")
            #     model, optimizer, res = load_voc_model(pt_path=f'/data/saved_model/{name}_{i-1}_best.pt',
            #                                            cfg='cfg/yolov3-spp-voc.cfg',
            #                                            parallel=True, parallel_port=666, init_group=True)
            #     exec(f"queried_repo={name}_qr")
            #     with torch.no_grad():
            #         exec(
            #             "scores = al_scoring(unlab_arr=" + name + '_ul_set' + ", model=model, s_gt_ds=s_gt_ds, method_name='" + name + "', cocoid2vocid=cocoid2vocid, queried_repo=queried_repo)")
            #     exec("queried_repo, total_cost = al_mainloop(scoring_arr=scores, src_gt_ds=s_gt_ds, "
            #          "lab_arr=" + name + '_l_set' + ", unlab_arr=" + name + "_ul_set" +
            #          ", budget=budget_arr[i], queried_repo=queried_repo, method_name='" +
            #          name + "',iteration=" + str(i) + ", src2tgt_label_map=cocoid2vocid" + ")")
            #     exec(f"{name}_qr=queried_repo")
            #     continue
        else:
            # load last round model
            model, optimizer, res = load_voc_model(pt_path=f'/data/saved_model/{name}_{i - 1}_best.pt',
                                                   cfg='cfg/yolov3-spp-voc.cfg',
                                                   parallel=True, init_group=False)
            if res == 1:
                print(f"{name} model in last iteration {i-1} has been returned.")
            else:
                print(f"{name} model in last iteration {i-1} has not been found, return initial model.")

        model.eval()
        exec(f"queried_repo={name}_qr")
        with torch.no_grad():
            exec("scores = al_scoring(unlab_arr=" + name + '_ul_set' + ", model=model, s_gt_ds=s_gt_ds, method_name='" + name + "', cocoid2vocid=cocoid2vocid, queried_repo=queried_repo)")
        exec("queried_repo, total_cost = al_mainloop(scoring_arr=scores, src_gt_ds=s_gt_ds, "
             "lab_arr=" + name + '_l_set' + ", unlab_arr=" + name + "_ul_set" +
             ", budget=budget_arr[i], queried_repo=queried_repo, method_name='" +
             name + "',iteration="+str(i)+", src2tgt_label_map=cocoid2vocid"+")")
        exec(f"{name}_qr=queried_repo")
        # train/test model
        # calc initial performance point
        updated_lab_ds = LoadImagesAndLabelsByImgFiles(
            img_files=queried_repo.keys()+init_lab,
            img_size=img_size,
            batch_size=batch_size,
            augment=True,
            hyp=hyp,  # augmentation hyperparameters
            rect=False,  # rectangular training
            image_weights=False,
            cache_images=True
        )
        # Dataloader
        ini_dataloader = torch.utils.data.DataLoader(updated_lab_ds,
                                                     batch_size=batch_size,
                                                     num_workers=0,
                                                     shuffle=False,  # Shuffle=True unless rectangular training is used
                                                     pin_memory=True,
                                                     collate_fn=updated_lab_ds.collate_fn)

        model, best_ap = train_mix(model=model, optimizer=optimizer, dataloader=ini_dataloader, tgt_dataloader=t_gt_dl,
                                   start_epoch=0, epochs=50, nc=nc, batch_size=batch_size, da_switch=True,
                                   src2tgt_label_map=cocoid2vocid, save_epoch=tuple(), notest=False, test_dl=test_dl,
                                   ins_gain=5, best_save_name=f'/data/saved_model/{name}_{i}_best.pt',
                                   save_prefix='saved_ckpt_al_', saved_map_dir=f'/data/saved_model/{name}_{i}_saved_map.txt')

        exec(name + '_lc' + '.append([total_cost, best_ap])')
        exec(f"print({name}_lc)")
        # same lc
        exec(f"np.savetxt('/data/saved_al/{name}_{i}_lc.txt', {name}_lc)")

        print(name, total_cost, best_ap)

for name in name_arr:
    exec(f"print({name}_lc)")
