import os
# mix train
os.system("/home/tangyingpeng/anaconda3/bin/python3.7 -u /home/tangyingpeng/yolov3/train_da_mix.py --cache-images --da --no-target-training --output-results results/results_mix_wo_tgt_training.txt")
os.system("/home/tangyingpeng/anaconda3/bin/python3.7 -u /home/tangyingpeng/yolov3/train_da_mix.py --cache-images --da --output-results results/results_mix_da.txt")

os.system("/home/tangyingpeng/anaconda3/bin/python3.7 -u /home/tangyingpeng/yolov3/train_da.py --cache-images --target-only --output-results results/results_only_target.txt")
os.system("/home/tangyingpeng/anaconda3/bin/python3.7 -u /home/tangyingpeng/yolov3/train_da.py --cache-images --da --output-results results/results_da.txt")
os.system("/home/tangyingpeng/anaconda3/bin/python3.7 -u /home/tangyingpeng/yolov3/train_da.py --cache-images --output-results results/results_woda.txt")
os.system("/home/tangyingpeng/anaconda3/bin/python3.7 -u /home/tangyingpeng/yolov3/train_da.py --cache-images --da --no-target-training --output-results results/results_wo_tgt_training.txt")
