python3 Train_cifar.py --noise_mode asym --r 0.4 --dataset cifar100
