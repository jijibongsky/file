# 参考文献
ICLR'21: DIVIDEMIX: LEARNING WITH NOISY LABELS AS SEMI-SUPERVISED LEARNING

# 数据集
运行代码能自动下载指定的数据集(cifar10, cifar100等)

# 运行环境
安装pytorch即可

# 开始训练

假设指定噪声类型noise_mode为asym(非对称), 噪声比例r为0.4，数据集为cifar100

```
run python3 Train_cifar.py --noise_mode asym --r 0.4 --dataset cifar100 
```

具体流程请进一步参考脚本内的注释


# 方法框架
![Image](./img/framework.png)
大致方法就是训练两个模型A和B，得到两个模型对每个样本的损失，并使用GMM模型基于预测的损失将数据集D划分X和U两部分，X代表损失低的那部分样本（也就是置信度高的，相信其label是正确的），U代表损失低的那部分样本（也就是置信度低的，这部分样本的abel很可能是错误的，因此把其label丢掉）。接着，使用半监督的学习方式对X和U进行训练更新模型A和B。整个过程反复迭代即可。

# 算法流程
![Image](./img/algorithm.png)

- 输入：两个模型1和2，训练数据以及一些其它参数
- 第2行：对两个模型进行warmup，让其产生初步的分类能力
- 第4~8行：对训练集分别根据两个模型1和2进行GMM划分，得到X和U
- 第10~11行：分别从X和U中采样B个样本进行训练
- 第12~22行：对于采样中的每个样本都进行M次数据增强（扰动），对于x部分的样本，求得其M次扰动后的平均预测值与其给的真实label的滑动平均作为新的label赋予给x部分样本；对于u部分的样本，使用co-guessing的方式对赋予其新的label，即使用两个模型对M此扰动后的样本的平均预测值作为新的label。二者的label均使用sharpen进行锐化。
- 第23~26行：构成新的数据集后，根据MixMatch写出最终的损失L
- 第27行：根据SGD更新模型

