本例子展示了如何在公开数据集上跑主动学习算法。代码基于开源主动学习工具包ALiPy实现。

`query_instance.py`文件中展示了主动学习过程调用的基本流程。主要包括数据集划分，计算模型初始性能，进入主动学习循环（查询->更新模型->保存中间结果），画出实验结果图等。具体每段代码行为请参考脚本内注释。

脚本内共运行了Uncertainty，QBC，ExpectedErrorReduction，DensityWeighted，Random，Coreset，QUIRE，LAL，GraphDensity九种不同的查询策略。可根据需要注释掉部分查询策略，以缩短脚本运行时间。

# 运行环境安装

```
pip install alipy
```

# 代码执行

```
python query_instance.py
```

*注意`fetch_dataset`函数可能需要在翻墙环境下才能快速把数据下载下来，国内环境容易中断且下载缓慢*
