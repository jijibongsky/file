import json
import numpy as np
from time import time
import sys
import os
root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(root_dir)

total_sens = set()

def load_data(file_in):
    rfile = open(file_in,"r",encoding="utf8")
    k = 0
    for line in rfile:
        k += 1
        if k == 1:
            continue
        line = line.strip()
        new_line = line.split("\t")
        if len(new_line) != 3:
            print(line)
        else:
            if new_line[0] not in total_sens:
                total_sens.add(new_line[0])
            if new_line[1] not in total_sens:
                total_sens.add(new_line[1])
    rfile.close()

    print("k===", k)
    print("len(total_sens)=====", len(total_sens))


if __name__ == "__main__":
    begin = time()
    file_in = "/home/sun/deep_learning/text_matching/data/lcqmc/train.tsv"
    load_data(file_in)
    print("花费时间：", time()-begin)



