# coding=utf-8
# Copyright 2018 The Google AI Language Team Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Extract pre-computed feature vectors from BERT."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import re
import tensorflow as tf
import collections
import sys
import os
root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(root_dir)
import tokenization


flags = tf.flags
FLAGS = flags.FLAGS

flags.DEFINE_string("input_file", "/home/sun/deep_learning/bert/data/input.txt" , "")
flags.DEFINE_string("output_file", "/home/sun/deep_learning/bert/data/tf_examples_ceshi.tfrecord", "")
flags.DEFINE_string("vocab_file", "/home/data/bert/model/chinese_L-12_H-768_A-12/vocab.txt", "The vocabulary file that the BERT model was trained on.")

flags.DEFINE_integer("max_seq_length", 128, "The maximum total input sequence length after WordPiece tokenization. Sequences longer than this will be truncated, and sequences shorter than this will be padded.")
flags.DEFINE_bool("do_lower_case", True, "Whether to lower case the input text. Should be True for uncased models and False for cased models.")
flags.DEFINE_integer("batch_size", 4, "Batch size for predictions.")


class InputExample(object):
  def __init__(self, unique_id, text_a, text_b):
    self.unique_id = unique_id
    self.text_a = text_a
    self.text_b = text_b


class InputFeatures(object):
  def __init__(self, unique_id, tokens, input_ids, input_mask, input_type_ids):
    self.unique_id = unique_id
    self.tokens = tokens
    self.input_ids = input_ids
    self.input_mask = input_mask
    self.input_type_ids = input_type_ids


def create_int_feature(values):
  feature = tf.train.Feature(int64_list=tf.train.Int64List(value=list(values)))
  return feature


def create_float_feature(values):
  feature = tf.train.Feature(float_list=tf.train.FloatList(value=list(values)))
  return feature


def convert_examples_to_features(examples, seq_length, tokenizer):
  def _truncate_seq_pair(tokens_a, tokens_b, max_length):
      while True:
          total_length = len(tokens_a) + len(tokens_b)
          if total_length <= max_length:
              break
          if len(tokens_a) > len(tokens_b):
              tokens_a.pop()
          else:
              tokens_b.pop()

  features = []
  for (ex_index, example) in enumerate(examples):
    tokens_a = tokenizer.tokenize(example.text_a)
    tokens_b = None
    if example.text_b:
      tokens_b = tokenizer.tokenize(example.text_b)

    if tokens_b:
      _truncate_seq_pair(tokens_a, tokens_b, seq_length - 3)
    else:
      # Account for [CLS] and [SEP] with "- 2"
      if len(tokens_a) > seq_length - 2:
        tokens_a = tokens_a[0:(seq_length - 2)]

    tokens = []
    input_type_ids = []
    tokens.append("[CLS]")
    input_type_ids.append(0)
    for token in tokens_a:
      tokens.append(token)
      input_type_ids.append(0)
    tokens.append("[SEP]")
    input_type_ids.append(0)

    if tokens_b:
      for token in tokens_b:
        tokens.append(token)
        input_type_ids.append(1)
      tokens.append("[SEP]")
      input_type_ids.append(1)

    input_ids = tokenizer.convert_tokens_to_ids(tokens)

    input_mask = [1] * len(input_ids)

    # Zero-pad up to the sequence length.
    while len(input_ids) < seq_length:
      input_ids.append(0)
      input_mask.append(0)
      input_type_ids.append(0)

    assert len(input_ids) == seq_length
    assert len(input_mask) == seq_length
    assert len(input_type_ids) == seq_length

    if ex_index < 2:
      tf.logging.info("*** Example ***")
      tf.logging.info("unique_id: %s" % (example.unique_id))
      tf.logging.info("tokens: %s" % " ".join(
          [tokenization.printable_text(x) for x in tokens]))
      tf.logging.info("input_ids: %s" % " ".join([str(x) for x in input_ids]))
      tf.logging.info("input_mask: %s" % " ".join([str(x) for x in input_mask]))
      tf.logging.info(
          "input_type_ids: %s" % " ".join([str(x) for x in input_type_ids]))

    features.append(
        InputFeatures(
            unique_id=example.unique_id,
            tokens=tokens,
            input_ids=input_ids,
            input_mask=input_mask,
            input_type_ids=input_type_ids))
  return features


def read_examples(input_file):
  examples = []
  unique_id = 0
  with tf.gfile.GFile(input_file, "r") as reader:
    while True:
      line = tokenization.convert_to_unicode(reader.readline())
      if not line:
        break
      line = line.strip()
      text_a = None
      text_b = None
      m = re.match(r"^(.*) \|\|\| (.*)$", line)
      if m is None:
        text_a = line
      else:
        text_a = m.group(1)
        text_b = m.group(2)
      examples.append(
          InputExample(unique_id=unique_id, text_a=text_a, text_b=text_b))
      unique_id += 1
  return examples


def write2file(features_object, output_file):
  writer = tf.python_io.TFRecordWriter(output_file)
  for (inst_index, instance) in enumerate(features_object):
      features = collections.OrderedDict()
      # features["tokens"] = create_int_feature(instance.tokens)
      features["input_ids"] = create_int_feature(instance.input_ids)
      features["input_mask"] = create_int_feature(instance.input_mask)
      features["input_type_ids"] = create_int_feature(instance.input_type_ids)
      tf_example = tf.train.Example(features=tf.train.Features(feature=features))
      writer.write(tf_example.SerializeToString())
  writer.close()


def save():
  tf.logging.set_verbosity(tf.logging.INFO)
  tokenizer = tokenization.FullTokenizer(vocab_file=FLAGS.vocab_file, do_lower_case=FLAGS.do_lower_case)
  examples = read_examples(FLAGS.input_file)
  features_object = convert_examples_to_features(examples=examples, seq_length=FLAGS.max_seq_length, tokenizer=tokenizer)
  print("examples===", examples[0].text_a)
  print("features===", features_object[0].tokens)
  print("features===", features_object[0].input_ids)
  write2file(features_object, FLAGS.output_file)


def load_data1(batch_size, input_file, seq_length, is_training, drop_remainder):
  def _decode_record(record, name_to_features):
      """Decodes a record to a TensorFlow example."""
      example = tf.parse_single_example(record, name_to_features)
      for name in list(example.keys()):
          t = example[name]
          if t.dtype == tf.int64:
              t = tf.to_int32(t)
          example[name] = t
      return example

  name_to_features = {
      "input_ids": tf.FixedLenFeature([seq_length], tf.int64),
      "input_mask": tf.FixedLenFeature([seq_length], tf.int64),
      "segment_ids": tf.FixedLenFeature([seq_length], tf.int64)
  }

  # For training, we want a lot of parallel reading and shuffling.
  # For eval, we want no shuffling and parallel reading doesn't matter.
  d = tf.data.TFRecordDataset(input_file)
  if is_training:
      d = d.repeat()
      d = d.shuffle(buffer_size=20)

  d = d.apply(
      tf.contrib.data.map_and_batch(
          lambda record: _decode_record(record, name_to_features),
          batch_size=batch_size,
          drop_remainder=drop_remainder))
  return d




def ceshi_load_data1():
    datas = load_data1(FLAGS.batch_size, FLAGS.output_file, FLAGS.max_seq_length, is_training=None, drop_remainder=True)  # True
    print("datas=====", datas)

    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())

        # iterator = datas.make_one_shot_iterator().get_next()
        # print(type(iterator["input_ids"]))
        # print("iterator===", iterator["input_ids"])
        # print("iterator===", iterator["input_mask"])
        # print("iterator===", iterator["segment_ids"])
        # print(iterator["input_ids"].shape)

        # k = 0
        # while True:
        #     k += 1
        #     a = iterator["input_ids"]
        #     if k % 100000000 == 0:
        #         print(k)

        # while True:
        print("datas=====", datas)
        print("datas=====", datas)
        print("datas=====", type(datas))
        # input("---")

        # a=sess.run(datas["input_ids"])
        # A = sess.run(a)
        # print("===", A)


def load_data(train_f, epochs, batch_size,padded_shapes):
    def parse_exmp(serial_exmp):
        features = {'input_ids': tf.FixedLenFeature([128], tf.int64),
                    'input_mask': tf.FixedLenFeature([128], tf.int64),
                    'input_type_ids': tf.FixedLenFeature([128], tf.int64)}
        feats = tf.parse_single_example(serial_exmp, features=features)
        input_ids = tf.cast(feats['input_ids'], tf.int32)
        input_mask = tf.cast(feats['input_mask'], tf.int32)
        input_type_ids = tf.cast(feats['input_type_ids'], tf.int32)
        return input_ids, input_mask, input_type_ids

    dataset = tf.data.TFRecordDataset(train_f)
    dataset_train = dataset.map(parse_exmp)
    dataset_train.repeat(epochs).shuffle(20).padded_batch(batch_size, padded_shapes=padded_shapes)
    return dataset_train


def ceshi_load_data():
    train_f = ["/home/sun/deep_learning/bert/data/tf_examples_ceshi.tfrecord"]
    epochs = 10
    batch_size = 20
    padded_shapes = ([128], [128], [128])  # 把image pad至784，把label pad至[3,5]，shape是一个scalar，不输入数字

    dataset_train = load_data(train_f, epochs, batch_size, padded_shapes)

    a = dataset_train.make_one_shot_iterator().get_next()
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        k = 0
        flag = True
        while flag:
            try:
                k += 1
                if k % 10 == 0:
                    print(k)
                # a = dataset_train.make_one_shot_iterator().get_next()
                A = sess.run(a)
                print("===", len(A))
                print("===", len(A[0]))
                print("===", type(A[0]))
                print("===", len(A[1]))
                print("===", len(A[2]))
                # input("---")
            except:
                print(k)
                flag = False
                print(1111)


if __name__ == "__main__":
    # save()

    ceshi_load_data()

    # ceshi_load_data1()

