import sys
import os
# os.environ["CUDA_VISIBLE_DEVICES"] = "0"

root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(root_dir)

from my_extract_features import my_preprocessing_data, convert_examples_to_features
import tokenization


vocab_file = "/home/data/bert/model/chinese_L-12_H-768_A-12/vocab.txt"
tokenizer = tokenization.FullTokenizer(vocab_file=vocab_file, do_lower_case=True)

def bert_seg(input_data):
    examples = my_preprocessing_data(input_data)
    features = convert_examples_to_features(examples=examples, seq_length=128, tokenizer=tokenizer)  # 列表
    result = features[0].tokens
    result = " ".join(result)
    return result


# 字典形式保存
def load_write_one_sentence(input_file, write_file):
    rfile = open(input_file, "r", encoding="utf8")
    wfile = open(write_file, "w", encoding="utf8")
    all_sentence = {}
    k = 0
    for line in rfile:
        k += 1
        if k == 1:
            continue
        line = line.strip()
        new_line = line.split("\t")
        if len(new_line) != 3:
            print(line)
        if new_line[0] not in all_sentence:
            all_sentence[new_line[0]] = bert_seg(new_line[0])
        if new_line[1] not in all_sentence:
            all_sentence[new_line[1]] = bert_seg(new_line[1])
    for key in all_sentence:
        wfile.write(key + "\t" + all_sentence[key] + "\n")
    rfile.close()
    wfile.close()


# 字典形式保存
def load_write_sentence_pair(input_file, write_file):
    rfile = open(input_file, "r", encoding="utf8")
    wfile = open(write_file, "w", encoding="utf8")
    all_sentence_pair = {}
    k = 0
    for line in rfile:
        k += 1
        if k == 1:
            continue
        line = line.strip()
        new_line = line.split("\t")
        if len(new_line) != 3:
            print(line)
        a = new_line[0] + "\t" + new_line[1]
        if a not in all_sentence_pair:
            all_sentence_pair[a] = bert_seg(a)
    for key in all_sentence_pair:
        wfile.write(key + "\t\t" + all_sentence_pair[key] + "\n")
    rfile.close()
    wfile.close()


# 原始顺序保存
def load_write1(input_file, write_file):
    def bert_seg(input_data):
        examples = my_preprocessing_data(input_data)
        features = convert_examples_to_features(examples=examples, seq_length=128, tokenizer=tokenizer)  # 列表
        result = features[0].tokens[1:-1]
        result = " ".join(result)
        return result

    rfile = open(input_file, "r", encoding="utf8")
    wfile = open(write_file, "w", encoding="utf8")
    # wfile.write("text_a\ttext_b\tlabel\n")
    k = 0
    for line in rfile:
        k += 1
        if k == 1:
            continue
        line = line.strip()
        new_line = line.split("\t")
        if len(new_line) == 3:
            a = bert_seg(new_line[0])
            b = bert_seg(new_line[1])
            wfile.write(a + "\t" + b + "\t" + new_line[2] + "\n")
        else:
            print("---", line)
    rfile.close()
    wfile.close()


if __name__ == "__main__":
    # input_data = "怎么办理移机\t我想知道移机aaaa怎么办理"
    # input_data = "怎么办理移机"
    # result = bert_seg(input_data)
    # print(result)

    # input_file = "/home/sun/deep_learning/text_matching/data/lcqmc/train.tsv"
    # out_file = "/home/sun/deep_learning/text_matching/data/lcqmc/train_bert_seg.tsv"
    # load_write_one_sentence(input_file, out_file)

    input_file = "/home/sun/deep_learning/text_matching/data/lcqmc/train.tsv"
    out_file = "/home/sun/deep_learning/text_matching/data/lcqmc/train_bert_seg_pair.tsv"
    load_write_sentence_pair(input_file, out_file)


    # input_file = "/home/sun/deep_learning/text_matching/data/lcqmc/train.tsv"
    # out_file = "/home/sun/deep_learning/text_matching/data/lcqmc/train_bert.txt"
    # load_write1(input_file, out_file)
