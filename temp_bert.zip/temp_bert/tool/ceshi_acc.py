
def load_teacher_scores(data_dir):
    rfile = open(data_dir, "r", encoding="utf8")
    teacher_label=[]
    for line in rfile:
        a = [float(i) for i in line.strip().split("\t")]
        if a[0]>a[1]:
            teacher_label.append(0)
        else:
            teacher_label.append(1)
    return teacher_label


def load_label(data_dir):
    rfile = open(data_dir, "r", encoding="utf8")
    y = []
    k = 0
    for line in rfile:
        k += 1
        if k == 1:
            continue
        a = line.strip().split("\t")[2]
        y.append(int(a))
    return y


def compare(teacher_label, y):
    print(len(teacher_label) == len(y))
    num_equal = 0
    for i, j in zip(teacher_label, y):
        if i == j:
            num_equal += 1
    print(num_equal/len(teacher_label))


if __name__ == '__main__':
    teacher_label = load_teacher_scores("/home/sun/deep_learning/text_matching/data/teacher_scores/dsa_score200000.txt")
    y = load_label("/home/sun/deep_learning/text_matching/data/lcqmc/train.tsv")
    compare(teacher_label, y)
