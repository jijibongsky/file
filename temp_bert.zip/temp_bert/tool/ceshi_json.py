import json
import numpy as np

# test_dict = {'bigberg': [7600, {1: [['iPhone', 6300], ['Bike', 800], ['shirt', 300]]}]}
# a = np.array([1., 1, 2, 3], dtype='float32')
a = np.array([[1., 1, 2, 3], [2., 3, 4]], dtype='float64')  #
print(a.dtype)
print(type(a))

# for w in a:
#     print(type(w))
#     print("===", w.flat)


# test_dict = {'bigberg': a}
# json_str = json.dumps(test_dict)
# new_dict = json.loads(json_str)
# print("json_str====", json_str)
# print("json_str====", type(json_str))
# print("new_dict====", new_dict)
# print("new_dict====", type(new_dict))


# file = "/home/sun/deep_learning/bert/data/output.jsonl"
# rfile = open(file, "r", encoding="utf8")
# for line in rfile:
#     line = line.strip()
#     all_features = json.loads(line)["features"]
#     a = all_features[0]["layers"][0]["values"]
#     print(a)
#     print(len(a))
#     print(type(a))
#     i = 1
#     j = 0
#     print("11111=====", all_features[i].keys())  # ['token', 'layers']
#     print("22222=====", all_features[i]["token"])  # 怎
#     print("33333=====", all_features[i]["layers"][j].keys())  # ['index', 'values']
#     print("44444=====", all_features[i]["layers"][j]["index"])  # -1
#     print("55555=====", all_features[i]["layers"][j]["values"])
#     print("66666=====", len(all_features[i]["layers"][j]["values"]))
