import tensorflow as tf
import modeling
from my_run_classifier import model_fn_builder

flags = tf.flags
FLAGS = flags.FLAGS

# print(111, FLAGS)
max_seq_length = 100

def serving_input_receiver_fn():
    input_ids = tf.placeholder(tf.int32, shape=[None, max_seq_length], name="input_ids_2")
    input_mask = tf.placeholder(tf.int32, shape=[None, max_seq_length], name="input_mask_2")
    segment_ids = tf.placeholder(tf.int32, shape=[None, max_seq_length], name="segment_ids_2")
    input_diff = tf.placeholder(tf.int32, shape=[None, max_seq_length], name="input_diff_2")
    label_ids = tf.placeholder(tf.int32, shape=[None], name="label_ids_2")

    receiver_tensors = {
        "input_ids_1": input_ids,
        "input_mask_1": input_mask,
        "segment_ids_1": segment_ids,
        "input_diff_1": input_diff,
        "label_ids_1": label_ids
    }
    features_old = {
        "input_ids": input_ids,
        "input_mask": input_mask,
        "segment_ids": segment_ids,
        "input_diff": input_diff,
        "label_ids": label_ids
    }
    return tf.estimator.export.ServingInputReceiver(features_old, receiver_tensors)
    # features_old 是原模型中的数据，对应到 model_fn_builder 中的 model_fn的输入，（model_fn 是 tf.estimator.Estimator 的第一个参数）


if __name__ == '__main__':
    bert_config = modeling.BertConfig.from_json_file(FLAGS.bert_config_file)
    model_fn = model_fn_builder(
        bert_config=bert_config,
        num_labels=2,
        init_checkpoint=FLAGS.init_checkpoint,
        learning_rate=FLAGS.learning_rate,
        num_train_steps=100,
        num_warmup_steps=100,
        use_tpu=FLAGS.use_tpu,
        use_one_hot_embeddings=False
    )
    estimator = tf.estimator.Estimator(model_fn, FLAGS.output_dir, params=None)
    estimator.export_savedmodel("/home/data/deep_learning/bert/data/export/test", serving_input_receiver_fn)
