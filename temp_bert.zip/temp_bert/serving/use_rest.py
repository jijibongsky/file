import requests
import json

dict = {'query': 'haha haha', 'docs': ['ai aa', 'ai bb']}
json_info = json.dumps(dict)
print("json_info====", json_info)
r = requests.post('http://192.168.2.100:8866/similarity', json=json_info)

print("r111111", r)
data_dict = json.loads(r.text)
result = data_dict["sim_scores"]
print(result)
