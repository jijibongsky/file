
max_seq_length = 100

def _truncate_seq_pair(tokens_a, tokens_b, max_length):
  while True:
    total_length = len(tokens_a) + len(tokens_b)
    if total_length <= max_length:
      break
    if len(tokens_a) > len(tokens_b):
      tokens_a.pop()
    else:
      tokens_b.pop()


def preprocess(input_left, input_right, tokenizer):
    tokens_a = tokenizer.tokenize(input_left)
    tokens_b = None
    if input_right:
        tokens_b = tokenizer.tokenize(input_right)

    if tokens_b:
        _truncate_seq_pair(tokens_a, tokens_b, max_seq_length - 3)
    else:
        # Account for [CLS] and [SEP] with "- 2"
        if len(tokens_a) > max_seq_length - 2:
            tokens_a = tokens_a[0:(max_seq_length - 2)]

    tokens = []
    segment_ids = []
    tokens.append("[CLS]")
    segment_ids.append(0)
    for token in tokens_a:
        tokens.append(token)
        segment_ids.append(0)
    tokens.append("[SEP]")
    segment_ids.append(0)

    if tokens_b:
        for token in tokens_b:
            tokens.append(token)
            segment_ids.append(1)
        tokens.append("[SEP]")
        segment_ids.append(1)

    input_ids = tokenizer.convert_tokens_to_ids(tokens)

    # The mask has 1 for real tokens and 0 for padding tokens. Only real
    # tokens are attended to.
    input_mask = [1] * len(input_ids)

    # Zero-pad up to the sequence length.
    while len(input_ids) < max_seq_length:
        input_ids.append(0)
        input_mask.append(0)
        segment_ids.append(0)
    input_diff = [0]*max_seq_length
    return input_ids, input_mask, segment_ids, input_diff


def predict_input_fn(input_left, input_right,tokenizer):
    input_left = [input_left]*len(input_right)
    assert len(input_left) == len(input_right)
    all_input_ids,  all_input_mask, all_segment_ids, all_input_diff=[],[],[],[]
    for i in range(len(input_left)):
        input_ids, input_mask, segment_ids, input_diff = preprocess(input_left[i], input_right[i], tokenizer)
        all_input_ids.append(input_ids)
        all_input_mask.append(input_mask)
        all_segment_ids.append(segment_ids)
        all_input_diff.append(input_diff)
    return {
        "input_ids_1": all_input_ids,
        "input_mask_1": all_input_mask,
        "segment_ids_1": all_segment_ids,
        "input_diff_1": all_input_diff
    }


if __name__ == '__main__':
    print(111)
