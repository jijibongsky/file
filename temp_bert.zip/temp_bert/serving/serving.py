import json
import os
from flask import Flask
from flask import request
from pathlib import Path
from tensorflow.contrib import predictor
from preprocess import predict_input_fn

import sys
root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(root_dir)
import tokenization


def get_model():
    export_dir = "/home/data/deep_learning/bert/data/export/lcqmc"
    subdirs = [x for x in Path(export_dir).iterdir() if x.is_dir()]
    latest = str(sorted(subdirs)[-1])
    print("load {}".format(latest))
    predict_fn = predictor.from_saved_model(latest)
    return predict_fn

predict_fn = get_model()

BERT_BASE_DIR = "/home/data/deep_learning/bert/model/chinese_L-12_H-768_A-12/"
tokenizer = tokenization.FullTokenizer(vocab_file=BERT_BASE_DIR + "vocab.txt", do_lower_case=True)
print("111", predict_fn)

app = Flask(__name__)
@app.route("/similarity", methods=["GET", "POST"])
def compute_sim():
    if request.method == "POST":
        data = request.get_data()
        dict1 = json.loads(data.decode("utf-8"))
        dict1 = json.loads(dict1)
        query = dict1["query"]
        docs = dict1["docs"]
        features = predict_input_fn(query, docs, tokenizer)

        print("features====", features)
        result = predict_fn(features)
        probs = result["probabilities"]
        probs = probs.tolist()
        scores={}
        scores['sim_scores']=probs
        return json.dumps(scores)
    else:
        return "<h1>只接受post请求</h1>"


if __name__ == '__main__':
    print("fist loading vocab and tensorflow model")
    app.run(host="0.0.0.0", port=8866, debug=False)

    # query = "怎么办理移机"
    # docs = ["移机怎么办理", "如何办移机"]
    # features = predict_input_fn(query, docs)
    # print(1111, features)
    # for key in features:
    #     print(key, features[key])
    #     print()
