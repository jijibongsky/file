import os

model_path = "/home/data/deep_learning/deeplearning/xlnet_extension_tf/result/ner/CoNLL-2003/"
# model_path = "/home/data/deep_learning/deeplearning/bert-chinese-ner/output/ner/result_CoNLL-2003_old_loss/"

eval_perl = "conlleval"
label_path = model_path + "aaa.txt"
# label_path = model_path + "label_test.txt"
metric_path = model_path + "bbb.txt"
os.system("perl {} < {} > {}".format(eval_perl, label_path, metric_path))