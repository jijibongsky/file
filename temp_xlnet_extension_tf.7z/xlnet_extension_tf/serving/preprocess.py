import sys
import os

root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(root_dir)
sys.path.append(root_dir + "/xlnet")
print("root_dir===", root_dir)
from run_ner import XLNetTokenizer
from run_ner import XLNetExampleConverter
from run_ner import NerProcessor
from run_ner import InputExample
import prepro_utils

max_seq_length = 100
spiece_model_file = "/home/data/deep_learning/xlnet/models/xlnet_cased_L-12_H-768_A-12/spiece.model"
processor = NerProcessor()
label_list = processor.get_labels()
tokenizer = XLNetTokenizer(sp_model_file=spiece_model_file, lower_case=False)
example_converter = XLNetExampleConverter(
    label_list=label_list,
    max_seq_length=max_seq_length,
    tokenizer=tokenizer)


def decode_predict(input_ids_all, input_masks_all, segment_ids_all, predict_ids_all):
    total_results = []
    for input_ids, input_masks, segment_ids, predict_ids in zip(input_ids_all, input_masks_all, segment_ids_all, predict_ids_all):
        total_result = []
        input_tokens = tokenizer.ids_to_tokens(input_ids)
        output_predicts = [label_list[idx] for idx in predict_ids]
        decoded_tokens = []
        decoded_predicts = []
        results = zip(input_tokens, input_masks, output_predicts)
        for input_token, input_mask, output_predict in results:
            if input_token in ["<cls>", "<sep>"] or input_mask == 1:
                continue

            if output_predict in ["<pad>", "<cls>", "<sep>", "X"]:
                output_predict = "O"

            if input_token.startswith(prepro_utils.SPIECE_UNDERLINE):
                decoded_tokens.append(input_token)
                decoded_predicts.append(output_predict)
            else:
                decoded_tokens[-1] = decoded_tokens[-1] + input_token

        decoded_text = "".join(decoded_tokens).replace(prepro_utils.SPIECE_UNDERLINE, " ").strip()
        decoded_predict = " ".join(decoded_predicts).strip()
        for word, tag in zip(decoded_text.split(" "), decoded_predict.split(" ")):
            total_result.append(word + "/" + tag)
        total_results.append(" ".join(total_result))
    return total_results


def predict_input_fn(sentences):
    all_input_ids,  all_input_mask, all_segment_ids = [], [], []
    all_tokens = []
    for i in range(len(sentences)):
        sentence = sentences[i]
        label = ["O"] * len(sentence.split(" "))
        label = " ".join(label)
        example = InputExample(guid=None, text=sentence, label=label)
        feature = example_converter.convert_single_example(example, logging=False)
        tokens = tokenizer.tokenize(sentence)
        all_input_ids.append(feature.input_ids)
        all_input_mask.append(feature.input_masks)
        all_segment_ids.append(feature.segment_ids)
        all_tokens.append(tokens)

    return {
        "input_ids": all_input_ids,
        "input_masks": all_input_mask,
        "segment_ids": all_segment_ids,}, all_tokens


if __name__ == '__main__':
    sentences = ["Japan began the defence of their Asian Cup title with a lucky 2-1 win against Syria in a Group C championship match on Friday ."]
    features, _ = predict_input_fn(sentences)
    for key in features:
        print(key, features[key])

    input_ids = [[
        5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 768, 402, 18, 5019, 20, 58, 1811, 841, 976, 33, 24, 5683, 159, 13, 174, 521, 157, 3996, 25, 24, 1140, 330, 2892, 854, 31, 372, 17, 9, 4, 3]]
    input_masks = [[
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]
    segment_ids = [[
        4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2]]
    predict_ids = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 2, 6, 0, 0,
      0, 0, 0, 9, 9, 0, 0, 1, 0, 0, 2, 6, 0, 0, 0, 0,
      0, 9, 11, 10]]

    total_results = decode_predict(input_ids, input_masks, segment_ids, predict_ids)
    print(total_results)