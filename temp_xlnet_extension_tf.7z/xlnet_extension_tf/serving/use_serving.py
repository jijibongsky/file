import requests
import json
import os
import sys
from preprocess import predict_input_fn, decode_predict

# 启动serving
# nvidia-docker run -p 8866:8501 \
# --mount type=bind,source=/home/data/deep_learning/deeplearning/xlnet_extension_tf/export/ceshi,target=/models/ner -e MODEL_NAME=ner \
# -t tensorflow/serving:1.12.0-gpu &

root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(root_dir)

sentences = ["Japan began the defence of their Asian Cup a lucky 2-1 win against Syria in a Group C championship match on Friday ."]
features, all_tokens = predict_input_fn(sentences)
# for key in features:
#     print(key, features[key])

payload = {"inputs": features}
r = requests.post('http://192.168.2.100:8866/v1/models/ner:predict', json=payload)
results = json.loads(r.text)
new_result = decode_predict(features["input_ids"], features["input_masks"], features["segment_ids"], results["outputs"])
print("new_result", new_result)
