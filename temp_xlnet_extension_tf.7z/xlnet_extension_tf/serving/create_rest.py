import json
import os
from flask import Flask
from flask import request
from pathlib import Path
from tensorflow.contrib import predictor
import sys

# root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
# sys.path.append(root_dir)
from preprocess import predict_input_fn, decode_predict


export_dir = "/home/data/deep_learning/deeplearning/xlnet_extension_tf/export/ceshi/"
def get_model():
    subdirs = [x for x in Path(export_dir).iterdir() if x.is_dir()]
    latest = str(sorted(subdirs)[-1])
    print("load {}".format(latest))
    predict_fn = predictor.from_saved_model(latest)
    return predict_fn

predict_fn=get_model()

app = Flask(__name__)
@app.route("/ner", methods=["GET", "POST"])
def compute_sim():
    if request.method == "POST":
        data = request.get_data()
        data = data.decode("utf-8")
        dict1 = json.loads(data)
        try:
            sentence = dict1["sentence"]
        except:
            dict1 = json.loads(dict1)
            sentence = dict1["sentence"]

        sentences = [sentence]
        features, all_tokens = predict_input_fn(sentences)
        results = predict_fn(features)
        new_result = decode_predict(features["input_ids"], features["input_masks"], features["segment_ids"],
                       results["predict"].tolist())
        # print("new_result===", new_result)
        new_result = {"result": new_result[0]}
        return json.dumps(new_result, ensure_ascii=False)
    else:
        return "<h1>只接受post请求</h1>"


if __name__ == '__main__':
    print("fist loading vocab and tensorflow model")
    app.run(host="0.0.0.0", port=8866, debug=False)

