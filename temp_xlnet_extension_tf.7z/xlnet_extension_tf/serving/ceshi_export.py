import json
import os
from flask import Flask
from flask import request
from pathlib import Path
from tensorflow.contrib import predictor
import pickle
from preprocess import predict_input_fn, decode_predict

import sys
root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(root_dir)

export_dir = "/home/data/deep_learning/deeplearning/xlnet_extension_tf/export/ceshi/"

def get_model():
    subdirs = [x for x in Path(export_dir).iterdir() if x.is_dir()]
    latest = str(sorted(subdirs)[-1])
    print("load {}".format(latest))
    predict_fn = predictor.from_saved_model(latest)
    return predict_fn

predict_fn=get_model()

sentences = ["Japan began the defence of their Asian Cup a lucky 2-1 win against Syria in a Group C championship match on Friday ."]
features, all_tokens = predict_input_fn(sentences)
for key in features:
    print(key, features[key])

results = predict_fn(features)

new_results = decode_predict(features["input_ids"], features["input_masks"], features["segment_ids"], results["predict"].tolist())
print(new_results)

