import requests
import json

dict = {'sentence': "Japan began the defence of their Asian Cup title with a lucky 2-1 win against Syria in a Group C championship match on Friday ."}
json_info = json.dumps(dict, ensure_ascii=False)
r = requests.post('http://192.168.2.100:8866/ner', json=json_info)

print("r111111", r)
data_dict = json.loads(r.text)

print("data_dict", data_dict)
