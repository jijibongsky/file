import json
import os


model_path = "/home/data/deep_learning/deeplearning/xlnet_extension_tf/result/ner/CoNLL-2003/"
data_in = model_path + "predict.1564827557.7760966.json"
data_out = model_path + "aaa.txt"

fr = open(data_in, "r", encoding="utf8")
fw = open(data_out, "w", encoding="utf8")
data_list = json.load(fr)
for data in data_list:
    # print(data)
    # print(data)  # {'text': ' AMARILLO 1996-12-06', 'label': 'B-LOC O', 'predict': 'B-LOC O'}
    words = data['text'].strip().split(" ")
    tags = data['label'].strip().split(" ")
    predicts = data['predict'].strip().split(" ")
    if len(words) != len(tags):
        print()
    for word, tag, predict in zip(words, tags, predicts):
        fw.write(word + " " + tag + " " + predict + "\n")
    fw.write("\n")



eval_perl = "conlleval"
label_path = model_path + "aaa.txt"
metric_path = model_path + "bbb.txt"
os.system("perl {} < {} > {}".format(eval_perl, label_path, metric_path))

