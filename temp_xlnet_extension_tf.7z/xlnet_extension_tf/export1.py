import tensorflow as tf

# import sys
# import os
# root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
# sys.path.append(root_dir)
# print(root_dir)

import sys
sys.path.append('xlnet')

from xlnet import xlnet
from run_ner import XLNetModelBuilder
from run_ner import NerProcessor
import model_utils


flags = tf.flags
FLAGS = flags.FLAGS

print("FLAGS.output_dir====", FLAGS.output_dir)
max_seq_length = 128

def serving_input_receiver_fn():
    input_ids = tf.placeholder(tf.int32, shape=[None, max_seq_length], name="input_ids_2")
    input_masks = tf.placeholder(tf.float32, shape=[None, max_seq_length], name="input_mask_2")
    segment_ids = tf.placeholder(tf.int32, shape=[None, max_seq_length], name="segment_ids_2")
    label_ids = tf.placeholder(tf.int32, shape=[None, max_seq_length], name="label_ids_2")

    receiver_tensors = {
        "input_ids_1": input_ids,
        "input_masks_1": input_masks,
        "segment_ids_1": segment_ids,
        "label_ids_1": label_ids
    }
    features_old = {
        "input_ids": input_ids,
        "input_masks": input_masks,
        "segment_ids": segment_ids,
        "label_ids": label_ids
    }
    return tf.estimator.export.ServingInputReceiver(features_old, receiver_tensors)
    # features_old 是原模型中的数据，对应到 model_fn_builder 中的 model_fn的输入，（model_fn 是 tf.estimator.Estimator 的第一个参数）


if __name__ == '__main__':
    # bert_config = modeling.BertConfig.from_json_file(FLAGS.bert_config_file)
    # model_fn = model_fn_builder(
    #     bert_config=bert_config,
    #     num_labels=11,
    #     init_checkpoint=FLAGS.init_checkpoint,
    #     learning_rate=FLAGS.learning_rate,
    #     num_train_steps=100,
    #     num_warmup_steps=100,
    #     use_tpu=False,
    #     use_one_hot_embeddings=False
    # )



    processor = NerProcessor()
    label_list = processor.get_labels()
    model_config = xlnet.XLNetConfig(json_path=FLAGS.model_config_path)
    model_builder = XLNetModelBuilder(model_config=model_config, use_tpu=FLAGS.use_tpu)
    model_fn = model_builder.get_model_fn(label_list)

    # estimator = tf.estimator.Estimator(model_fn, FLAGS.model_dir, params=None)
    # estimator.export_savedmodel("export/ner", serving_input_receiver_fn)

    tpu_config = model_utils.configure_tpu(FLAGS)
    estimator = tf.contrib.tpu.TPUEstimator(
        use_tpu=FLAGS.use_tpu,
        model_fn=model_fn,
        config=tpu_config,
        export_to_tpu=FLAGS.use_tpu,
        train_batch_size=FLAGS.train_batch_size,
        eval_batch_size=FLAGS.eval_batch_size,
        predict_batch_size=FLAGS.predict_batch_size)
    estimator.export_savedmodel("export/ner", serving_input_receiver_fn)