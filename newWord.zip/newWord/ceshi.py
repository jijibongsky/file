import re


def split_sentence(sentence):
    split_ = "，。！？~、.!?；;：:“”《》（）()->│｜〔〕【】＜＞─[]"
    for s in split_:
        sentence = sentence.replace(s, s + "\n")
    sentence = sentence.split("\n")
    return sentence


def split_sentence_re(sentence):
    split_str = "，。！？~、!；;：:“”《》（）->│｜〔〕【】＜＞─[]"
    split_str = list(split_str) + ['\.', '\?', '\(', '\)']
    # split_ = ['，', '。', '！', '？', '~', '、', '!', '；', ';', '：', ':', '“', '”', '《', '》', '（', '）', '-',
    #           '>', '│', '｜', '〔', '〕', '【', '】', '＜', '＞', '─', '[', ']', '\.', '\?', '\(', '\)']
    split_rule = "|".join(list(split_str))
    new_sentence = re.split(split_rule, sentence)
    return new_sentence


if __name__ == '__main__':
    sentence = "你好啊，今天你吃的什么。"
    new_sentence = split_sentence(sentence)
    print(111, new_sentence)
    new_sentence = split_sentence_re(sentence)
    print(222, new_sentence)
