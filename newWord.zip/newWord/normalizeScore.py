import pickle
import math


def normalizeScore(scores, length_reward=None):
    freList = []
    miList = []
    rightEntropyList = []
    leftEntropyList = []
    for key in scores:
        score = scores[key]
        # print(key, score)
        freList.append(score.fre)
        miList.append(score.MI)
        rightEntropyList.append(score.rightEntropy)
        leftEntropyList.append(score.leftEntropy)
    freList.sort()
    miList.sort()
    rightEntropyList.sort()
    leftEntropyList.sort()
    totalWord = len(freList)
    min_ = int(totalWord / 100)
    max_ = int(99 * totalWord / 100)
    minFre = freList[min_]
    maxFre = freList[max_]
    minMi = miList[min_]
    maxMi = miList[max_]
    minRightEntropy = rightEntropyList[min_]
    maxRightEntropy = rightEntropyList[max_]
    minLeftEntropy = leftEntropyList[min_]
    MaxLeftEntropy = leftEntropyList[max_]

    for key in scores:
        score = scores[key]
        if score.fre < minFre:
            fre = 0
        elif score.fre > maxFre:
            fre = 1
        else:
            fre = (score.fre - minFre) / (maxFre - minFre)

        if score.MI < minMi:
            MI = 0
        elif score.MI > maxMi:
            MI = 1
        else:
            MI = (score.MI - minMi) / (maxMi - minMi)

        if score.rightEntropy < minRightEntropy:
            rightEntropy = 0
        elif score.rightEntropy > maxRightEntropy:
            rightEntropy = 1
        else:
            rightEntropy = (score.rightEntropy - minRightEntropy) / (maxRightEntropy - minRightEntropy)
        if score.leftEntropy < minLeftEntropy:
            leftEntropy = 0
        elif score.leftEntropy > MaxLeftEntropy:
            leftEntropy = 1
        else:
            leftEntropy = (score.leftEntropy - minLeftEntropy) / (MaxLeftEntropy - minLeftEntropy)

        if length_reward:
            L = math.sqrt(len(key.split()))
            score.total = fre + MI + rightEntropy + leftEntropy
        else:
            score.total = fre + MI + rightEntropy + leftEntropy


if __name__ == '__main__':
    scores = pickle.load(open("ceshi.pkl", "rb"))
    normalizeScore(scores, length_reward=True)
    # for key in scores:
    #     score = scores[key]
    #     print(key, score.total)
