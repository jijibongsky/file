import math
import pickle
import jieba
from node import Node, Score
from normalizeScore import normalizeScore


class Tree(object):
    def __init__(self, config=None):
        self.config = config
        self.wordNumber = 0
        self.root = Node()
        self.root_reverse = Node()
        self.N = 4
        self.minWordFre = 2
        self.wordScore = {}

    def generateForwardDic(self, sentences):
        for sentence in sentences:
            if len(sentence) == 0:
                continue
            self.wordNumber += len(sentence)
            for i in range(len(sentence)):
                # print(111, sentence[i])
                cur = self.root.next  # 是一个字典，用来存储下属的组合
                curNode = None  # 当前词对应的 node
                # (int j = 0; j < N && i + j < chs.length; j++)
                for j in range(min(self.N, len(sentence) - i)):
                    k = i + j
                    # print(2222, sentence[k])
                    if cur.get(sentence[k]):
                        curNode = cur.get(sentence[k])
                        curNode.upfre()
                        cur = curNode.next
                    else:
                        addNode = Node(sentence[k])
                        cur[sentence[k]] = addNode
                        addNode.father = curNode
                        addNode.upfre()
                        curNode = addNode
                        cur = curNode.next
                    # print(1111, self.getWords(curNode))

    def getFre(self, tempsentence):
        cur = self.root.next
        curNode = None
        for i in range(len(tempsentence)):
            if cur.get(tempsentence[i]):
                curNode = cur.get(tempsentence[i])
                cur = curNode.next
            else:
                return 0
        return curNode.fre

    def getWords(self, node):
        tempString = []
        tempString.append(node.word)
        while node.father != None:
            node = node.father
            tempString.append(node.word)
        return list(reversed(tempString))

    def getRightEntropy(self, node):
        entropy = 0
        sum = 0
        cur = node.next
        for tnode in cur.values():
            number = tnode.fre
            entropy += number * math.log(number)
            sum += number
        if sum == 0:
            return 0
        else:
            return math.log(sum) - entropy / sum

    def getMI(self, node, tempsentence):
        coProbability = node.fre / self.wordNumber
        mi = []
        for pos in range(1, len(tempsentence)):
            leftPart = tempsentence[0:pos]
            rightPart = tempsentence[pos:]
            leftProbability = self.getFre(leftPart) / self.wordNumber
            rightProbability = self.getFre(rightPart) / self.wordNumber
            mi.append(coProbability / (leftProbability * rightProbability))
        MI = min(mi)
        return math.log(MI)

    def depthOrderTraversal2(self):
        # self.root
        for node in self.root.next.values():
            if node.fre < self.minWordFre:
                continue
            stack = []
            stack.append(node)
            while stack:
                node1 = stack.pop()
                cur = node1.next
                if node1.father is not None:
                    tempString = self.getWords(node1)
                    # print(11111, tempString)
                    if len(tempString) <= self.N:
                        rightEntropy = self.getRightEntropy(node1)
                        mi = self.getMI(node1, tempString)
                        score = Score(tempString, node1.fre, mi, rightEntropy)
                        self.wordScore[" ".join(tempString)] = score
                # else:
                #     print("父节点为空：")
                for node2 in cur.values():
                    if node2.fre < self.minWordFre:
                        continue
                    stack.append(node2)

    def _test_forword(self):
        for key in self.wordScore:
            score = self.wordScore[key]
            if score.fre > 10:
                print("word", "".join(score.word))
                print("word", score.fre)
                print("MI", score.MI)
                print("rightEntropy", score.rightEntropy)
                print("leftEntropy", score.leftEntropy)
                print("total", score.total)
                print()

    def generateBackwardDic(self, sentences):
        for sentence in sentences:
            if sentence == []:
                continue
            sentence = list(reversed(sentence))
            for i in range(len(sentence)):
                cur = self.root_reverse.next
                curNode = None
                for j in range(min(self.N, len(sentence) - i)):
                    k = i + j
                    if cur.get(sentence[k]):
                        curNode = cur.get(sentence[k])
                        curNode.upfre()
                        cur = curNode.next
                    else:
                        addNode = Node(sentence[k])
                        cur[sentence[k]] = addNode
                        addNode.father = curNode
                        addNode.upfre()
                        curNode = addNode
                        cur = curNode.next

    def getLeftEntropy(self, sentence):
        cur = self.root_reverse.next
        for i in range(len(sentence)):
            if cur.get(sentence[i]):
                curNode = cur.get(sentence[i])
                cur = curNode.next
            else:
                return 0
        # for word in cur:
        #     print("{}左邻接词{}".format(" ".join(sentence), word))
        #     print("{}左邻接词频{}".format(" ".join(sentence), cur.get(word).fre))

        entropy = 0
        sum = 0
        for tnode in cur.values():
            number = tnode.fre
            entropy += number * math.log(number)
            sum += number
        if sum == 0:
            return 0
        else:
            return math.log(sum) - entropy / sum

    def getLeftEntropyNode(self):
        for word in self.wordScore:
            chs = word.split()
            chs = list(reversed(chs))
            leftEntropy = self.getLeftEntropy(chs)
            self.wordScore.get(word).updataLeftEntropy(leftEntropy)


def load_data(data_file):
    fr = open(data_file, "r", encoding="utf8")
    lines = []
    for line in fr:
        line = line.strip()
        line = jieba.lcut(line)
        # line = list(line)
        lines.append(line)
    return lines


if __name__ == '__main__':
    # sentences = []
    # sentences.append("我在杭州西湖边的西湖博物馆里面")
    # sentences.append("今天天气怎么样")
    # sentences = [list(sen) for sen in sentences]
    # print(sentences)

    data_file = "预处理文件.txt"
    sentences = load_data(data_file)
    from time import time

    begin_time = time()
    tree = Tree()
    tree.generateForwardDic(sentences)
    tree.depthOrderTraversal2()
    tree.generateBackwardDic(sentences)
    tree.getLeftEntropyNode()

    # tree._test_forword()
    # print(111, time() - begin_time)

    # 对结果进行分析
    scores = tree.wordScore
    normalizeScore(scores, length_reward=True)
    scores_list = sorted(scores.items(), key=lambda d: d[1].total, reverse=True)
    # for key in scores:
    #     score = scores[key]
    #     print(key, score.total)
    for i, term in enumerate(scores_list):
        if i < 1000:
            print(111, term[0], term[1].total)

    # pickle.dump(score, open("ceshi.pkl", "wb"), protocol=2)
