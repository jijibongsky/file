class Node(object):
    def __init__(self, word=None, isEnd=False):
        self.word = word
        self.fre = 0
        self.isEnd = isEnd
        self.next = {}
        self.father = None

    def upfre(self):
        self.fre += 1


class Score(object):
    def __init__(self, word=None, fre=0, MI=0, rightEntropy=0, leftEntropy=0):
        self.word = word
        self.fre = fre
        self.MI = MI
        self.rightEntropy = rightEntropy
        self.leftEntropy = leftEntropy
        self.total = 0

    def updataLeftEntropy(self, leftEntropy):
        self.leftEntropy = leftEntropy
