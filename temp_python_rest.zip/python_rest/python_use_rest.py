import requests
import json

dict = {'sentence':'haha','en':'ai'}
json_info = json.dumps(dict)
# r = requests.post('http://192.168.2.100:8815/resttest', json=json_info)
r = requests.post('http://0.0.0.0:8815/resttest', json=json_info)
data_dict = json.loads(r.text)
result = data_dict["result"]
print(result)
