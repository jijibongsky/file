
Tags = ["TIME", "PER", "ORG", "LOC"]
def main(data_in, data_out):
    fr = open(data_in, "r", encoding="utf8")
    fw = open(data_out, "w", encoding="utf8")
    k = 0
    for line in fr:
        k += 1
        line = line.strip()
        if line == "":
            continue
        newline = line.split("|||||")
        words = newline[0].split(" ")
        tags = newline[1].split(" ")
        if "TIME" not in tags:
            continue
        if len(words) != len(tags):
            print("line===", line)
            continue
        # fw.write(line + "\n")
        for word, tag in zip(words, tags):
            if tag not in Tags:
                for w in word:
                    fw.write(w + " " + "O" + "\n")
                continue
            if len(word) == 1:
                fw.write(word + " " + "B-" + tag + "\n")
            else:
                fw.write(word[0] + " " + "B-" + tag + "\n")
                for i in range(1, len(word)):
                    fw.write(word[i] + " " + "I-" + tag + "\n")
        fw.write("\n")


data_in = "baidu_ner_result1wan.txt"
data_out = "train.txt"
main(data_in, data_out)
