from time import time
import paddlehub as hub
lac = hub.Module(name='lac')

begin_time = time()
def gen_data(data_in):
    fr = open(data_in, "r", encoding="utf8")
    lines = []
    k = 0
    for line in fr:
        k += 1
        if k % 10000 == 0:
            print("lines:{}, total times:{}".format(k, time() - begin_time))
        line = line.strip()
        if line == "":
            continue
        line = line.split()
        line = "".join(line)
        lines.append(line)
        if k % 100 == 0:
            yield lines
            lines = []


data_in = "100000.txt"
datas = gen_data(data_in)
data_out = "baidu_ner_result.txt"
fw = open(data_out, "w", encoding="utf8")


for data in datas:
    inputs = {"text": data}
    results = lac.lexical_analysis(data=inputs)
    for result in results:
        words = " ".join(result['word'])
        tags = " ".join(result['tag'])
        # print(words + "|||||" + tags)
        fw.write(words + "|||||" + tags + "\n")
