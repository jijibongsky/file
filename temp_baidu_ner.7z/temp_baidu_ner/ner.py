
import paddlehub as hub
lac = hub.Module(name='lac')
test_text =["我爱自然语言处理", "南京市长江大桥", "无线电法国别研究"]
inputs = {"text": test_text}
results = lac.lexical_analysis(data=inputs)
for result in results:
   print(result['word'])
   print(result['tag'])
