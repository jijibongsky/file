from pypinyin import lazy_pinyin, Style
from tacotron.utils.text import text_to_sequence
import jieba


def load_dict(data_file):
    my_dict = {}
    fr = open(data_file, "r", encoding="utf8")
    for line in fr:
        line = line.strip()
        line = line.split("\t")
        if len(line) != 2:
            print(11111111, line)
        my_dict[line[0]] = line[1]
    return my_dict


def my_pinyin(sentence, my_dict=None):
    tone_number = {"1", "2", "3", "4", "#"}
    # sentence = jieba.lcut(sentence)
    # sentence = "#1".join(sentence)
    result = lazy_pinyin(sentence, style=Style.TONE3)
    new_result = []
    for term in result:
        if term[-1] not in tone_number:
            term += "5"
        new_result.append(term)
    if my_dict is None:
        return " ".join(new_result)
    else:
        new_result1 = []
        for term in new_result:
            new_result1.append(my_dict.get(term, term))
        return " ".join(new_result1)


my_dict = load_dict("dictionary.txt")
if __name__ == '__main__':
    sentence = '聪明的小兔子'
    result = my_pinyin(sentence, my_dict)
    # result = my_pinyin(sentence)
    result1 = text_to_sequence(result, ["basic_cleaners"])
    print(111111111, result)
    print(222222222, result1)
