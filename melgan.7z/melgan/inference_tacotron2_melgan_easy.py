# -*-coding:utf-8-*-
import argparse
import os
import numpy as np
import torch
import tensorflow as tf
from time import time
from scipy.io.wavfile import write

from hparams import hparams, hparams_debug_string
from infolog import log
from tacotron.synthesizer import Synthesizer
from melgan_vocoder.model.generator import Generator
from melgan_vocoder.utils.hparams import HParam, load_hparam_str

import warnings

warnings.filterwarnings("ignore")
os.environ["CUDA_VISIBLE_DEVICES"] = '0'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

MAX_WAV_VALUE = 32768.0


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--taco_checkpoint',
                        default='./logs-Tacotron-2_phone/taco_pretrained/', help='Path to model checkpoint')
    parser.add_argument('--hparams', default='',
                        help='Hyperparameter overrides as a comma-separated list of name=value pairs')
    parser.add_argument('--model', default='Tacotron')
    parser.add_argument('--mels_dir', default='tacotron_output/eval/',
                        help='folder to contain mels to synthesize audio from using the Wavenet')
    parser.add_argument('--output_dir', default='output/', help='folder to contain synthesized mel spectrograms')
    parser.add_argument('--text_list', default='sentences_phone.txt',
                        help='Text file contains list of texts to be synthesized. Valid if mode=eval')
    parser.add_argument('--speaker_id', default=None,
                        help='Defines the speakers ids to use when running standalone Wavenet on a folder of mels. this variable must be a comma-separated list of ids')

    # melgan
    parser.add_argument('--vocoder_config', type=str, default=None,
                        help="yaml file for config. will use hp_str from checkpoint if not given.")
    parser.add_argument('--vocoder_checkpoint', type=str,
                        default='./melgan_vocoder/chkpt/biaobei/biaobei_aca5990_3125.pt',
                        help="path of checkpoint pt file for evaluation")
    args = parser.parse_args()
    return args


def init_tacotron2(args):
    print('\n#####################################')
    if args.model == 'Tacotron':
        print('\nInitialising Tacotron Model...\n')
        t2_hparams = hparams.parse(args.hparams)
        try:
            checkpoint_path = tf.train.get_checkpoint_state(args.taco_checkpoint).model_checkpoint_path
            log('loaded model at {}'.format(checkpoint_path))
        except:
            raise RuntimeError('Failed to load checkpoint at {}'.format(args.taco_checkpoint))
        # Create output path if it doesn't exist
        log(hparams_debug_string())
        synth = Synthesizer()
        synth.load(checkpoint_path, t2_hparams)
    return synth


def init_melgan(args):
    # melgan
    print('\n#####################################')
    checkpoint = torch.load(args.vocoder_checkpoint)
    if args.vocoder_config is not None:
        hp = HParam(args.config)
    else:
        hp = load_hparam_str(checkpoint['hp_str'])

    melgan_model = Generator(hp.audio.n_mel_channels).cuda()
    melgan_model.load_state_dict(checkpoint['model_g'])
    melgan_model.eval(inference=False)

    # torch.save(model, 'genertor1.pt')  # 保存和加载整个模型
    # torch.save(model.state_dict(), 'genertor2.pt')   # 仅保存和加载模型参数(推荐使用)

    return melgan_model, hp, checkpoint


def load_model(args):
    synth = init_tacotron2(args)
    voc_model, voc_hp, voc_checkpoint = init_melgan(args)
    output_melgan_dir = 'tacotron_' + args.output_dir + 'melgan/'
    os.makedirs(output_melgan_dir, exist_ok=True)
    return synth, voc_model, voc_hp, voc_checkpoint, output_melgan_dir


def tts_interface(synth, voc_model, texts):
    mels = synth.synthesize1(texts)
    with torch.no_grad():
        t2_mel = mels[0]
        t2_mel = np.transpose(t2_mel, [1, 0])
        t2_mel = t2_mel[np.newaxis, :]
        mel = torch.from_numpy(t2_mel)
        mel = mel.cuda()
        audio = voc_model.inference(mel)
        audio = audio.cpu().detach().numpy()
    return audio


def get_sentences(args):
    with open(args.text_list, 'rb') as f:
        sentences = list(map(lambda l: l.decode("utf-8")[:-1], f.readlines()))
    return sentences


args = parse_args()
synth, voc_model, voc_hp, voc_checkpoint, output_melgan_dir = load_model(args)


def main():
    sentences = get_sentences(args)
    sentences = [sentences[i] for i in range(0, len(sentences))]
    begin_time = time()
    for i, texts in enumerate(sentences):
        audio = tts_interface(synth, voc_model, texts)
        out_path = output_melgan_dir + str(i) + ('_melgan_epoch%04d.wav' % voc_checkpoint['epoch'])
        write(out_path, voc_hp.audio.sampling_rate, audio)
        print("synthesis mel{} : {}".format(i, time() - begin_time))
    print("总共花费：", time() - begin_time)


if __name__ == '__main__':
    main()
