import time

def crawl_url(i):        # 假设这是爬虫程序，爬取一个 URL
    time.sleep(0.02)     # 模拟 IO 操作
    return i

def main():
    from concurrent.futures import ProcessPoolExecutor
    from functools import partial
    executor = ProcessPoolExecutor(max_workers=100)
    futures = []
    for i in range(100):
        futures.append(executor.submit(partial(crawl_url, i)))
    futures = [a.result() for a in futures]
    # print(futures)


class CustomTask:
    def __init__(self):
        self._result = None

    def run(self, i):
        # 你的代码, 你用来进行多线程
        result = i+1
        self._result = result

    def get_result(self):
        return self._result

def main1():
    import threading
    for i in range(10):
        ct = CustomTask()
        t = threading.Thread(target=ct.run, args=(i,))
        t.start()
        result = ct.get_result()
        print(111, result)


if __name__ == '__main__':
    start = time.time()
    main()
    main1()
    end = time.time()
    print('多线程耗时：{:.4f}s'.format(end - start))
