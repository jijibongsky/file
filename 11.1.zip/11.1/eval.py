import sys

sys.path.append('/home/aistudio/external-libraries')
# !git clone https://github.com/PaddlePaddle/ERNIE.git
# !git -C ./ERNIE branch origin/dygraph
sys.path.append('./ERNIE')
import numpy as np
from sklearn.metrics import f1_score
import paddle as P
import paddle.fluid as F
import paddle.fluid.layers as L
import paddle.fluid.dygraph as D


from ernie.tokenizing_ernie import ErnieTokenizer
from ernie.modeling_ernie import ErnieModelForSequenceClassification

# 设置好所有的超参数，对于ERNIE任务学习率推荐取1e-5/2e-5/5e-5, 根据显存大小调节BATCH大小, 最大句子长度不超过512.
BATCH = 16
MAX_SEQLEN = 300
LR = 5e-5
EPOCH = 10

tokenizer = ErnieTokenizer.from_pretrained('ernie-1.0')


def make_data(path):
    data = []
    for i, l in enumerate(open(path)):
        if i == 0:
            continue
        l = l.strip().split(',')
        text, label = l[3], int(l[-1])
        text_id, _ = tokenizer.encode(text)  # ErnieTokenizer 会自动添加ERNIE所需要的特殊token，如[CLS], [SEP]
        text_id = text_id[:MAX_SEQLEN]
        text_id = np.pad(text_id, [0, MAX_SEQLEN - len(text_id)], mode='constant')  # 对所有句子都补长至300，这样会比较费显存；
        label_id = np.array(label + 1)
        data.append((text_id, label_id))
    return data


all_data = make_data('/home/data/deep_learning/ERNIE/Sementic_analysis/data/train.csv')
test_data, train_data = all_data[:1000], all_data[1000:]  # 为了简单起见，取头1000条样本做为测试集；
D.guard().__enter__()  # 为了让Paddle进入动态图模式，需要添加这一行在最前面

ernie = ErnieModelForSequenceClassification.from_pretrained('ernie-1.0', num_labels=3)

def get_batch_data(data, i):
    d = data[i * BATCH: (i + 1) * BATCH]
    feature, label = zip(*d)
    feature = np.stack(feature)  # 将BATCH行样本整合在一个numpy.array中
    label = np.stack(list(label))
    feature = D.to_variable(feature)  # 使用to_variable将numpy.array转换为paddle tensor
    label = D.to_variable(label)
    return feature, label


sd, _ = D.load_dygraph("./my_paddle_model61.pdparams")
ernie.set_dict(sd)
ernie.eval()
all_pred, all_label = [], []
with D.base._switch_tracer_mode_guard_(is_train=False):  # 在这个with域内ernie不会进行梯度计算；
    ernie.eval()  # 控制模型进入eval模式，这将会关闭所有的dropout；
    for j in range(len(test_data) // BATCH):
        feature, label = get_batch_data(test_data, j)
        loss, logits = ernie(feature, labels=label)
        all_pred.extend(L.argmax(logits, -1).numpy())
        all_label.extend(label.numpy())

        _, logits1 = ernie(feature)
        pred = logits.numpy().argmax(-1)
        # print(111111111111, '\n'.join(map(str, pred.tolist())))
        print(111111111111, pred)

    ernie.train()
f1 = f1_score(all_label, all_pred, average='macro')
print('f1 %.5f' % f1)
