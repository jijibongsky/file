
Tags = ["TIME", "PER", "ORG", "LOC"]
def main(data_in, data_out):
    fr = open(data_in, "r", encoding="utf8")
    fw = open(data_out, "w", encoding="utf8")
    k = 1
    for line in fr:
        k += 1
        if k % 100000 == 0:
            print(k)
        if k > 2000000:
            break
        line = line.strip()
        if line == "":
            continue
        newline = line.split("|||||")
        words_ner = newline[1].split(" ")
        words = newline[0].split(" ")
        if "TIME" in words_ner and len("".join(words)) < 100:
            # fw.write(line + "\n")
            if len(words_ner) != len(words):
                print(line)
                continue
            words_ner = [word_ner if word_ner in Tags else "O" for word_ner in words_ner]
            for word, word_ner in zip(words, words_ner):
                if word_ner == "O":
                    for w in word:
                        fw.write(w + "\t" + "O" + "\n")
                elif len(word) == 1:
                    fw.write(word + "\t" + "B-" + word_ner + "\n")
                else:
                    fw.write(word[0] + "\t" + "B-" + word_ner + "\n")
                    for i in range(1, len(word)):
                        fw.write(word[i] + "\t" + "I-" + word_ner + "\n")
            fw.write("\n")


data_in = "baidu_ner_result.txt"
data_out = "train.txt"
main(data_in, data_out)
