# coding=utf-8
# Copyright 2019/7/16 10:50 by ZTE
# Author: Kangkang Sun

import json
import os
from flask import Flask
from flask import request
import sys
import paddlehub as hub

os.environ['CUDA_VISIBLE_DEVICES'] = ''
# root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
# sys.path.append(root_dir)
# print(root_dir)


def meg_result(results):
    new_results = []
    for result in results:
        new_result = []
        words = result['word']
        tags = result['tag']
        for word, tag in zip(words, tags):
            new_result.append(word + "/" + tag)
        new_results.append(new_result)
    return new_results


lac = hub.Module(name='lac')
app = Flask(__name__)
@app.route('/ner', methods=['GET', 'POST'])
def compute_sim():
    if request.method == 'POST':
        data = request.get_data()
        dict1 = json.loads(data.decode('utf-8'))
        sentences = dict1['sentence']
        print("sentence: ", sentences)
        inputs = {"text": sentences}
        results = lac.lexical_analysis(data=inputs)
        new_results = meg_result(results)
        res = {"result": new_results}
        return json.dumps(res, ensure_ascii=False)
    else:
        return '<h1>只接受post请求！</h1>'


if __name__ == '__main__':
    print(("* First loading vocab and TensorFlow model, then starting Flask server...please wait until server has fully started"))
    app.run(host='0.0.0.0', port=8811, debug=False, threaded=True)
