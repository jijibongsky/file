# coding=utf-8
# Copyright 2019/8/5 18:47 by ZTE
# Author: Kangkang Sun

# "1号楼，2号楼，3号楼，4号楼，5号楼，6号楼，7号楼，8号楼，9号楼，12号楼，13栋，14栋，B16栋"


def create_locs(data_in, data_out):
    fr = open(data_in, "r", encoding="utf8")
    fw = open(data_out, "w", encoding="utf8")
    total_locs = []
    for line in fr:
        line = line.strip()
        if line != "":
            locs = create_locs_line(line)
            total_locs += locs
    print("len(total_locs)====", len(total_locs))
    total_locs = list(set(total_locs))
    for loc in total_locs:
        fw.write(loc + "\n")
    print("len(total_locs)====", len(total_locs))
    return total_locs


def create_locs_line1(line):
    locs = []
    line = line.split()
    if len(line) == 2:
        locs.append(line[0])
        locs.append(line[0] + line[1])
    elif len(line) == 3:
        loc = line[0]+line[1]
        room = line[2].split("，")
        if len(room) == 1:
            locs.append(loc)
            locs.append(loc + room[0])
        else:
            locs.append(loc)
            for i in range(len(room)):
                locs.append(loc + room[i])
    return locs


def merge(locs):
    new_locs = []
    for loc in locs:
        new_locs.append(" ".join(loc))
    return new_locs


def create_locs_line(line):
    locs = []
    line = line.split()
    if len(line) == 2:
        locs.append([line[0] + "/CITY"])
        locs.append([line[1] + "/PARK"])
        locs.append([line[0] + "/CITY", line[1] + "/PARK"])
        for i in range(1, 7):
            locs.append(["{}楼/FLOOR".format(i)])
            locs.append([line[1] + "/PARK", "{}楼/FLOOR".format(i)])
            locs.append([line[0] + "/CITY", line[1] + "/PARK", "{}楼/FLOOR".format(i)])
    elif len(line) == 3:
        locs.append([line[0] + "/CITY"])
        locs.append([line[1] + "/PARK"])
        locs.append([line[0] + "/CITY", line[1] + "/PARK"])
        building = line[2].split("，")
        for j in range(len(building)):
            locs.append([building[j] + "/BUILDING"])
            locs.append([line[1] + "/PARK", building[j] + "/BUILDING"])
            locs.append([line[0] + "/CITY", line[1] + "/PARK", building[j] + "/BUILDING"])
            for i in range(1, 7):
                locs.append([building[j] + "/BUILDING", "{}楼/FLOOR".format(i)])
                locs.append([line[1] + "/PARK", building[j] + "/BUILDING", "{}楼/FLOOR".format(i)])
                locs.append([line[0] + "/CITY", line[1] + "/PARK", building[j] + "/BUILDING", "{}楼/FLOOR".format(i)])
    locs = merge(locs)
    return locs


# line = "深圳 观澜"
# line1 = "武汉 友谊大道 钢铁大楼"
# line2 = "天津 中兴产业基地 8号楼，12号楼"
# line3 = "北京 朝阳区 燕郊基地 A，B，3号楼，4号楼，6号楼"
# locs = create_locs_line(line)
# new_locs = merge(locs)
# print(locs)


data_in = "原始会议室.txt"
data_out = "loc.txt"
total_locs = create_locs(data_in, data_out)
print(len(total_locs))
for loc in total_locs:
    print(loc)
