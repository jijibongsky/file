# coding=utf-8
# Copyright 2019/8/5 19:10 by ZTE
# Author: Kangkang Sun

time_dict = {"上午": [9, 10, 11, 12], "早上": [9, 10, 11, 12],
             "下午": [1, 2, 3, 4, 5, 13, 14, 15, 16, 17], "晚上": [6, 7, 8, 9, 18, 19, 20, 21]}

zh_num = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10,
             "十一": 11, "十二": 12, "十三": 13, "十四": 14, "十五": 15,
             "十六": 16, "十七": 17, "十八": 18, "十九": 19, "二十": 20, "二十一": 21}
num_zh = {1: '一', 2: '二', 3: '三', 4: '四', 5: '五', 6: '六', 7: '七', 8: '八', 9: '九', 10: '十',
          11: '十一', 12: '十二', 13: '十三', 14: '十四', 15: '十五', 16: '十六', 17: '十七',
          18: '十八', 19: '十九', 20: '二十', 21: '二十一'}

num_zh_big = {1: '一', 2: '二', 3: '三', 4: '四', 5: '五', 6: '六', 7: '七', 8: '八', 9: '九', 10: '十',
          11: '十一', 12: '十二', 13: '十三', 14: '十四', 15: '十五', 16: '十六', 17: '十七',
          18: '十八', 19: '十九', 20: '二十', 21: '二十一', 22: '二十二', 23: '二十三', 24: '二十四', 25: '二十五',
          26: '二十六', 27: '二十七', 28: '二十八', 29: '二十九', 30: '三十', 31: '三十一'}

DAY = ["今天", "明天", "后天", "大后天", "下周一", "周一", "周二", "周三", "周四", "周五", "周六", "周日"]+[str(i) + "号" for i in list(range(1, 32))]
DAY1 = [str(i) + "号" for i in list(range(1, 32))]   # if random.random() < 1/6:
HALF_DAY = ["上午", "早上", "下午", "晚上"]

# 九点，九点半，九点整，9点，9点半，9点整，9:30, 9:00


def create_times_one(day, half_day):
    times = []
    hour = time_dict[half_day]
    base_day = [day + "/DAY"]
    for h in hour:
        times.append([str(h) + "点" + "/TIME"])
        times.append(base_day)
        times.append(base_day + [half_day + "/TIME"])

        times.append(base_day + [str(h) + "点" + "/TIME"])
        times.append(base_day + [str(h) + "点半" + "/TIME"])
        times.append(base_day + [str(h) + "点整" + "/TIME"])
        times.append(base_day + [str(h) + ":30" + "/TIME"])
        times.append(base_day + [str(h) + ":00" + "/TIME"])
        times.append(base_day + [num_zh[h] + "点" + "/TIME"])
        times.append(base_day + [num_zh[h] + "点半" + "/TIME"])
        times.append(base_day + [num_zh[h] + "点整" + "/TIME"])

        times.append(base_day + [half_day + str(h) + "点" + "/TIME"])
        times.append(base_day + [half_day + str(h) + "点半" + "/TIME"])
        times.append(base_day + [half_day + str(h) + "点整" + "/TIME"])
        times.append(base_day + [half_day + str(h) + ":30" + "/TIME"])
        times.append(base_day + [half_day + str(h) + ":00" + "/TIME"])
        times.append(base_day + [half_day + num_zh[h] + "点" + "/TIME"])
        times.append(base_day + [half_day + num_zh[h] + "点半" + "/TIME"])
        times.append(base_day + [half_day + num_zh[h] + "点整" + "/TIME"])

    times = [" ".join(time) for time in times]
    return times


def create_times(data_out):
    fw = open(data_out, "w", encoding="utf8")
    total_times = []
    for day in DAY:
        for half_day in HALF_DAY:
            times = create_times_one(day, half_day)
            total_times += times
    print("len(total_times)====", len(total_times))
    total_times = list(set(total_times))
    print("len(total_times)====", len(total_times))
    for time in total_times:
        fw.write(time+"\n")


# day = "今天"
# half_day = "晚上"
# times = create_times_one(day, half_day)
# print(len(times))
# for time in times:
#     print(time)

data_out = "time.txt"
create_times(data_out)
