# coding=utf-8
# Copyright 2019/8/2 15:02 by ZTE
# Author: Kangkang Sun
import random

random.seed(0)


def load_time(data_time):
    times = []
    fr = open(data_time, "r", encoding="utf8")
    for line in fr:
        line = line.strip()
        if line != "":
            times.append(line)
    return times


def load_loc(data_loc):
    locs = []
    fr = open(data_loc, "r", encoding="utf8")
    for line in fr:
        line = line.strip()
        if line != "":
            locs.append(line)
    return locs


def create_sentences(data_time, data_loc, fw):
    times = load_time(data_time)
    locs = load_loc(data_loc)
    total_num = len(begins) * len(ends) * len(times) * len(locs)
    print("总个数：", total_num)
    rate = 200000/total_num
    sentences = []
    for begin in begins:
        for time in times:
            for loc in locs:
                for end in ends:
                    if random.random() < rate:
                        if random.random() < 2/3:
                            sentence = [begin + "/O", time, loc, end + "/O"]
                            sentences.append(" ".join(sentence))
                        else:
                            sentence = [begin + "/O", loc, time, end + "/O"]
                            sentences.append(" ".join(sentence))
    for sentence in sentences:
        fw.write(sentence + "\n")
    return sentences


def create_sentences_single(data_time, data_loc, fw):
    times = load_time(data_time)
    locs = load_loc(data_loc)
    begins = ["那", "有没有"]
    ends = ["的会议室呢", "的呢", "其他的会议室呢"]

    total_num_times = len(begins) * len(ends) * len(times)
    total_num_locs = len(begins) * len(ends) * len(locs)
    print("total_ntemp_um_times===", total_num_times)
    print("total_num_locs===", total_num_locs)
    rate_times = 30000 / total_num_times
    rate_locs = 30000 / total_num_locs
    sentences = []
    for begin in begins:
        for time in times:
            for end in ends:
                if random.random() < rate_times:
                    sentence = [begin + "/O", time, end + "/O"]
                    sentences.append(" ".join(sentence))

    for begin in begins:
        for loc in locs:
            for end in ends:
                if random.random() < rate_locs:
                    sentence = [begin + "/O", loc, end + "/O"]
                    sentences.append(" ".join(sentence))

    for sentence in sentences:
        fw.write(sentence + "\n")
    return sentences


def trans_train_data(data_out_sentence, data_out_word):
    fr = open(data_out_sentence, "r", encoding="utf8")
    fw = open(data_out_word, "w", encoding="utf8")
    sentences = []
    for line in fr:
        line = line.strip()
        if line != "":
            sentences.append(line)
    random.shuffle(sentences)
    for line in sentences:
        line = line.split(" ")
        for pair in line:
            pair = pair.split("/")
            if len(pair) != 2:
                print(line)
            word = pair[0]
            tag = pair[1]
            if tag == "O":
                for i in range(len(word)):
                    fw.write(word[i] + " " + "O" + "\n")
            elif len(word) == 1:
                fw.write(word + " " + "B-" + tag + "\n")
            else:
                fw.write(word[0] + " " + "B-" + tag + "\n")
                for i in range(1, len(word)):
                    fw.write(word[i] + " " + "I-" + tag + "\n")
        fw.write("\n")


begins = ["我想预订", "帮我预定", "我要预订", "订一下", "帮我订一下"]
ends = ["的会议室"]
data_time = "time.txt"
data_loc = "loc.txt"
data_out_sentence = "huiyi_data.txt"
data_out_word = "train.txt"

# fw_sentence = open(data_out_sentence, "w", encoding="utf8")
# sentences1 = create_sentences(data_time, data_loc, fw_sentence)
# sentences2 = create_sentences_single(data_time, data_loc, fw_sentence)
# print(len(sentences1 + sentences2))

trans_train_data(data_out_sentence, data_out_word)

