# coding=utf-8
# Copyright 2019/8/5 19:57 by ZTE
# Author: Kangkang Sun

import random

random.seed(0)

def ceshi():
    total_num = 10000
    b = []
    for i in range(total_num):
        a = random.random()
        b.append(a)

    print(sum(b)/total_num)
    print(max(b))
    print(min(b))


for i in range(5):
    print(random.random())
