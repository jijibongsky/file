# coding=utf-8
# Copyright 2019/9/5 16:41 by ZTE
# Author: Kangkang Sun

data_in = "中国城市.txt"
data_out = "citys.txt"
fr = open(data_in, "r", encoding="utf8")
fw = open(data_out, "w", encoding="utf8")
citys = []
for line in fr:
    line = line.strip()
    if line == "":
        continue
    line = line.split()
    if len(line) == 1:
        continue
    for city in line:
        citys.append(city)

for city in citys:
    if city[-1] == "市":
        fw.write(city[:-1] + "\n")
    fw.write(city + "\n")