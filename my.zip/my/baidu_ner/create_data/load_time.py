# coding=utf-8
# Copyright 2019/9/5 17:07 by ZTE
# Author: Kangkang Sun
data_times = "time.txt"
fr_time = open(data_times, "r", encoding="utf8")
DAY = []
TIME = []
for line in fr_time:
    line = line.strip()
    if line == "":
        continue
    line = line.split(" ")
    for pair in line:
        pair = pair.split("/")
        if len(pair) != 2:
            print(pair)
        if pair[1] == "DAY":
            DAY.append(pair[0])

DAY = list(set(DAY))
for day in DAY:
    print(day)
print(len(DAY))