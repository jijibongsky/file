from time import time
import random
import paddlehub as hub
lac = hub.Module(name='lac')

random.seed(1)

begin_time = time()
def gen_data(data_in):
    fr = open(data_in, "r", encoding="utf8")
    all_sentences = []
    for line in fr:
        all_sentences.append(line)

    for i in range(5):
        random.shuffle(all_sentences)

    k = 0
    lines = []
    for line in all_sentences:
        k += 1
        lines.append(line.strip())
        if k % 100 == 0:
            yield lines
            lines = []
        if k % 10000 == 0:
            print("{}step花费时间{}".format(k, time()-begin_time))
    if lines!=[]:
        yield lines


data_in = "1000wan.txt"
datas = gen_data(data_in)
data_out = "baidu_ner_result.txt"
fw = open(data_out, "w", encoding="utf8")


for data in datas:
    inputs = {"text": data}
    results = lac.lexical_analysis(data=inputs)
    for result in results:
        words = " ".join(result['word'])
        tags = " ".join(result['tag'])
        # print(words + "|||||" + tags)
        fw.write(words + "|||||" + tags + "\n")
