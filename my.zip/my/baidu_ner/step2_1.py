# coding=utf-8
# Copyright 2019/8/2 16:12 by ZTE
# Author: Kangkang Sun
import re

tag = ["TIME", "PER", "ORG", "LOC"]


def load_city(data_in):
    fr = open(data_in, "r", encoding="utf8")
    citys = []
    for line in fr:
        line = line.strip()
        if line != "":
            citys.append(line)
    return citys


def Chinese_word_extraction(content_raw):
    chinese_pattern = u"([\u4e00-\u9fa5]+)"
    re_data = re.findall(chinese_pattern, content_raw)
    content_clean = ''.join(re_data)
    return content_clean


def main(data_in, data_out):
    fr = open(data_in, "r", encoding="utf8")
    fw = open(data_out, "w", encoding="utf8")
    jjj = 0
    k = 0
    for line in fr:
        k += 1
        if k == 1:
            continue
        if k % 100000 == 0:
            print(k)
        # if k > 1000000:
        #     break
        line = line.strip()
        if line == "":
            continue
        # print("line===", line)
        # input()
        newline = line.split("|||||")
        words_ner = newline[1].split(" ")
        words = newline[0].split(" ")
        ha = "".join(words).replace(" ", "")
        haha = Chinese_word_extraction(ha)
        if len(haha)/len(ha) < 0.5:
            jjj += 1
            # print("words===", words)
            continue

        if len("".join(words)) < 100:
            # fw.write(line + "\n")
            if len(words_ner) != len(words):
                print(line)
                continue
            words_ner = [word_ner if word_ner in tag else "O" for word_ner in words_ner]
            count = [1 if word_ner != "O" else 0 for word_ner in words_ner]
            if sum(count) == 0:
                continue
            for word, word_ner in zip(words, words_ner):
                if word_ner == "LOC" and word in citys:
                    word_ner = "CITY"
                if word_ner == "TIME" and word in DAY:
                    word_ner = "DAY"

                if word_ner == "O":
                    for w in word:
                        fw.write(w + " " + "O" + "\n")
                elif len(word) == 1:
                    fw.write(word + " " + "B-" + word_ner + "\n")
                else:
                    fw.write(word[0] + " " + "B-" + word_ner + "\n")
                    for i in range(1, len(word)):
                        fw.write(word[i] + " " + "I-" + word_ner + "\n")
            fw.write("\n")
    print(jjj)

if __name__ == '__main__':
    data_in = "600wan.txt"
    data_out = "baidu_ner.txt"

    DAY = ["今天", "明天", "后天", "大后天", "下周一", "周一", "周二", "周三", "周四", "周五", "周六", "周日"]\
          + [str(i) + "号" for i in list(range(1, 32))]
    citys = load_city("citys.txt")
    main(data_in, data_out)
