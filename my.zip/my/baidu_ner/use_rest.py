# coding=utf-8
# Copyright 2019/7/16 11:15 by ZTE
# Author: Kangkang Sun

import json
import requests
import time

sentences = []
# sentences.append("周恩来原籍浙江绍兴，1898年3月5日生于江苏淮安。")
# sentences.append("我想订今天早上九点半南研二区二号楼的会议室")

textmod={}
textmod["sentence"] = sentences

url = 'http://10.46.169.213:8811/ner'

r = requests.post(url, json=textmod)
end_time = time.time()
print(r.text)
