import os


eval_perl = "conlleval"
label_path = "ccc.txt"
metric_path = "ddd.txt"
os.system("perl {} < {} > {}".format(eval_perl, label_path, metric_path))