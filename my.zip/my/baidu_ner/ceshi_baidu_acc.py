from time import time
import paddlehub as hub

# 测试百度ner的准确率

def gen_data(data_in):
    fr = open(data_in, "r", encoding="utf8")
    sentences = []
    sentence = []

    k = 0
    for line in fr:
        line = line.strip()
        if line != "":
            sentence.append(line.split(" ")[0])
        if line == "" and sentence != []:
            k += 1
            sentences.append("".join(sentence))
            sentence = []
            if k % 10 == 0:
                yield sentences
                sentences = []
            if k % 10000 == 0:
                print(k)
    if sentence != []:
        sentences.append("".join(sentence))
    if sentences != []:
        yield sentences


def baidu_ner():
    datas = gen_data(data_test)
    fw = open(data_test_out, "w", encoding="utf8")
    for data in datas:
        inputs = {"text": data}
        results = lac.lexical_analysis(data=inputs)
        for result in results:
            words = " ".join(result['word'])
            tags = " ".join(result['tag'])
            # print(words + "|||||" + tags)
            fw.write(words + "|||||" + tags + "\n")


def main(data_test_out, data_test_out_new):
    Tags = ["PER", "ORG", "LOC"]
    frr = open(data_test_out, "r", encoding="utf8")
    fww = open(data_test_out_new, "w", encoding="utf8")
    k = 0
    for line in frr:
        k += 1
        line = line.strip()
        if line == "":
            continue
        newline = line.split("|||||")
        words = newline[0].split(" ")
        predict_tags = newline[1].split(" ")

        if len(words) != len(predict_tags):
            print("line===", line)
            continue

        for word, tag in zip(words, predict_tags):
            if tag not in Tags:
                for w in word:
                    fww.write(w + " " + "O" + "\n")
                continue
            if len(word) == 1:
                fww.write(word + " " + "B-" + tag + "\n")
            else:
                fww.write(word[0] + " " + "B-" + tag + "\n")
                for i in range(1, len(word)):
                    fww.write(word[i] + " " + "I-" + tag + "\n")
        fww.write("\n")


def merge(data_in_1, data_in_2,data_out):
    fr1 = open(data_in_1, "r", encoding="utf8")
    fr2 = open(data_in_2, "r", encoding="utf8")
    fw = open(data_out, "w", encoding="utf8")
    for line1, line2 in zip(fr1,fr2):
        line1 = line1.strip()
        line2 = line2.strip()
        if line1 != "":
            line2 = line2.split(" ")
            fw.write(line1 + " " + line2[1] + "\n")
        else:
            fw.write("\n")

data_test = "/home/data/deep_learning/deeplearning/bert-chinese-ner/data/ner/chinese/dev.txt"
data_test_out = "aaa.txt"
data_test_out_new = "bbb.txt"
data_out = "ccc.txt"
lac = hub.Module(name='lac')

baidu_ner()
main(data_test_out, data_test_out_new)
merge(data_test, data_test_out_new, data_out)
