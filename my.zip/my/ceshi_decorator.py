import time
from functools import wraps


def timeit(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.process_time()
        ret = func(*args, **kwargs)
        end = time.process_time()
        print('used:', end - start)
        return ret
    return wrapper


@timeit
def foo():
    print('in foo()')


if __name__ == '__main__':
    foo()
