# coding=utf-8
# Copyright 2020/5/9 11:40 by ZTE
# Author: Kangkang Sun

import pypinyin
from pypinyin import pinyin, lazy_pinyin, Style, load_phrases_dict


# 不带声调的(style=pypinyin.NORMAL)
def my_pinyin(word):
    # result = pypinyin.pinyin(word, style=pypinyin.NORMAL) # 不带声调
    # result = pypinyin.pinyin(word)  # 带声调
    result = pypinyin.pinyin(word, style=Style.TONE3, heteronym=True)
    # result = [word[0] for word in result]
    result = [word[0] if word[0][-1] in ["1", "2", "3", "4"] else word[0] + "5" for word in result]
    result = " ".join(result)
    return result

def ceshi1():
    # 常见用法
    pinyin('中心')  # [['zhōng'], ['xīn']]
    pinyin('中心', heteronym=True)  # 启用多音字模式  # [['zhōng', 'zhòng'], ['xīn']]
    pinyin('中心', style=Style.FIRST_LETTER)  # 设置拼音风格  # [['z'], ['x']]
    pinyin('中心', style=Style.TONE2, heteronym=True)  # [['zho1ng', 'zho4ng'], ['xi1n']]
    pinyin('中心', style=Style.TONE3, heteronym=True)  # [['zhong1', 'zhong4'], ['xin1']]
    pinyin('中心', style=Style.BOPOMOFO)  # 注音风格   # [['ㄓㄨㄥ'], ['ㄒㄧㄣ']]
    lazy_pinyin('中心')  # 不考虑多音字的情况   # ['zhong', 'xin']

def ceshi2():
    # 自定义词典
    pinyin('步履蹒跚')  # [['bù'], ['lǚ'], ['mán'], ['shān']]
    load_phrases_dict({'步履蹒跚': [['bù'], ['lǚ'], ['pán'], ['shān']]})
    pinyin('步履蹒跚')  # [['bù'], ['lǚ'], ['pán'], ['shān']]

if __name__ == '__main__':
    # sentence = "你好明天。"
    # sentence = "你今天中午吃的什么。"
    sentence = "我今天中午吃的回锅肉。"
    # sentence = "欢迎使用语音助手。"
    py = my_pinyin(sentence)
    # print(111111, sentence, py.capitalize())
    print("拼音：", py)
