import pickle

def save(data, fname):
    pickle.dump(data, open(fname, "wb"), protocol=2)

def load(fname):
    data = pickle.load(open(fname, "rb"))
    return data