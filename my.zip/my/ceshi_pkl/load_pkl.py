import pickle



handle = open('dataset-cornell-length10-filter1-vocabSize40000.pkl','rb')    #open的参数是pkl文件的路径
data = pickle.load(handle)  # Warning: If adding something here, also modifying saveDataset
word2id = data['word2id']
id2word = data['id2word']
idCount = data.get('idCount', None)
trainingSamples = data['trainingSamples']

handle.close()


