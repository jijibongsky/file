import numpy as np
from PIL import Image
import cv2


img = cv2.imread("IMG_9175.JPG")
# print(1, img.shape)
cv2.imwrite('0.png', img * [1, 0, 0])
cv2.imwrite('1.png', img * [0, 1, 0])
cv2.imwrite('2.png', img * [0, 0, 1])

for i in img:
    # print(444, i.shape)  # (1760, 3)
    for j in i:
        # print(5555, j)  #  [34  33 131]
        # if j[2] >= 130 and j[2]<=132:
        # if j[2] == 131:
        if (j == [34, 33, 131]).all():
            j[1] = 0
            j[0] = 255  # 蓝
            j[2] = 0
            # j[0] = 0
            # j[2] = 255
cv2.imwrite('ceshi.png', img)
