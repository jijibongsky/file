import numpy as np
from time import time
import numba as nb


@nb.njit()
def arr_sum(src_arr):
    res = 0
    shape = src_arr.shape
    for r in range(0, shape[0]):
        for c in range(0, shape[1]):
            res += src_arr[r][c]
    return res


a = np.random.random((128, 128))
begin_time = time()
for i in range(1000):
    b = arr_sum(a)
print(time() - begin_time)

begin_time = time()
for i in range(1000):
    b = arr_sum(a)
print(time() - begin_time)

# import pyximport;pyximport.install() # 不需要编译，直接import，或者先编译成so文件

from cython_sum import arr_sum1
begin_time3 = time()
for i in range(1000):
    b = arr_sum1(a)
print(3333, time() - begin_time3)
