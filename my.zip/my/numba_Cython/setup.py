from distutils.core import setup
from Cython.Build import cythonize
# setup(ext_modules=cythonize(["cython_sum.pyx"]), script_args=["build_ext", "-b", "./"])

# build_dir = "build"
# setup(ext_modules=cythonize(["cython_sum.pyx"]), script_args=["build_ext", "-b", build_dir])
# setup(ext_modules=cythonize(["ceshi1.py"]), script_args=["build_ext", "-b", build_dir])
