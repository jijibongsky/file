import os

os.system("python ceshi_argparse.py --model aaa --model_dir bbb")
