import argparse

parse = argparse.ArgumentParser()
parse.add_argument("--model", default="my_model", help="model")
parse.add_argument("--model_dir", default="my_model_dir", help="model_dir")
args = parse.parse_args()
print("model", args.model)
print("model_dir", args.model_dir)
