import os
os.system("python ceshi_tf_flags.py --model aaa --model_dir bbb")
