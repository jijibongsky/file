import tensorflow as tf

flags = tf.flags
FLAGS = flags.FLAGS

flags.DEFINE_string("model", "my_model", "model.")
flags.DEFINE_string("model_dir", "my_model_dir", "model_dir")

print("model", FLAGS.model)
print("model_dir", FLAGS.model_dir)
