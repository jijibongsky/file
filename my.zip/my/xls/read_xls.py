# coding=utf-8
# Copyright 2019/2/11 10:03 by ZTE
# Author: Kangkang Sun
# coding=utf-8
# Copyright 2018/12/25 14:21 by ZTE
# Author: Kangkang Sun

import xlrd


def xls2dict(data_file):
    readbook = xlrd.open_workbook(data_file, 'r')
    sheet = readbook.sheet_by_name('Sheet1')
    nrows = sheet.nrows
    for i in range(1, nrows):
        value = sheet.cell(i, 0).value
        label = sheet.cell(i, 1).value
        IS_OK = sheet.cell(i, 2).value
        print("====", value, label, IS_OK)

data_file = 'data/ceshi.xlsx'
dict = xls2dict(data_file)

