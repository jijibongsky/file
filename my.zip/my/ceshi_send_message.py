# -*- coding: utf-8 -*-

import time
from twilio.rest import Client
text = '123'
auth_token = '4f17eb25dbbc322b330f98e79b7d47c0'  # 去twilio.com注册账户获取token
account_sid = 'ACd9cabb656eba44324538766ff623c7c6'
# PwtDu8aX0zAY_cgrcEqnKK1zpb2S2eGsXVtsfjKo 故障码

client = Client(account_sid, auth_token)

def sent_message(phone_number):
    mes = client.messages.create(
        from_='+17178836705',  # 填写在active number处获得的号码
        body=text,
        to=phone_number
    )
    print("OK")

sent_message("+8615996207881")

# while 1:
#     sent_message("+86要收到信息的号码")
#     time.sleep(3600 * 24)
