import sys
import os
from glob import glob


# 获取需要转换的路径
def get_user_path(argv_dir):
    if os.path.isdir(argv_dir):
        return argv_dir
    elif os.path.isabs(argv_dir):
        return argv_dir
    else:
        return False


# 对转换的TS文件进行排序
def get_sorted_ts(user_path):
    ts_list = glob(os.path.join(user_path, '*.ts'))
    # print(ts_list)
    boxer = []
    for ts in ts_list:
        # print(22222222, ts)
        if os.path.exists(ts):
            # print(333333333, os.path.splitext(os.path.basename(ts)))
            file, _ = os.path.splitext(os.path.basename(ts))
            file = file.split("_")[1]
            boxer.append(int(file))
    boxer.sort()
    # print(boxer)
    return boxer


# 文件合并
def convert_m3u8(boxer, o_file_name):
    # cmd_arg = str(ts0)+"+"+str(ts1)+" "+o_file_name
    tmp = []
    for ts in boxer:
        tmp.append("segment_" + str(ts) + '.ts')
    cmd_str = '+'.join(tmp)
    exec_str = "copy /b " + cmd_str + ' ' + o_file_name
    print("copy /b "+cmd_str+' '+o_file_name)

    os.system(exec_str)
    if not os.path.exists(o_file_name):
        print(2222222222222222, exec_str)
        print(2222222222222222, o_file_name)

def deal_one(input_dir, output_file_name):
    user_path = get_user_path(input_dir)
    os.chdir(user_path)
    boxer = get_sorted_ts(user_path)
    # for key in boxer:
    #     if key != boxer[key]:
    #         print(key)
    # boxer = boxer[500:]
    convert_m3u8(boxer, output_file_name)


if __name__ == '__main__':

    input_dir = "D:\\111111111\\Videos\\111111111111"
    output_file_name = "D:\\111111111\\111.mp4"
    deal_one(input_dir, output_file_name)

    # old_dirs = "D:\\111111111\\Videos\\"
    # new_dirs = "D:\\111111111\\new_Videos\\"
    # k = 0
    # for dir in os.listdir(old_dirs):
    #     k += 1
    #     if "qqv" in dir:
    #         file_name = dir.split("\\")[-1].replace("qqv", "mp4")
    #         input_dir = old_dirs + dir
    #         output_file_name = new_dirs + file_name.replace(" ", "").replace("-", "").replace(",","")
    #         if os.path.exists(output_file_name):
    #             # print('目标文件已存在，程序停止运行。')
    #             continue
    #         deal_one(input_dir, output_file_name)
    #     else:
    #         print(111111111111111, dir)

