def leijia(mylist):
    new_list = []
    temp = 0
    for x in mylist:
        temp = temp + x
        new_list.append(temp)
    return new_list


traffic = [[820, 240, 0, 24, 0, 66, 12, 0, 980, 0, 79, 100, 9, 37, 898], 3265]
eat = [[9, 353, 168, 150, 130, 450, 389, 360, 232, 484, 285, 239, 118, 346, 192], 3905]
stay = [[68, 280, 280, 231, 231, 133, 133, 133, 90, 176, 176, 219, 219, 219, 0], 2588]
play = [[0, 562, 906, 616, 660, 0, 504, 572, 10, 660, 283, 0, 570, 330, 0], 5673]
total = [traffic, eat, stay, play]
# [820, 1060, 1060, 1084, 1084, 1150, 1162, 1162, 2142, 2142, 2221, 2321, 2330, 2367, 3265]
# [9, 362, 530, 680, 810, 1260, 1649, 2009, 2241, 2725, 3010, 3249, 3367, 3713, 3905]
# [68, 348, 628, 859, 1090, 1223, 1356, 1489, 1579, 1755, 1931, 2150, 2369, 2588, 2588]
# [0, 562, 1468, 2084, 2744, 2744, 3248, 3820, 3830, 4490, 4773, 4773, 5343, 5673, 5673]
for term in total:
    term[0] = leijia(term[0])
    print(term[0])
    # print(term)
    # print(sum(term[0]))

# import matplotlib.pyplot as plt
#
# # labels = '交通', '吃', '住', '玩'  # 自定义标签
# labels = 'traffic', 'eat', 'stay', 'play'  # 自定义标签
# sizes = [3265, 3905, 2588, 5673]  # 每个标签占多大
# # explode = (0, 0.1, 0, 0)  # 将某部分爆炸出来
# plt.pie(sizes, explode=None, labels=labels, autopct='%1.2f%%', shadow=False, startangle=90)
# plt.axis('equal')
# plt.show()

########
import pandas_alive
import pandas as pd

covid_df = pd.read_csv('data.csv', index_col=0, parse_dates=[0])
print(1111, covid_df)
print(2222)
covid_df.plot_animated(filename='example.gif', n_visible=4)
