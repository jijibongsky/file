# 导入所需要的库
import cv2

data_dir = "/Users/sunkangkang/Downloads/未命名文件夹/视频/"
file_name = "IMG_65692.MOV"
cap = cv2.VideoCapture(data_dir + file_name)
frame_count = 1
success = True
while (success):
    success, frame = cap.read()
    params = []
    params.append(1)
    cv2.imwrite("{}IMG_65692/{}.jpg".format(data_dir, frame_count), frame, params)
    frame_count = frame_count + 1
    print(111111, frame_count)
cap.release()
