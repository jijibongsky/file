from gensim.models import KeyedVectors
import numpy as np
from time import time
import numba as nb

data_file_w = "/home/data/Tencent_ChineseEmbedding/Tencent_AILab_ChineseEmbedding1wan.txt"
wv_model = KeyedVectors.load_word2vec_format(data_file_w, binary=False)
wv_model.init_sims(replace=True)  # 神奇，很省内存，可以运算most_similar
word_dict = wv_model.wv.vocab.keys()
word_size = wv_model.wv.syn0[0].shape[0]


class WORD_SIM():
    def __init__(self, querys, docs):
        self.word2id = {}
        self.id2word = {}
        k = 0
        for word in querys + docs:
            if word not in self.word2id:
                self.word2id[word] = k
                self.id2word[k] = word
                k += 1

        query_matrix = [self.get_vec(self.id2word[id]) for id in range(len(set(querys)))]
        doc_matrix = [self.get_vec(self.id2word[id]) for id in range(len(self.id2word))]
        query_matrix = np.array(query_matrix)
        doc_matrix = np.array(doc_matrix)
        self.score = self.cosine(query_matrix, doc_matrix)

    def get_vec(self, word):
        if word in word_dict:
            vec = wv_model[word]
        else:
            vec = np.zeros(word_size, dtype=np.float32)
        return vec

    def cosine(self, vec1: np.ndarray, vec2: np.ndarray):
        dot_val = np.dot(vec1, vec2.T)
        modulus1 = np.linalg.norm(vec1, axis=-1, keepdims=True)
        modulus2 = np.linalg.norm(vec2, axis=-1, keepdims=True)
        cos_val = dot_val / (np.dot(modulus1, modulus2.T) + 1e-8)
        return cos_val

    def get_sim(self, word1, word2):
        id1 = self.word2id[word1]
        id2 = self.word2id[word2]
        return self.score[id1, id2]


# querys = ["我们", "自己", "就是"]
# docs = ["我们", "可以", "自己", "这个"]
fr = open("/home/data/fanyi_data/small_data/zh.txt")
docs = []
for line in fr:
    line = line.strip().split()
    docs.extend(line)
    if len(docs) > 10000:
        break

querys = ["我们", "自己", "就是"]
print(11111111, len(list(set(docs))))

begin_time = time()
word_sim = WORD_SIM(querys, docs)
k = 0
for word1 in querys:
    for word2 in docs:
        k += 1
        a = word_sim.get_sim(word1, word2)
        # print(word1, word2, a)
print(k, time() - begin_time)
