import numpy as np


def cosine(vec1: np.ndarray, vec2: np.ndarray):
    dot_val = np.dot(vec1, vec2.T)
    modulus1 = np.linalg.norm(vec1, axis=-1, keepdims=True)
    modulus2 = np.linalg.norm(vec2, axis=-1, keepdims=True)
    cos_val = dot_val / (np.dot(modulus1, modulus2.T) + 1e-8)
    return cos_val


def euclidean(vec1: np.ndarray, vec2: np.ndarray):
    shape1 = vec1.shape
    shape2 = vec2.shape
    assert shape1[1] == shape2[1]
    euc = np.linalg.norm(vec1 - vec2, axis=-1)
    return 1. / (1 + euc)


vec1 = np.random.random((2, 200))
vec2 = np.random.random((5, 200))
score1 = cosine(vec1, vec2)
print(1111111, score1)

# score2 = euclidean(vec1, vec2)
# print(2222222, score2)

