# data_file = "/home/data/Tencent_ChineseEmbedding/Tencent_AILab_ChineseEmbedding.txt"
# data_file_w = "/home/data/Tencent_ChineseEmbedding/Tencent_AILab_ChineseEmbedding100wan.txt"
# fr = open(data_file, "r", encoding="utf8")
# fw = open(data_file_w, "w", encoding="utf8")
# fw.write("999999 200\n")
# k = 0
# for line in fr:
#     k += 1
#     if k == 1:
#         continue
#     if k > 1000000:
#         break
#     fw.write(line)

from gensim.models import KeyedVectors
import numpy as np

data_file_w = "/home/data/Tencent_ChineseEmbedding/Tencent_AILab_ChineseEmbedding1wan.txt"
wv_model = KeyedVectors.load_word2vec_format(data_file_w, binary=False)
wv_model.init_sims(replace=True)  # 神奇，很省内存，可以运算most_similar
word_dict = wv_model.wv.vocab.keys()
# word_dict1 = wv_model.vocab
word_size = wv_model.wv.syn0[0].shape[0]

# a = wv_from_text.most_similar(positive=["我们"], topn=20)
# print("word_size", word_size)

def get_vec(word):
    if word in word_dict:
        vec = wv_model[word]
    else:
        vec = np.zeros(word_size, dtype=np.float32)
    return vec

b = get_vec("我们")
print(b)
