# coding=utf-8
# Copyright 2019/11/22 15:29 by ZTE
# Author: Kangkang Sun
# encoding: utf-8

import traceback
import logging

logger = logging.getLogger(__name__)

def ceshi(x):
    if x == 1:
        logger.warning("There is no valid test set file in dir {}, please check.".format(x))
    elif x == 2:
        logger.info("The useful test set file is {}.".format(x))
    elif x == 3:
        try:
            a = 1/0
        except Exception as e:
            logger.error("There are some bugs, please check!")
            logger.error(e)
            logger.error('traceback.format_exc():\n%s' % traceback.format_exc())


if __name__ == '__main__':
    ceshi(1)
