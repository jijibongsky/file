# coding=utf-8
# Copyright 2019/11/22 15:37 by ZTE
# Author: Kangkang Sun


import logging
import logging.handlers


from ceshi1 import ceshi

# 屏蔽第三方包的日志输出
logging.getLogger('pdfminer.pdfdocument').setLevel(logging.ERROR)
logging.getLogger('pdfminer.pdfpage').setLevel(logging.ERROR)
logging.getLogger('pdfminer.pdfinterp').setLevel(logging.ERROR)


# 总开关，控制多个文件
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# handler定义某一个日志文件
handler = logging.handlers.TimedRotatingFileHandler('./ceshi.log', when='D', interval=1, backupCount=30, encoding='UTF-8')
# handler = logging.handlers.TimedRotatingFileHandler('./shangfei.log', when='M', interval=1, backupCount=30, encoding='UTF-8')
handler.suffix = "%Y-%m-%d.log"
handler.setLevel(logging.INFO)
logging_format = logging.Formatter( '%(asctime)s - %(levelname)s - %(filename)s - %(funcName)s - %(lineno)s - %(message)s')
handler.setFormatter(logging_format)

# 把handler定义的日志文件加到总的日志中
logger.addHandler(handler)

ceshi(3)

