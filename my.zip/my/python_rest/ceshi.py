import base64
import cv2

#通过opencv转base64
img_im= cv2.imread("2222.jpg")
aa=base64.b64encode(cv2.imencode('.jpg', img_im)[1]).decode()
print(111, len(aa))  #17292


#通过bytes再转base64
bb=base64.b64encode(open("2222.jpg", 'rb').read())
print(222, len(bb))  #43848

