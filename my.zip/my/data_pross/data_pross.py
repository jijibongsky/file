import jieba
import re
from simplified_data.langconv import Converter


def load_punc(file):
    rfile = open(file, 'r', encoding='utf8')
    punc = []
    for line in rfile:
        line = line.strip()
        punc.append(line)
    return punc


def punc_uniform(sentence, punc):
    new_sentence = ""
    for w in sentence:
        if w not in punc:
            new_sentence += w
    return new_sentence


def jieba_fenci(sentence, number=False):
    words = jieba.cut(sentence)
    result = ""
    if number==False:
        for w in words:
            result += w + " "
    else:
        for w in words:
            if w.isdigit():
                result += "number" + " "
            else:
                result += w + " "
    result = re.sub(" +", " ", result)
    return result[:-1]


# 全角转半角
def strQ2B(ustring):
    rstring = ""
    for uchar in ustring:
        inside_code=ord(uchar)
        if inside_code == 12288:                              #全角空格直接转换
            inside_code = 32
        elif (inside_code >= 65281 and inside_code <= 65374): #全角字符（除空格）根据关系转化
            inside_code -= 65248
        rstring += chr(inside_code)
    return rstring


# 转换繁体到简体
def cht_to_chs(line):
     line = Converter('zh-hans').convert(line)
     line.encode('utf-8')
     return line


def pross_data(sentence, punc):
    sentence = sentence.replace(" ", "")
    sentence = cht_to_chs(sentence)  # 繁体转简体
    sentence = strQ2B(sentence)  # 全角转半角
    sentence = sentence.lower()  # 大写转小写
    sentence = jieba_fenci(sentence, True)
    sentence = punc_uniform(sentence, punc)  # 标点统一（去除标点）
    return sentence


def main(read_file, write_file, file_punc):
    punc = load_punc(file_punc)
    rfile = open(read_file, 'r', encoding='utf8')
    wfile = open(write_file, 'w', encoding='utf8')
    k = 0
    for line in rfile:
        k += 1
        if k == 1:
            continue
        new_line = line.strip().split("\t")
        if len(new_line) != 3:
            print(line.strip())
        else:
            sentence_one = pross_data(new_line[0], punc)
            sentence_two = pross_data(new_line[1], punc)
            wfile.write(sentence_one + "\t" + sentence_two + "\t" + new_line[2] + "\n")


if __name__ == '__main__':
    file_punc = 'punctuation.txt'
    root_dir = "/home/sun/deep_learning/text_matching/data/lcqmc/"
    read_file = root_dir + "train.tsv"
    write_file = root_dir + "train.txt"
    main(read_file, write_file, file_punc)

    # a = cht_to_chs('把中文字符串進行繁體和簡體中文的轉換')
    # print(a)

    # b = strQ2B('你\u3000好ｐｙｔｈｏｎ')
    # print("===", b)

    # punc = load_punc(file_punc)
    # print(punc)

    # str1 = "我们WEReee都是"
    # print(str1.lower())

    # str1 = "11abc"
    # print(str1.isnumeric())  # True if 只包含数字。注意：此函数只能用于unicode string
    # print(str1.isdigit())  # True if 只包含数字
    # print(str1.isalpha())  # True if 只包含字母
    # print(str1.isalnum())  # True if 只包含字母或者数字

    # str1 = "woe1234haha"
    # str2 = re.sub("\d+", "@@", str1)
    # print(str2)

