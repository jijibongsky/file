import numpy as np
from PIL import Image

# image_file = "data/2222.jpg"
# im = Image.open(image_file).convert('RGB')
# image_array = np.array(im, "int")
#
# print("---", image_array.dtype)
# print("---", type(image_array))
# print("---", image_array.shape)
# image_array = np.array(image_array, dtype=np.uint8)   # 保存图片要存成 uint8 格式
# Image.fromarray(image_array).save("data/ceshi.jpg")

image_file = "data/1111.PNG"
im = Image.open(image_file).convert('L')
# image_array = np.array(im)
image_array = np.array(im, "int")

print("---", image_array.dtype)
print("---", type(image_array))
print("---", image_array.shape)
# np.uinit8(a)
image_array = np.array(image_array, dtype=np.uint8)   # 保存图片要存成 uint8 格式
Image.fromarray(image_array).save("data/ceshi.jpg")