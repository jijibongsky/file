from PIL import Image
import numpy as np


im = Image.open("data/2222.jpg", "r")

# print(im.size, im.format, im.mode)
# print(im.getbbox())
# im.save("data/dog.png", 'png')
# im.thumbnail((200, 200), resample=Image.BICUBIC)  # 创建缩略图
# im.show()


# - Image.FLIP_LEFT_RIGHT, 表示将图像左右翻转
# - Image.FLIP_TOP_BOTTOM, 表示将图像上下翻转
# - Image.ROTATE_90, 表示将图像逆时针旋转90°
# - Image.ROTATE_180, 表示将图像逆时针旋转180°
# - Image.ROTATE_270, 表示将图像逆时针旋转270°
# - Image.TRANSPOSE, 表示将图像进行转置(相当于顺时针旋转90°)
# - Image.TRANSVERSE, 表示将图像进行转置, 再水平翻转
# im_rotate_180 = im.transpose(Image.FLIP_LEFT_RIGHT)
# im_rotate_180.show()


# 裁剪矩形区域（左上角x,y坐标,右下角的x,y坐标）
box = (0, 0, 400, 400)
region = im.crop(box)
region.show()
region.save("data/caijian.png", 'png')
#
# im.paste(region, (100, 100), None)  # 将region图像粘贴到左上角为(100,100)的位置
# im.show()


# 颜色通道分离
# r, g, b = im.split()
# r.show()
# g.show()
# b.show()

# im_merge = Image.merge("RGB", [r, g, b])  #颜色通道合并
# im_merge.show()


# im_resize = im.resize((200, 200))  # resize方法可以将原始的图像转换大小,size是转换之后的大小
# im_resize.show()
# im_resize_box = im.resize((100, 100), box=(0, 0, 400, 400))   # 裁剪 box 位置的图片，变换到（100,100）的大小
# im_resize_box.show()


# mode转换
# im_L = im.convert("L")
# im_L.show()
# im_rgb = im_L.convert("RGB")
# im_rgb.show()
# print(im_L.mode)
# print(im_rgb.mode)


# 在PIL.ImageFilter函数中定义了大量内置的filter函数，比如
# BLUR(模糊操作)
# GaussianBlur(高斯模糊)
# MedianFilter(中值过滤器)
# FIND_EDGES(查找边)等
# from PIL import ImageFilter
# im_blur = im.filter(ImageFilter.BLUR)
# im_blur.show()
# im_find_edges = im.filter(ImageFilter.FIND_EDGES)
# im_find_edges.show()


# 对图像像素操作
# im_point = im.point(lambda x:x*0.5)
# im_point.show()


# 例子1
# def ceshi(x):
#     if x < 100:
#         return 255
#     else:
#         return 0
# source = im.split()
# R, G, B = 0, 1, 2
# mask = source[R].point(lambda x: x<100 and 255)  # x<100,return 255,otherwise return 0
# # mask = source[R].point(lambda x: ceshi(x))  # x<100,return 255,otherwise return 0
# print(np.array(mask))
# out_G = source[G].point(lambda x:x*0.7)
# source[G].paste(out_G, None, mask)  # 将 out_G粘贴回来，但是只保留'R'通道像素值<100的部分
# source[G].show()
# im_new = Image.merge(im.mode, source)  # 合并成新的图像
# im_new.show()



# 例子2，图像增强, 增加亮度(Brightness),增加对比度(Contrast)
# from PIL import ImageEnhance
# brightness = ImageEnhance.Brightness(im)
# im_brightness = brightness.enhance(0.5)
# im_brightness.show()
# im_contrast = ImageEnhance.Contrast(im)
# im_contrast.enhance(1.5)
# im_contrast.enhance(1.5).show()


# from PIL import ImageSequence
# from PIL import Image
# gif = Image.open("data/3333.gif")
# for i, frame in enumerate(ImageSequence.Iterator(gif), 1):
#     if frame.mode == 'JPEG':
#         frame.save("data/data1/%d.jpg" %i)
#     else:
#         frame.save("data/data1/%d.png" % i)
