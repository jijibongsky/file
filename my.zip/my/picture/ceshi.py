from PIL import Image
# im1 = Image.open("data/2222.jpg")
# im2 = Image.open("data/22222.jpg")
# print(im1.mode, im1.size)
# print(im2.mode, im2.size)
#
# im_1 = im1.resize((500, 500))
# im_2 = im2.resize((500, 500))
# print(im_1.mode, im_1.size)
# print(im_2.mode, im_2.size)
# # out = image1 (1.0 - alpha) + image2 alpha
# # 若变量alpha为0.0，返回第一张图像的拷贝。若变量alpha为1.0，将返回第二张图像的拷贝
# im = Image.blend(im_1, im_2, 0.5)
# im.show()



from PIL import Image
im = Image.open("data/2222.jpg")
print(im.getbbox())
