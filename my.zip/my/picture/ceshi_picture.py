import cv2
import os
import numpy as np
from PIL import Image

input_dir = "/home/data/deep_learning/my/picture/"
im_fn = "fenjing.jpg"
output_dir = "/home/data/deep_learning/my/picture/data"

# image = cv2.imread(input_dir + im_fn)
# image = image[:, :, 0:1]
# cv2.imwrite(os.path.join(output_dir, im_fn), image)

# image = Image.open(input_dir+im_fn, "r")
# image = image.convert("RGB")
# # image = image.convert("L")
# image = np.array(image, "f")
# image = Image.fromarray(np.uint8(image))
# image.save(os.path.join(output_dir,im_fn))

# image = Image.new("RGB", (300, 300), (255, 255, 0))
# image.save(os.path.join(output_dir, "111.jpg"))

# image = np.zeros((1000, 1000))
# # image = np.zeros((1000, 1000)) + 255
# # image = np.zeros((1000, 1000, 3))
# image = Image.fromarray(np.uint8(image))
# image.save(os.path.join(output_dir, "111.jpg"))

# image=np.zeros((300,400)) + 255
image=np.zeros((300, 400, 3)) + 255
# image = np.zeros((300, 400, 3), np.uint8) + 255
# cv2.line(image, (10,200), (200, 200), color=(0, 255, 0), thickness=3, lineType=cv2.LINE_AA) #绿色，三个像素宽度
# cv2.imwrite(os.path.join(output_dir, im_fn), image)

# box = np.array([[10, 10], [100, 10]])
# box = np.array([[10, 10], [100, 10], [100, 100]])
box = np.array([[10, 10], [100, 10], [100, 100], [10,100]])
cv2.polylines(image, [box.astype(np.int32).reshape((-1, 1, 2))], True, color=(0, 255, 0), thickness=2)
cv2.imwrite(os.path.join(output_dir,im_fn), image)
