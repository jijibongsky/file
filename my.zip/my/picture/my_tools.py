# coding=utf-8
# Copyright 2019/12/3 16:47 by ZTE
# Author: Kangkang Sun

import cv2
import numpy as np
import os
from PIL import Image


# 获取一张图片的boxes
def get_one_boxes(label_fn):
    boxes = []
    fr = open(label_fn, "r", encoding="utf8")
    for line in fr:
        line = line.strip()
        if line == "":
            continue
        line = line.split(",")
        line = [int(i) for i in line[:8]]
        boxes.append(line)
    boxes = np.array(boxes)
    return boxes


# 在原图上画线
def plot_box(im_fn, boxes, output_dir):
    _, fn = os.path.split(im_fn)
    img = cv2.imread(im_fn)
    for i, box in enumerate(boxes):
        cv2.polylines(img, [box[:8].astype(np.int32).reshape((-1, 1, 2))], True, color=(0, 255, 0), thickness=2)

        # first_point = (box[0], box[1])
        # last_point = (box[4], box[5])
        # cv2.rectangle(img, first_point, last_point, (0, 255, 0), thickness=2)

    cv2.imwrite(os.path.join(output_dir, fn), img)


# 把标注的图形裁剪下来
def save_lines(image_file, boxes, output_dir):
    def save_line(image, position8, index):
        # 左上角坐标（距离左边距离和上边距离），和右下角坐标（距离左边距离和上边距离）
        # box = (position8[0], position8[1], position8[-2], position8[-1])
        box = (position8[0], position8[1], position8[4], position8[5])
        region = image.crop(box)
        # region.save("ceshi/_caijian{}.png".format(index), 'png')
        region_np = region.convert("RGB")  # 图像类型
        region_np = np.array(region_np, 'f')
        im2 = Image.fromarray(np.uint8(region_np))
        im2.save(os.path.join(output_dir, "_caijian{}.jpg".format(index)))

    image = Image.open(image_file, "r")
    for i, box in enumerate(boxes):
        save_line(image, box, i)


# 对图形 reshape
def reshape_picture(data_file_in, data_file_out, img_h=32):
    im = Image.open(data_file_in)
    (x, y) = im.size
    new_x = int(x/y*img_h)
    im = im.resize((new_x, img_h), Image.ANTIALIAS)  # resize image with high-quality
    im.save(data_file_out)


# 统计图片大小
def statistics_pixel(data_in):
    len_dict = {}
    for file in os.listdir(data_in):
        if file[-4:] != ".jpg":
            continue
        data_file_in = os.path.join(data_in, file)
        im = Image.open(data_file_in)
        (x, y) = im.size  # 宽度，高度
        if y not in len_dict:
            len_dict[y] = 1
        else:
            len_dict[y] += 1
    print(len_dict)
    len_dict = sorted(len_dict.items(), key=lambda d: d[1], reverse=True)
    for line in len_dict:
        print(line)


if __name__ == '__main__':
    output_dir = "/home/skk/ceshi/a_task/chinese_ocr/text_detection_ctpn/main/ceshi"
    im_dir = "/home/skk/ceshi/a_task/chinese_ocr/text_detection_ctpn/main/mlt_selected/image/"
    label_dir = "/home/skk/ceshi/a_task/chinese_ocr/text_detection_ctpn/main/mlt_selected/label/"
    im_fn = im_dir + "006.jpg"
    label_fn = label_dir + "006.txt"

    # 获取一张图片的boxes
    boxes = get_one_boxes(label_fn)

    # 在原图上画线
    plot_box(im_fn, boxes, output_dir)

    # 把标注的图形裁剪下来
    save_lines(im_fn, boxes, output_dir)

    # 对图形 reshape
    data_file_in = "/home/skk/ceshi/a_task/chinese_ocr/text_detection_ctpn/main/ceshi/_caijian0.jpg"
    data_file_out = "/home/skk/ceshi/a_task/chinese_ocr/text_detection_ctpn/main/ceshi/ceshi.jpg"
    reshape_picture(data_file_in, data_file_out, img_h=32)

    # 统计图片大小
    data_in = "/home/skk/ceshi/a_task/chinese_ocr/text_detection_ctpn/main/ceshi"
    statistics_pixel(data_in)
