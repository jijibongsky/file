# coding=utf-8
# Copyright 2019/5/24 11:02 by ZTE
# Author: Kangkang Sun

from PIL import Image
import numpy as np

image_path = "data/2222.jpg"
# image_path = "data/demo.jpg"
# im = Image.open(image_path, "r")
# im1 = np.array(im, 'f')
# im2 = Image.fromarray(np.uint8(im1))
# im2.save("data/dog.png", 'png')


# im = Image.open(image_path, "r").convert("RGB")
# im1 = np.array(im, 'f')
# im2 = Image.fromarray(np.uint8(im1))
# im2.save("data/dog.jpg")

img = Image.open("data/aaaa.jpg").convert('L')  # 图像类型
# img = np.array(img1, 'f') / 255.0 - 0.5  # 读出来的原始值在[0, 255] 之间
img1 = np.array(img, 'f')
im2 = Image.fromarray(np.uint8(img1))
im2.save("data/dog.jpg")



