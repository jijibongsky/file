x = 1
aa = "y=x+1"
exec(aa)
# print(y)


LOC = """ 
def factorial(num): 
    fact=1 
    for i in range(1,num+1): 
        fact = fact*i 
    return fact 
print(factorial({})) 
""".format(3)
exec(LOC)
