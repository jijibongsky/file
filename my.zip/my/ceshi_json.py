# coding=utf-8
# Copyright 2019/4/4 11:01 by ZTE
# Author: Kangkang Sun
import json

# data = [ { 'a': 1, 'b' : 2, 'c' : 3, 'd' : 4, 'e' : 5 } ]
# data = { 'a': 1, 'b' : 2, 'c' : 3, 'd' : 4, 'e' : 5 }
data = ['母婴', '房产', '美容', '娱乐', '交通', '健身', '美食', '闲聊', '旅游', '教育']
# a = json.dumps(data, ensure_ascii=False)
# b = json.loads(a)
# print("a===", type(a), a)
# print("b===", type(b), b)

with open('/home/skk/test.json', 'w', encoding="utf8") as f:
    json.dump(data, f, indent=4, ensure_ascii=False)
with open('/home/skk/test.json', 'r', encoding="utf8") as f:
    data = json.load(f)
    print("data===", type(data), data)
