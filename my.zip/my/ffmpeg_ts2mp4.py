# ffmpeg -i x.ts  -c copy x.mp4
# ffmpeg -y -i x.ts -c:v libx264 -c:a copy -bsf:a aac_adtstoasc x.mp4

import os

filepath = "/Users/sunkangkang/Downloads/aaa"
a = [f for f in os.listdir(filepath) if f[-3:] == ".ts"]
file_list = sorted(a)
with open("{}/file_list.txt".format(filepath), "w+") as f:
    for file in file_list:
        f.write("file '{}'\n".format(file))

# ffmpeg -f concat -i file_list.txt -c copy output.mp4