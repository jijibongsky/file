import os

def read(data_file, save_file):
    fobj = open(data_file, 'r', encoding='utf8')
    file = open(save_file, 'w', encoding='utf-8')
    k = -1
    for line in fobj:
        k += 1
        # print(line.strip())
        file.write(line)
        if k > 100:
            return

corpus = "D:\我的文件\data\大语料"
data_file = os.path.join(corpus, 'common_data_fenci.txt')
save_file = os.path.join(corpus, 'ceshi.txt')
read(data_file,save_file)