import jieba
from time import time
import re


def jieba_fenci(content):
    content = re.sub(' +', ' ', content)
    seg_list = jieba.cut(content)
    corpus = " ".join(seg_list)
    corpus = re.sub(' +', ' ', corpus)
    return corpus


def read_write(read_file, write_filw):
    read_in = open(read_file,'r',encoding='utf8')
    write_out = open(write_filw,'w',encoding='utf8')
    for line in read_in:
        result = jieba_fenci(line.strip())
        write_out.write(result+"\n")
    read_in.close()
    write_out.close()


# jieba.load_userdict("/home/skk/translate_data/userdict.txt")
content = "有 哪个 大家 默认 肯定 没人能 解释 清楚 ， 而 实际上 科学家 已经 搞懂 了 的 问题 "
content = content.replace(" ", "")
content = jieba_fenci(content)
print(content)

# read_file = "/home/skk/translate_data/data/weibo_encode.txt"
# write_filw = "/home/skk/translate_data/data/weibo_encode_seg.txt"
# read_write(read_file, write_filw)
