# coding=utf-8
# Copyright 2019/1/9 15:40 by ZTE
# Author: Kangkang Sun
import jieba


def fenzi(text):
    # 判断是不是全是中文
    def check_all_chinese(check_str):
        for ch in check_str:
            if ch < u'\u4e00' or ch > u'\u9fff':
                return False
        return True
    seg_words = jieba.cut(text)
    words = []
    for word in seg_words:
        if word == " ":
            continue
        if check_all_chinese(word):
            words.append(" ".join(word))
        else:
            words.append(word)
    new_text = " ".join(words)
    return new_text

text1 = "输入繁体字，点下面i love you      的繁体字按钮进行转换"
new_text = fenzi(text1)
print("new_text", new_text)