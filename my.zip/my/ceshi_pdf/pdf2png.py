# coding=utf-8
# Copyright 2019/9/17 18:52 by ZTE
# Author: Kangkang Sun

from pdf2image import convert_from_path
import tempfile
import multiprocessing
import os
from time import time


class PdfToImage_multiprocessing():
    def __init__(self, pdf, img):
        self.pdf = pdf
        self.img = img

    def convers(self, fileName, outputDir):
        # pdf转图片核心，自行学习pdf2image库
        with tempfile.TemporaryDirectory() as path:
            images = convert_from_path(fileName, dpi=100, output_folder=outputDir, fmt='jpeg')
            # for index, img in enumerate(images):
            #     print(index)
            #     img.save('%s/page_%s.png' % (outputDir, index))

    def main(self, processes=4):
        # 创建进程池
        pool = multiprocessing.Pool(processes=processes)
        for fileName in os.listdir(self.pdf):
            if fileName[-4:] != ".pdf":
                # print(111, fileName)
                continue
            dirName = fileName[:-4]
            dirPath = os.path.join(self.img, dirName)
            if os.path.exists(dirPath):
                # os.removedirs(dirPath)
                os.system("rm -rf {}".format(dirPath))
            print(dirPath)
            os.mkdir(dirPath)
            outputDir = dirPath
            fileName = self.pdf + '/' + fileName
            # 调用进程池进行转换
            pool.apply_async(self.convers, args=(fileName, outputDir))
        # 关闭进程池，回收进程
        pool.close()
        pool.join()


class PdfToImage():
    def __init__(self, pdf, img):
        self.pdf = pdf
        self.img = img

    def convers(self, fileName, outputDir):
        # pdf转图片核心，自行学习pdf2image库
        with tempfile.TemporaryDirectory() as path:
            images = convert_from_path(fileName, dpi=100, output_folder=outputDir, fmt='jpeg')
            # for index, img in enumerate(images):
            #     print(index)
            #     img.save('%s/page_%s.png' % (outputDir, index))

    def main(self):
        for fileName in os.listdir(self.pdf):
            if fileName[-4:] != ".pdf":
                # print(111, fileName)
                continue
            dirName = fileName[:-4]
            dirPath = os.path.join(self.img, dirName)
            if os.path.exists(dirPath):
                os.system("rm -rf {}".format(dirPath))
            print(dirPath)
            os.mkdir(dirPath)
            outputDir = dirPath
            fileName = self.pdf + '/' + fileName
            print("fileName", fileName)
            print("outputDir", outputDir)
            self.convers(fileName, outputDir)


if __name__ == '__main__':
    pdf = "/home/data/deep_learning/temp/EO-SSPL"
    img = "/home/data/deep_learning/temp/result"

    pdftoimg = PdfToImage_multiprocessing(pdf, img)
    begin_time = time()
    pdftoimg.main(processes=10)
    print(time()-begin_time)

    # pdftoimg = PdfToImage(pdf, img)
    # begin_time = time()
    # pdftoimg.main()
    # print(time()-begin_time)
