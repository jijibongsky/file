# coding=utf-8
# Copyright 2019/9/17 16:53 by ZTE
# Author: Kangkang Sun

import pdfplumber
from pdf2image import convert_from_path
import tempfile
from time import time


def pdf2txt(file):
    pdf = pdfplumber.open(file)
    page_count = len(pdf.pages)
    wenjian = []
    print(page_count)
    for page in pdf.pages:
        a = page.extract_text()
        wenjian.append(a)
    wenjian = "\n".join(wenjian)
    return wenjian


def pdf2png(filename, outputDir):
    print('filename=', filename)
    print('outputDir=', outputDir)
    with tempfile.TemporaryDirectory() as path:
        images = convert_from_path(filename, dpi=100, output_folder=outputDir, fmt='jpeg')

        # images = convert_from_path(filename)
        # for index, img in enumerate(images):
        #     print(index)
        #     img.save('%s/page_%s.png' % (outputDir, index))


if __name__ == '__main__':
    root_dir = "/home/data/deep_learning/temp/EO-SSPL/"
    output_dir = "/home/data/deep_learning/temp/ceshi"
    pdffilename = root_dir + "EO_225A4100-000-001_EO3_009.pdf"

    wenjian = pdf2txt(pdffilename)
    print(wenjian)

    # begin_time = time()
    # pdf2png(pdffilename, output_dir)   # linux 可运行，windows有问题
    # print(time()-begin_time)
