# -*- encoding:utf-8 -*-
import sys
import os
import pickle
from time import time
from textrank4zh import TextRank4Keyword, TextRank4Sentence


def load_data(data_file_in, num_line, flag_list=False):
    fr = open(data_file_in, "r", encoding="utf8")
    lines = []
    k = 0
    for line in fr:
        line = line.strip()
        k += 1
        if k > num_line:
            if flag_list:
                return lines
            else:
                return "".join(lines)
        lines.append(line)
    if flag_list:
        return lines
    else:
        return "".join(lines)


def save(data, fname):
    pickle.dump(data, open(fname, "wb"), protocol=2)

def load(fname):
    data = pickle.load(open(fname, "rb"))
    return data

num_line = 100000
data_file_in = "/home/data/deep_learning/key_words/data/ai_zh.txt"
model_path = "ceshi.model.pkl"

if not os.path.exists(model_path):
    text = load_data(data_file_in, num_line=num_line, flag_list=False)
    begin_time1 = time()
    tr4w = TextRank4Keyword()
    tr4w.analyze(text=text, lower=True, window=2)  # py2中text必须是utf8编码的str或者unicode对象，py3中必须是utf8编码的bytes或者str对象
    print("训练模型花费时间：{}".format(time() - begin_time1))
    save(tr4w, model_path)
else:
    tr4w = load(model_path)

# for item in tr4w.get_keywords(20, word_min_len=2):
#     print(item.word, item.weight)

begin_time = time()
keyphrases = tr4w.get_keyphrases(keywords_num=20000, min_occur_num=2)
print("花费时间：{}".format(time() - begin_time))

for phrase in keyphrases:
    print(phrase)
