# coding:utf-8
# CreatDate: 2021/10/26 14:19 by ZTE
# Author: Kangkang Sun

import asyncio
import pickle
import websockets
import json
from pydub import AudioSegment
import numpy as np
import time
from io import BytesIO


def get_data():
    sound = AudioSegment.from_file(path, format="wav")
    wavform = np.frombuffer(sound.get_array_of_samples(), dtype=np.int16)
    wavform1 = [int(i) for i in wavform]
    interval = 0.5
    for i in range(0, len(wavform1), int(interval * 16000)):
        start_id = i
        end_id = min(len(wavform1), int(i + interval * 16000))
        T_wavform = wavform1[start_id:end_id]
        yield T_wavform
        # time.sleep(interval * 2)
        time.sleep(interval)


async def start(websocket):
    start_tag = {"signal": "start", "nbest": 1, "continuous_decoding": False}
    start_tag = json.dumps(start_tag)
    await websocket.send(start_tag)
    response_str = await websocket.recv()
    print(1111111, response_str)


async def stop(websocket):
    stop_tag = {"signal": "end"}
    stop_tag = json.dumps(stop_tag)
    if stop_tag == "exit":
        await websocket.close(reason="user exit")
    await websocket.send(stop_tag)
    recv_text = await websocket.recv()
    print(1111111, recv_text)


async def recognize(websocket):
    # stop_tag = {"signal": "end"}
    # stop_tag = json.dumps(stop_tag)

    data_list = get_data()
    for data in data_list:
        import struct
        dataStr = b''
        for uint_16t in data:
            dataStr += struct.pack('h', uint_16t)

        await websocket.send(dataStr)
        recv_text = await websocket.recv()

        # recv_text = websocket.recv()
        print(2222222, recv_text)

    recv_text = await websocket.recv()
    print(2222222, recv_text)


# 客户端主逻辑
async def main_logic():
    async with websockets.connect('ws://localhost:10086') as websocket:
        await start(websocket)
        await recognize(websocket)
        await stop(websocket)


# reader.readAsArrayBuffer(blob)
path = "/home/vca/skk/data/ASR/data/data_aishell/data_aishell/wav/test/S0764/BAC009S0764W0402.wav"
asyncio.get_event_loop().run_until_complete(main_logic())

# arr = [0, 0, 0, 0, 0, 6, 0, 4, 0, 0, 0, 32]
# arr=np.array(arr)
# compressed_array = BytesIO()
# np.savez_compressed(compressed_array, arr)
# compressed_array.seek(0)
# print(111111, compressed_array)
# print(111111, compressed_array.getbuffer())
