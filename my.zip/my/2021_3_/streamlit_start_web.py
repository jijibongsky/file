# coding:utf-8
# CreatDate: 2022/4/27 16:35 by ZTE
# Author: Kangkang Sun
import streamlit as st
import base64

import io
import time
import plotly_express as px
from flask import json
import requests
from PIL import Image
import numpy as np

from my_tools.tools import get_result, format_func, format_func_field
from my_tools.tools import decode_image_file_and_save, ocr_infer_one
from my_tools.tools import detface_infer_one
from my_tools.tools import decoded_wav
from my_tools.tools import encode_wav_file


# st.title("中兴通讯自然语言处理演示页面")
# st.header("中兴通讯自然语言处理演示页面")
# st.subheader("中兴通讯自然语言处理演示页面")
# st.info("中兴通讯自然语言处理演示页面")    # 会自动忽略换行符
# st.warning("中兴通讯自然语言处理演示页面")
# st.write("中兴通讯自然语言处理演示页面")   # 会自动忽略换行符
# st.markdown('中兴通讯自然语言处理演示页面')
# '中兴通讯自然语言处理演示页面'
# st.markdown('')

# st.info("""1. 中兴通讯自然语言处理演示页面
# 2. 11111111111111111111111
# """)
# st.info("""中兴通讯自然语言处理演示页面
# 11111111111111111111111
# """)    # 会自动忽略换行符

def main():
    readme_text = st.title("中兴通讯AI能力演示页面")

    # st.sidebar.title("What to do")
    app_mode = st.sidebar.selectbox("模型选择",
                                    ["自然语言处理",
                                     "人脸识别&OCR",
                                     "语音识别&语音合成"])
    if app_mode == "自然语言处理":
        # readme_text.empty()
        nlp()
    elif app_mode == "人脸识别&OCR":
        # readme_text.empty()
        det_face()
        ocr()
    elif app_mode == "语音识别&语音合成":
        # readme_text.empty()
        # run_the_app()
        tts()
        asr()


def nlp():
    st.image("/home/vca/skk/code/temp/streamlit_20220505/logo.PNG",
             width=600)  # st.sidebar.image
    text_input = st.text_input('请输入文本')
    option = st.selectbox('请选择任务',
                          ["match", "ner", "seg", "sentiment",
                           "news_classification",
                           "news_summary"],
                          0,
                          format_func,
                          )  # 下拉框选择

    # if st.checkbox('识别'):  # 这是一个框，选上后就是 yes
    # print(111111111111111111, text_input, option)
    result = get_result(text_input, option)
    # st.write('识别结果:', result)
    st.info("识别结果:{}".format(result))


def det_face():
    st.subheader("")
    st.subheader("中兴通讯人脸检测演示")
    w = st.file_uploader("人脸检测图片上传", type="jpg")
    if w:
        result, old_image = detface_infer_one(w)
        # st.code("""result:\n{}""".format(result["result"]), "Python")
        img_str = decode_image_file_and_save(result["return_picture"])
        # st.image(img_str, width=1000)
        st.image(old_image)
        st.image(img_str)


def ocr():
    st.subheader("")
    st.subheader("中兴通讯OCR演示")
    w = st.file_uploader("OCR图片文件", type="jpg")
    # w = st.file_uploader("Upload a wav file", type="wav")
    # print(2222222222, w.name)  # 001.jpg
    if w:
        result = ocr_infer_one(w)
        st.code("""result:\n{}""".format(result["result"]), "Python")
        # out_put_file = "/home/vca/skk/code/paddle/PaddleOCR_210703/output/ceshi.jpg"
        # decode_image_file_and_save(result["return_picture"], out_put_file)
        # st.image(out_put_file, width=1000)
        img_str = decode_image_file_and_save(result["return_picture"])
        st.image(img_str, width=1000)


def tts():
    st.subheader("")
    st.subheader("中兴通讯语音合成演示")
    text_input_tts = st.text_input('请输入需要合成的文本')
    if text_input_tts:
        res = requests.post(url='http://10.229.89.98:8815/TTS',
                            json={'sentence': text_input_tts})
        result = json.loads(res.text)
        # file_name = "/home/vca/skk/code/paddle/PaddleSpeech_211227/demos/text_to_speech/results/ceshi.wav"
        wav_decode = decoded_wav(result["result"])
        st.audio(wav_decode)


def asr():
    st.subheader("")
    st.subheader("中兴通讯语音识别演示")
    w = st.file_uploader("请上传语音文件", type=["wav"])
    if w:
        from pydub import AudioSegment

        sound = AudioSegment.from_file(w, format="wav")
        print(111111, sound)

        AUDIO_FILE = "ceshi.wav"
        sound.export(AUDIO_FILE, format='wav')

        fileName = w.name
        FORMAT = fileName[-3:]
        speech, length = encode_wav_file(AUDIO_FILE)
        post_data = {
            'speech': speech,
            'fileName': fileName,
            'format': FORMAT,
            # 'rate': RATE,
            # 'channel': 1,
            # 'len': length,
        }
        res = requests.post(url='http://10.229.89.98:8817/ASR', json=post_data)
        result = json.loads(res.text)
        # print("result", result)
        st.code("""result:\n{}""".format(result["result"][0]), "Python")


def ceshi():
    # 录音有问题
    from ipywebrtc import CameraStream, AudioRecorder
    camera = CameraStream(constraints={'audio': True, 'video': False},
                          mimeType='audio/wav')
    recorder = AudioRecorder(stream=camera)
    print(11111111, recorder)
    recorder.recording = True
    print(22222222, recorder)
    # say something
    time.sleep(2)
    recorder.recording = False
    print(33333333, recorder)

    try:
        recorder.save('test.wav')
        st.audio('test.wav')
    except:
        print(11111111, "save error")


# # 侧边栏，下拉框
# add_selectbox = st.sidebar.selectbox('How would you like to be contacted?', ('Email', 'Home phone', 'Mobile phone'))

# conda activate wenet
# streamlit run start_web.py
if __name__ == '__main__':
    main()

# conda activate wenet
# cd /home/vca/skk/code/temp/streamlit_20220505
# streamlit run start_web.py
# nohup streamlit run  start_web.py >2022.5.13.out
