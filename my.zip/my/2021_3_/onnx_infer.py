# coding:utf-8
# CreatDate: 2022/4/13 12:46 by ZTE
# Author: Kangkang Sun
import time
import onnxruntime as ort
import numpy as np
from paddle import inference

# os.environ["CUDA_VISIBLE_DEVICES"] = "1"
# docker run -v /home:/home --cpuset-cpus="0" -it onnxocr_cpu:v1 /bin/bash

def onnx_infer():
    model_file_path_det = "/home/vca/skk/code/paddle/ONNXRunTimeOCR/inference_model/onnx11/det_db/model.onnx"
    sess_det = ort.InferenceSession(model_file_path_det)
    input_tensor = sess_det.get_inputs()[0]
    img = np.random.rand(1, 3, 640, 640).astype(np.float32)
    input_dict = {}
    input_dict[input_tensor.name] = img
    outputs = sess_det.run(None, input_dict)
    print(1111111, outputs[0].shape)

def create_predictor(model_dir, use_gpu, gpu_mem):
    model_file_path = model_dir + "/inference.pdmodel"
    params_file_path = model_dir + "/inference.pdiparams"
    config = inference.Config(model_file_path, params_file_path)
    if use_gpu:
        config.enable_use_gpu(gpu_mem, 0)
    else:
        config.disable_gpu()
        config.set_cpu_math_library_num_threads(1)

    # enable memory optim
    config.enable_memory_optim()
    config.disable_glog_info()
    config.delete_pass("conv_transpose_eltwiseadd_bn_fuse_pass")
    config.switch_use_feed_fetch_ops(False)

    # create predictor
    predictor = inference.create_predictor(config)
    input_names = predictor.get_input_names()
    for name in input_names:
        input_tensor = predictor.get_input_handle(name)
    output_names = predictor.get_output_names()
    output_tensors = []
    for output_name in output_names:
        output_tensor = predictor.get_output_handle(output_name)
        output_tensors.append(output_tensor)
    return predictor, input_tensor, output_tensors

def ceshi_paddle_det(det_predictor, det_input_tensor, det_output_tensors):
    img = np.random.rand(1, 3, 640, 640).astype(np.float32)
    begin_time = time.time()
    for i in range(10):
        det_input_tensor.copy_from_cpu(img)
        det_predictor.run()
        outputs = []
        for output_tensor in det_output_tensors:
            output = output_tensor.copy_to_cpu()
            outputs.append(output)
        preds = {"maps": outputs[0]}
    print(11111111, time.time() - begin_time)
    print(22222222, preds.keys(), preds["maps"].shape())

model_dir = "/home/vca/skk/code/paddle/PaddleOCR_210703/inference/ch_db_mv3_DPC2"
use_gpu = True
gpu_mem = 5000
det_predictor, det_input_tensor, det_output_tensors = create_predictor(model_dir, use_gpu, gpu_mem)
ceshi_paddle_det(det_predictor, det_input_tensor, det_output_tensors)
