# coding:utf-8
# CreatDate: 2022/7/21 10:27 by ZTE
# Author: Kangkang Sun
import os

file_path = "/var/www/project/logs/projectpom.log"
filepath, tempfilename = os.path.split(file_path)  # 拆分路径和文件
filename, extension = os.path.splitext(tempfilename)  # 拆分文件名和后缀
print("文件路径 ", filepath)
print("文件名（全） ", tempfilename)
print("文件名 ", filename)
print("文件后缀    ", extension)
