# coding:utf-8
# CreatDate: 2021/12/16 11:07 by ZTE
# Author: Kangkang Sun

import requests
import os
from getTk import ctx

wordlist = ["I wish to enable all of the users to enjoy 1080P at all times",
            "I wish to enable all high value areas to enjoy 1080P"]

log = open("log.txt", "a", encoding="utf-8")
for word in wordlist:
    file_name = "mp3/" + word.replace(" ", "_").replace(".", "").replace(",", "") + ".mp3"
    if os.path.exists(file_name):
        continue
    word2 = word
    # url = "https://translate.google.cn/translate_tts?ie=UTF-8&q=" + word2 + "&tl=la&total=1&idx=0&textlen=" + str(len(word)) + "&tk=" + ctx.call("TL", word) + "&client=webapp"
    url = "https://translate.google.cn/translate_tts?ie=UTF-8&q=" + word2 + "&tl=en&total=1&idx=0&textlen=" + str(len(word)) + "&tk=" + ctx.call("TL", word) + "&client=webapp"
    try:
        newfile = open(file_name, "wb")
        context = requests.get(url, timeout=3000)
        for data in context.iter_content(chunk_size=1024):
            if data: newfile.write(data)
        newfile.close()
        log.write(word + "\r\n")
        log.flush()
        a = "ffmpeg -i {} -acodec pcm_s16le -ac 1 -ar 16000 {}".format(file_name, file_name.replace("mp3", "wav"))
        os.system(a)
    except:
        log.write(word + "-wrong" + "\r\n")
        log.flush()
        continue
