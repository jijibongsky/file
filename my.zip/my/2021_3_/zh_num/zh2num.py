# coding:utf-8
# CreatDate: 2021/8/31 10:34 by ZTE
# Author: Kangkang Sun

import re

CN_NUM = {'〇': 0, '一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8, '九': 9,
          '零': 0, '壹': 1, '贰': 2, '叁': 3, '肆': 4, '伍': 5, '陆': 6, '柒': 7, '捌': 8, '玖': 9,
          '貮': 2, '两': 2}
CN_UNIT = {'十': 10, '拾': 10, '百': 100, '佰': 100, '千': 1000, '仟': 1000, '万': 10000, '萬': 10000, '亿': 100000000,
           '億': 100000000}
UNIT_CN1 = {10000: '万', 100000000: '亿'}
CN_UNIT1 = {'万': 10000, '亿': 100000000}
CN_UNIT2 = {'百': 100, '佰': 100, '千': 1000, '仟': 1000, '万': 10000, '萬': 10000, '亿': 100000000, '億': 100000000}

regex_num = '[〇一二三四五六七八九零壹贰叁肆伍陆柒捌玖貮两十拾百佰千仟万萬亿億]{1,}点儿{0,1}[一二三四五六七八九零]{1,}|[〇一二三四五六七八九零壹贰叁肆伍陆柒捌玖貮两十拾百佰千仟万萬亿億]{1,}'

def cn2numlist(cn):
    lcn = list(cn)
    unit = 0  # 当前的单位
    ldig = []  # 临时数组
    while lcn:
        cndig = lcn.pop()  # 从后往前
        if cndig in CN_UNIT:
            unit = CN_UNIT.get(cndig)
            if unit in UNIT_CN1:
                ldig.append(UNIT_CN1[unit])
                unit = 1
        else:
            dig = CN_NUM.get(cndig)
            if unit:
                dig = dig * unit
                unit = 0
            ldig.append(dig)
    # 处理10-19的数字。十前面没有数字
    if unit == 10:
        ldig.append(10)
    return ldig


def numlist2num(numlist):
    ret = 0
    tmp = 0
    # '一百二十三万四千五百六十七'  1234567,
    while numlist:
        x = numlist.pop()
        if x in CN_UNIT1:
            tmp *= CN_UNIT1[x]
            ret += tmp
            # ret = (ret + tmp) * CN_UNIT1[x]
            tmp = 0
        else:
            tmp += x
    ret += tmp
    return ret


def only_num(cn):
    # '一三一四'
    temp = ""
    for w in cn:
        if w in CN_NUM:
            temp += str(CN_NUM[w])
        else:
            return
    return int(temp)


def deal_with_spoken(cn):
    num_end = None
    # 处理口语话表述，如：'七百五', '两七百五', '七万五',
    if len(cn) >= 3 and cn[-3] in CN_NUM and cn[-1] in CN_NUM and cn[-2] in CN_UNIT2:
        num = CN_NUM[cn[-3]] * CN_UNIT2[cn[-2]] + CN_NUM[cn[-1]] * CN_UNIT2[cn[-2]] / 10
        num_end = int(num)
        cn = cn[:-3]
    # '一千零十',  '一千零十一',
    if "零十" in cn[-3:]:
        if "零十" == cn[-2:]:
            cn = cn[:-2]
            num_end = 10
        else:
            num_end = 10 + CN_NUM[cn[-1]]
            cn = cn[:-3]
    return num_end, cn


def cn2int(cn):
    if cn.strip() == "":
        return ""
    # 特殊情况处理
    # 纯数字，如：'一三一四'
    num = only_num(cn)
    if num:
        return str(num)

    # 处理口语话表述，如：'七百五', '两七百五', '七万五',  # '一千零十',  '一千零十一',
    num_end, cn1 = deal_with_spoken(cn)
    if num_end:
        cn = cn1

    numlist = cn2numlist(cn)

    ret = numlist2num(numlist)
    if num_end:
        ret = ret + num_end
    return str(ret)


def cn2num(cn):
    if "点" in cn:
        cn = cn.replace("点儿", "点")
        new_cn = cn.split("点")
        ret1 = cn2int(new_cn[0])
        ret2 = cn2int(new_cn[1])
        ret = "{}.{}".format(ret1, ret2)
        # ret = " {}.{} ".format(ret1, ret2)
    else:
        ret = cn2int(cn)
        # ret = " {} ".format(ret)
    return ret


def end2end_cn2num(sentence):
    candidate_number = re.findall(regex_num, sentence)
    candidate_number = sorted(candidate_number, key=lambda d: len(d), reverse=True)
    for cn in candidate_number:
        num = cn2num(cn)  # 返回的是字符串
        sentence = sentence.replace(cn, num)
    return sentence


if __name__ == '__main__':
    # 同样基于中国数字4位一节的习惯，从后往前读取数字，遇到“个”“十”“百”“千”的直接将前一个数字（即下一个pop出来的数字）乘以位数，
    # 先写到一个临时数组里；遇到逢4的位，即“万”“亿”“兆”这种，把单位写进临时数组，最后再统一读出数组，进行累加。
    # 同样有一些特殊情况需要注意：
    # 口语中“一万五”、“一千五”的“五”在最高位减一位而不是个位；
    # 口语中可能会说“一千零十”而不是“一千零一十”，注意“零十”的情况；
    # 未考虑输入“一三一四”、“五万五亿九”这种错误输入情况。

    test_dig = [
        # '九',
        # '十一',
        # '一百二十三',
        # '一千二百零三',
        # '两千二百零三',
        # '一万一千一百零一',
        # '十万零三千六百零九',
        # '一百二十三万四千五百六十七',
        # '一千一百二十三万四千五百六十七',
        # '一亿一千一百二十三万四千五百六十七',
        # '一百零二亿五千零一万零一千零三十八',
        # '一千一百一十一亿一千一百二十三万四千五百六十七',
        # '一三一四',
        # '七百五',
        # '两千七百五',
        # '七万五',
        # '一千零十',
        # '一千零十一',
        # '零',
        # '三点五',
        # '一百二十三万四千五百六十七点一二',
    ]
    # for sen in test_dig:
    #     a = cn2num(sen)
    #     print(44444444, sen, a)
    #     print()

    # 端到端
    # # sentence = "我有二十三点五块钱，你有七百五"
    # # sentence = "我有零点5块钱，你有七百五"
    # sentence = "我有三点儿五块钱，你有七百五"
    # sentence = "今天天气怎么样"
    # sentence = "我有三点五元"
    sentence = '五百六十分。'
    # sentence = '五十六十分。'
    # sentence = '十分二百三十'
    new_sentence = end2end_cn2num(sentence)
    print(new_sentence)
