# coding:utf-8
# CreatDate: 2021/11/29 16:11 by ZTE
# Author: Kangkang Sun

"""
ffmpeg -i 6月12日20点10分.aac \
-acodec pcm_s16le -ac 1 -ar 16000 \
6月12日20点10分.wav
"""
