# coding=utf-8
# Copyright 2020/8/31 11:20 by ZTE
# Author: Kangkang Sun
import librosa
import numpy as np


def add_noise(my_path, noise_path, output_path, SNR=None):
    """
    输入噪声和信号，按照一定的信噪比将两者叠加，输出含有噪声的信号
    噪声长度大于音频：随机从噪声中截取音频长度的数据
    噪声长度小于音频：首先随机截取后拼接噪声，然后同上处理
    """
    n, sr_n = librosa.load(noise_path, sr=16000)
    x, sr_x = librosa.load(my_path, sr=16000)
    if x.size < n.size:
        # 计算叠加噪声的随机区间
        header_pointer = np.random.random_integers(0, n.size - x.size - 1)
        orig_noise = n[header_pointer:x.size + header_pointer]
        # 计算噪声和音频强度
        if not SNR:
            SNR = np.random.uniform(snr_low, snr_high)  # 随机在定义的区间选择信噪比
        trimed_x = x[librosa.amplitude_to_db(x, ref=1.0) > db_thresh]  # 计算音频强度
        P_signal = np.sum(trimed_x ** 2) / trimed_x.size
        trimed_n = orig_noise[librosa.amplitude_to_db(orig_noise, ref=1.0) > db_thresh]  # 计算噪声强度
        P_noise = np.sum(trimed_n ** 2) / trimed_n.size
        noise = orig_noise * (P_signal / (10 ** (SNR / 10) * P_noise)).astype('float32')
    else:
        # 计算噪声和音频强度
        if not SNR:
            SNR = np.random.uniform(snr_low, snr_high)  # 随机在定义的区间选择信噪比
        trimed_x = x[librosa.amplitude_to_db(x, ref=1.0) > db_thresh]  # 计算音频强度
        P_signal = np.sum(trimed_x ** 2) / trimed_x.size
        trimed_n = n[librosa.amplitude_to_db(n, ref=1.0) > db_thresh]  # 计算噪声强度
        P_noise = np.sum(trimed_n ** 2) / trimed_n.size

        len_slice_noise = int(n.size * cutoff_ratio)  # 每一次随机选择的噪声长度
        raw_noise = np.array([]).astype('float32')
        for i in range(x.size // len_slice_noise + 2):
            header_pointer = np.random.random_integers(0, int(n.size - len_slice_noise) - 2)
            raw_noise = np.append(raw_noise, n[header_pointer:len_slice_noise + header_pointer])  # 每一步截取噪声的区间

        header_pointer = np.random.random_integers(0, raw_noise.size - x.size - 1)
        orig_noise = raw_noise[header_pointer:x.size + header_pointer]

        # 生成含有噪声的信号
        noise = orig_noise * (P_signal / (10 ** (SNR / 10) * P_noise))
    librosa.output.write_wav(output_path, x + noise, 16000)
    return


snr_low = -8  # snr_low:信噪比下限
snr_high = 4  # snr_high:信噪比上限
db_thresh = -45  # db_thresh:信号强度阈值，大于阈值的信号才会被用来计算信号强度
cutoff_ratio = 0.4  # cutoff:在噪声小于信号长度时，采用截断选择信号的比例（小于0.5）
my_path = "/home/vca/skk/data/ASR/data/data_aishell/data_aishell/wav/test/S0764/BAC009S0764W0402.wav"
noise_path = "/home/vca/skk/data/ASR/data/data_aishell/data_aishell/wav/noise/factory1.wav"
SNR = 4

output_path = "1.wav".format(SNR)
add_noise(my_path, noise_path, output_path, SNR=SNR)
