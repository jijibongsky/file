# coding=utf-8
# Copyright 2020/6/3 15:17 by ZTE
# Author: Kangkang Sun
from pydub.utils import make_chunks
from pydub import AudioSegment
import numpy as np


def ceshi(path):
    sound1 = AudioSegment.from_file(path, format="wav")
    sound2 = AudioSegment.from_file(path, format="wav")
    combined = sound1 + sound2  # sound1 和 sound2 拼接
    played_togther = sound1.overlay(sound2 - 15, loop=True)  # 混合声音
    combined.export("combined.wav", format='wav')
    played_togther.export("played_togther.wav", format='wav')
    print(4444444, len(sound1))
    print(5555555, sound1.duration_seconds)

def ceshi_danju(path):
    sound1 = AudioSegment.from_file(open(path, "rb"), format="wav")
    # sound1 = AudioSegment.from_file(path, format="wav")
    frames_per_second = sound1.frame_rate
    channel_count = sound1.channels
    bytes_per_sample = sound1.sample_width
    duration_seconds = sound1.duration_seconds
    _data = sound1._data
    dBFS = sound1.dBFS
    rms = sound1.rms
    np_chunk = np.frombuffer(sound1.get_array_of_samples(), dtype=np.int16)
    print("frames_per_second", frames_per_second)
    print("channel_count", channel_count)
    print(33333, bytes_per_sample)
    print(44444, _data[:10])
    print(55555, len(np_chunk), np_chunk.shape, np_chunk[:10])

    sound1 = sound1.set_frame_rate(22500)
    sound1 = sound1.set_channels(2)
    print("frames_per_second", sound1.frame_rate)
    print("channel_count", sound1.channels)

    sound2 = sound1[1000:3000]  # 单位毫秒
    louder = sound1 + 6
    quieter = sound1 - 6  # 声音降低6dB
    sound2.export("ceshi.wav", format='wav')


def ceshi_danju_seg(path):
    sound = AudioSegment.from_file(path, format="wav")
    chunks = make_chunks(sound, 1000)
    print(1111111111, sound.duration_seconds)
    print(2222222222, len(chunks))
    for chunk in chunks:
        print(3333333333, chunk.duration_seconds)
    print(sound[:1])


if __name__ == '__main__':
    path = "/home/vca/skk/data/ASR/data/data_aishell/data_aishell/wav/test/S0764/BAC009S0764W0402.wav"
    ceshi(path)
    # ceshi_danju(path)
    # ceshi_danju_seg(path)
