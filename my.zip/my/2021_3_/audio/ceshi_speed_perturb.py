# coding=utf-8
# Copyright 2020/8/31 11:11 by ZTE
# Author: Kangkang Sun

from pydub import AudioSegment


def speed_change(sound, speed=1.0):
    sound_with_altered_frame_rate = sound._spawn(sound.raw_data,
                                                 overrides={"frame_rate": int(sound.frame_rate * speed)})
    return sound_with_altered_frame_rate.set_frame_rate(sound.frame_rate)

path = "/home/vca/skk/data/ASR/data/data_aishell/data_aishell/wav/test/S0764/BAC009S0764W0402.wav"
sound = AudioSegment.from_file(path)
slow_sound = speed_change(sound, 0.9)
fast_sound = speed_change(sound, 1.1)
slow_sound.export("ceshi_0_9.wav", format='wav')
fast_sound.export("ceshi_1_1.wav", format='wav')
