# coding=utf-8
# Copyright 2020/8/17 15:40 by ZTE
# Author: Kangkang Sun
import torchaudio.backend.sox_io_backend as sox
from scipy.io import wavfile
import torchaudio as ta
import torchaudio
import numpy as np
import torch
import librosa
compute_fbank = ta.compliance.kaldi.fbank


def read_save(path):
    wav1 = librosa.core.load(path, sr=16000)[0]  # (132387,)
    wavfile.write("1.wav", 16000, wav1.astype(np.float32))

    wav2, sr_n = librosa.load(path, sr=16000)  # (132387,)
    librosa.output.write_wav("2.wav", wav2, 16000)

    wav3 = torch.tensor(np.array([np.array(wav1)]))
    print(11111, wav3.shape, wav3)  # [1, 132387]
    sox.save("3.wav", wav3, 16000, format="wav", bits_per_sample=16)

    wav4, sample_rate = sox.load(path, normalize=True)
    print(222222, wav4.shape, wav4)  # [1, 132387]

    sox.save("4.wav", wav4, sample_rate, format="wav", bits_per_sample=16)

    wav5, sample_rate = torchaudio.load(path)  # [1, 132387]
    print(333333, wav5.shape, wav5)

    wav6 = torchaudio.transforms.Resample(sample_rate, 22500)(wav5)
    print(444444, wav6.shape, wav6)


def compute_mel(path):
    def count_fbank(path, sample_rate):
        wav = librosa.core.load(path, sr=sample_rate)[0]
        wav = np.array([np.array(wav)])
        wav = torch.tensor(wav, dtype=torch.float32)
        feature = compute_fbank(wav, num_mel_bins=80, sample_frequency=sample_rate)
        return feature
    feature1 = count_fbank(path, 16000)
    print(222222222, feature1.shape)


if __name__ == '__main__':
    path = "/home/vca/skk/data/ASR/data/data_aishell/data_aishell/wav/test/S0764/BAC009S0764W0402.wav"
    # read_save(path)
    compute_mel(path)
