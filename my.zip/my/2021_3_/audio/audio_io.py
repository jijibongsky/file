# coding:utf-8
# CreatDate: 2022/7/20 17:22 by ZTE
# Author: Kangkang Sun
import base64
from io import BufferedReader, BytesIO
from pydub import AudioSegment


def encode_wav_file(AUDIO_FILE):
    with open(AUDIO_FILE, 'rb') as speech_file:
        speech_data = speech_file.read()
    speech = base64.b64encode(speech_data)
    speech = speech.decode('utf8')
    return speech


def decode_wav_file(speech):
    speech = speech.encode('utf8')
    speech = base64.b64decode(speech)
    speech = BytesIO(speech)  # 转化为_io.BytesIO类型
    speech = BufferedReader(speech)  # 转化为_io.BufferedReader类型
    return speech


if __name__ == '__main__':
    wav_in_path = '/home/vca/skk/data/婴儿哭声/婴儿哭声/train/awake/awake_0.wav'
    speech = encode_wav_file(wav_in_path)
    speech_io = decode_wav_file(speech)
    wav_audio = AudioSegment.from_file(wav_in_path, format="wav")
    print(1111111111, wav_audio)
