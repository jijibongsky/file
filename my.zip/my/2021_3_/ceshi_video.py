# coding:utf-8
# CreatDate: 2022/7/15 10:44 by ZTE
# Author: Kangkang Sun

import cv2
import os


# 检查视频，并合并视频
def merge():
    data_dir = "/home/vca/skk/code/paddle/PaddleDetection2_20220609/video/跌倒合集/"
    videof1 = data_dir + "fall_50.mp4"  # fps: 23, frame_count: 5585    (480, 854, 3)  0.5620608899297423
    videof2 = data_dir + "fall_custom_325.mp4"  # fps: 29, frame_count: 10598   (544, 960, 3)   0.5666666666666667

    capture1 = cv2.VideoCapture(videof1)
    capture2 = cv2.VideoCapture(videof2)

    out_path = data_dir + "合集.mp4"
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    writer = cv2.VideoWriter(out_path, fourcc, 25, (960, 544))

    while 1:
        ret, frame = capture1.read()
        if not ret:
            break
        frame = cv2.resize(frame, ((960, 544)))
        writer.write(frame)
    while 1:
        ret, frame = capture2.read()
        if not ret:
            break
        frame = cv2.resize(frame, ((960, 544)))
        writer.write(frame)
    writer.release()


def get_pianduan(videof, out_path, a=1, b=10):
    capture = cv2.VideoCapture(videof)
    # Get Video info : resolution, fps, frame count
    width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = int(capture.get(cv2.CAP_PROP_FPS))
    frame_count = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
    print("fps: %d, frame_count: %d" % (fps, frame_count))

    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    writer = cv2.VideoWriter(out_path, fourcc, fps, (width, height))

    k = 0
    while 1:
        ret, frame = capture.read()
        if not ret:
            break
        k += 1
        if k >= a and k < b:
            writer.write(frame)
    writer.release()

# 切分视频
def main_get_pianduan(videof, output_dir, keyframe):
    for i in range(len(keyframe) - 1):
        get_pianduan(videof, os.path.join(output_dir, 'fall_{}.mp4'.format(i)), a=keyframe[i], b=keyframe[i + 1])


def save_frame():
    videof = "/home/vca/skk/code/paddle/PaddleDetection2_20220609/video/跌倒合集/合集.mp4"
    capture = cv2.VideoCapture(videof)
    k = 0
    while 1:
        ret, frame = capture.read()
        if not ret:
            break
        cv2.imwrite("/home/vca/skk/code/paddle/PaddleDetection2_20220609/output/ceshi/{}.jpg".format(k), frame)
        k += 1


if __name__ == '__main__':
    merge()
    videof = "/home/vca/skk/code/paddle/PaddleDetection2_20220609/video/跌倒合集/合集.mp4"
    output_dir = "/home/vca/skk/code/paddle/PaddleDetection2_20220609/video/跌倒合集/片段"
    keyframe1 = [50, 133, 253, 378, 485, 550, 645, 773, 948, 1081, 1140, 1235, 1412, 1545, 1650, 1764, 1860, 1924, 1988,
                 2084, 2148, 2257, 2356, 2424, 2492, 2660, 2788, 2899, 2995, 3090, 3202, 3304, 3427, 3554, 3649, 3760,
                 3906, 3970, 4046, 4178, 4290, 4416, 4545, 4688, 4880, 4928, 4976, 5040, 5120, 5295, 5417]  # 50个
    # main_get_pianduan(videof, output_dir, keyframe1)
