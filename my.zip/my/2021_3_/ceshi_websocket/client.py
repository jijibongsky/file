# coding:utf-8
# CreatDate: 2021/10/26 16:37 by ZTE
# Author: Kangkang Sun

import websocket
from websocket import create_connection
import json
from pydub import AudioSegment
import numpy as np
import time
import pickle
import ctypes as ct
from io import BytesIO
import struct

# 和wenet的c++推理配套
def get_data():
    sound = AudioSegment.from_file("/export/data/asr-data/OpenSLR/33/data_aishell/wav/test/S0764/BAC009S0764W0121.wav",
                                   format="wav")
    wavform = np.frombuffer(sound.get_array_of_samples(), dtype=np.int16)
    wavform1 = [int(i) for i in wavform]
    interval = 0.5
    return wavform1

    # for i in range(0, len(wavform1), int(interval * 16000)):
    #     start_id = i
    #     end_id = min(len(wavform1), int(i + interval * 16000))
    #     T_wavform = wavform1[start_id:end_id]
    #     yield T_wavform
    #     time.sleep(interval * 2)


def start():
    # ws = create_connection("ws://10.229.89.98:10087") # 英文
    ws = create_connection("ws://10.229.89.98:10088") # 中文
    start_tag = {"signal": "start", "nbest": 1, "continuous_decoding": False}
    start_tag = json.dumps(start_tag)
    ws.send(start_tag)
    result = ws.recv()
    print(111111111, result)

    data = get_data()
    dataStr = b''
    for uint_16t in data:
        dataStr += struct.pack('h', uint_16t)
    ws.send(dataStr, opcode=websocket.ABNF.OPCODE_BINARY)

    stop_tag = {"signal": "end"}
    stop_tag = json.dumps(stop_tag)
    ws.send(stop_tag)
    result = ws.recv()
    print(5555555, result)

if __name__ == '__main__':
    start()
