# coding:utf-8
# CreatDate: 2021/6/17 14:28 by ZTE
# Author: Kangkang Sun

import json
import cv2
import re
import copy
import base64
import numpy as np
import requests
import editdistance
from PIL import Image

flag_use_rest = True
# flag_use_rest = False
# url_ocr = 'http://10.229.89.97:8880/ocr'
url_ocr = 'http://10.229.89.97:8818/ocr'

field_type_dict = {"数字": "\d+"}


# 获取模板
def get_template(data_file_template, dtype="file"):
    if dtype == "file":
        with open(data_file_template, 'r', encoding="utf8") as f:
            template = json.load(f)
    else:
        template = data_file_template
    reference = template["reference"]
    required_dict = template["required_dict"]
    label_shape = template["label_shape"]

    # 不限制关键字段不重复
    reference_dict = {}
    reference_direction_dict = {}
    for term in reference:
        # term["label"]: term["points"]
        key = term["label"]
        reference_dict[key] = term["points"]
        if key[-3:] in ["__上", "__下", "__左", "__右"]:
            if key[:-3] in reference_direction_dict:
                reference_direction_dict[key[:-3]].append([key[-1], term["points"]])
            else:
                reference_direction_dict[key[:-3]] = [[key[-1], term["points"]]]
    return reference_dict, reference_direction_dict, required_dict, label_shape


def encoded_picture(path):
    with open(path, 'rb') as f:
        img_byte = base64.b64encode(f.read())
    img_str = img_byte.decode('utf8')
    return img_str


def process_sentence(sentence):
    sentence = sentence.replace("：", ":")
    sentence = sentence.replace("（", "(")
    sentence = sentence.replace("）", ")")
    return sentence


# 获取预测结果
def get_prediction(data_file, my_boxes=None):
    if flag_use_rest:
        if my_boxes:
            data = {'recognize_img': encoded_picture(data_file), 'file_name': data_file, "return_picture": 0,
                    "boxes": my_boxes}
        else:
            data = {'recognize_img': encoded_picture(data_file), 'file_name': data_file, "return_picture": 0}
        res = requests.post(url=url_ocr, json=data)
        result = json.loads(res.text)
        result_picture = result["boxes"]
    else:
        with open(data_file, 'r', encoding="utf8") as f:
            result_picture = json.load(f)

    for term in result_picture:
        term[0] = process_sentence(term[0])
    return result_picture


# 匹配方向相关的关键字段
def gen_direction_box(strict_match_dict, result_picture, reference_direction_dict, flag_strictly=False,
                      strict_match_set={}):
    # 根据方向选择匹配上的关键字段。
    def center(box):
        return box[0][0] + box[2][0] + box[0][1] + box[2][1]

    def choose_box_direction(temp_result, term_reference):
        temp_count = []
        new_result = {}
        for term in term_reference:
            direction = term[0]
            if direction == "上":
                myList1 = sorted(temp_result, key=lambda d: d[0][1] + d[3][1])
                new_result["上"] = myList1[0]
                temp_count.append(center(myList1[0]))
            elif direction == "下":
                myList1 = sorted(temp_result, key=lambda d: d[0][1] + d[3][1])
                new_result["下"] = myList1[-1]
                temp_count.append(center(myList1[-1]))
            elif direction == "左":
                myList1 = sorted(temp_result, key=lambda d: d[0][0] + d[1][0])
                new_result["左"] = myList1[0]
                temp_count.append(center(myList1[0]))
            elif direction == "右":
                myList1 = sorted(temp_result, key=lambda d: d[0][0] + d[1][0])
                new_result["右"] = myList1[-1]
                temp_count.append(center(myList1[-1]))

        if len(temp_count) != len(list(set(temp_count))):
            return None
        return new_result

    if flag_strictly:
        for key in reference_direction_dict:
            term_reference = reference_direction_dict[key]
            temp_result = []
            for term_result in result_picture:
                if term_result[0] == key:
                    temp_result.append(term_result[1])
            if len(temp_result) >= len(term_reference):
                new_result = choose_box_direction(temp_result, term_reference)
                for temp_key in new_result:
                    strict_match_dict["{}__{}".format(key, temp_key)] = new_result[temp_key]
    else:
        temp_result_picture = []
        for key in reference_direction_dict:
            term_reference = reference_direction_dict[key]
            temp_result = []
            for term_result in result_picture:
                if term_result[0] in strict_match_set:
                    continue
                res = re.match('^({})'.format(key), term_result[0])
                if res and res.end() > 2:
                    temp_result.append(term_result[1])
            if len(temp_result) >= len(term_reference):
                new_result = choose_box_direction(temp_result, term_reference)
                for temp_key in new_result:
                    strict_match_dict["{}__{}".format(key, temp_key)] = new_result[temp_key]
                    a = ["{}__{}_pd".format(key, temp_key), new_result[temp_key], 1]
                    # print(55555555, a)
                    temp_result_picture.append(a)

        result_picture.extend(temp_result_picture)


# 如果数量不够，需要做模糊匹配（需要注意调整框的位置）
def get_modify_box(strict_match_dict, reference_dict, result_picture, image_file, predict_function):
    for key_reference in reference_dict:
        # if key_reference[-3:] in ["__上", "__下", "__左", "__右"]:    ## 需要完善
        #     print(111111111111111111111, key_reference)
        for term_result in result_picture:
            key_result = term_result[0]
            res = re.match('^({})'.format(key_reference), key_result)
            if res and res.end() > 2 and key_reference != key_result:
                # print(1111111111111111, key_reference, key_result, res, res.group())
                candidate_box = []
                # image_file=None
                if image_file:  # 自适应系数
                    temp_box = term_result[1]
                    x_1 = temp_box[0][0]
                    y_1 = temp_box[0][1]
                    x_2 = temp_box[1][0]
                    y_2 = temp_box[1][1]
                    x_3 = temp_box[2][0]
                    y_3 = temp_box[2][1]
                    x_4 = temp_box[3][0]
                    y_4 = temp_box[3][1]
                    for k in np.arange(0.6, 1.6, 0.05):
                        rate = len(key_reference) / len(key_result) * k  # 乘上系数
                        new_x2 = x_1 + (x_2 - x_1) * rate
                        new_y2 = y_1 + (y_2 - y_1) * rate
                        new_x3 = x_4 + (x_3 - x_4) * rate
                        new_y3 = y_4 + (y_3 - y_4) * rate
                        new_box = [[x_1, y_1], [new_x2, new_y2], [new_x3, new_y3], [x_4, y_4]]
                        candidate_box.append(new_box)

                    # data = {'recognize_img': encoded_picture(image_file), 'file_name': image_file,
                    #         "return_picture": 1, "boxes": candidate_box}
                    # res = requests.post(url=url_ocr, json=data)
                    # result = json.loads(res.text)
                    # T_result_picture = result["boxes"]

                    T_result_picture = predict_function(image_file, my_boxes=candidate_box)
                    # print(11111111111111111111111111111111111111111111)
                    a = []
                    b = []
                    min_error = 100
                    for i, term in enumerate(T_result_picture):
                        if key_reference[-3:] in ["__上", "__下", "__左", "__右"]:
                            # print(55555555555, key_reference, term[1])
                            T_key_reference = key_reference[:-3]
                        else:
                            T_key_reference = key_reference
                        # print(55555555555, key_reference, term[0])
                        # print(66666666666, process_sentence(term[0]))
                        # print(77777777777, key_reference)
                        if process_sentence(term[0]) == T_key_reference:
                            a.append(i)

                        error = editdistance.eval(T_key_reference, process_sentence(term[0]))
                        # print(111111111, i, key_reference, process_sentence(term[0]), error, min_error)
                        if error < min_error:
                            min_error = error
                            b = []
                            b.append(i)
                        elif error == min_error:
                            b.append(i)
                        # print(222222222, b)
                    # print(999999999999999999999, key_reference, term_result[0], a, b)
                    if a:
                        # index = a[int(len(a) / 2)]
                        index = a[0]
                    else:
                        # index = b[int(len(b) / 2)]
                        index = b[0]

                    new_box = candidate_box[index]
                    # print(222222222222, new_box)

                    strict_match_dict[key_reference] = new_box
                else:
                    rate = len(key_reference) / len(key_result)
                    point1 = term_result[1][0]
                    point3 = term_result[1][2]
                    point4 = term_result[1][3]
                    x3 = rate * (point3[0] - point1[0]) + point1[0]
                    new_box = [point1, [x3, point1[1]], [x3, point3[1]], point4]
                    strict_match_dict[key_reference] = new_box


def get_key_point(reference_dict, result_picture, reference_direction_dict, image_file, predict_function):
    # 完全匹配的关键词
    strict_match_dict = {}
    for term in result_picture:
        if term[0] in reference_dict:
            if term[0] not in strict_match_dict:
                strict_match_dict[term[0]] = term[1]
            else:
                print("重复字段：{}".format(term))
                del strict_match_dict[term[0]]

    # 匹配方向相关的关键字段, strict_match_dict 是字典，可以直接修改里面的值
    if reference_direction_dict:  # 非空
        gen_direction_box(strict_match_dict, result_picture, reference_direction_dict, flag_strictly=True)
        # for key in strict_match_dict:
        #     print(111111111, key, strict_match_dict[key])

    # strict_match_set = {key for key in strict_match_dict.keys()}   # 处理重复匹配的问题，还需要优化。
    strict_match_set = {}  # 测试用

    # 如果数量不够，需要做模糊匹配（需要注意调整框的位置）
    if len(strict_match_dict) < 4:
        get_modify_box(strict_match_dict, reference_dict, result_picture, image_file,
                       predict_function=predict_function)  ####
        # 还需要处理既包含方向信息有包含多余字的框。
        gen_direction_box(strict_match_dict, result_picture, reference_direction_dict, flag_strictly=False,
                          strict_match_set=strict_match_set)
        get_modify_box(strict_match_dict, reference_dict, result_picture, image_file, predict_function=predict_function)
    return strict_match_dict


# 如果有多个框匹配上，选择面积最大的四个点。
def choose4points(myList_label, myList_result, labels):
    myList_label = [list(term) for term in myList_label]
    myList_result = [list(term) for term in myList_result]
    myList = copy.deepcopy(myList_label)
    myList1 = sorted(myList, key=lambda d: d[0] + d[1])
    x1 = myList1[0]
    x4 = myList1[-1]
    myList.remove(x1)
    myList.remove(x4)
    myList2 = sorted(myList, key=lambda d: d[0] - d[1])
    x3 = myList2[0]
    x2 = myList2[-1]
    new_myList_label = []
    new_myList_result = []
    new_labels = []
    for i, j, k in zip(myList_label, myList_result, labels):
        if i in [x1, x2, x3, x4]:
            new_myList_label.append(i)
            new_myList_result.append(j)
            new_labels.append(k)
    new_myList_label = np.array(new_myList_label)
    new_myList_result = np.array(new_myList_result)
    return new_myList_label, new_myList_result, new_labels


# 根据模板和预测结果挑选最合适的四个关键点对（需要考虑字符一样的情景、以及字符包含的情景）
def get_point_pair(reference_dict, key_point_dict):
    pts_label = []
    pts_result = []
    labels = []
    for key in key_point_dict:
        try:
            # print(key, reference_dict[key], result_dict[key])
            point_label = [reference_dict[key][0], reference_dict[key][2]]
            point_result = [key_point_dict[key][0], key_point_dict[key][2]]
            a = [1 / 2 * (point_label[0][0] + point_label[1][0]), 1 / 2 * (point_label[0][1] + point_label[1][1])]
            b = [1 / 2 * (point_result[0][0] + point_result[1][0]), 1 / 2 * (point_result[0][1] + point_result[1][1])]
            pts_label.append(a)
            pts_result.append(b)
            labels.append(key)
            print("match====", key, a, b)
        except:
            print("get_point_pair KeyError", reference_dict, key)
    pts_label = np.float32(pts_label)
    pts_result = np.float32(pts_result)

    print("match labels", labels)
    if len(pts_label) > 4:
        pts_label, pts_result, new_labels = choose4points(pts_label, pts_result, labels)
        print("match new_labels", new_labels)

    FLAG = True
    temp_sum = 0
    for a, b in zip(pts_label, pts_result):
        error = abs(a[0] - b[0]) + abs(a[1] - b[1])
        if error > 6:
            FLAG = False
        temp_sum += error
    if temp_sum > 15:
        FLAG = False
    # print("四点总误差：{}".format(temp_sum))
    return pts_label, pts_result, FLAG


# 仿射变换
def perspective(image_file, pts1, pts2, label_shape, output_image_file):
    # print(11111111111111111111111111111, image_file)
    output_shape = (int(label_shape[0]), int(label_shape[1]))
    # img = cv2.imread(image_file)
    img = np.array(Image.open(image_file).convert('RGB'))
    img = img[:, :, ::-1]

    M = cv2.getPerspectiveTransform(pts1, pts2)  # 生成透视变换矩阵；进行透视变换
    # h, w, _ = img.shape
    # dst = cv2.warpPerspective(img, M, (int(1.2 * w), int(1.2 * h)))
    dst = cv2.warpPerspective(img, M, output_shape)
    cv2.imwrite(output_image_file, dst)


# 计算iou
def count_iou(rect1, rect2):
    xmin1, ymin1 = rect1[0]
    xmax1, ymax1 = rect1[2]
    xmin2, ymin2, = rect2[0]
    xmax2, ymax2 = rect2[2]

    s1 = (xmax1 - xmin1) * (ymax1 - ymin1)
    s2 = (xmax2 - xmin2) * (ymax2 - ymin2)
    sum_area = s1 + s2
    left = max(xmin2, xmin1)
    right = min(xmax2, xmax1)
    top = max(ymin2, ymin1)
    bottom = min(ymax2, ymax1)
    if left >= right or top >= bottom:
        return 0
    intersection = (right - left) * (bottom - top)
    return intersection / (sum_area - intersection) * 1.0


# 找出最大的 iou
def find_maxiou_box(required_box, required_content, result_picture, threshold=0.5):
    max_iou = -1
    max_box = []
    for i, term in enumerate(result_picture):
        content = term[0]
        box = term[1]
        temp_iou = count_iou(box, required_box)
        if temp_iou > max_iou:
            max_iou = temp_iou
            max_box = [required_content, content, i]
    if max_iou > threshold:
        del result_picture[max_box[2]]
        return max_box[:2]
    else:
        return None


# 获取预测结果的关键点
def get_required_box(required_dict, result_picture, data_file, predict_function, threshold=0.5):
    def pross(sentence):
        if ":" in sentence:
            sentence = sentence.split(":")[-1]
        return sentence

    new_dict = {}
    mis_match_dict = {}
    for key in required_dict:
        required_content = key
        required_box = required_dict[key]["box"]
        # 基于 iou 找，匹配上后会删掉对应的result。
        temp_result = find_maxiou_box(required_box, required_content, result_picture, threshold=threshold)
        # temp_result = None  # 调试用
        if temp_result:
            new_dict[temp_result[0]] = pross(temp_result[1])
        else:
            # 基于精确位置找
            mis_match_dict[key] = required_dict[key]["box"]

    if mis_match_dict:
        print("mis_match_dict==============", mis_match_dict)
        keys = []
        boxes = []
        for key in mis_match_dict:
            boxes.append(mis_match_dict[key])
            keys.append(key)

        # data = {'recognize_img': encoded_picture(data_file), 'file_name': data_file, "return_picture": 1,
        #         "boxes": boxes}
        # res = requests.post(url=url_ocr, json=data)
        # result = json.loads(res.text)
        # result_picture = result["boxes"]

        result_picture = predict_function(data_file, my_boxes=boxes)
        # print(222222222222222222222222222222222222)

        for key, term in zip(keys, result_picture):
            new_dict[key] = term[0]
        print("result_mis_match", result_picture)

    # 基于规则，对于预测结果进行过滤。
    for key in new_dict:
        # 后续增加 try
        field_type = required_dict[key].get("field_type", None)
        field_type = field_type_dict.get(field_type, None)
        if field_type:
            old_content = new_dict[key]
            temp_result = re.findall(field_type, old_content)
            if len(temp_result) == 1:
                new_dict[key] = temp_result[0]

    # 处理多预测的问题
    return new_dict


def end2end_format(data_file_template, image_file, output_image_file, predict_function, dtype="file"):
    # 获取模板
    reference_dict, reference_direction_dict, required_dict, label_shape = get_template(data_file_template, dtype=dtype)

    # 仿射变换,并放缩到合适大小。
    # 获取预测结果
    # result_picture = predict_function(data_file)  # json 格式本地文件，本地测试用
    result_picture = predict_function(image_file)  # 图片
    print("result_picture=======", result_picture)

    # 获取预测结果的关键点
    key_point_dict = get_key_point(reference_dict, result_picture, reference_direction_dict, image_file,
                                   predict_function=predict_function)
    print("key_point_dict=======", key_point_dict)

    # 根据模板和预测结果挑选最合适的四个关键点对

    pts_label, pts_result, FLAG = get_point_pair(reference_dict, key_point_dict)
    if pts_result.shape[0] < 4:
        return {}
    # 仿射变换
    perspective(image_file, pts_result, pts_label, label_shape=label_shape, output_image_file=output_image_file)
    ###################

    # 对新图片做预测，并匹配结果。
    # result_picture = predict_function(data_file_perspective)
    result_picture = predict_function(output_image_file)
    # result_dict = get_key_point(reference_dict, result_picture)
    # pts_label, pts_result, FLAG = get_point_pair(reference_dict, result_dict)
    # print(11111111, pts_label, pts_result, FLAG)
    result = get_required_box(required_dict, result_picture, output_image_file, predict_function=predict_function,
                              threshold=0.3)
    return result


if __name__ == '__main__':
    # 增值税发票
    data_file_template = "data/增值税发票/template/1.json"  # 模板

    image_file = "data/增值税发票/2.png"  # 原始图片
    output_image_file = "data/增值税发票/result/2_1.png"  # 仿射变换后的图片

    # image_file = "data/增值税发票/3.png"  # 原始图片
    # output_image_file = "data/增值税发票/result/3_1.png"

    # 获取模板
    reference_dict, reference_direction_dict, required_dict, label_shape = get_template(data_file_template)

    # 仿射变换,并放缩到合适大小。
    # 获取预测结果
    # result_picture = get_prediction(data_file)  # json 格式本地文件，本地测试用
    result_picture = get_prediction(image_file)  # 图片
    # 获取预测结果的关键点
    key_point_dict = get_key_point(reference_dict, result_picture, reference_direction_dict, image_file,
                                   predict_function=get_prediction)
    print(key_point_dict)

    # 根据模板和预测结果挑选最合适的四个关键点对
    pts_label, pts_result, FLAG = get_point_pair(reference_dict, key_point_dict)
    # 仿射变换
    perspective(image_file, pts_result, pts_label, label_shape=label_shape, output_image_file=output_image_file)
    ###################

    # 对新图片做预测，并匹配结果。
    # result_picture = get_prediction(data_file_perspective)
    result_picture = get_prediction(output_image_file)
    # result_dict = get_key_point(reference_dict, result_picture)
    # pts_label, pts_result, FLAG = get_point_pair(reference_dict, result_dict)
    # print(11111111, pts_label, pts_result, FLAG)
    result = get_required_box(required_dict, result_picture, output_image_file,predict_function=get_prediction, threshold=0.3)

    # result = end2end_format(data_file_template, image_file, output_image_file=output_image_file,
    #                         predict_function=get_prediction)
    print("================")
    for key in result:
        print(2222, key, result[key])
