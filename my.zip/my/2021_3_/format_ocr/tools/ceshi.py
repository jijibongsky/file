# coding:utf-8
# CreatDate: 2021/6/25 12:36 by ZTE
# Author: Kangkang Sun

from PIL import Image
import numpy as np
import cv2
import os


# 对检测出来的文本框做一个仿射变换，变成一个长方形。
def get_rotate_crop_image(img, points):
    img_crop_width = int(
        max(np.linalg.norm(points[0] - points[1]),   # 求范数，默认二范数
            np.linalg.norm(points[2] - points[3])))
    img_crop_height = int(
        max(np.linalg.norm(points[0] - points[3]),
            np.linalg.norm(points[1] - points[2])))
    pts_std = np.float32([[0, 0], [img_crop_width, 0], [img_crop_width, img_crop_height], [0, img_crop_height]])
    M = cv2.getPerspectiveTransform(points, pts_std)
    dst_img = cv2.warpPerspective(img, M, (img_crop_width, img_crop_height),
        borderMode=cv2.BORDER_REPLICATE, flags=cv2.INTER_CUBIC)
    dst_img_height, dst_img_width = dst_img.shape[0:2]
    if dst_img_height * 1.0 / dst_img_width >= 1.5:
        dst_img = np.rot90(dst_img)
    return dst_img


image_file = "../../test_data/倾斜反光身份证.PNG"
# points = [[250, 335], [521, 310], [524, 341], [254, 366]]  # 性别女民族汉
points = [[473, 602], [771, 530], [777, 554], [479, 626]]  # 310104198604230289

points = np.array(points, dtype="float32")
img = np.array(Image.open(image_file).convert('RGB'))
img = img[:, :, ::-1]
dst_img = get_rotate_crop_image(img, points)
image = Image.fromarray(np.uint8(dst_img))
image.save(os.path.join("/home/vca/skk/code/paddle/PaddleOCR/about_format", "ceshi1.jpg"))
