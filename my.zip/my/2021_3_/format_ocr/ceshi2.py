# coding:utf-8
# CreatDate: 2021/6/15 20:28 by ZTE
# Author: Kangkang Sun
import cv2
import json
import numpy as np


def perspective(image_file, pts1, pts2, output_shape, output_file):
    img = cv2.imread(image_file)
    # 生成透视变换矩阵；进行透视变换
    M = cv2.getPerspectiveTransform(pts1, pts2)
    h, w, _ = img.shape
    # dst = cv2.warpPerspective(img, M, (int(2 * w), int(2 * h)))
    dst = cv2.warpPerspective(img, M, output_shape)
    cv2.imwrite(output_file, dst)


# 测试仿射变换
def ceshi1():
    image_file = '../test_data/ocr_15.png'
    output_file = "../output/ceshi.jpg"

    # 原图中书本的四个角点(左上、右上、左下、右下),与变换后矩阵位置
    # pts1 = [[130, 60], [731, 173], [122, 361], [727, 329]]  # 只要点对应，顺序没有要求
    # # pts2 = [[130, 60], [780, 60], [130, 361], [780, 361]]
    # pts2 = [[0, 0], [650, 0], [0, 301], [650, 301]]   # 模板图片中对应的位置信息

    pts1 = [[130, 60], [731, 173], [727, 329], [122, 361]]
    # pts2 = [[0, 0], [650, 0], [650, 301], [0, 301]]
    # pts2 = [[100, 0], [750, 0], [750, 301], [100, 301]]
    pts2 = [[100, 200], [1200, 200], [1200, 501], [100, 501]]
    pts1 = np.float32(pts1)
    pts2 = np.float32(pts2)
    # output_shape = (2 * int(pts2[3][0]), int(2 * pts2[3][1]))  # 模板图片的大小
    output_shape = (1500, 1000)  # 模板图片的大小
    perspective(image_file, pts1, pts2, output_shape=output_shape, output_file=output_file)


ceshi1()


# padding 构造测试图片
def ceshi_padding():
    input_img_file = "/home/vca1/skk/code/paddle/PaddleOCR/about_format/data/发票/10.jpg"
    output_img_file = "/home/vca1/skk/code/paddle/PaddleOCR/about_format/data/发票/result/ceshi1.jpg"
    im = cv2.imread(input_img_file)
    im_shape = im.shape
    print(1111111, im_shape)
    dh = 1000
    dw = 1500
    padimg = np.zeros((dh, dw, im.shape[2]), im.dtype)
    padimg[100:im_shape[0] + 100, 120:im_shape[1] + 120] = im
    img = padimg
    cv2.imwrite(output_img_file, img)


# 获取模板
def get_template(data_file_template):
    # 增值税发票
    reference = [
        {"label": "纳税人识别号:__上", "points": [[237, 297], [423, 297], [423, 331], [237, 331]]},
        {"label": "纳税人识别号:__下", "points": [[237, 881], [423, 881], [423, 913], [237, 913]]},
        {"label": "规格型号", "points": [[619, 427], [745, 427], [745, 461], [619, 461]]},
        {"label": "税率", "points": [[1451, 429], [1513, 429], [1513, 461], [1451, 461]]},
        {"label": "价税合计(大写)", "points": [[257, 783], [491, 783], [491, 821], [257, 821]]},
        {"label": "(小写)", "points": [[1309, 785], [1413, 785], [1413, 823], [1309, 823]]},
        {"label": "开票日期:", "points": [[1339, 193], [1477, 193], [1477, 229], [1339, 229]]},
    ]
    required_dict = {
        "销售方名称": {"box": [[443, 845], [765, 845], [765, 879], [443, 879]]},
        # "销售方开户行及账号":{"box":[[439, 963], [841, 963], [841, 995], [439, 995]]} , # 贴的太紧了
        # "税率": {"box":[[1463, 471], [1507, 471], [1507, 503], [1463, 503]]},  # 贴的太紧了
        "销售方开户行及账号": {"box": [[421, 963], [1051, 963], [1051, 995], [421, 995]]},
        "税率": {"box": [[1449, 471], [1517, 471], [1517, 503], [1449, 503]]},
        "收款人": {"box": [[191, 1001], [381, 1001], [381, 1035], [191, 1035]]},
        "金额": {"box": [[1319, 469], [1437, 469], [1437, 501], [1319, 501]]},
    }
    label_shape = [1905, 1131]
    template = {
        "reference": reference,
        "required_dict": required_dict,
        "label_shape": label_shape,
        "imagePath": "1.jpg",
    }
    with open('data/增值税发票/template/1.json', 'w', encoding="utf8") as f:
        json.dump(template, f, indent=4, ensure_ascii=False)

    # 银行进账单_贷方凭证
    # reference = [
    #     {'label': '出票人', 'points': [[103, 137], [132, 137], [132, 225], [103, 225]]},
    #     {'label': '收款人', 'points': [[634, 135], [663, 135], [663, 221], [634, 221]]},
    #     {'label': '开户银行__左', 'points': [[148, 212], [247, 212], [247, 239], [148, 239]]},
    #     {'label': '开户银行__右', 'points': [[680, 211], [778, 211], [778, 238], [680, 238]]},
    #     {'label': '票据号码', 'points': [[105, 379], [204, 379], [204, 410], [105, 410]]},
    #     {'label': '记账', 'points': [[880, 514], [943, 514], [943, 545], [880, 545]]}
    # ]
    # required_dict = {
    #     '日期': {"box": [[480, 78], [737, 78], [737, 105], [480, 105]]},
    #     '出票人开户银行': {"box": [[259, 207], [534, 207], [534, 237], [259, 237]]},
    #     '收款人开户银行': {"box": [[792, 209], [1071, 209], [1071, 237], [792, 237]]},
    #     '出票人账号': {"box": [[260, 162], [477, 162], [477, 189], [260, 189]], "field_type": "数字"}
    # }
    # label_shape = [1236, 666]
    # template = {
    #     "reference": reference,
    #     "required_dict": required_dict,
    #     "label_shape": label_shape,
    #     "imagePath": "1.jpg",
    # }
    # with open('data/发票/银行进账单_贷方凭证/template/1.json', 'w', encoding="utf8") as f:
    #     json.dump(template, f, indent=4, ensure_ascii=False)

    # 进账单_回单
    # reference = [
    #     {'label': '出票人', 'points': [[79, 207], [108, 207], [108, 296], [79, 296]]},
    #     {'label': '收款人', 'points': [[677, 206], [710, 206], [710, 298], [677, 298]]},
    #     {'label': '开户银行__左', 'points': [[124, 283], [239, 283], [239, 314], [124, 314]]},
    #     {'label': '开户银行__右', 'points': [[724, 284], [841, 284], [841, 315], [724, 315]]},
    #     {'label': '票据号码', 'points': [[98, 468], [218, 468], [218, 500], [98, 500]]},
    #     {'label': '开户银行签章', 'points': [[1016, 572], [1193, 572], [1193, 604], [1016, 604]]}
    # ]
    # required_dict = {
    #     '日期': {"box": [[517, 143], [774, 143], [774, 174], [517, 174]]},
    #     '出票人开户银行': {"box": [[258, 285], [652, 285], [652, 316], [258, 316]]},
    #     '收款人开户银行': {"box": [[858, 287], [1253, 287], [1253, 318], [858, 318]]},
    #     '出票人账号': {"box": [[257, 239], [647, 239], [647, 271], [257, 271]], "field_type": "数字"}
    # }
    # label_shape = [1357, 666]
    # template = {
    #     "reference": reference,
    #     "required_dict": required_dict,
    #     "label_shape": label_shape,
    #     "imagePath": "1.jpg",
    # }
    # with open('data/发票/进账单_回单/template/1.json', 'w', encoding="utf8") as f:
    #     json.dump(template, f, indent=4, ensure_ascii=False)

    # with open(data_file_template, 'r', encoding="utf8") as f:
    #     template = json.load(f)
    # reference = template["reference"]
    # required_dict = template["required_dict"]
    # label_shape = template["label_shape"]
    # reference_dict = {term["label"]: term["points"] for term in reference}
    # return reference_dict, required_dict, label_shape


# get_template("")


# 获取预测结果
def get_prediction():
    picture2 = [['江苏银行', [[238, 45], [427, 50], [426, 99], [236, 94]], 0.999],
                ['进账单（回单）', [[537, 55], [932, 63], [932, 114], [537, 105]], 0.958],
                ['BANK OFJIANGSU', [[245, 96], [424, 96], [424, 117], [245, 117]], 0.976],
                ['2019年0月2日', [[539, 135], [808, 132], [808, 169], [539, 172]], 0.998],
                ['全称泰州市土地储备和不动产登记中心', [[139, 180], [640, 184], [640, 218], [139, 215]], 0.985],
                ['全称泰州市泰政交通投资有限公司', [[744, 180], [1264, 180], [1264, 218], [744, 218]], 0.941],
                ['此联是开户银行交给持（出）票人的回单', [[1313, 189], [1337, 189], [1337, 598], [1313, 598]], 0.96],
                ['出票人', [[92, 202], [122, 202], [122, 291], [92, 291]], 0.999],
                ['账号16200188000372507', [[135, 224], [514, 233], [514, 272], [135, 264]], 0.999],
                ['账号16200188000050330', [[738, 228], [1140, 234], [1140, 272], [738, 265]], 0.998],
                ['开户银行江苏银行泰州分行营业部', [[136, 275], [584, 278], [584, 316], [136, 312]], 0.999],
                ['开户银行', [[745, 280], [875, 280], [875, 312], [745, 312]], 0.999],
                ['江苏银行泰州分行营业部', [[886, 280], [1213, 283], [1213, 316], [886, 312]], 1.0],
                ['金额', [[92, 319], [124, 319], [124, 399], [92, 399]], 0.998],
                ['亿千百', [[886, 322], [999, 327], [998, 363], [885, 358]], 0.999],
                ['人民币', [[152, 325], [241, 329], [239, 363], [151, 360]], 1.0],
                ['十万千百十元角', [[992, 322], [1269, 325], [1269, 365], [992, 361]], 0.997],
                ['分', [[1269, 332], [1294, 332], [1294, 361], [1269, 361]], 1.0],
                ['）壹九元整', [[136, 342], [397, 322], [402, 394], [141, 413]], 0.771],
                ['0', [[938, 384], [951, 384], [951, 402], [938, 402]], 0.948],
                ['票据种类', [[115, 417], [231, 417], [231, 451], [115, 451]], 0.999],
                ['票据张数', [[414, 417], [531, 417], [531, 451], [414, 451]], 1.0],
                ['US203）175*85', [[47, 469], [67, 469], [67, 586], [47, 586]], 0.9],
                ['票据号码', [[114, 462], [229, 462], [229, 497], [114, 497]], 1.0],
                ['复核', [[231, 565], [293, 565], [293, 601], [231, 601]], 0.999],
                ['记账', [[464, 567], [526, 567], [526, 603], [464, 603]], 0.998],
                ['开户银行签章', [[1041, 572], [1217, 575], [1217, 607], [1041, 604]], 1.0]]

    with open('data/发票/进账单_回单/result/4_1.json', 'w', encoding="utf8") as f:
        json.dump(picture2, f, indent=4, ensure_ascii=False)
    # with open(data_file, 'r', encoding="utf8") as f:
    #     result_picture = json.load(f)
    # return result_picture

# get_prediction()
