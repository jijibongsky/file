# coding=utf-8
# Copyright 2019/3/29 15:35 by ZTE
# Author: Kangkang Sun

a = "shs{}hshhs{}asjkajs".format("1111", "2222")
b = "shs{}hshhs{}asjkajs".format(1111, 2222)
c = "{1} {0} {1}".format("hello", "world")
d = "网站名：{name}, 地址 {url}".format(name="菜鸟教程", url="www.runoob.com")

site = {"name": "菜鸟教程", "url": "www.runoob.com"}
e = "网站名：{name}, 地址 {url}".format(**site)

f = "{:.4f}".format(3.1415926)  # 3.1416
g = round(3.131615, 3)  # 3.132
gg = '{:05d}.txt'.format(22)  # 00022.txt
