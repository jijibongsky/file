# coding:utf-8
# CreatDate: 2021/3/9 14:58 by ZTE
# Author: Kangkang Sun

import yaml

file_path = "ceshi.yml"
file_path1 = "ceshi1.yml"
with open(file_path) as f:
    cfg = yaml.load(f, Loader=yaml.Loader)
    for item in cfg.items():
        print(111111, item)

cfg["OptimizerBuilder"]["optimizer"]["momentum"] = 1
with open(file_path1, "w", encoding="utf-8") as f:
    yaml.dump(cfg, f, Dumper=yaml.Dumper, sort_keys=False)

with open(file_path1, 'r', encoding='utf-8') as f:
    file = yaml.load(f, Loader=yaml.FullLoader)
    for item in file.items():
        print(222222, item)
