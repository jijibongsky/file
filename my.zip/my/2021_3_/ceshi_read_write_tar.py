# coding:utf-8
# CreatDate: 2021/12/7 17:18 by ZTE
# Author: Kangkang Sun

import argparse
import io
import logging
import os
import tarfile
import time
import multiprocessing

import torch
import librosa
import numpy as np
import torchaudio
import torchaudio.backend.sox_io_backend as sox

AUDIO_FORMAT_SETS = set(['flac', 'mp3', 'm4a', 'ogg', 'opus', 'wav', 'wma'])


def write_tar_file(data_list, tar_file):
    logging.info('Processing {}'.format(tar_file))
    with tarfile.open(tar_file, "w") as tar:
        for i, item in enumerate(data_list):
            key, txt, wav = item
            suffix = wav.split('.')[-1]
            assert suffix in AUDIO_FORMAT_SETS
            with open(wav, 'rb') as fin:
                data = fin.read()
            # print(1111111111, data)

            txt_file = key + '.txt'
            txt = txt.encode('utf8')
            txt_data = io.BytesIO(txt)
            txt_info = tarfile.TarInfo(txt_file)
            txt_info.size = len(txt)
            tar.addfile(txt_info, txt_data)

            wav_file = key + '.' + suffix
            wav_data = io.BytesIO(data)
            wav_info = tarfile.TarInfo(wav_file)
            wav_info.size = len(data)
            tar.addfile(wav_info, wav_data)


def read_tar(data_file):
    stream = open(data_file, 'rb')
    stream1 = tarfile.open(fileobj=stream, mode="r|*")
    prev_prefix = None
    example = {}
    valid = True
    for i, tarinfo in enumerate(stream1):
        # print(i, tarinfo)
        # <TarInfo 'X0000011120_210540023_S00041.wav' at 0x7fe0a82337c0>
        name = tarinfo.name
        pos = name.rfind('.')
        assert pos > 0
        prefix, postfix = name[:pos], name[pos + 1:]
        # print(111111111, prefix)   # BAC009S0353W0191   BAC009S0353W0191
        # print(222222222, postfix)  # txt wav
        if prev_prefix is not None and prefix != prev_prefix:
            example['key'] = prev_prefix
            # print(3333333333, example)
            # {'txt': '坐在警车里吃方便面啃面包',
            # 'wav': tensor([[-0.0008, -0.0013, -0.0011,  ..., -0.0015, -0.0015, -0.0016]]),
            # 'sample_rate': 16000, 'key': 'BAC009S0352W0449'}
            if valid:
                yield example
            example = {}
            valid = True

        file_obj = stream1.extractfile(tarinfo)
        if postfix == 'txt':
            example['txt'] = file_obj.read().decode('utf8').strip()
        elif postfix in AUDIO_FORMAT_SETS:
            waveform, sample_rate = torchaudio.load(file_obj)
            example['wav'] = waveform
            example['sample_rate'] = sample_rate
        prev_prefix = prefix
    if prev_prefix is not None:
        example['key'] = prev_prefix
        yield example
    stream.close()
    stream1.close()


if __name__ == '__main__':
    a = ["BAC009S0764W0121", "甚至出现交易几乎停滞的情况",
         "/export/data/asr-data/OpenSLR/33/data_aishell/wav/test/S0764/BAC009S0764W0121.wav"]
    b = ["BAC009S0764W0122", "一二线城市虽然也处于调整中",
         "/export/data/asr-data/OpenSLR/33/data_aishell/wav/test/S0764/BAC009S0764W0122.wav"]
    data_list = [a, b]
    tar_file = "ceshi.tar"
    # write_tar_file(data_list, tar_file)
    data_Iteration = read_tar(tar_file)
    for data in data_Iteration:
        print(data)
