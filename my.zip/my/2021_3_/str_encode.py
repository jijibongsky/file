# coding:utf-8
# CreatDate: 2021/9/27 15:37 by ZTE
# Author: Kangkang Sun

a = "\\u4e00".encode('utf-8').decode('unicode_escape')
b = "我们".encode('unicode_escape').decode('utf-8')
print(111111, a)
print(222222, b)
