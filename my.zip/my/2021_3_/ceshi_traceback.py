# coding:utf-8
# CreatDate: 2021/9/7 11:20 by ZTE
# Author: Kangkang Sun
import traceback

s = 0
try:
    for i in range(10 ** 10):
        s += 1
except:
    print(222222222)
    print(traceback.format_exc())

