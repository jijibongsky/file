# coding:utf-8
# CreatDate: 2022/7/21 18:15 by ZTE
# Author: Kangkang Sun
import sys
import os
root_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.insert(1, root_path)  # sys.path 是一个列表，越靠前优先级越大。
