# coding:utf-8
# CreatDate: 2021/11/30 11:58 by ZTE
# Author: Kangkang Sun

import matplotlib.pyplot as plt
import numpy as np
import random

# 加图例和颜色；横坐标竖着写。
x = ['02-10 00:00:00', '02-11 00:00:00', '02-12 00:00:00', '02-13 00:00:00', '02-14 00:00:00', '02-15 00:00:00']
y1 = [75.28510250343591, 65.92934005201397, 71.72168261831267, 77.61654159591691, 72.3276262143227, 58.25263285195231]
y2 = [68.08982484271026, 67.78284392378966, 70.93868935530014, 81.08597637818332, 83.44075379834972, 81.5877399696628]

# plt.plot(x, y1, label='new strategy')
# plt.plot(x, y2, label='original strategy', color='r')
# plt.xticks(rotation=270)
# plt.legend()
# plt.show()

def plot_hist(data_list, all_scores):
    plt.subplot(1, 2, 1)
    plt.hist(data_list, bins=1000, histtype='bar', rwidth=1)
    plt.legend()
    plt.xlabel('x1')
    plt.ylabel('y1')
    plt.xlim(0, 1)
    # plt.title(u'测试例子——直方图', FontProperties=font)
    plt.title('original')
    plt.subplot(1, 2, 2)
    plt.hist(all_scores, bins=1000, histtype='bar', rwidth=1)
    plt.legend()
    plt.xlabel('x2')
    plt.ylabel('y2')
    plt.show()

data_list = np.random.random(100)
data_list.sort()
all_scores = np.random.random(100)
plot_hist(data_list, all_scores)
