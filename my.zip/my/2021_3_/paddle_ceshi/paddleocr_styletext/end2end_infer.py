# coding:utf-8
# CreatDate: 2022/4/22 10:32 by ZTE
# Author: Kangkang Sun
import cv2
import os
import numpy as np
from infer_one_line import infer_one

from my_tools.my_tools import get_crop, paste_back, draw_text
output_dir = "/home/vca/skk/code/paddle/PaddleOCR_220415/StyleText/output_data"
old_image = "test_data/示例身份证.png"
box = [[75, 34], [146, 34], [146, 56], [75, 56]]
text_corpus = "李大钊"
language = "ch"
box = np.array(box)
crop = get_crop(old_image, box)

fake_fusion, fake_bg = infer_one(crop, text_corpus, language)  # 真实数据推理
# fake_fusion, fake_bg = infer_one(style_image_path, text_corpus, language)

fake_fusion_complete = paste_back(old_image, box, fake_fusion, crop)
cv2.imwrite(os.path.join(output_dir, "fake_fusion_complete.jpg"), fake_fusion_complete)

# 直接在背景上写字不太好，需要单独设置比较好的字体
font_path = "/home/vca/skk/code/paddle/PaddleOCR_220415/StyleText/fonts/ch_standard.ttf"
corpus_list, text_input_list, img = draw_text(text_corpus, font_path, fake_bg)
fake_fusion_draw = paste_back(old_image, box, img, crop)
cv2.imwrite(os.path.join(output_dir, "fake_fusion_draw.jpg"), fake_fusion_draw)
cv2.imwrite(os.path.join(output_dir, "img.jpg"), img)
