# coding:utf-8
# CreatDate: 2022/4/22 11:23 by ZTE
# Author: Kangkang Sun
import cv2
import copy
import numpy as np
from PIL import Image, ImageDraw, ImageFont


def get_crop(old_image, box):
    min_x = min(box[:, 0])
    max_x = max(box[:, 0])
    min_y = min(box[:, 1])
    max_y = max(box[:, 1])
    img = cv2.imread(old_image)
    crop = img[min_y:max_y, min_x:max_x]
    return crop


def paste_back(old_image, box, fake_fusion, crop):
    min_x = min(box[:, 0])
    max_x = max(box[:, 0])
    min_y = min(box[:, 1])
    max_y = max(box[:, 1])
    img = cv2.resize(fake_fusion, (crop.shape[1], crop.shape[0]))
    old_image_np = cv2.imread(old_image)
    old_image_np[min_y:max_y, min_x:max_x] = img
    return old_image_np


def get_valid_height(font_path, height):
    char_list = " 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    font = ImageFont.truetype(font_path, height - 4)
    _, font_height = font.getsize(char_list)
    if font_height <= height - 4:
        return height - 4
    else:
        return int((height - 4) ** 2 / font_height)


def load_fonts(font_path, height):
    font_height = get_valid_height(font_path, height)
    font = ImageFont.truetype(font_path, font_height)
    # print(1111111111, font_path)  # ./fonts/en_standard.ttf、 ch_standard.ttf、 ko_standard.ttf
    # print(2222222222, font_height) # 21、28、27
    # print(3333333333, font)
    return font


def draw_text(corpus, font_path, imgbg):
    width = imgbg.shape[1]
    height = imgbg.shape[0]
    font = load_fonts(font_path, height)
    corpus_list = []
    text_input_list = []
    while len(corpus) != 0:
        # bg = Image.new("RGB", (width, height), color=(127, 127, 127))
        bg = Image.fromarray(np.uint8(imgbg))
        # bg = Image.open("output_data/fake_bg.jpg", "r").convert("RGB")
        draw = ImageDraw.Draw(bg)
        char_x = 2
        i = 0
        while i < len(corpus):
            char_i = corpus[i]
            char_size = font.getsize(char_i)[0]
            # split when char_x exceeds char size and index is not 0 (at least 1 char should be wroten on the image)
            if char_x + char_size >= width and i != 0:
                text_input = np.array(bg).astype(np.uint8)
                text_input = text_input[:, 0:char_x, :]
                corpus_list.append(corpus[0:i])
                text_input_list.append(text_input)
                corpus = corpus[i:]
                i = 0
                break
            draw.text((char_x, 2), char_i, fill=(0, 0, 0), font=font)
            char_x += char_size

            i += 1
        # the whole text is shorter than style input
        if i == len(corpus):
            text_input = np.array(bg).astype(np.uint8)
            text_input = text_input[:, 0:char_x, :]

            corpus_list.append(corpus[0:i])
            text_input_list.append(text_input)
            break

    img = copy.deepcopy(text_input_list[0])
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            # img[i,j] is the RGB pixel at position (i, j)
            # check if it's [0, 0, 0] and replace with [255, 255, 255] if so
            if img[i, j].sum() <= 100:
                img[i, j] = np.array([255, 255, 255]) - img[i, j]
    return corpus_list, text_input_list, img


if __name__ == '__main__':
    # old_image = "/home/vca/skk/code/paddle/PaddleOCR_220415/StyleText/examples/sun1_wen2_qing1_12.jpg"
    # box = [[190, 367], [455, 367], [455, 448], [190, 448]]
    # box = np.array(box)
    # crop = get_crop(old_image, box)
    # cv2.imwrite("/home/vca/skk/code/paddle/PaddleOCR_220415/StyleText/examples/ceshi.jpg", crop)

    corpus = "A123456"
    font_path = "fonts/en_standard.ttf"
    image_path = "output_data/fake_bg.jpg"
    imgbg = cv2.imread(image_path)[:, :, ::-1]

    corpus_list, text_input_list, img = draw_text(corpus, font_path, imgbg)
    cv2.imwrite("examples/ceshi.jpg", text_input_list[0])
    cv2.imwrite("examples/ceshi1.jpg", img)
