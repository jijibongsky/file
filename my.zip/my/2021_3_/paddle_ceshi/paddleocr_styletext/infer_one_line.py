# Copyright (c) 2020 PaddlePaddle Authors. All Rights Reserve.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import os
import cv2
import sys

# os.environ["CUDA_VISIBLE_DEVICES"] = "7"

__dir__ = os.path.dirname(os.path.abspath(__file__))
sys.path.append(__dir__)
sys.path.append(os.path.abspath(os.path.join(__dir__, '..')))

from utils.config import ArgsParser
from engine.synthesisers import ImageSynthesiser

args = ArgsParser().parse_args()
image_synthesiser = ImageSynthesiser()

def infer_one(style_image_path, text_corpus, language):
    if isinstance(style_image_path, str):
        img = cv2.imread(style_image_path)
    else:
        img = style_image_path
    synth_result = image_synthesiser.synth_image(text_corpus, img, language)
    fake_text = synth_result["fake_text"]  # fake_text 具有目标文本相同文本样式的前景图像。
    fake_sk = synth_result["fake_sk"]  # fake_sk 是目标文本骨架（感觉像是把 fake_text 文字部分变量，比如黑色边白色）
    fake_bg = synth_result["fake_bg"]  # fake_bg 的背景
    fake_fusion = synth_result["fake_fusion"]  # fake_fusion 是最终的目标文本图像。
    # cv2.imwrite("fake_fusion.jpg", fake_fusion)
    # cv2.imwrite("fake_text.jpg", fake_text)
    # cv2.imwrite("fake_bg.jpg", fake_bg)
    # cv2.imwrite("fake_sk.jpg", fake_sk)
    return fake_fusion, fake_bg

if __name__ == '__main__':
    style_image_path = "/home/vca/skk/code/paddle/PaddleOCR_220415/StyleText/examples/style_images/1.jpg"
    text_corpus = "testocr"
    language = "en"
    fake_fusion, fake_bg = infer_one(style_image_path, text_corpus, language)
