from scipy.io.wavfile import write
import argparse
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
# os.environ["CUDA_VISIBLE_DEVICES"] = ""

import numpy as np
from time import time
# import shutil
# import random

from flask import request
from flask import Flask
from flask import abort
import json
import base64
import logging
import logging.handlers
from pydub import AudioSegment

from infer_online import load_model, deal_one

# from melgan_vocoder.model.generator import Generator
# from melgan_vocoder.utils.hparams import HParam, load_hparam_str
# from datasets_tacotron import audio as audio
# import dataset
# import utils

# import hparams as hp
# import model as M
# from datasets_tacotron.trans2pinyin import sentence2id, my_dict, split_sentence, sentence_pro

root_dir = os.path.abspath(os.path.dirname(__file__))
print(11111111, root_dir)

def set_log(log_dir):
    # 屏蔽第三方包的日志输出
    # logging.getLogger('pdfminer.pdfdocument').setLevel(logging.ERROR)

    # 总开关，控制多个文件
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    # handler定义某一个日志文件
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    handler = logging.handlers.TimedRotatingFileHandler(log_dir + "TTS.log",
                                                        when='D', interval=1, backupCount=30, encoding='UTF-8')
    # handler = logging.handlers.TimedRotatingFileHandler(log_dir, when='M', interval=1, backupCount=30, encoding='UTF-8')
    handler.suffix = "%Y-%m-%d.log"
    handler.setLevel(logging.INFO)
    logging_format = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(filename)s - %(funcName)s - %(lineno)s - %(message)s')
    handler.setFormatter(logging_format)
    # 把handler定义的日志文件加到总的日志中
    logger.addHandler(handler)
    return logger


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--step', type=int, default=380000)
    parser.add_argument("--alpha", type=float, default=1.0)
    parser.add_argument('--vocoder_config', type=str, default=None,
                        help="yaml file for config. will use hp_str from checkpoint if not given.")
    parser.add_argument('--vocoder_checkpoint', type=str,
                        default=os.path.join(root_dir,
                                             "melgan_vocoder/chkpt/biaobei_train_16_h256/biaobei_train_16_h256_3100.pt"),
                        # default='./melgan_vocoder/chkpt/biaobei_train_16_256_gta_phone_fastspeech/biaobei_train_16_256_gta_phone_fastspeech_1350.pt',
                        help="path of checkpoint pt file for evaluation")
    args = parser.parse_args()
    return args

def encoded_wav(path):
    with open(path, 'rb') as f:
        img_byte = base64.b64encode(f.read())
    wav_str = img_byte.decode('utf8')
    return wav_str

def decoded_wav(wav_str):
    wav_decode_ = wav_str.encode('utf8')  # ascii编码
    wav_decode = base64.b64decode(wav_decode_)  # base64解码
    # fw = open(log_dir + "ceshi.wav", "wb")
    # fw.write(wav_decode)
    return wav_decode


model_dir_am = "/root/.paddlespeech/models/fastspeech2_csmsc-zh/fastspeech2_nosil_baker_ckpt_0.4"
model_dir_voc = "/root/.paddlespeech/models/pwgan_csmsc-zh/pwg_baker_ckpt_0.4"

tts_executor = load_model(model_dir_am, model_dir_voc)

app = Flask(__name__)

@app.route('/TTS', methods=['POST'])
def create_task():
    if not request.json:
        abort(401)
    data_dict = request.json  # request.json 是字符串  json.loads 加载字符串
    sentence = data_dict['sentence']
    # print("{} 输入句子：{}".format(datetime.datetime.now(), sentence))

    logger.info("输入句子：{}".format(sentence))
    out_path = os.path.join(root_dir, "results", '{}.wav'.format(sentence[:5]))
    _ = deal_one(tts_executor, sentence, out_path, merge_sentences=False)

    # sound = AudioSegment.from_file(open(out_path, "rb"), format="wav")
    # sound = sound.set_frame_rate(16000)
    # sound = sound.set_channels(1)
    # out_path = out_path + ".wav"
    # sound.export(out_path, format='wav')

    wav_str = encoded_wav(out_path)
    RESULT = {"result": wav_str}
    RESULT = json.dumps(RESULT)
    return RESULT


if __name__ == "__main__":
    if not os.path.exists("results"):
        os.mkdir("results")
    logger = set_log(root_dir + '/log/')
    app.run(host='0.0.0.0', port=8815)
    # app.run(host='0.0.0.0', port=8816)

    # nohup python -u start_rest.py >2022.5.7.out
"""
nvidia-docker run \
-p 8899:22 \
-p 8815:8815 \
-v /home/vca/skk:/home/vca/skk \
-v /root/.paddlespeech:/root/.paddlespeech \
-v /root/datasets:/root/datasets \
--shm-size 256G \
-it paddlespeech:v0.0.4 /bin/bash \
"""
