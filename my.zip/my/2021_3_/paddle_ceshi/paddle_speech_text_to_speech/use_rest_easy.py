import requests
import json
import base64
import time

def decoded_wav(wav_str, file_name):
    wav_decode_ = wav_str.encode('utf8')  # ascii编码
    wav_decode = base64.b64decode(wav_decode_)  # base64解码
    fw = open(file_name, "wb")
    fw.write(wav_decode)

# sentence = "今天是2017-10-31，星期三"
# sentence = "今天是2017/10/31，星期三"
# sentence = "今天去超市花了1234元。"
# sentence = "小明考试考了98分。"
# sentence = "小明穿过人行道去银行存钱。"
# sentence = "这两批货物都打折出售，严重折本，他再也经不起这样折腾了。"
# sentence = "人要行，干一行行一行，一行行行行行;"
# sentence = "佟大为妻子产下一女"
# sentence = "今天是2022年1月14，星期五"
sentence = "全国一共有112所211高校"

begin_time = time.time()
res = requests.post(url='http://10.229.89.98:8815/TTS', json={'sentence': sentence})
result = json.loads(res.text)
file_name = "./results/{}.wav1.wav".format(sentence[:5])
wav_decode = decoded_wav(result["result"], file_name)
print(111111, len(sentence), time.time() - begin_time)
