# coding:utf-8
# CreatDate: 2021/12/31 9:19 by ZTE
# Author: Kangkang Sun
import os
import sys
os.environ["CUDA_VISIBLE_DEVICES"] = "2"

import paddle

root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../"))
print("root_dir=======", root_dir)
sys.path.insert(1, root_dir)

from paddlespeech.cli import TTSExecutor

#  __call__ 中的 _init_from_path  if hasattr(self, 'am_inference') and hasattr(self, 'voc_inference'):

def load_model(model_dir_am, model_dir_voc):
    tts_executor = TTSExecutor()
    am_ckpt = os.path.join(model_dir_am, "snapshot_iter_76000.pdz")
    am_config = os.path.join(model_dir_am, "default.yaml")
    am_stat = os.path.join(model_dir_am, "speech_stats.npy")
    phones_dict = os.path.join(model_dir_am, "phone_id_map.txt")

    voc_ckpt = os.path.join(model_dir_voc, "pwg_snapshot_iter_400000.pdz")
    voc_config = os.path.join(model_dir_voc, "pwg_default.yaml")
    voc_stat = os.path.join(model_dir_voc, "pwg_stats.npy")

    tts_executor._init_from_path(am_ckpt=am_ckpt, am_config=am_config, am_stat=am_stat, phones_dict=phones_dict,
                                 voc_ckpt=voc_ckpt, voc_config=voc_config, voc_stat=voc_stat)
    return tts_executor


def deal_one(tts_executor, sentence, output='output.wav', merge_sentences=True):
    wav_file = tts_executor(
        text=sentence,
        output=output,
        am='fastspeech2_csmsc',
        voc='pwgan_csmsc',
        lang='zh',
        device=paddle.get_device(),
        merge_sentences=merge_sentences,
    )
    return wav_file


if __name__ == '__main__':
    model_dir_am = "/root/.paddlespeech/models/fastspeech2_csmsc-zh/fastspeech2_nosil_baker_ckpt_0.4"
    model_dir_voc = "/root/.paddlespeech/models/pwgan_csmsc-zh/pwg_baker_ckpt_0.4"
    tts_executor = load_model(model_dir_am, model_dir_voc)
    sentence = "今天的天气不错啊。明天天气怎么样。"
    output = '/home/vca/skk/code/paddle/PaddleSpeech_211227/demos/text_to_speech/ceshi/output.wav'
    wav_file = deal_one(tts_executor, sentence, output, merge_sentences=False)
