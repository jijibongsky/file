# coding:utf-8
# CreatDate: 2022/2/14 17:28 by ZTE
# Author: Kangkang Sun
import paddle

# use_gpu = True
use_gpu = False
device = 'gpu:{}'.format(0) if use_gpu else 'cpu'
device = paddle.set_device(device)

def where_ceshi1():
    import paddle
    x = paddle.to_tensor([0.9383, 0.1983, 3.2, 1.2])
    y = paddle.to_tensor([1.0, 1.0, 1.0, 1.0])
    out = paddle.where(x > 1, x, y)
    print(out)

# T temp = x * static_cast<T>(slope) + static_cast<T>(offset);
# T temp_max = temp > zero ? temp : zero;
# T temp_min = temp_max < one ? temp_max : one;
# return temp_min;

def sigmoid_ceshi():
    m = paddle.nn.Sigmoid()
    x = paddle.to_tensor([[-1.0, -2.0, 3.0, 4.0], [1.0, 2.0, -3.0, -4.0]])
    out = m(x)
    print(111111, out)

def my_hardsigmoid(x, slope, offset):
    # temp = x * slope + offset
    # temp_max = temp > zero ? temp: zero
    # out = temp_max < one ? temp_max: one
    x = x * slope + offset
    # print(11111111111, x)
    y0 = paddle.full(shape=x.shape, dtype='float32', fill_value=0)
    y1 = paddle.full(shape=x.shape, dtype='float32', fill_value=1)
    out = paddle.where(x > 0, x, y0)
    x = paddle.where(out < 1, out, y1)
    return x


# where_ceshi1()
# sigmoid_ceshi()

# slope = 0.2
# offset = 0.5
# x = paddle.to_tensor([[-1.0, 0.2, 3.0, 4.0], [1.0, 2.0, 0.3, -4.0]])
# x = my_hardsigmoid(x, slope, offset)
# print(22222222, x)
