# coding:utf-8
# CreatDate: 2022/3/31 11:11 by ZTE
# Author: Kangkang Sun

import paddle.nn.functional as F
import numpy as np
import paddle

# input_data = np.random.rand(2, 3, 4, 5)
input_data = np.random.rand(2, 3, 4) * 12
x = paddle.to_tensor(input_data, dtype="float32")
outputs = F.relu6(x)
print(111111, outputs)
