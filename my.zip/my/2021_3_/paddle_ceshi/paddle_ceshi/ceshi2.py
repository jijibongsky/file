# coding:utf-8
# CreatDate: 2022/3/21 15:51 by ZTE
# Author: Kangkang Sun
import paddle
import numpy as np
from paddle.nn import Conv2D
import paddle.nn as nn

# use_gpu = True
use_gpu = False
device = 'gpu:{}'.format(0) if use_gpu else 'cpu'
device = paddle.set_device(device)

n1 = 2
n2 = 3
input_data = np.random.rand(n1, n2, 1, 48)
x = paddle.to_tensor(input_data, dtype="float32")

# adaptive_avg_pool = paddle.nn.AdaptiveAvgPool2D(output_size=1)
# pool_out = adaptive_avg_pool(x=x)
# print(111111111111, pool_out.shape)

conv1 = Conv2D(
    in_channels=n2,
    out_channels=n2,
    kernel_size=2,
    stride=2,
    padding=0,
)
# pool_out_1 = conv1(x)
# print(2222222222222, pool_out_1.shape)

kernel_size = [1, 24]
pool2d_max = nn.AvgPool2D(kernel_size=kernel_size, stride=[1, 1], padding=0)
size = x.shape
out = paddle.sum(x, axis=3, keepdim=True) / size[-1]

pool_out2 = pool2d_max(x)
print(333333333333, pool_out2.shape)
print(444444444444, out.shape)
