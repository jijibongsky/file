# coding:utf-8
# CreatDate: 2022/3/31 16:20 by ZTE
# Author: Kangkang Sun

import paddle
import paddle.nn as nn

x_var = paddle.uniform((2, 4, 8, 8), dtype='float32', min=-1., max=1.)
conv1 = nn.Conv2DTranspose(in_channels=4, out_channels=6, kernel_size=(2, 2), stride=1)
conv2 = nn.Conv2DTranspose(in_channels=4, out_channels=6, kernel_size=(2, 2), stride=2)
y_var1 = conv1(x_var)
y_var2 = conv2(x_var)
y_np1 = y_var1.numpy()
y_np2 = y_var2.numpy()
print(y_np1.shape)  # (2, 6, 9, 9)
print(y_np2.shape)  # (2, 6, 16, 16)
