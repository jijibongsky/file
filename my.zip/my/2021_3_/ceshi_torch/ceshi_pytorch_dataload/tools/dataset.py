import random
import os
import torch
import torch.distributed as dist
from torch.utils.data import IterableDataset


import tools.processor as processor

def read_lists(list_file):
    lists = []
    with open(list_file, 'r', encoding='utf8') as fin:
        iii = 0
        for line in fin:
            # lists.append(line.strip())
            if os.path.exists(line.strip()) and os.path.getsize(line.strip()):
                lists.append(line.strip())
            # else:
            #     iii += 1
            #     print(11111111, line.strip())
        # print(iii)
        # input(11)
    return lists

def read_symbol_table(symbol_table_file):
    symbol_table = {}
    with open(symbol_table_file, 'r', encoding='utf8') as fin:
        for line in fin:
            arr = line.strip().split()
            assert len(arr) == 2
            symbol_table[arr[0]] = int(arr[1])
    return symbol_table

class Processor(IterableDataset):
    def __init__(self, source, f, *args, **kw):
        assert callable(f)
        self.source = source
        self.f = f
        self.args = args
        self.kw = kw

    def set_epoch(self, epoch):
        self.source.set_epoch(epoch)

    def __iter__(self):
        """ Return an iterator over the source dataset processed by the
            given processor.
        """
        assert self.source is not None
        assert callable(self.f)
        return self.f(iter(self.source), *self.args, **self.kw)

    def apply(self, f):
        assert callable(f)
        return Processor(self, f, *self.args, **self.kw)


class DistributedSampler:
    def __init__(self, shuffle=True, partition=True):
        self.epoch = -1
        self.update()
        self.shuffle = shuffle
        self.partition = partition

    def update(self):
        assert dist.is_available()
        if dist.is_initialized():
            self.rank = dist.get_rank()
            self.world_size = dist.get_world_size()
        else:
            self.rank = 0
            self.world_size = 1
        worker_info = torch.utils.data.get_worker_info()
        if worker_info is None:
            self.worker_id = 0
            self.num_workers = 1
        else:
            self.worker_id = worker_info.id
            self.num_workers = worker_info.num_workers
        return dict(rank=self.rank,
                    world_size=self.world_size,
                    worker_id=self.worker_id,
                    num_workers=self.num_workers)

    def set_epoch(self, epoch):
        self.epoch = epoch

    def sample(self, data):
        """ Sample data according to rank/world_size/num_workers

            Args:
                data(List): input data list

            Returns:
                List: data list after sample
        """
        data = data.copy()
        # TODO(Binbin Zhang): fix this
        # We can not handle uneven data for CV on DDP, so we don't
        # sample data by rank, that means every GPU gets the same
        # and all the CV data
        if self.partition:
            if self.shuffle:
                random.Random(self.epoch).shuffle(data)
            data = data[self.rank::self.world_size]
        data = data[self.worker_id::self.num_workers]
        return data


class DataList(IterableDataset):
    def __init__(self, lists, shuffle=True, partition=True):
        self.lists = lists
        self.sampler = DistributedSampler(shuffle, partition)

    def set_epoch(self, epoch):
        self.sampler.set_epoch(epoch)

    def __iter__(self):
        sampler_info = self.sampler.update()
        lists = self.sampler.sample(self.lists)
        for src in lists:
            # yield dict(src=src)
            data = dict(src=src)
            # print(11111111, src)   # /home/vca/skk/data/ASR/english/GigaSpeech/unified_data/giga_shards/train_xs/shards_000000007.tar
            # print(22222222, data)  # {'src': '/home/vca/skk/data/ASR/english/GigaSpeech/unified_data/giga_shards/train_xs/shards_000000008.tar'}
            data.update(sampler_info)
            yield data


def Dataset(data_type, data_list_file, symbol_table, conf,
            bpe_model=None, partition=True):
    """ Construct dataset from arguments

        We have two shuffle stage in the Dataset. The first is global
        shuffle at shards tar/raw file level. The second is global shuffle
        at training samples level.

        Args:
            data_type(str): raw/shard
            bpe_model(str): model for english bpe part
            partition(bool): whether to do data partition in terms of rank
    """
    assert data_type in ['raw', 'shard']
    lists = read_lists(data_list_file)
    # print(1111111, lists)
    #  ['/home/vca/skk/data/ASR/english/GigaSpeech/unified_data/giga_shards/train_xs/shards_000000000.tar',
    # '/home/vca/skk/data/ASR/english/GigaSpeech/unified_data/giga_shards/train_xs/shards_000000001.tar',
    # '/home/vca/skk/data/ASR/english/GigaSpeech/unified_data/giga_shards/train_xs/shards_000000002.tar',
    # '/home/vca/skk/data/ASR/english/GigaSpeech/unified_data/giga_shards/train_xs/shards_000000003.tar']

    shuffle = conf.get('shuffle', True)
    dataset = DataList(lists, shuffle=shuffle, partition=partition)

    if data_type == 'shard':
        dataset = Processor(dataset, processor.url_opener)  # 更新数据 dict，加入一个新的 key stream。
        dataset = Processor(dataset, processor.tar_file_and_group)
        # for data in dataset:
        #     print(1111111111, data)
        # dataset 每一项元素类似于如下：读取二进制文件在里面。
        # {'txt': '坐在警车里吃方便面啃面包',
        # 'wav': tensor([[-0.0008, -0.0013, -0.0011,  ..., -0.0015, -0.0015, -0.0016]]),
        # 'sample_rate': 16000, 'key': 'BAC009S0352W0449'}
    else:
        dataset = Processor(dataset, processor.parse_raw)
    ##
    dataset = Processor(dataset, processor.tokenize, symbol_table, bpe_model)  # 每一项增加 tokens（分词）和 label（ID）两个字段。
    filter_conf = conf.get('filter_conf', {})
    dataset = Processor(dataset, processor.filter, **filter_conf)  # 过滤掉一些异常数据

    resample_conf = conf.get('resample_conf', {})
    dataset = Processor(dataset, processor.resample, **resample_conf)

    speed_perturb = conf.get('speed_perturb', False)
    if speed_perturb:
        dataset = Processor(dataset, processor.speed_perturb)

    fbank_conf = conf.get('fbank_conf', {})
    dataset = Processor(dataset, processor.compute_fbank, **fbank_conf)

    spec_aug = conf.get('spec_aug', True)
    if spec_aug:
        spec_aug_conf = conf.get('spec_aug_conf', {})
        dataset = Processor(dataset, processor.spec_aug, **spec_aug_conf)

    if shuffle:
        shuffle_conf = conf.get('shuffle_conf', {})
        dataset = Processor(dataset, processor.shuffle, **shuffle_conf)

    sort = conf.get('sort', True)
    if sort:
        sort_conf = conf.get('sort_conf', {})
        dataset = Processor(dataset, processor.sort, **sort_conf)

    batch_conf = conf.get('batch_conf', {})
    dataset = Processor(dataset, processor.batch, **batch_conf)
    dataset = Processor(dataset, processor.padding)
    return dataset
