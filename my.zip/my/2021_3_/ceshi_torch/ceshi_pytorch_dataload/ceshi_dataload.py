# coding:utf-8
# CreatDate: 2022/3/2 12:47 by ZTE
# Author: Kangkang Sun

from torch.utils.data import DataLoader
from tools.dataset import Dataset, read_symbol_table
# 运行环境  98 服务器 wenet

data_type = 'shard'
train_data = 'data.list'
bpe_model = "/home/vca/skk/code/torch/wenet_211101/examples/gigaspeech/s0/data_giga_mls_english_opus/lang_char/train_unigram5000.model"
symbol_table_file = "/home/vca/skk/code/torch/wenet_211101/examples/gigaspeech/s0/data_giga_mls_english_opus/lang_char/train_unigram5000_units.txt"

symbol_table = read_symbol_table(symbol_table_file)
train_conf = {'filter_conf': {'max_length': 2000, 'min_length': 100, 'token_max_length': 160, 'token_min_length': 1},
              'resample_conf': {'resample_rate': 16000},
              'speed_perturb': False,
              'fbank_conf': {'num_mel_bins': 80, 'frame_shift': 10, 'frame_length': 25, 'dither': 1.0},
              'spec_aug': True,
              'spec_aug_conf': {'num_t_mask': 3, 'num_f_mask': 2, 'max_t': 50, 'max_f': 10},
              'shuffle': True,
              'shuffle_conf': {'shuffle_size': 1500},
              'sort': True,
              'sort_conf': {'sort_size': 500},
              'batch_conf': {'batch_type': 'static', 'batch_size': 2}}  # 'batch_conf': {'batch_type': 'dynamic', 'max_frames_in_batch': 24000}

train_dataset = Dataset(data_type, train_data, symbol_table,
                        train_conf, bpe_model, partition=True)

data_loader = DataLoader(train_dataset,
                         batch_size=None,
                         pin_memory=False,
                         num_workers=1,
                         prefetch_factor=100)

for batch_idx, batch in enumerate(data_loader):
    key, feats, target, feats_lengths, target_lengths = batch
    print(111111, key)
    print(222222, feats.shape)
    print(333333, target.shape)
    print(444444, feats_lengths.shape)
    print(555555, target_lengths.shape)
    print()
