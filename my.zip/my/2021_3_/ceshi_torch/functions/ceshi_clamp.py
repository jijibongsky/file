# coding=utf-8
# Copyright 2020/8/4 15:57 by ZTE
# Author: Kangkang Sun
import torch
import numpy as np
import random

feature = [i + 0.5 for i in range(10)]
random.shuffle(feature)
feature = torch.tensor(feature)
print(1111111, feature)
feature = torch.clamp(feature, 3, 9)
print(2222222, feature)
