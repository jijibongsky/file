# coding=utf-8
# Copyright 2020/7/31 11:08 by ZTE
# Author: Kangkang Sun

import torch
import torch.nn as nn
import numpy as np

def ceshi1():
    # # my_func = nn.Sequential(nn.ReflectionPad1d(2))
    # my_func = nn.ReflectionPad1d(2)
    # x = np.random.random((1, 2, 4))
    # x1 = torch.tensor(x, dtype=torch.float32)
    # y1 = my_func(x1)
    # print(1111111, x.shape, x)
    # print(2222222, y1.shape, y1)

    x = np.random.random((1, 2, 4))
    x1 = torch.tensor(x, dtype=torch.float32)
    # y1 = my_func(x1)
    y1 = nn.ReflectionPad1d(2)(x1)
    print(1111111, x.shape, x)
    print(2222222, y1.shape, y1)


def ceshi2():
    odim = 256
    conv = nn.Sequential(
                nn.Conv2d(1, odim, 3, 2),
                nn.ReLU(),
                nn.Conv2d(odim, odim, 3, 2),
                nn.ReLU()
            )

    x = np.random.random((32, 1, 587, 40))
    x = torch.tensor(x, dtype=torch.float32)
    f1 = nn.Conv2d(1, odim, 3, 2)  # in_channels, out_channels, kernel_size, stride
    y1 = f1(x)
    y2 = conv(x)
    print(1111111, y1.shape)
    print(2222222, y2.shape)
