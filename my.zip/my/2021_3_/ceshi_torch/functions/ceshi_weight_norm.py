# coding=utf-8
# Copyright 2020/7/31 11:13 by ZTE
# Author: Kangkang Sun
import torch
import torch.nn as nn
import numpy as np

x = np.random.random((1, 2, 5))
x = torch.tensor(x, dtype=torch.float32)
f = nn.utils.weight_norm(nn.Conv1d(2, 3, kernel_size=2, stride=1))
z = f(x)
z1 = nn.Conv1d(2, 3, kernel_size=2, stride=1)(x)
print(3333333, z)
print(4444444, z1)

# 有问题
# x = np.random.random((3, 80, 16))
# x = torch.tensor(x, dtype=torch.float32)
# conv = nn.Conv1d(80, 512, kernel_size=7, stride=1)
# y = conv(x)
# z = nn.utils.weight_norm(y)
# print(2222222, y.shape)
# print(3333333, z.shape)
