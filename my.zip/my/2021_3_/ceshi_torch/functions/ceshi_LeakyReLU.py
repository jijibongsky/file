# coding=utf-8
# Copyright 2020/5/27 14:23 by ZTE
# Author: Kangkang Sun
import torch
import numpy as np
import torch.nn as nn

feature = np.array([[[0, 0, 0], [-0.1, 0.3, -4], [3, 4, 5]]])
feature = torch.tensor(feature)
# if x > 0: y = c else: y = kx
a = nn.LeakyReLU(0.2)(feature)
print(feature)
print(a)
