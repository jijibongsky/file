# coding=utf-8
# Copyright 2020/5/27 15:29 by ZTE
# Author: Kangkang Sun
import torch

a = torch.randn(5, 6)
x = [5, 4, 3, 2, 1]
mask = torch.zeros(5, 6, dtype=torch.float)
for e_id, src_len in enumerate(x):
    mask[e_id, src_len:] = 1
print(1111111, mask.shape)
print(2222222, a.shape)
a.masked_fill_(mask.byte(), -float('inf'))
print(3333333, a.shape)

print(4444444, -float('inf'))
print(5555555, mask)
print(6666666, a)
