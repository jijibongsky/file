# coding=utf-8
# Copyright 2020/7/30 17:20 by ZTE
# Author: Kangkang Sun

import torch
import torch.nn as nn
import numpy as np


# # my_func = nn.Sequential(nn.ReflectionPad1d(2))
# my_func = nn.ReflectionPad1d(2)
# x = np.random.random((1, 2, 4))
# x1 = torch.tensor(x, dtype=torch.float32)
# y1 = my_func(x1)
# print(1111111, x.shape, x)
# print(2222222, y1.shape, y1)


x = np.random.random((1, 2, 4))
x1 = torch.tensor(x, dtype=torch.float32)
# y1 = my_func(x1)
y1 = nn.ReflectionPad1d(2)(x1)
print(1111111, x.shape, x)
print(2222222, y1.shape, y1)
