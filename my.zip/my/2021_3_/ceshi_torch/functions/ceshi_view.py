# coding=utf-8
# Copyright 2020/5/27 15:05 by ZTE
# Author: Kangkang Sun
import torch
import torch.nn as nn
import numpy as np
idim = 40
odim = 256

f = nn.Sequential(
    nn.Linear(odim * (((idim - 1) // 2 - 1) // 2), odim),
    # PositionalEncoding(odim, dropout_rate)
)

x = np.random.random((32, 256, 146, 9))
x = torch.tensor(x, dtype=torch.float32)
x = torch.tensor(x)
b, c, t, f = x.size()
x = x.transpose(1, 2)
print(11111, x.shape)
x = x.contiguous()  # 没有这一步下面的 .view 会报错。
print(22222, x.shape)
x = x.view(b, t, c * f)   # 相当于numpy中resize（）的功能
print(33333, x.shape)
# x = f(x1)
# print(x.shape)
