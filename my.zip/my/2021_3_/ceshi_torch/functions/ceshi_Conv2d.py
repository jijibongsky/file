# coding=utf-8
# Copyright 2020/5/27 14:49 by ZTE
# Author: Kangkang Sun
import torch
import torch.nn as nn
import numpy as np
odim = 256

x = np.random.random((32, 1, 587, 40))
x = torch.tensor(x, dtype=torch.float32)
f = nn.Conv2d(1, odim, 3, 2)  # in_channels, out_channels, kernel_size, stride
y = f(x)
print(1111111, y.shape)
