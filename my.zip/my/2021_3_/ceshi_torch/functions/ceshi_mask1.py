# coding=utf-8
# Copyright 2020/5/27 16:09 by ZTE
# Author: Kangkang Sun
import torch

PAD = 0


def get_dec_seq_mask(targets, targets_length=None):
    steps = targets.size(-1)
    padding_mask = targets.ne(PAD).unsqueeze(-2)
    seq_mask = torch.ones([steps, steps], device=targets.device)
    seq_mask = torch.tril(seq_mask).bool()
    seq_mask = seq_mask.unsqueeze(0)
    return seq_mask & padding_mask

x = torch.tensor([[1, 2, 3, 0, 0], [1, 2, 0, 0, 0]])
y = get_dec_seq_mask(x)
print(y)
