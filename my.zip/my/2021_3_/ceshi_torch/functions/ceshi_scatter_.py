# coding=utf-8
# Copyright 2020/5/28 16:39 by ZTE
# Author: Kangkang Sun
import torch
confidence = 0.9
true_dist = [[0.0500, 0.0500, 0.0500],
        [0.0500, 0.0500, 0.0500],
        [0.0500, 0.0500, 0.0500]]
target = [1, 2, 0]
true_dist = torch.tensor(true_dist)
target = torch.tensor(target)
true_dist.scatter_(1, target.unsqueeze(1), confidence)   # dim, index, src
print(1111111, target.unsqueeze(1))
print(2222222, true_dist)
