# coding=utf-8
# Copyright 2020/5/27 14:37 by ZTE
# Author: Kangkang Sun
import torch

# 运算函数
# 大于 torch.gt
# 小于 torch.lt
# 等于 torch.eq
# 非零 torch.nonzero
# 非 torch.ne

tensor = torch.tensor([[1, 2, 3], [0, 1, 0]])
a = tensor.ne(0)
print(a)
