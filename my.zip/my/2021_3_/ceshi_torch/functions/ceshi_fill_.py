# coding=utf-8
# Copyright 2020/5/28 16:36 by ZTE
# Author: Kangkang Sun
import torch
import numpy as np

smoothing = 0.1
feature = np.random.random((2, 3, 4))
# feature = np.array([[[0, 0, 0], [2, 3, 4], [3, 4, 5]]])
x = torch.tensor(feature)
size = x.size(2)
true_dist = x.clone()
print(111111, true_dist)
true_dist.fill_(smoothing / (size - 1))
print(222222, true_dist)
