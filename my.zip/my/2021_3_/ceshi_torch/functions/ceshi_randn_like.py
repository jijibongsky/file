# coding=utf-8
# Copyright 2020/8/7 17:48 by ZTE
# Author: Kangkang Sun
import torch
import numpy as np

feature = np.random.random((2, 3))
feature = torch.tensor(feature)
a = torch.randn_like(feature)
print(a)
