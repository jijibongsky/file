# coding=utf-8
# Copyright 2020/5/27 14:45 by ZTE
# Author: Kangkang Sun
import torch
import numpy as np

x = np.random.random((2, 3, 4))
x = torch.tensor(x)
y = x.unsqueeze(1)
print(11111111, x.shape)
print(22222222, y.shape)
