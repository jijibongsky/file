# coding=utf-8
# Copyright 2020/5/27 14:49 by ZTE
# Author: Kangkang Sun
import torch
import torch.nn as nn
import numpy as np

a = torch.cuda.is_available()
print(111111111, a)

# conv = nn.Conv1d(80, 512, kernel_size=7, stride=1)
conv = nn.Conv1d(80, 512, kernel_size=1, stride=1)
# conv = nn.Conv1d(80, 80, kernel_size=3, stride=1, dilation=4, groups=80)
x = np.random.random((3, 80, 16))
x = torch.tensor(x, dtype=torch.float32)
y2 = conv(x)
print(2222222, y2.shape)
