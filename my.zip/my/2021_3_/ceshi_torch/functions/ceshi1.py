# coding=utf-8
# Copyright 2020/5/27 14:23 by ZTE
# Author: Kangkang Sun
import torch
import torch.nn as nn
import numpy as np

feature = np.random.random((3, 256, 80))
feature = torch.tensor(feature)
feature = feature.clone().detach().float()
# f = nn.ConvTranspose1d(256, 128, kernel_size=16, stride=8, padding=4)
f = nn.ConvTranspose1d(256, 128, kernel_size=16, stride=8, padding=4)
a = f(feature)
print(a.shape)

input = 128
stride = 8
padding = 4
kernelSize = 16
a = (input - 1) * stride - 2 * padding + kernelSize + padding
b = (input - 1) * stride - 2 * padding + kernelSize
c = (input - 1) * stride - 2 * padding + 1 * (kernelSize - 1) + padding + 1
print(1111111, a)
print(1111111, b)
print(1111111, c)
