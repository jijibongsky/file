# coding:utf-8
# CreatDate: 2021/1/5 16:22 by ZTE
# Author: Kangkang Sun
import torch

x = torch.randn([2, 3, 4])
y = x.repeat(4, 1, 1)

print(11111, x.shape, x)
print(22222, y.shape, y)
