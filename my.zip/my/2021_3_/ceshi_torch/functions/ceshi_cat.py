# coding:utf-8
# CreatDate: 2021/11/12 14:13 by ZTE
# Author: Kangkang Sun

import torch
import numpy as np
# x = np.random.random((1, 4, 5))
# x1 = np.zeros((1, 2, 5))
x = np.random.random((1, 4))
x1 = np.zeros((1, 2))

x = torch.tensor(x, dtype=torch.float32)
x1 = torch.tensor(x1, dtype=torch.float32)
y = torch.cat([x, x1], 1)
print(x.shape)
print(y.shape)
