# coding=utf-8
# Copyright 2020/6/8 16:43 by ZTE
# Author: Kangkang Sun

import torch

ngpu = 1
print(torch.cuda.is_available())
device = torch.device("cuda:0" if (torch.cuda.is_available() and ngpu > 0) else "cpu")
print(device)

print(torch.cuda.get_device_name(0))
print(torch.rand(3, 3).cuda())
input()
