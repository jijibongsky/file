# coding:utf-8
# CreatDate: 2021/12/27 20:52 by ZTE
# Author: Kangkang Sun

import torch


class InputFeatures(object):
    """A single set of features of data."""

    def __init__(self, input_ids, input_mask):
        self.input_ids = input_ids
        self.input_mask = input_mask


a = InputFeatures(input_ids=1, input_mask=2)
b = InputFeatures(input_ids=3, input_mask=4)
features = [a, b]
cached_features_file = "ceshi"
# torch.save(features, cached_features_file)
features1 = torch.load(cached_features_file)
print(1111111, features1)
print(2222222, features1[0].input_ids)
