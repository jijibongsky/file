# coding=utf-8
# Copyright 2020/6/8 11:07 by ZTE
# Author: Kangkang Sun
import torch
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
flag_gpu = torch.cuda.is_available()

def checkpoint_averaging(model_paths, out_put_path):
    checkpoint = torch.load(model_paths[0], map_location='cuda:0' if flag_gpu else "cpu")
    new_model = checkpoint['model']
    N = len(model_paths)
    for key in new_model:
        new_model[key] = new_model[key] / N
    for model_path in model_paths[1:]:
        checkpoint = torch.load(model_path, map_location='cuda:0' if flag_gpu else "cpu")
        model = checkpoint['model']
        for key in model:
            new_model[key] += model[key] / N
    torch.save({"model": new_model}, out_put_path)

if __name__ == '__main__':
    model_paths = []
    out_put_path = "checkpoint_averaging.pt"
    checkpoint_averaging(model_paths, out_put_path)
