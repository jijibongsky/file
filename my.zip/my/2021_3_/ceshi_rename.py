# coding:utf-8
# CreatDate: 2021/12/7 10:09 by ZTE
# Author: Kangkang Sun
import os

def my_move(file1, file2):
    fr = open(file1, "rb")
    fw = open(file2, "wb")
    for line in fr:
        fw.write(line)
