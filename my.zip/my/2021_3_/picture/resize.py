from PIL import Image
import cv2

data_file_in = "/Users/sunkangkang/Downloads/IMG_6186.JPG"
data_file_out = "/Users/sunkangkang/Downloads/IMG_6186_1.JPG"

# im = Image.open(data_file_in)
# (x, y) = im.size
# print(x, y)
# out = im.resize((295, 413), Image.ANTIALIAS)  # resize image with high-quality
# out = out.convert('RGB')
# out.save(data_file_out)

a = 1518/2280
b = 295/413
print(111, a, b)

img = cv2.imread(data_file_in)
img=img[77:-78, :]
print(1111, img.shape)
dst = cv2.resize(img, (295, 413))
cv2.imwrite(data_file_out, dst)
