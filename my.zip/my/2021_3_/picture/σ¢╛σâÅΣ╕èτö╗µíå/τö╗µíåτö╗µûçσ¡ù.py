# coding=utf-8
# Copyright  2020/09/30 15:04 by ZTE
# Author: Kangkang Sun
import numpy as np
import math
from PIL import Image, ImageDraw, ImageFont
import random
import cv2


def draw_ocr_box_txt(image_file,
                     boxes,
                     drop_score=0.5,
                     font_path="/home/vca/skk/code/paddle/PaddleOCR/doc/simfang.ttf"):
    img = cv2.imread(image_file)
    image = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))

    h, w = image.height, image.width
    img_left = image.copy()
    img_right = Image.new('RGB', (w, h), (255, 255, 255))

    import random
    random.seed(0)
    draw_left = ImageDraw.Draw(img_left)
    draw_right = ImageDraw.Draw(img_right)
    for txt, box, score in boxes:
        box = np.array(box, dtype="float32")
        if score < drop_score:
            continue
        color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        draw_left.polygon(box, fill=color)
        # draw_left.polygon(box, outline=(0, 0, 0))  # 黑线
        draw_right.polygon(
            [
                box[0][0], box[0][1], box[1][0], box[1][1], box[2][0],
                box[2][1], box[3][0], box[3][1]
            ],
            outline=color)
        box_height = math.sqrt((box[0][0] - box[3][0]) ** 2 + (box[0][1] - box[3][1]) ** 2)
        box_width = math.sqrt((box[0][0] - box[1][0]) ** 2 + (box[0][1] - box[1][1]) ** 2)
        if box_height > 2 * box_width:
            font_size = max(int(box_width * 0.9), 10)
            font = ImageFont.truetype(font_path, font_size, encoding="utf-8")
            cur_y = box[0][1]
            for c in txt:
                char_size = font.getsize(c)
                draw_right.text((box[0][0] + 3, cur_y), c, fill=(0, 0, 0), font=font)
                cur_y += char_size[1]
        else:
            font_size = max(int(box_height * 0.8), 10)
            font = ImageFont.truetype(font_path, font_size, encoding="utf-8")
            draw_right.text([box[0][0], box[0][1]], txt, fill=(0, 0, 0), font=font)
    img_left = Image.blend(image, img_left, 0.5)  # 两张图融合显示
    img_show = Image.new('RGB', (w * 2, h), (255, 255, 255))
    img_show.paste(img_left, (0, 0, w, h))  # 图片指定区域替换
    img_show.paste(img_right, (w, 0, w * 2, h))
    return np.array(img_show)


def draw_lines(image_file, boxes, drop_score=0.5, font_path="/home/vca/skk/code/paddle/PaddleOCR/doc/simfang.ttf"):
    img = cv2.imread(image_file)
    image = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    draw_ = ImageDraw.Draw(image)

    for txt, box, score in boxes:
        if score < drop_score:
            continue
        box = np.array(box, dtype="float32")
        print(1111111111, box)
        print(2222222222, txt)
        draw_.polygon(box, outline=(0, 0, 0))  # 黑线
        # draw_left.polygon(box, fill=(0, 0, 0))

        box_height = math.sqrt((box[0][0] - box[3][0]) ** 2 + (box[0][1] - box[3][1]) ** 2)
        font_size = max(int(box_height * 0.8), 10)
        font = ImageFont.truetype(font_path, font_size, encoding="utf-8")
        # draw_.text([box[0][0], box[0][1]], txt, fill=(0, 0, 0), font=font)  # 在原图对应位置写字，要和
        draw_.text([box[0][0], box[0][1] - 15], txt, fill=(0, 0, 0), font=font)

    image = np.array(image)
    return image


if __name__ == '__main__':
    txt_box = [['苏A(**)C', [[2015, 1006], [2105, 999], [2106, 1030], [2016, 1039], [2015, 1006]], 1],
               ['1227607C', [[1982, 1050], [2106, 1034], [2105, 1064], [1985, 1081], [1982, 1050]], 1],
               ['苏A(**)C', [[1110, 1288], [1223, 1265], [1229, 1300], [1116, 1322], [1110, 1288]], 1],
               ['1351745C', [[1079, 1333], [1230, 1304], [1235, 1338], [1085, 1364], [1079, 1333]], 1],
               ['苏A(**)C', [[192, 1159], [307, 1160], [309, 1199], [192, 1196], [192, 1159]], 1],
               ['1679198C', [[155, 1199], [310, 1206], [310, 1242], [157, 1235], [155, 1199]], 1]]

    image_file = "/home/vca/skk/data/OCR/数据堂车牌/电动车牌标注返修batch01_不包含自行车等属性_20220527/picture/南京_高度2距离2_00002.jpg"
    img_left = draw_lines(image_file, txt_box)
    cv2.imwrite("/home/vca/skk/code/paddle/PaddleOCR_210703/output/ceshi.jpg", img_left[:, :, ::-1])
    img = draw_ocr_box_txt(image_file, txt_box)
    cv2.imwrite("/home/vca/skk/code/paddle/PaddleOCR_210703/output/ceshi1.jpg", img[:, :, ::-1])
