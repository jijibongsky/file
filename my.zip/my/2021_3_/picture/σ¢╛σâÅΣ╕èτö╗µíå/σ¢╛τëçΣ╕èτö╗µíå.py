# coding:utf-8
# CreatDate: 2022/3/17 16:00 by ZTE
# Author: Kangkang Sun

import cv2
import numpy as np
from PIL import Image, ImageDraw


def draw_ocr_box_txt(image_file, boxes):
    img = cv2.imread(image_file)
    img = img[:, :, ::-1]
    image = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    h, w = image.height, image.width
    img_left = image.copy()
    import random
    random.seed(0)
    draw_left = ImageDraw.Draw(img_left)
    for box in boxes:
        box = np.array(box, dtype="float32")
        color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        draw_left.polygon(box, fill=color)
        # draw_left.polygon(box, outline=(0, 0, 0))  # 黑线
    img_left = Image.blend(image, img_left, 0.5)  # 两张图融合显示
    img_show = Image.new('RGB', (w, h), (255, 255, 255))
    img_show.paste(img_left, (0, 0, w, h))  # 图片指定区域替换
    return np.array(img_show)

image_file = "/home/vca/skk/data/OCR/电瓶车牌/ocr_carid_labeled/images_640_640/liu2_shu3_guang1_11.jpg"
dt_boxes = [[[297, 293], [424, 293], [424, 333], [297, 333]]]
img = draw_ocr_box_txt(image_file, dt_boxes)
cv2.imwrite("/home/vca/skk/code/paddle/PaddleOCR_210703/output/扩充.jpg", img)
