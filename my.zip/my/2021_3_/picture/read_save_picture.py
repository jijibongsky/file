# coding:utf-8
# CreatDate: 2022/2/16 16:03 by ZTE
# Author: Kangkang Sun

from PIL import Image
import numpy as np
import cv2


def read_save():
    image_file = "/home/vca/skk/code/paddle/ONNXRunTimeOCR/images/ocr_15.png"
    image_file_out = "/home/vca/skk/code/paddle/PaddleOCR_210703/output/ceshi.png"
    # img = np.array(Image.open(image_file).convert('RGB'))
    # im2 = Image.fromarray(np.uint8(img))
    # im2.save(image_file_out, 'png')

    # img = cv2.imread(image_file)
    # cv2.imwrite(image_file_out, img)

    img = np.array(Image.open(image_file).convert('RGB'))
    img = img[:, :, ::-1]  # 如果不加这个，颜色不对
    cv2.imwrite(image_file_out, img)
    img1 = np.rot90(img)  # 逆时针旋转90度
    cv2.imwrite(image_file_out + ".png", img1)

read_save()
