# coding:utf-8
# CreatDate: 2022/3/19 11:15 by ZTE
# Author: Kangkang Sun
import cv2
import numpy as np


def Bilinear_interpolation(src, new_size):
    dst_w, dst_h = new_size    # 目标图像的宽和高
    src_h, src_w = src.shape[:2]   # shape = (h, w, c)
    if src_h == dst_h and src_w == dst_w:
        return src.copy()
    scale_x = float(src_w) / dst_w  # 缩放比例
    scale_y = float(src_h) / dst_h

    # 遍历目标图，插值
    dst = np.zeros((dst_h, dst_w, 3), dtype=np.uint8)  # 生成一张目标尺寸大小的空白图
    for n in range(dst.shape[2]):  # 循环channel
        for dst_y in range(dst_h):
            for dst_x in range(dst_w):
                # 目标像素在原图上的坐标
                src_x = (dst_x + 0.5) * scale_x - 0.5  # src + 0.5 = (dst +0.5) * scale
                src_y = (dst_y + 0.5) * scale_y - 0.5

                # 计算在原图上四个临近点的位置
                src_x_0 = int(np.floor(src_x))  # 向下取整
                src_y_0 = int(np.floor(src_y))
                src_x_1 = min(src_x_0 + 1, src_w - 1)  # 防止出界
                src_y_1 = min(src_y_0 + 1, src_h - 1)

                # 双线性插值
                value0 = (src_x_1 - src_x) * src[src_y_0, src_x_0, n] + (src_x - src_x_0) * src[src_y_0, src_x_1, n]  # 上面两个点
                value1 = (src_x_1 - src_x) * src[src_y_1, src_x_0, n] + (src_x - src_x_0) * src[src_y_1, src_x_1, n]  # 下面两个点
                dst[dst_y, dst_x, n] = int((src_y_1 - src_y) * value0 + (src_y - src_y_0) * value1)
    return dst


if __name__ == '__main__':
    img_in = cv2.imread('/home/vca/skk/code/paddle/PaddleOCR_210703/test_data/ocr_14.jpg')
    img_out = Bilinear_interpolation(img_in, (1000, 1000))
    print(img_in.shape)
    print(img_out.shape)
    cv2.imwrite("/home/vca/skk/code/paddle/PaddleOCR_210703/output/ceshi.jpg", img_in)
    cv2.imwrite("/home/vca/skk/code/paddle/PaddleOCR_210703/output/ceshi_resize.jpg", img_out)
