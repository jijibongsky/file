# https://huggingface.co/transformers/training.html
# https://huggingface.co/transformers/custom_datasets.html

# 97 服务器 conda transformers  torch 1.7.1

# from transformers.models.bert.modeling_bert import BertForSequenceClassification, BertForTokenClassification
# BertForTokenClassification.from_pretrained(pretrained_model_name_or_path="bert-base-chinese")

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"

import torch
from sklearn.model_selection import train_test_split
from transformers import DistilBertTokenizerFast
from transformers import Trainer, TrainingArguments, AdamW
from torch.utils.data import DataLoader

# from transformers import DistilBertForSequenceClassification as SequenceClassification
# model_name = 'distilbert-base-uncased'

from transformers.models.bert.modeling_bert import BertForSequenceClassification as SequenceClassification
# model_name = 'bert-base-chinese'
# model_name = 'hfl/chinese-bert-wwm-ext'
model_name = "/home/vca1/skk/code/transformers/pretrained_models/chinese-bert-wwm-ext"

# /root/.cache/huggingface

def load_data(data_file):
    fr = open(data_file, "r", encoding="utf8")
    texts = []
    labels = []
    for i, line in enumerate(fr):
        if i > 10000:
            continue
        line = line.strip().split("\t")
        texts.append(line[1])
        labels.append(0 if line[0] == "neg" else 1)
    return texts, labels


class MyDataset(torch.utils.data.Dataset):
    def __init__(self, encodings, labels):
        self.encodings = encodings
        self.labels = labels

    def __getitem__(self, idx):
        item = {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}
        item['labels'] = torch.tensor(self.labels[idx])
        # print(11111111, item)
        # input(11)
        return item

    def __len__(self):
        return len(self.labels)


data_dir = "data/sentiment_40k/"
train_texts, train_labels = load_data(data_dir + "train.txt")
test_texts, test_labels = load_data(data_dir + "test.txt")
train_texts, val_texts, train_labels, val_labels = train_test_split(train_texts, train_labels, test_size=0.05)

tokenizer = DistilBertTokenizerFast.from_pretrained(model_name)
# train_encodings = tokenizer(train_texts, truncation=True, padding=True)
# train_encodings = tokenizer(train_texts, truncation=True, max_length=128)  # 不 padding
train_encodings = tokenizer(train_texts, truncation=True, padding="max_length", max_length=128)
val_encodings = tokenizer(val_texts, truncation=True, padding=True)
test_encodings = tokenizer(test_texts, truncation=True, padding=True)

train_dataset = MyDataset(train_encodings, train_labels)
val_dataset = MyDataset(val_encodings, val_labels)
test_dataset = MyDataset(test_encodings, test_labels)


# Fine-tuning with Trainer
# training_args = TrainingArguments(
#     output_dir='./results',  # output directory
#     num_train_epochs=3,  # total number of training epochs
#     per_device_train_batch_size=12,  # batch size per device during training
#     per_device_eval_batch_size=4,  # batch size for evaluation
#     warmup_steps=500,  # number of warmup steps for learning rate scheduler
#     weight_decay=0.01,  # strength of weight decay
#     logging_dir='./logs',  # directory for storing logs
#     logging_steps=10,
# )
# model = SequenceClassification.from_pretrained(model_name)
# trainer = Trainer(
#     model=model,  # the instantiated 🤗 Transformers model to be trained
#     args=training_args,  # training arguments, defined above
#     train_dataset=train_dataset,  # training dataset
#     eval_dataset=val_dataset  # evaluation dataset
# )
# trainer.train()


# Fine-tuning with native PyTorch
# device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
# model = SequenceClassification.from_pretrained(model_name)
# model.to(device)
# model.train()
# train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)
# optim = AdamW(model.parameters(), lr=5e-5)
# for epoch in range(3):
#     for i, batch in enumerate(train_loader):
#         if i % 100 == 0:
#             print("epoch:{} step:{}".format(epoch, i))
#         optim.zero_grad()
#         input_ids = batch['input_ids'].to(device)
#         attention_mask = batch['attention_mask'].to(device)
#         labels = batch['labels'].to(device)
#         outputs = model(input_ids, attention_mask=attention_mask, labels=labels)
#         loss = outputs[0]
#         loss.backward()
#         optim.step()


# 加载训练好的模型推理
device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
model = SequenceClassification.from_pretrained("results/checkpoint-2000")
model.to(device)
model.eval()
tokenizer = DistilBertTokenizerFast.from_pretrained(model_name)
train_texts = ["你叫什名字", "今天天气不错"]
train_encodings = tokenizer(train_texts, truncation=True, padding=True)
input_ids = torch.tensor(train_encodings["input_ids"]).to(device)
attention_mask = torch.tensor(train_encodings["attention_mask"]).to(device)
labels = torch.tensor([1] * input_ids.shape[0]).to(device)
print(1111, input_ids.shape)  # [2, 8]
print(2222, attention_mask.shape)  # [2, 8]
print(3333, labels.shape)  # [2]
outputs = model(input_ids, attention_mask=attention_mask, labels=labels)
print(4444, outputs.logits)



