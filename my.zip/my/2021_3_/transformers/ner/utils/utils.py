# coding:utf-8
# CreatDate: 2021/12/22 12:37 by ZTE
# Author: Kangkang Sun
import os
import torch
import numpy as np

# from datasets import load_metric
# # metric = load_metric("seqeval")
# metric = load_metric("utils/seqeval.py")


class DataProcessor(object):
    """Base class for data converters for sequence classification data sets."""

    def get_labels(self):
        """Gets the list of labels for this data set."""
        raise NotImplementedError()

    @classmethod
    def _read_data(cls, input_file):
        """Reads a BIO data."""
        with open(input_file) as f:
            lines = []
            words = []
            labels = []
            for i, line in enumerate(f):
                contends = line.strip()
                word = line.strip().split(' ')[0]
                label = line.strip().split(' ')[-1]
                # if contends.startswith("-DOCSTART-"):
                #     words.append('')
                #     continue
                # if len(contends) == 0 and words[-1] == '。':
                # print(1111111111, i, len(contends))
                if len(contends) == 0:
                    # print(2222222222, i)
                    l = ' '.join([label for label in labels if len(label) > 0])
                    w = ' '.join([word for word in words if len(word) > 0])
                    lines.append([l, w])
                    words = []
                    labels = []
                    continue
                words.append(word)
                labels.append(label)
                # print(55555, line)
                # print(66666, lines)
            if len(words) > 0:
                l = ' '.join([label for label in labels if len(label) > 0])
                w = ' '.join([word for word in words if len(word) > 0])
                lines.append([l, w])
            return lines


class NerProcessor(DataProcessor):
    def get_train_examples(self, data_dir, label_map, tokenizer, max_length=128):
        return self._create_example(self._read_data(os.path.join(data_dir, "train.txt")), label_map, tokenizer,
                                    max_length=max_length)

    def get_dev_examples(self, data_dir, label_map, tokenizer, max_length=128):
        return self._create_example(self._read_data(os.path.join(data_dir, "dev.txt")), label_map, tokenizer,
                                    max_length=max_length)

    def get_test_examples(self, data_dir, label_map, tokenizer, test_data=None, max_length=128):
        return self._create_example(
            self._read_data(os.path.join(data_dir, "test.txt") if test_data is None else test_data), label_map,
            tokenizer, max_length=max_length)

    def get_labels(self, data_dir):
        with open(os.path.join(data_dir, "train.txt")) as f:
            labels = []
            for line in f:
                contends = line.strip()
                label = line.strip().split(' ')[-1]
                if len(contends) != 0:
                    labels.append(label)
            labels = list(set(labels))
            try:
                labels.remove("O")
                labels.sort()
                labels = ["O"] + labels
            except:
                labels.sort()
                labels = ["O"] + labels
            return labels

    def _create_example(self, lines, label_map, tokenizer, max_length=128):
        examples = []
        for (i, line) in enumerate(lines):
            # print(111111111, line)
            tokenized_inputs = tokenizer(line[1].split(), truncation=True, is_split_into_words=True,
                                         padding="max_length", max_length=max_length)
            # print(222222222, tokenized_inputs)
            word_ids = tokenized_inputs.word_ids(batch_index=0)  # Map tokens to their respective word.
            # print(333333333, word_ids)
            temp_labels = line[0].split()
            previous_word_idx = None
            label_ids = []
            for word_idx in word_ids:  # Set the special tokens to -100.
                if word_idx is None:
                    label_ids.append(-100)
                elif word_idx != previous_word_idx:  # Only label the first token of a given word.
                    label_ids.append(label_map[temp_labels[word_idx]])
            tokenized_inputs["labels"] = label_ids
            tokenized_inputs["word_ids"] = word_ids
            examples.append(tokenized_inputs)
        return examples


def get_label_list(data_dir):
    processor = NerProcessor()
    label_list = processor.get_labels(data_dir)
    return label_list


class MYDataset(torch.utils.data.Dataset):
    def __init__(self, all_data):
        self.all_data = all_data

    def __getitem__(self, idx):
        # print(1111111, self.all_data[idx])
        # print(2222222, self.all_data[idx].keys())
        # input(11)
        item = {
            "attention_mask": self.all_data[idx]["attention_mask"],
            "input_ids": self.all_data[idx]["input_ids"],
            "labels": self.all_data[idx]["labels"],
            # "tokens": self.all_data[idx]["tokens"],
            # "ner_tags": self.all_data[idx]["ner_tags"],
            # "id": self.all_data[idx]["id"],
        }
        return item

    def __len__(self):
        return len(self.all_data)


def get_last_checkpoint(result_dir):
    checkpoint_list = [term for term in os.listdir(result_dir) if "checkpoint-" in term]
    # print(111111111, checkpoint_list)
    # checkpoint_list = ["checkpoint-9000", "checkpoint-8500", "checkpoint-9500"]
    checkpoint_list1 = sorted(checkpoint_list, key=lambda d: int(d.split("-")[1]), reverse=True)
    return os.path.join(result_dir, checkpoint_list1[0])


def compute_metrics(label_list):
    def compute_metrics_(p):
        predictions, labels = p
        predictions = np.argmax(predictions, axis=2)
        # print(predictions)
        # Remove ignored index (special tokens)

        true_predictions = [
            [label_list[p] for (p, l) in zip(prediction, label) if l != -100]
            for prediction, label in zip(predictions, labels)
        ]
        true_labels = [
            [label_list[l] for (p, l) in zip(prediction, label) if l != -100]
            for prediction, label in zip(predictions, labels)
        ]

        results = metric.compute(predictions=true_predictions, references=true_labels)
        return {
            "precision": results["overall_precision"],
            "recall": results["overall_recall"],
            "f1": results["overall_f1"],
            "accuracy": results["overall_accuracy"],
        }

    return compute_metrics_


if __name__ == '__main__':
    data_dir = "/home/vca1/skk/code/a_task/bert_sequence_labeling/data/ner/chinese"
    # label_list = get_label_list(data_dir)
    # print(1111111, label_list)
    import json

    output_dir = "/home/vca1/skk/code/transformers/ner/results_chinese"
    with open(os.path.join(output_dir, 'label_list.json'), 'r', encoding="utf8") as fr:
        label_list, max_length = json.load(fr)
        print(label_list)
