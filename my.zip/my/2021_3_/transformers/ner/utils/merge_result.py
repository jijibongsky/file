# coding=utf-8
# Copyright 2019/7/19 10:27 by ZTE
# Author: Kangkang Sun


def merge_words(sentence):
    new_sentence = []
    pair = sentence[0].split("/")
    before_tag = "O"
    if pair[1] != "O":
        before_tag = pair[1].split("-")[1]
    temp_word = [pair[0]]
    temp_tag = [pair[1]]
    for i in range(1, len(sentence)):
        pair = sentence[i].split("/")
        word = pair[0]
        tag = pair[1]
        if tag != "O":
            tag = tag.split("-")[1]
        if tag == before_tag:
            temp_word.append(word)
            temp_tag.append(pair[1])
        else:
            merge_word = " ".join(temp_word)
            merge_tag = " ".join(temp_tag)
            new_sentence.append(merge_word + "/" + merge_tag)
            before_tag = tag
            temp_word = [word]
            temp_tag = [pair[1]]
    if temp_word != []:
        merge_word = " ".join(temp_word)
        merge_tag = " ".join(temp_tag)
        new_sentence.append(merge_word + "/" + merge_tag)
    return new_sentence


def merge_result(sentence):
    entitys_org = merge_words(sentence)
    new_sentence = []
    for pair in entitys_org:
        pair = pair.split("/")
        words = pair[0].split(" ")
        tags = pair[1]
        if tags[0] == "O":
            new_sentence.append("".join(words) + "/" + "O")
        else:
            temp_word = ""
            before_tag = ""
            for word, tag in zip(words, tags.split(" ")):
                split_tag = tag.split("-")
                # print(word, split_tag)
                if split_tag[0] == "B":
                    if temp_word != "":
                        # print(temp_word + "/" + before_tag)
                        new_sentence.append(temp_word + "/" + before_tag)
                        temp_word = word
                        before_tag = split_tag[1]
                    else:
                        temp_word += word
                        before_tag = split_tag[1]
                else:
                    temp_word += word
                    before_tag = split_tag[1]
            if temp_word != "":
                new_sentence.append(temp_word + "/" + before_tag)
    return new_sentence


if __name__ == '__main__':
    sentences = []
    sentences.append(
        ['海/O', '钓/O', '比/O', '赛/O', '地/O', '点/O', '在/O', '厦/B-LOC', '门/I-LOC', '与/O', '金/B-LOC', '门/I-LOC', '之/O',
         '间/O', '的/O', '海/O', '域/O', '。/O'])
    sentences.append(
        ['堆/B-ORG', '龙/I-ORG', '德/B-ORG', '庆/I-ORG', '“/B-ORG', '流/I-ORG', '动/I-ORG', '党/I-ORG', '校/I-ORG', '”/I-ORG',
         '深/O', '入/O', '农/O', '牧/O', '区/O'])
    sentences.append(
        ["周/B-PER", "恩/I-PER", "来/I-PER", "原/O", "籍/O", "浙/B-LOC", "江/I-LOC", "绍/B-LOC", "兴/I-LOC", ",/O", "1898/O",
         "年/O", "3/O", "月/O", "5/O", "日/O", "生/O", "于/O", "江/B-LOC", "苏/I-LOC", "淮/B-LOC", "安/I-LOC", "。/O"])
    sentences.append(
        ['我/O', '想/O', '订/O', '南/B-LOC', '京/I-LOC', '12/I-TIME', '点/I-TIME', '整/I-TIME', '的/O', '会/O', '议/O', '室/O'])

    sentences.append(
        ['210/B-TIME', '##8/I-TIME', '年/I-TIME', '9/B-TIME', '月/I-TIME', '3/I-TIME', '号/I-TIME', ',/O', '天/O', '气/O',
         '晴/O'])
    # entitys_org = merge_words(sentences[4])
    # print(entitys_org)
    #
    # new_sentence = merge_result(sentences[4])
    # print(new_sentence)

    sentences = [
        ['周/B-PER', '恩/I-PER', '来/I-PER', '原/O', '籍/O', '浙/B-LOC', '江/I-LOC', '绍/B-LOC', '兴/I-LOC', '，/O', '1898/O',
         '年/O', '3/O', '月/O', '5/O', '日/O', '生/O', '于/O', '江/B-LOC', '苏/I-LOC', '淮/B-LOC', '安/I-LOC', '。/O'],
        ['我/O', '和/O', '张/B-PER', '明/I-PER', '天/O', '一/O', '起/O', '去/O', '杭/B-LOC', '州/I-LOC', '吃/O', '饭/O']]
    new_sentences = [merge_result(sentence) for sentence in sentences]
    print(111111, new_sentences)
