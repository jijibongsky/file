一、开源框架：
Transformers： https://github.com/huggingface/transformers

二、训练数据
测试用的数据集为：人民日报语料1998版+MSRA数据集
数据集路径：98服务器 /home/vca/data/ner/data/chinese

其余数据可参考：https://zhuanlan.zhihu.com/p/164966421

三、实验
代码地址：98服务器 /home/vca/data/ner

3.1 启动环境
nvidia-docker run --net=host -v /home/vca/data/ner:/home/vca/data/ner -it zxaisp-aie-ner:v0.0.1 /bin/bash
或者conda activate python37

3.2 模型训练：
修改 train.py 中的
model_name：预训练模型地址
data_dir：数据地址
output_dir：保存模型地址
然后执行 python3 train.py 训练模型

3.3 启动模型推理：
修改 start_rest.py 中的
model_dir ：训练好的模型的地址
pre_train_model_name ： 预训练模型地址，会用到词表之类的。
然后执行 python3 start_rest.py 启动推理服务

3.4 调用推理服务：
修改use_rest.py中的 textmod 和 url
然后执行Python use_rest.py调用推理服务
