# coding=utf-8
# Copyright 2019/7/16 10:50 by ZTE
# Author: Kangkang Sun

import json
import os
import torch
from flask import Flask
from flask import request
from utils.utils import get_last_checkpoint
from infer import load_model, deal_one
root_dir = os.path.abspath(os.path.dirname(__file__))
print("root_dir=======", root_dir)

os.environ['CUDA_VISIBLE_DEVICES'] = '0'
# os.environ['CUDA_VISIBLE_DEVICES'] = ''

device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

# model_dir = os.path.join(root_dir, "results_chinese")
model_dir = os.path.join(root_dir, "results_chinese_1")
# pre_train_model_name = os.path.join(root_dir, "../pretrain_models/chinese-bert-wwm-ext")
pre_train_model_name = os.path.join(root_dir, "pretrain_models/chinese-bert-wwm-ext")  # 预训练模型地址，会用到词表之类的。


with open(os.path.join(model_dir, 'label_list.json'), 'r', encoding="utf8") as fr:
    label_list, max_length = json.load(fr)
checkpoint = get_last_checkpoint(model_dir)
model, tokenizer = load_model(pre_train_model_name, checkpoint, device)

app = Flask(__name__)
@app.route('/ner', methods=['GET', 'POST'])
def compute_sim():
    if request.method == 'POST':
        data = request.get_data()
        dict1 = json.loads(data.decode('utf-8'))
        sentences = dict1['sentence']
        print("sentence: ", sentences)
        # sentences = [["周恩来原籍浙江绍兴，1898年3月5日生于江苏淮安。"], ["我和张明天一起去杭州吃饭"]]
        result = deal_one(model, tokenizer, sentences, label_list, device, max_length=max_length)
        print("result===", result)
        res = {"result": result}
        return json.dumps(res, ensure_ascii=False)
    else:
        return '<h1>只接受post请求！</h1>'


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description="Read text files.")
    parser.add_argument('--port', default=8801, type=str, help='model save path')
    args = parser.parse_args()
    app.run(host='0.0.0.0', port=args.port, debug=False, threaded=True)
