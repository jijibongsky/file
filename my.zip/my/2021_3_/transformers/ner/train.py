# coding:utf-8
# CreatDate: 2021/12/21 13:05 by ZTE
# Author: Kangkang Sun
import os
import json
import torch
from transformers import AutoTokenizer
from transformers import DataCollatorForTokenClassification
from transformers import AutoModelForTokenClassification
from transformers import TrainingArguments, Trainer
from utils.utils import get_label_list, MYDataset, NerProcessor, get_last_checkpoint
# from utils.utils import compute_metrics
from eval import eval_main

root_dir = os.path.abspath(os.path.dirname(__file__))
print("root_dir=======", root_dir)
# os.environ["CUDA_VISIBLE_DEVICES"] = "1"
# /root/.cache/huggingface

def load_data(output_dir, data_dir, tokenizer, label_list, num_train_epochs, batch_size, max_length=128):
    label_map = {label: i for (i, label) in enumerate(label_list, 0)}
    with open(os.path.join(output_dir, 'label_list.json'), 'w', encoding="utf8") as fw:
        fw.write(json.dumps([label_list, max_length], ensure_ascii=False))
        # fw.write(json.dumps(label_list, ensure_ascii=False))

    processor = NerProcessor()
    train_data = processor.get_train_examples(data_dir, label_map, tokenizer, max_length=max_length)
    dev_data = processor.get_dev_examples(data_dir, label_map, tokenizer, max_length=max_length)
    test_data = processor.get_test_examples(data_dir, label_map, tokenizer, max_length=max_length)
    # print(11111111, len(train_data))
    # input(11)

    # train_data = train_data[:199]
    total_step = int(len(train_data) * num_train_epochs / batch_size)
    # print(111111111, len(train_data), total_step)

    # save_steps = min(total_step, 1000)
    save_steps = min(total_step, 100)

    train_data = MYDataset(train_data)
    dev_data = MYDataset(dev_data)
    test_data = MYDataset(test_data)
    return train_data, dev_data, test_data, save_steps


def train_main(model_name, data_dir, output_dir, num_train_epochs, batch_size, learning_rate, max_length=128):
    # tokenizer = AutoTokenizer.from_pretrained("hfl/chinese-bert-wwm-ext")
    # print(1111111111111111, model_name)
    # for file in os.listdir(model_name):
    #     print(2222222, file)
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    label_list = get_label_list(data_dir)
    train_data, dev_data, test_data, save_steps = load_data(output_dir, data_dir, tokenizer, label_list,
                                                            num_train_epochs, batch_size, max_length=max_length)

    data_collator = DataCollatorForTokenClassification(tokenizer)

    # model = AutoModelForTokenClassification.from_pretrained("hfl/chinese-bert-wwm-ext", num_labels=len(label_list))  # 训练
    model = AutoModelForTokenClassification.from_pretrained(model_name, num_labels=len(label_list))  # 训练
    # model = AutoModelForTokenClassification.from_pretrained(
    #     '/home/vca1/skk/code/transformers/ner/results_chinese/checkpoint-2000', num_labels=len(label_list))  # 验证
    # compute_metrics_ = compute_metrics(label_list)
    training_args = TrainingArguments(
        output_dir=output_dir,
        evaluation_strategy="epoch",
        learning_rate=learning_rate,
        per_device_train_batch_size=batch_size,
        per_device_eval_batch_size=16,
        num_train_epochs=num_train_epochs,
        weight_decay=0.01,
        save_steps=save_steps,
    )
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_data,
        eval_dataset=dev_data,
        data_collator=data_collator,
        tokenizer=tokenizer,
        # compute_metrics=compute_metrics_
    )
    trainer.train()  # 训练
    # metric_res = trainer.evaluate()  # 验证
    # print(1111111111111, metric_res)


if __name__ == '__main__':
    # model_name = "distilbert-base-uncased"
    # model_name = "hfl/chinese-bert-wwm-ext"

    # model_name = os.path.join(root_dir, "../pretrain_models/chinese-bert-wwm-ext")
    model_name = os.path.join(root_dir, "pretrain_models/chinese-bert-wwm-ext")
    data_dir = os.path.join(root_dir, "data/chinese")
    output_dir = os.path.join(root_dir, "results_chinese_111")

    # data_dir = os.path.join(root_dir, "data/huiyi2")
    # output_dir = os.path.join(root_dir, "results_huiyi2")

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    num_train_epochs = 3
    batch_size = 64
    learning_rate = 2e-5
    max_length = 128

    train_main(model_name, data_dir, output_dir, num_train_epochs, batch_size, learning_rate, max_length=max_length)

    device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
    # output_dir = "/home/vca1/skk/code/transformers/ner/results/bak"
    checkpoint = get_last_checkpoint(output_dir)
    print(111111, checkpoint)
    eval_result = eval_main(model_name, checkpoint, data_dir, batch_size=32, device=device, output_dir=output_dir)
    print("results:", ''.join(eval_result))

"""
python3.7
docker run --net=host \
-v /home:/home \
-it zxaisp-aie-ner:v0.0.1 /bin/bash

"""
