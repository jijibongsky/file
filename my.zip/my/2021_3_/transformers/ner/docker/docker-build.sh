docker build --no-cache -f dockerfile -t zxaisp-aie-ner:v0.0.1 .
