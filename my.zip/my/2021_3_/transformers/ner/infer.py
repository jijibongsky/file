# coding:utf-8
# CreatDate: 2021/12/22 16:29 by ZTE
# Author: Kangkang Sun
import os
import json
import torch
from transformers import AutoTokenizer
from transformers import AutoModelForTokenClassification
from utils.merge_result import merge_result
from utils.utils import get_last_checkpoint

root_dir = os.path.abspath(os.path.dirname(__file__))
print("root_dir=======", root_dir)


def load_model(pre_train_model_name, checkpoint, device):
    model = AutoModelForTokenClassification.from_pretrained(checkpoint)
    model.to(device)
    model.eval()
    tokenizer = AutoTokenizer.from_pretrained(pre_train_model_name)
    return model, tokenizer


def deal_one(model, tokenizer, test_texts, label_list, device, max_length=128):
    test_encodings = tokenizer(test_texts, truncation=True, is_split_into_words=True, padding="max_length",
                               max_length=max_length)

    sentences_len = [sum(term) for term in test_encodings["attention_mask"]]
    tokens = [tokenizer.convert_ids_to_tokens(test_encodings["input_ids"][i]) for i in range(len(test_texts))]

    input_ids = torch.tensor(test_encodings["input_ids"]).to(device)
    attention_mask = torch.tensor(test_encodings["attention_mask"]).to(device)
    labels = torch.tensor([[1] * input_ids.shape[1]] * input_ids.shape[0]).to(device)

    outputs = model(input_ids, attention_mask=attention_mask, labels=labels)
    # print(3333333, outputs.keys())  # ['loss', 'logits']
    logits = outputs.logits
    last_k_scores, last_k_preds = logits.topk(1)
    last_k_preds = last_k_preds.cpu().detach().numpy()
    # print(4444444, logits.shape, last_k_preds.shape, last_k_preds)  # ([2, 128, 7]) (2, 128, 1)

    results = []
    for i in range(len(sentences_len)):
        result = []
        token = tokens[i]
        for j, term in enumerate(last_k_preds[i]):
            if j > 0 and j < sentences_len[i] - 1:
                result.append("/".join([token[j], label_list[term[0]]]))
        results.append(result)
    # print(11111111111111111, results)
    results = [merge_result(sentence) for sentence in results]
    # print(22222222222222222, results)
    return results


if __name__ == '__main__':
    os.environ["CUDA_VISIBLE_DEVICES"] = "0"
    device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

    model_dir = os.path.join(root_dir, "results_chinese_1")  ##
    # pre_train_model_name = os.path.join(root_dir, "../pretrain_models/chinese-bert-wwm-ext")
    pre_train_model_name = os.path.join(root_dir, "pretrain_models/chinese-bert-wwm-ext")

    with open(os.path.join(model_dir, 'label_list.json'), 'r', encoding="utf8") as fr:
        label_list, max_length = json.load(fr)
    checkpoint = get_last_checkpoint(model_dir)

    test_texts = [["周恩来原籍浙江绍兴，1898年3月5日生于江苏淮安。"], ["我和张明天一起去杭州吃饭"]]
    model, tokenizer = load_model(pre_train_model_name, checkpoint, device)

    results = deal_one(model, tokenizer, test_texts, label_list, device, max_length=max_length)
    print(11111, results)
