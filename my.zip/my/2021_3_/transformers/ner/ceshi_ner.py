# coding:utf-8
# CreatDate: 2021/12/21 13:05 by ZTE
# Author: Kangkang Sun
import os
import torch
from datasets import load_dataset
from transformers import AutoTokenizer
from transformers import DataCollatorForTokenClassification
from transformers import AutoModelForTokenClassification
from transformers import TrainingArguments, Trainer

os.environ["CUDA_VISIBLE_DEVICES"] = "1"

model_name = "distilbert-base-uncased"


#  /root/.cache/huggingface/datasets/wnut_17/wnut_17
wnut = load_dataset("wnut_17")

# wnut["train"][0]
# {'id': '0',
#  'ner_tags': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 8, 8, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0],
#  'tokens': ['@paulwalk', 'It', "'s", 'the', 'view', 'from', 'where', 'I', "'m", 'living', 'for', 'two', 'weeks', '.', 'Empire', 'State', 'Building', '=', 'ESB', '.', 'Pretty', 'bad', 'storm', 'here', 'last', 'evening', '.']
# }

label_list = wnut["train"].features["ner_tags"].feature.names
# label_list = ['O', 'B-corporation', 'I-corporation', 'B-creative-work', 'I-creative-work', 'B-group', 'I-group',
#               'B-location', 'I-location', 'B-person', 'I-person', 'B-product', 'I-product']


tokenizer = AutoTokenizer.from_pretrained(model_name)


# sentence = ['@paulwalk', 'It', "'s", 'the', 'view', 'from', 'where', 'I', "'m", 'living', 'for', 'two', 'weeks', '.',
#             'Empire', 'State', 'Building', '=', 'ESB', '.', 'Pretty', 'bad', 'storm', 'here', 'last', 'evening', '.']
# tokenized_input = tokenizer(sentence, is_split_into_words=True)
# tokens = tokenizer.convert_ids_to_tokens(tokenized_input["input_ids"])
# print(1111111, tokenized_input)
# print(2222222, tokens)
# input(11)

def tokenize_and_align_labels(examples):
    # print(1111111111, len(examples["tokens"]), type(examples["tokens"][0]), examples["tokens"][0])
    # 1000 <class 'list'> ['@paulwalk', 'It', "'s", 'the', 'view', 'from', 'where', 'I', "'m", 'living', 'for', 'two', 'weeks', '.',
    # 'Empire', 'State', 'Building', '=', 'ESB', '.', 'Pretty', 'bad', 'storm', 'here', 'last', 'evening', '.']
    # input(11)
    tokenized_inputs = tokenizer(examples["tokens"], truncation=True, is_split_into_words=True)

    labels = []
    for i, label in enumerate(examples["ner_tags"]):
        word_ids = tokenized_inputs.word_ids(batch_index=i)  # Map tokens to their respective word.
        previous_word_idx = None
        label_ids = []
        for word_idx in word_ids:  # Set the special tokens to -100.
            if word_idx is None:
                label_ids.append(-100)
            elif word_idx != previous_word_idx:  # Only label the first token of a given word.
                label_ids.append(label[word_idx])
        labels.append(label_ids)
    tokenized_inputs["labels"] = labels
    # print(1111111111, type(labels), len(labels), labels[0])
    # input(11)
    return tokenized_inputs


tokenized_wnut = wnut.map(tokenize_and_align_labels, batched=True)


train_data = [term for term in tokenized_wnut["train"]]
test_data = [term for term in tokenized_wnut["test"]]


class MYDataset(torch.utils.data.Dataset):
    def __init__(self, all_data):
        self.all_data = all_data

    def __getitem__(self, idx):
        # print(1111111, self.all_data[idx])
        # print(2222222, self.all_data[idx].keys())
        # input(11)
        item = {
            "attention_mask": self.all_data[idx]["attention_mask"],
            "input_ids": self.all_data[idx]["input_ids"],
            "labels": self.all_data[idx]["labels"],
            # "tokens": self.all_data[idx]["tokens"],
            # "ner_tags": self.all_data[idx]["ner_tags"],
            # "id": self.all_data[idx]["id"],
        }
        return item

    def __len__(self):
        return len(self.all_data)


train_data1 = MYDataset(train_data)
test_data1 = MYDataset(test_data)


data_collator = DataCollatorForTokenClassification(tokenizer)

model = AutoModelForTokenClassification.from_pretrained(model_name, num_labels=len(label_list))
training_args = TrainingArguments(
    output_dir='./results',
    evaluation_strategy="epoch",
    learning_rate=2e-5,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=16,
    num_train_epochs=3,
    weight_decay=0.01,
)


trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_wnut["train"],
    eval_dataset=tokenized_wnut["test"],
    # train_dataset=train_data1,
    # eval_dataset=test_data1,
    data_collator=data_collator,
    tokenizer=tokenizer,
)
trainer.train()


# 加载训练好的模型推理
# device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
# model = AutoModelForTokenClassification.from_pretrained("results/checkpoint-500")
# model.to(device)
# model.eval()
# tokenizer = AutoTokenizer.from_pretrained(model_name)
#
# sentence = ['@paulwalk', 'It', "'s", 'the', 'view', 'from', 'where', 'I', "'m", 'living', 'for', 'two', 'weeks', '.',
#             'Empire', 'State', 'Building', '=', 'ESB', '.', 'Pretty', 'bad', 'storm', 'here', 'last', 'evening', '.']
# train_texts = [[" ".join(sentence)]]
#
# train_encodings = tokenizer(train_texts, truncation=True, is_split_into_words=True)
# input_ids = torch.tensor(train_encodings["input_ids"]).to(device)
# attention_mask = torch.tensor(train_encodings["attention_mask"]).to(device)
#
# labels = torch.tensor([[1] * input_ids.shape[1]]).to(device)
# # print(111111111, input_ids.shape, input_ids)  # [1, 34]
# # print(222222222, attention_mask.shape, attention_mask)  # [1, 34]
# # print(333333333, labels.shape, labels)  # [1, 34]
#
# outputs = model(input_ids, attention_mask=attention_mask, labels=labels)
# print(4444, outputs.logits.shape)  # [1, 34, 13]
# print(5555, outputs.keys())  # ['loss', 'logits']

