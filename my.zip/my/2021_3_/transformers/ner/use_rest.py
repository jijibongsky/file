# coding=utf-8
# Copyright 2019/7/16 11:15 by ZTE
# Author: Kangkang Sun

import json
import requests
import time

# curl http://10.229.89.97:8801/ner -X POST -H '"Content-type":"application/json"'  -d '{"sentence":[["帮我订张去杭州的机票"], ["鲁迅，原名周樟寿，后改名周树人，字豫山，后改字豫才，浙江绍兴人。"]]}'


sentences = []
# sentences.append("周恩来原籍浙江绍兴，1898年3月5日生于江苏淮安。")
# sentences.append("我想订今天早上九点半南研二区二号楼的会议室")
# sentences.append("我想订西丽8号下午的会议室")

sentences.append("帮我联系一下徐子阳")
sentences.append("我想订南京9:30:00的会议室")
sentences.append("我想订南京5:45的会议室")
sentences.append("我和张明天一起去杭州吃饭")
sentences.append("我想订南京12点整的会议室")
sentences.append("帮我订张明天去杭州的机票")
sentences.append("帮我订张去杭州的机票")
sentences.append("鲁迅，原名周樟寿，后改名周树人，字豫山，后改字豫才，浙江绍兴人。")

# textmod={}
# textmod["sentence"] = [[sentence] for sentence in sentences[-2:]]

textmod = {"sentence": [["帮我订张去杭州的机票"], ["鲁迅，原名周樟寿，后改名周树人，字豫山，后改字豫才，浙江绍兴人。"]]}

# url = 'http://10.229.89.97:8801/ner'
url = 'http://10.229.89.98:8801/ner'
# url = 'http://10.228.18.35:30800/ner/ner'
r = requests.post(url, json=textmod)
# r = requests.post(url, json=json.dumps(textmod))
end_time = time.time()
print(r.text)
