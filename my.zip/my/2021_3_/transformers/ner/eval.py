# coding:utf-8
# CreatDate: 2021/12/22 16:29 by ZTE
# Author: Kangkang Sun
import json
import os
import torch
from transformers import AutoTokenizer
from transformers import AutoModelForTokenClassification
from utils.utils import NerProcessor
import utils.conlleval as conlleval
from utils.utils import get_last_checkpoint

root_dir = os.path.abspath(os.path.dirname(__file__))
print("root_dir=======", root_dir)


def predict(test_data, result_file, batch_size, tokenizer, model, label_list, device):
    label_map = {i: label for (i, label) in enumerate(label_list)}
    fw = open(result_file, "w", encoding="utf8")
    for i in range(0, len(test_data), batch_size):
        # print("处理个数：", i)
        batch_data = test_data[i:i + batch_size]
        input_ids = [batch_data[j]["input_ids"] for j in range(len(batch_data))]
        attention_mask = [batch_data[j]["attention_mask"] for j in range(len(batch_data))]
        temp_labels = [batch_data[j]["labels"] for j in range(len(batch_data))]

        input_ids = torch.tensor(input_ids).to(device)
        attention_mask = torch.tensor(attention_mask).to(device)
        labels = torch.tensor(temp_labels).to(device)

        sentences_len = [sum(term["attention_mask"]) for term in batch_data]
        tokens = [tokenizer.convert_ids_to_tokens(batch_data[i]["input_ids"]) for i in range(len(batch_data))]
        word_ids = [batch_data[i]["word_ids"] for i in range(len(batch_data))]

        outputs = model(input_ids, attention_mask=attention_mask, labels=labels)
        # print(3333333, outputs.keys())  # ['loss', 'logits']
        logits = outputs.logits
        last_k_scores, last_k_preds = logits.topk(1)
        last_k_preds = last_k_preds.cpu().detach().numpy()

        for i in range(len(sentences_len)):
            token = tokens[i]
            word_id = word_ids[i]
            Previous = -1
            temp_word = ""
            temp_label = ""
            temp_predict = ""
            lines = []
            for j, term in enumerate(last_k_preds[i]):
                if j > 0 and j < sentences_len[i] - 1:
                    if Previous == word_id[j]:
                        temp_word += token[j]
                        temp_label = label_map.get(temp_labels[i][j], "O")
                        temp_predict = label_list[term[0]]
                    else:
                        if temp_word != "":
                            line = [temp_word, temp_label, temp_predict]
                            fw.write(" ".join(line) + "\n")
                            lines.append(line)
                        Previous = word_id[j]
                        temp_word = token[j]
                        temp_label = label_map.get(temp_labels[i][j], "O")
                        temp_predict = label_list[term[0]]
            line = [temp_word, temp_label, temp_predict]
            lines.append(line)
            fw.write(" ".join(line) + "\n")
            fw.write("\n")


def load_model(model_name, checkpoint, device):
    model = AutoModelForTokenClassification.from_pretrained(checkpoint)
    model.to(device)
    model.eval()
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    return model, tokenizer


def eval_main(model_name, checkpoint, data_dir, batch_size, device, output_dir):
    with open(os.path.join(output_dir, 'label_list.json'), 'r', encoding="utf8") as fr:
        # label_list = json.load(fr)
        label_list, max_length = json.load(fr)

    label_map = {label: i for (i, label) in enumerate(label_list, 0)}
    model, tokenizer = load_model(model_name, checkpoint, device)

    processor = NerProcessor()
    test_data = processor.get_test_examples(data_dir, label_map, tokenizer, max_length=max_length)
    # test_data = processor.get_test_examples(data_dir, label_map, tokenizer, test_data=os.path.join(data_dir, "test.txt1"))

    result_file = os.path.join(checkpoint, "label_test.txt")
    predict(test_data, result_file, batch_size, tokenizer, model, label_list, device)
    eval_result = conlleval.return_report(result_file)
    # 写结果到文件中
    with open(os.path.join(checkpoint, 'predict_score.txt'), 'w', encoding='utf-8') as fd:
        fd.write(''.join(eval_result))
    return eval_result


if __name__ == '__main__':
    os.environ["CUDA_VISIBLE_DEVICES"] = "1"
    # os.environ["CUDA_VISIBLE_DEVICES"] = ""

    device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

    # model_name = os.path.join(root_dir, "../pretrain_models/chinese-bert-wwm-ext")
    model_name = os.path.join(root_dir, "pretrain_models/chinese-bert-wwm-ext")
    batch_size = 32

    data_dir = os.path.join(root_dir, "data/chinese")
    output_dir = os.path.join(root_dir, "results_chinese_1")

    # data_dir = os.path.join(root_dir, "data/huiyi2")
    # output_dir = os.path.join(root_dir, "results_huiyi2")

    checkpoint = get_last_checkpoint(output_dir)
    eval_result = eval_main(model_name, checkpoint, data_dir, batch_size, device, output_dir=output_dir)
    print(11111111, ''.join(eval_result))
