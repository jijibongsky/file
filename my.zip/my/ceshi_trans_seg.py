# coding:utf-8
# CreatDate: 2021/1/26 15:50 by ZTE
# Author: Kangkang Sun
import numpy as np
import PIL.Image
import PIL.ImageDraw
label_mask = PIL.Image.fromarray(np.zeros((7, 10), dtype=np.uint8))
image_draw = PIL.ImageDraw.Draw(label_mask)
points_list = [(1, 1), (6, 1), (6, 4), (1, 4)]
image_draw.polygon(xy=points_list, outline=1, fill=2)

print(1111111111, np.array(label_mask))
print(2222222222, np.array(label_mask, dtype=bool))
