#!/usr/env/bin python3

"""
Generate training and test images.
"""
import traceback
import numpy as np
import sys
import multiprocessing as mp
from itertools import repeat
import os
from time import time


lock = mp.Lock()
counter = mp.Value('i', 0)
STOP_TOKEN = 'kill'


class Timer(object):
    MILLISECOND = 0
    SECOND = 1
    HOUR = 2

    start_time = 0
    ids_start_time = {}

    def __init__(self, show_type=MILLISECOND):
        self.show_type = show_type

    def start(self, tid=None):
        if tid:
            self.ids_start_time[tid] = time() * 1000
        else:
            self.start_time = time() * 1000

    def end(self, msg, tid=None):
        end_time = time() * 1000

        if tid and (tid in self.ids_start_time.keys()):
            total_time = end_time - self.ids_start_time[tid]
        else:
            total_time = end_time - self.start_time

        print_time = total_time
        if self.show_type == Timer.MILLISECOND:
            print_time = total_time
            print_unit = 'ms'
        elif self.show_type == Timer.SECOND:
            print_time = total_time / 1000
            print_unit = 's'
        elif self.show_type == Timer.HOUR:
            print_time = total_time / 1000 / 60 / 60
            print_unit = 'h'

        print("%s: %.3f %s" % (msg, print_time, print_unit))


def start_listen(q, fname):
    """ listens for messages on the q, writes to file. """
    f = open(fname, mode='a', encoding='utf-8')
    while 1:
        m = q.get()
        if m == STOP_TOKEN:
            break
        try:
            f.write(str(m) + '\n')
        except:
            traceback.print_exc()
        with lock:
            if counter.value % 1000 == 0:
                f.flush()
    f.close()


def get_num_processes(num_processes):
    processes = num_processes
    if processes is None:
        processes = max(os.cpu_count(), 2)
    return processes


def get_platform():
    platforms = {
        'linux1': 'Linux',
        'linux2': 'Linux',
        'darwin': 'OS X',
        'win32': 'Windows'
    }
    if sys.platform not in platforms:
        return sys.platform
    return platforms[sys.platform]


def ceshi(my_index):
    for i in range(10**7):
        my_index += 1
        my_index -= 1
    return my_index


def generate_img(img_index, q=None):
    global lock, counter
    # Make sure different process has different random seed
    np.random.seed()

    aa = ceshi(img_index)
    print(aa)

    base_name = '{:08d}'.format(img_index)
    label = "{}".format(base_name)
    if q is not None:
        q.put(label)
    with lock:
        counter.value += 1
        mumber_of_samples = 10
        print_end = '\n' if counter.value == mumber_of_samples else '\r'
        if counter.value % 100 == 0 or counter.value == mumber_of_samples:
            print("{}/{} {:2d}%".format(counter.value, mumber_of_samples, int(counter.value / mumber_of_samples * 100)), end=print_end)
            # print("{}/{} {:2d}%".format(counter.value, mumber_of_samples, int(counter.value / mumber_of_samples * 2)))


def restore_exist_labels(save_dir, label_path):
    start_index = 0
    if os.path.exists(label_path):
        start_index = 1
        print('Generate more text images in %s. Start index %d' % (save_dir, start_index))
    else:
        print('Generate text images in %s' % save_dir)
    return start_index


if __name__ == "__main__":
    if get_platform() == "OS X":
        mp.set_start_method('spawn', force=True)

    tmp_label_path = 'ceshi.txt'
    start_index = 1
    num_processes = 2
    mumber_of_samples = 10
    my_list = list(range(start_index, start_index + mumber_of_samples))

    manager = mp.Manager()
    q = manager.Queue()
    timer = Timer(Timer.SECOND)
    timer.start()
    with mp.Pool(processes=get_num_processes(num_processes)) as pool:
        pool.apply_async(start_listen, (q, tmp_label_path))
        pool.starmap(generate_img, zip(my_list, repeat(q)))
        q.put(STOP_TOKEN)
        pool.close()
        pool.join()
    timer.end("Finish generate data")
