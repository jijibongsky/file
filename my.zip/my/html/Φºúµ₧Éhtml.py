from bs4 import BeautifulSoup


def Parsing_one(text):
    text = text.replace("<br/>", "|||||")
    soup = BeautifulSoup(text, "html5lib")
    result = soup.find("html")
    text_result = result.text
    text_result = [line for line in text_result.split("|||||") if line.strip]
    return text_result


data_file = "/Users/sunkangkang/code/PycharmProjects/DeepLearning/my/html/aaa.html"
# data_file = "aaa.html"
fr = open(data_file, "r", encoding="utf8")
text = "".join(fr.readlines())

# text = """
# <body>
# <p class="story">Once upon a time there were three little sisters; and their names were
# <a href="http://example.com/elsie" class="sister" id="link1"><!-- Elsie --></a>,
# <a href="http://example.com/lacie" class="sister" id="link2">Lacie</a> and
# <a href="http://example.com/tillie" class="sister" id="link3">Tillie</a>;
# and they lived at the bottom of a well.</p>
# """

# text_result = Parsing_one(text)
# for line in text_result:
#     print(line)
