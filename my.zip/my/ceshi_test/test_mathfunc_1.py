import unittest
import mathfunc


class TestMathFunc(unittest.TestCase):

    def test_add(self):
        self.assertEqual(3, mathfunc.add(1, 2))
        self.assertNotEqual(3, mathfunc.add(2, 2))

    def test_minus(self):
        self.assertEqual(1, mathfunc.minus(3, 2))

    def test_multi(self):
        self.assertEqual(6, mathfunc.multi(3, 2))

    def test_divide(self):
        self.assertEqual(2, mathfunc.divide(6, 3))
        self.assertEqual(2.5, mathfunc.divide(5, 2))


if __name__ == '__main__':
    unittest.main()

