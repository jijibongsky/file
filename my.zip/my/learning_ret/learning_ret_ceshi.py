# coding=utf-8
# Copyright 2019/1/3 9:32 by ZTE
# Author: Kangkang Sun
import tensorflow as tf
import matplotlib.pyplot as plt
import os

os.environ["CUDA_VISIBLE_DEVICES"] = ""

global_steps = tf.placeholder(shape=[1], dtype=tf.int64)
cycle = tf.cast(tf.floor(1. + tf.cast(global_steps, dtype=tf.float32) / (2 * 1000.)), dtype=tf.float32)
x = tf.cast(tf.abs(tf.cast(global_steps, dtype=tf.float32) / 1000. - 2. * cycle + 1.), dtype=tf.float32)
learning_rate = 1e-6 + (1e-3 - 1e-6) * tf.maximum(0., (1 - x)) / tf.cast(2 ** (cycle - 1), dtype=tf.float32)
with tf.Session() as sess:
    lr_list = []
    cycle_list = []
    for i in range(8000):
        lr = sess.run(learning_rate, feed_dict={global_steps: [i]})
        lr_list.append(lr)

        cl = sess.run(cycle, feed_dict={global_steps: [i]})
        cycle_list.append(cl)

    plt.plot(cycle_list)
    plt.show()
