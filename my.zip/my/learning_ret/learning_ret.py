# coding=utf-8
# Copyright 2019/1/3 9:09 by ZTE
# Author: Kangkang Sun
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf


def get_triangular_lr_tensor(iteration, stepsize, base_lr, max_lr):
    cycle = tf.floor(1 + step / (2 * stepsize))
    x = tf.abs(step / stepsize - 2 * cycle + 1)
    # lr = base_lr + (max_lr - base_lr) * np.maximum(0, (1 - x))  # 周期性学习率
    lr = base_lr + (max_lr - base_lr) * tf.maximum(tf.constant(0, dtype=tf.float32), (1 - x)) / (2 ** (cycle - 1))
    return lr


def get_triangular_lr(iteration, stepsize, base_lr, max_lr):
    cycle = np.floor(1 + iteration / (2 * stepsize))
    x = np.abs(iteration / stepsize - 2 * cycle + 1)
    # lr = base_lr + (max_lr - base_lr) * np.maximum(0, (1 - x))
    lr = base_lr + (max_lr - base_lr) * np.maximum(0, (1 - x))/(2 ** (cycle - 1))
    return lr


if __name__ == '__main__':
    num_iterations = 200000
    stepsize = 15000
    base_lr = 0.0001
    max_lr = 0.001
    lr_trend = list()
    for step in range(num_iterations):
        lr = get_triangular_lr(step, stepsize, base_lr, max_lr)
        lr_trend.append(lr)
    plt.plot(lr_trend)
    plt.show()
