import random
import numpy as np

# a = {1:3, 2:4, 3:5}
# print(a.get(1, 0))
# print(a.get(6, 0))

########
data_label=np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])
np.random.seed(123)
shuffle_indices = np.random.permutation(np.arange(len(data_label)))
data_left = data_label[shuffle_indices]
print("===", data_left)

# random.seed(1)
# x = list(range(10))
# random.shuffle(x)
# print(x)

# import numpy as np
# a = np.arange(10)
# np.random.shuffle(a)
# print(a)
# print(type(a))

##############
# a = [1, 2, 3, 4, 5, 2, 6]
# del a[2]  # 删除第几个元素
# print(a)

# aa = [1, 2, 3, 4, 5, 2, 6]
# aa.remove(2)
# print(aa)

# aaa = [1, 2, 3, 4, 5, 2, 6]
# while aaa!=[]:
#     b = aaa.pop()
#     print(aaa, b)

##########

# set1 = {'apple', 'orange', 'apple', 'pear', 'orange', 'banana'}
# print(set1)
#
# a = set('abcde')
# b = set('cdefg')
# print(a - b)           # 集合a中包含而集合b中不包含的元素
# print(a | b)           # 集合a或b中包含的所有元素
# print(a & b)           # 集合a和b中都包含了的元素
# print(a ^ b)           # 不同时包含于a和b的元素



# a=1
# try:
#     while 1:
#         a += 1
#         a = a % 1000
#         print(a)
# except:
#     print("hahahaha")


# import numpy as np
# b = [3, 4, 4, -9]
# c = np.amax(b)  # 找最大元素，可以防止使用max有多个最大值的情况
# d = np.where(b == np.max(b))
# print(c)
# print(d)
# print(d[0][0])



