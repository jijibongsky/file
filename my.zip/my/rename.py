# coding=utf-8
# Copyright 2019/9/20 16:29 by ZTE
# Author: Kangkang Sun
import os

dir_in = "/home/skk/ceshi/temp/EO-SSPL"
dir_out = "/home/skk/ceshi/temp/EO-SSPL_1"

for file in os.listdir(dir_in):
    file1 = "_" + file
    file = os.path.join(dir_in, file)
    file1 = os.path.join(dir_out, file1)
    os.system("mv {} {}".format(file, file1))
