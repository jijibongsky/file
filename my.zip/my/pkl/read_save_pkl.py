import pickle

def read_pkl(read_file):
    handle = open(read_file,'rb')    #open的参数是pkl文件的路径
    data = pickle.load(handle)       #读取pkl文件的内容
    word2id = data['word2id']
    id2word = data['id2word']
    idCount = data.get('idCount', None)
    trainingSamples = data['trainingSamples']
    handle.close()
    return word2id, id2word, idCount, trainingSamples

def write_kpl(write_file,word2id, id2word, idCount, trainingSamples):
    with open(write_file, 'wb') as handle:
        data = {  # Warning: If adding something here, also modifying loadDataset
            'word2id': word2id,
            'id2word': id2word,
            'idCount': idCount,
            'trainingSamples': trainingSamples
        }
        pickle.dump(data, handle, -1)

read_file = 'dataset-weibo-length50-filter0-vocabSize80000.pkl'
#write_file = 'ceshi.pkl'
word2id, id2word, idCount, trainingSamples = read_pkl(read_file)
#write_kpl(write_file, word2id, id2word, idCount, trainingSamples)


