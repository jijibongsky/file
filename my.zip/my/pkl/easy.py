# coding=utf-8
# Copyright 2019/7/25 12:36 by ZTE
# Author: Kangkang Sun

import pickle

def save(data, fname):
    pickle.dump(data, open(fname, "wb"), protocol=2)

def load(fname):
    data = pickle.load(open(fname, "rb"))
    return data


tag2label = {'I-PER': 2, 'B-ORG': 5, 'I-ORG': 6, 'I-LOC': 4, 'O': 0, 'B-PER': 1, 'B-LOC': 3}

with open('aaaa.pkl', 'wb') as w:
    pickle.dump(tag2label, w)

with open('aaaa.pkl', 'rb') as rf:
    label2id = pickle.load(rf)
print("label2id====", label2id)