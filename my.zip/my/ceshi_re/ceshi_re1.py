# coding=utf-8
# Copyright 2019/11/8 17:42 by ZTE
# Author: Kangkang Sun

import re

# re.compile(
# re.search(
# re.match(   从字符串的开始部分开始匹配
# re.sub(
sentence1 = "我 们"
pattern = re.compile('[\u4e00-\u9fa5] {1,5}[\u4e00-\u9fa5]')
result1 = pattern.findall(sentence1)
print(111, result1)

sentence2 = "aa工程指令机型更改执行架次工程"
result1 = re.search(r'工程', sentence2)
result2 = re.match(r'工程', sentence2)  # 从字符串的开始部分开始匹配
print(222, result1)  # <_sre.SRE_Match object; span=(0, 2), match='工程'>
print(222, result2)  #

sentence3 = " 第1页 共1页"
result1 = re.search(r'第.*页.*共.*页', sentence3)
result2 = re.match(r'第.*页.*共.*页', sentence3)
print(333, result1)
print(333, result2)

sentence4 = "的12aA4567-890"
result1 = re.search(r'[\da-z]{3}A[\d]{4}-[\d]{3}', sentence4)
result2 = re.match(r'[\d]{3}A[\d]{4}-[\d]{3}', sentence4)
print(444, result1)
print(444, result2)


sentence5 = "a-123-456"
pattern_judge_sentence = r'\d{3}A\d{4}-\d{3}-\d{3}|\d{3}A\d{4}-\d{3}|-\d{3}-\d{3}|-\d{3}'
result1 = re.search(pattern_judge_sentence, sentence5)
result2 = re.match(pattern_judge_sentence, sentence5)
print(555, result1)
print(555, result2)

sentence6 = "a-123。456"
result1 = re.search(r'[。；;！!]', sentence6)
print(666, result1)


# pattern = re.compile('[\u4e00-\u9fa5] {1,5}[\u4e00-\u9fa5]')
# pattern = r'第.*页.*共.*页'
# pattern = r'[\d]{3}A[\d]{4}-[\d]{3}'
# pattern = r'\d{3}A\d{4}-\d{3}-\d{3}|\d{3}A\d{4}-\d{3}'
# pattern = r'[。；;！!]'
