import re


def ceshi():
    s = "输入繁 aa 88891234 体字，点下面 88891234的繁体字按钮进行转换"
    res1 = re.sub("[^ ]{3} \d{8}", "@", s)  # 三个非空格 + 一个空格 + 8 个数字替换为 @
    res2 = re.sub(" (.){2} \d{8}", "@", s)  # 一个空格 + 两个 任意字符 + 8个数字 替换为 @
    res3 = re.sub('\d+', '%', s)
    print("res1", res1)
    print("res2", res2)
    print("res3", res3)


def ceshi2():
    pattern = re.compile('{{[^}]+}}')
    result = pattern.findall('{{100M包年家庭宽带}}{{移机}}步{{}}骤')
    print(result)
    pattern_id = re.compile('[\d]{8}')
    result2 = pattern_id.findall('{{100M包12345678年家庭123611789宽带}}{{移机}}步骤')
    print(result2)


def ceshi3():
    sentence = "我们123A1234567你好"
    pattern2 = re.compile('\d{3}[A-Z]{1}\d{7}')
    result = pattern2.findall(sentence)
    result1 = re.findall('\d{3}[A-Z]{1}\d{7}', sentence)
    print(result)
    print(result1)


def ceshi4():
    punc2 = ['*', '[', '+', ')', '$', '(', '?', '.']
    text = "aaa+++aa???a|||bb.....kk[[[kcccd***deeffgghh"
    p = "."
    b = "\\{}+".format(p)
    res = re.sub(b, p, text)
    res2 = re.sub("\|+", "", text)
    print(res)
    print(res2)

ceshi2()

