# coding:utf-8
# CreatDate: 2020/12/23 9:54 by ZTE
# Author: Kangkang Sun
import re


# 贪婪非贪婪、直接抽取关键信息（抽取整个句子）。
def ceshi():
    # @正则表达式匹配中，(.*)和(.*?)匹配区别?
    # (.*)是贪婪匹配，会把满足正则的尽可能多的往后匹配
    # (.*?)是非贪婪匹配，会把满足正则的尽可能少匹配
    s = str("<a>哈哈</a><a>啦啦</a>")
    res1 = re.findall("<a>(.*)</a>", s)
    res2 = re.findall("<a>(.*?)</a>", s)
    res3 = re.findall("<a>.*?</a>", s)
    print(res1)  # ['哈哈</a><a>啦啦']
    print(res2)  # ['哈哈', '啦啦']
    print(res3)  # ['<a>哈哈</a>', '<a>啦啦</a>']


# 匹配开头结尾
def ceshi2():
    a = '001-苹果价格-60 002-橙子价格-70 003-香蕉价格-80'
    res1 = re.findall('\d+$', a)
    res2 = re.findall('^\d+', a)
    res3 = re.findall('\d+', a)
    print(res1)  # ['80']
    print(res2)  # ['001']
    print(res3)  # ['001', '60', '002', '70', '003', '80']


# 多部分匹配，只取其中一部分使用
def ceshi3():
    # exp1(?=exp2)：查找 exp2 前面的 exp1。
    # (?<=exp2)exp1：查找 exp2 后面的 exp1。
    regex = "((?<=[^A-Za-z0-9])|^)([\\-\\+]?\\d+)((?=[^A-Za-z0-9])|$)"
    regex1 = "((?<=[^A-Za-z0-9])|^)([-+]?\d+)((?=[^A-Za-z0-9])|$)"
    mask_with_wrapped = "NUM"
    content = "丢包率 大于 1%"
    res = re.sub(regex, mask_with_wrapped, content)
    res2 = re.findall(regex, content)
    res3 = re.findall(regex1, content)
    print(res)
    print(res2)
    print(res3)

    res4 = re.sub(regex1, r"\2aaa", content)
    print(res4)


# \w  匹配字母、数字、下划线。等价于 [A-Za-z0-9_]
# \s  匹配任何空白字符，包括空格、制表符、换页符等等。等价于 [ \f\n\r\t\v]。注意 Unicode 正则表达式会匹配全角空格符。
# \S  匹配任何非空白字符。等价于 [^ \f\n\r\t\v]。
# \d
# .*? 匹配所有内容
# .* 是贪婪匹配，会把满足正则的尽可能多的往后匹配
# .*? 是非贪婪匹配，会把满足正则的尽可能少匹配
# +  runoo+b，可以匹配 runoob、runooob、runoooooob 等，+ 号代表前面的字符必须至少出现一次（1次或多次）。
# *  runoo*b，可以匹配 runob、runoob、runoooooob 等，* 号代表前面的字符可以不出现，也可以出现一次或者多次（0次、或1次、或多次）。
# ?  colou?r 可以匹配 color 或者 colour，? 问号代表前面的字符最多只可以出现一次（0次、或1次）。
# .  匹配除换行符（\n、\r）之外的任何单个字符，相等于 [^\n\r]。
