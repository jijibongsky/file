# coding=utf-8
# Copyright 2019/11/8 17:42 by ZTE
# Author: Kangkang Sun

import re

# re.compile(
# re.search(  只找一个
# re.match(   从字符串的开始部分开始匹配
# re.sub(

sentence1 = "我 们"
pattern = re.compile('[\u4e00-\u9fa5] {1,5}[\u4e00-\u9fa5]')
result1 = pattern.findall(sentence1)
result2 = re.findall('[\u4e00-\u9fa5] {1,5}[\u4e00-\u9fa5]', sentence1)
print(111, result1)  # ['我 们']
print(111, result2)  # ['我 们']

sentence2 = "aa 工程 指令机型更改执 工程 行架次工程"
result1 = re.search('工程', sentence2)
result2 = re.match('工程', sentence2)  # 从字符串的开始部分开始匹配
print(222, result1, result1.group())  # <_sre.SRE_Match object; span=(0, 2), match='工程'>
print(222, result2)  # None

sentence5 = "a-123-456"
pattern1 = '\d{3}A\d{4}-\d{3}-\d{3}|\d{3}A\d{4}-\d{3}|-\d{3}-\d{3}|-\d{3}'
result1 = re.search(pattern1, sentence5)
result2 = re.match(pattern1, sentence5)
print(333, result1)  # <_sre.SRE_Match object; span=(1, 9), match='-123-456'>
print(333, result2)  # None

sentence6 = "a-123。45；6"
result1 = re.search('[。；;！!]', sentence6)
result2 = re.findall('[。；;！!]', sentence6)
print(444, result1)  # <_sre.SRE_Match object; span=(5, 6), match='。'>
print(444, result2)  # ['。', '；']
