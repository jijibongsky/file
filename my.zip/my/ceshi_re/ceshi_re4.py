# coding:utf-8
# CreatDate: 2020/12/25 15:29 by ZTE
# Author: Kangkang Sun
import re

sen = "Several failures occurred:  1) try 3 times, but excute exec_custom_python is still fail  2) try 3 times, but excute exec_custom_python is still fail"
para = re.sub('(\d+\))', r"\n\1", sen)
para1 = para.split("\n")
# print(para)
print(para1)

a = """Check ue attach status failed , ATF : WindowsError : :E : Robotframeworktru"""
# b = re.sub("(?<=WindowsError : :)(.*)", "", a)
# b = re.sub("(WindowsError : :)(.*)", r"\1", a)
# b = re.findall("(?<=WindowsError : :)(.*)", a)
b = re.findall("WindowsError : :(.*)", a)
print(b)


a = "<*> <*> <*> "
b = re.sub("(<\*> )+", "<*>", a)
print(b)


sen = "aaabbbaaabbbaaa"
rule1 = "aaa.*?aaa"
rule2 = "aaa.*aaa"
b1 = re.findall(rule1, sen)
b2 = re.findall(rule2, sen)
print(b1)
print(b2)


# 匹配包含两个以上 _ 的单词
sen = "check1_check_list_index_index1 failed"
a = re.findall("[a-zA-Z0-9_]+_[a-zA-Z0-9]+_[a-zA-Z0-9_]+", sen)
b = re.sub("[a-zA-Z0-9_]+_[a-zA-Z0-9]+_[a-zA-Z0-9_]+", "", sen)
print(a)
print(b)


# 不理解的
data = """Parent: Max # Caused by # False # should be true -"""
b = re.findall("(#.*?#) should be true", data)
c = re.findall("(.*?#) should be true", data)
print(b)
print(c)
