import hashlib
import datetime as date


# 1.区块链的基本框架定义
class Block:
    '''1.每个区块都有一个唯一的哈希值，用于自我标识。
       2.每个区块的哈希值是由该区块的索引、时间戳、数据、前一个区块的哈希，
         经过计算加密后得到的。其中，数据可以选取任意值。 '''
    def __init__(self, index, timestamp, data, previous_hash):
        self.index = index
        self.timestamp = timestamp
        self.data = data
        self.previous_hash = previous_hash
        self.hash = self.hash_block()
        # print(111, self.hash)
        
    def hash_block(self):
        '''hashlib主要提供字符加密功能，将md5和sha模块整合到了一起，
           支持md5,sha1, sha224, sha256, sha384, sha512等算法 '''
        sha256 = hashlib.sha256()  # 这里选用sha256
        sha256_string = (str(self.index) + str(self.timestamp) +
                         str(self.data) + str(self.previous_hash))
        sha256.update(sha256_string.encode('utf-8'))
        return sha256.hexdigest()
    
# 2.创建第一个区块（也叫创世区块）
def create_genesis_block():
    # Manually construct ablock with index zero andarbitrary previous hash.
    return Block(0, date.datetime.now(), "GenesisBlock", "0")


# 3.创建下一个区块:将链上前一个区块作为参数，生成后面的区块数据
def next_block(last_block):
    this_index = last_block.index + 1
    this_timestamp = date.datetime.now()
    this_data = "Hey! I'm block " + str(this_index)
    this_hash = last_block.hash
    return Block(this_index, this_timestamp, this_data, this_hash)


# 4.跑10个后续区块链测试
def main():
    # Create the blockchain and add the genesis block
    blockchain = [create_genesis_block()]
    previous_block = blockchain[0]
    # How many blocks should we add to the chain after the genesis block
    num_of_blocks_to_add= 10
    # Addblocks to the chain
    for i in range(0, num_of_blocks_to_add):
        block_to_add = next_block(previous_block)
        blockchain.append(block_to_add)
        previous_block = block_to_add
        # Telleveryone about it!
        print("Block #{} has been added to theblockchain!".format(block_to_add.index))
        print("Hash:{}".format(block_to_add.hash))


if __name__ == '__main__':
    main()

