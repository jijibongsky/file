# coding:utf-8
# CreatDate: 2021/2/22 15:57 by ZTE
# Author: Kangkang Sun

# pip install nvidia-ml-py3
import pynvml

pynvml.nvmlInit()
handle = pynvml.nvmlDeviceGetHandleByIndex(1)  # 这里的1是GPU id
meminfo = pynvml.nvmlDeviceGetMemoryInfo(handle)
print(meminfo.total / (1024 ** 3))  # 第二块显卡总的显存大小
print(meminfo.used)  # 这里是字节bytes，所以要想得到以兆M为单位就需要除以1024**2
print(meminfo.free)  # 第二块显卡剩余显存大小
