# coding=utf-8
# Copyright 2019/6/19 18:50 by ZTE
# Author: Kangkang Sun

from time import time
from stanfordcorenlp import StanfordCoreNLP
import json

def my_ner(nlp, sentence):
    tags = ["ORGANIZATION", "FACILITY", "DATE", "TIME"]
    res = nlp.ner(sentence)
    # res = [('合肥', 'ORGANIZATION'), ('工业', 'ORGANIZATION'),  ('大学', 'ORGANIZATION'), ('在', 'O'), ('屯溪路', 'FACILITY'), ('193', 'FACILITY'), ('号', 'FACILITY'), ('，', 'O'), ('李勇', 'PERSON'), ('在', 'O'), ('这里', 'O'), ('上', 'O'), ('大学', 'O')]
    label = ''
    labels = []
    temp_tag = ""
    for i in range(len(res)):
        if res[i][1] in tags:
            if temp_tag == "":
                temp_tag = res[i][1]
                label += res[i][0]
            elif temp_tag == res[i][1]:
                label += res[i][0]
            else:
                labels.append(label)
                temp_tag = res[i][1]
                label = res[i][0]
        elif label != "":
            labels.append(label)
            temp_tag = ""
            label = ''
    return labels


def merge(nlp, sentence):
    res = nlp.ner(sentence)
    # res = [('合肥', 'ORGANIZATION'), ('工业', 'ORGANIZATION'),  ('大学', 'ORGANIZATION'), ('在', 'O'), ('屯溪路', 'FACILITY'), ('193', 'FACILITY'), ('号', 'FACILITY'), ('，', 'O'), ('李勇', 'PERSON'), ('在', 'O'), ('这里', 'O'), ('上', 'O'), ('大学', 'O')]
    word = res[0][0]
    temp_tag = res[0][1]
    new_res = []
    for i in range(1, len(res)):
        if res[i][1] == temp_tag:
            temp_tag = res[i][1]
            word += res[i][0]
        else:
            new_res.append((word, temp_tag))
            temp_tag = res[i][1]
            word = res[i][0]
    new_res.append((word, temp_tag))
    return new_res


if __name__ == '__main__':
    nlp = StanfordCoreNLP('/home/data/stanford-corenlp-full-2018-10-05/', lang='zh')
    # sentence = '合肥工业大学在屯溪路193号，刘德水在这里上大学'
    # sentence = '我想听荷塘月色'
    sentence = '我想订明天早上9点3号楼的会议室'
    a = nlp.ner(sentence)

    while 1:
        sentence = input("请输入：")
        if sentence == "" or sentence == "q":
            nlp.close()
            break
        res1 = nlp.ner(sentence)
        print(111111, res1)
        # labels = my_ner(nlp, sentence)
        # print(labels)

        res = merge(nlp, sentence)
        print(res)
