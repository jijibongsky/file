from pyhanlp import *

print(HanLP.segment("你好，欢迎使用HanLP汉语处理包！接下来请从其他Demo中体验HanLP丰富的功能~"))
word_li = HanLP.segment("你好，欢迎使用HanLP汉语处理包！接下来请从其他Demo中体验HanLP丰富的功能~")

for word in word_li:
    print(word.word, word.nature)


import datetime
now_time = datetime.datetime.now()
print(now_time)

