# coding=utf-8
# Copyright 2019/6/19 18:50 by ZTE
# Author: Kangkang Sun

from time import time
from stanfordcorenlp import StanfordCoreNLP
from flask import request
from flask import Flask
from flask import abort
import json
import datetime



def my_ner(nlp, sentence):
    tags = ["ORGANIZATION", "FACILITY", "DATE", "TIME"]
    res = nlp.ner(sentence)
    label = ''
    labels = []
    temp_tag = ""
    for i in range(len(res)):
        if res[i][1] in tags:
            if temp_tag == "":
                temp_tag = res[i][1]
                label += res[i][0]
            elif temp_tag == res[i][1]:
                label += res[i][0]
            else:
                labels.append(label)
                temp_tag = res[i][1]
                label = res[i][0]
        elif label != "":
            labels.append(label)
            temp_tag = ""
            label = ''
    return labels


def merge(nlp, sentence):
    res = nlp.ner(sentence)
    word = res[0][0]
    temp_tag = res[0][1]
    new_res = []
    for i in range(1, len(res)):
        if res[i][1] == temp_tag:
            temp_tag = res[i][1]
            word += res[i][0]
        else:
            new_res.append((word, temp_tag))
            temp_tag = res[i][1]
            word = res[i][0]
    new_res.append((word, temp_tag))
    return res, new_res


nlp = StanfordCoreNLP('/home/skk/stanford-corenlp-full-2018-10-05/', lang='zh')
# sentence = '合肥工业大学在屯溪路193号，刘德水在这里上大学'
# sentence = '我想听荷塘月色'
sentence = '我想订明天早上9点3号楼的会议室'
a = nlp.ner(sentence)
b = nlp.pos_tag(sentence)

app = Flask(__name__)
@app.route('/ner', methods=['POST'])
def create_task_ner():
    if not request.json or not 'sentence' in request.json:
        abort(400)
    sentence = request.json['sentence']
    print("原始句：", sentence)
    res, result = merge(nlp, sentence)
    now_time = datetime.datetime.now()
    print(now_time, " 原始结果：", res)
    A = {"result": res}
    res = json.dumps(A, ensure_ascii=False)
    return res, 201


@app.route('/pos_tag', methods=['POST'])
def create_task_pos_tag():
    if not request.json or not 'sentence' in request.json:
        abort(400)
    sentence = request.json['sentence']
    print("原始句：", sentence)
    res = nlp.pos_tag(sentence)
    now_time = datetime.datetime.now()
    print(now_time, "原始结果：", res)
    A = {"result":res}
    res = json.dumps(A, ensure_ascii=False)
    return res, 201


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8817)
