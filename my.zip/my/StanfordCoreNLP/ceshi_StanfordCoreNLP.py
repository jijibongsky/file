# coding=utf-8
# Copyright 2019/6/6 15:26 by ZTE
# Author: Kangkang Sun

from time import time
from stanfordcorenlp import StanfordCoreNLP


def my_ner(nlp, sentence):
    tags = ["ORGANIZATION", "FACILITY", "DATE", "TIME"]
    res = nlp.ner(sentence)
    # res = [('合肥', 'ORGANIZATION'), ('工业', 'ORGANIZATION'),  ('大学', 'ORGANIZATION'), ('在', 'O'), ('屯溪路', 'FACILITY'), ('193', 'FACILITY'), ('号', 'FACILITY'), ('，', 'O'), ('李勇', 'PERSON'), ('在', 'O'), ('这里', 'O'), ('上', 'O'), ('大学', 'O')]
    label = ''
    labels = []
    temp_tag = ""
    for i in range(len(res)):
        if res[i][1] in tags:
            if temp_tag == "":
                temp_tag = res[i][1]
                label += res[i][0]
            elif temp_tag == res[i][1]:
                label += res[i][0]
            else:
                labels.append(label)
                temp_tag = res[i][1]
                label = res[i][0]
        elif label != "":
            labels.append(label)
            temp_tag = ""
            label = ''
    return labels


nlp = StanfordCoreNLP('/home/skk/stanford-corenlp-full-2018-10-05/', lang='zh')
# sentence = '合肥工业大学在屯溪路193号，刘德水在这里上大学'
# sentence = '我想听荷塘月色'
sentence = '我想订明天早上9点3号楼的会议室'

# print(nlp.pos_tag(sentence))
begin = time()
print(111111, nlp.ner(sentence))
print("花费时间：", time()-begin)

labels = my_ner(nlp, sentence)
print(labels)


# begin = time()
# for i in range(100):
#     a = nlp.ner(sentence)
# print("花费时间：",time()-begin)

# print(nlp.word_tokenize(sentence))
# print(222222, nlp.pos_tag(sentence))


import json
res = nlp.pos_tag(sentence)
print("原始结果：", res)
A = {"result": res}
res = json.dumps(A, ensure_ascii=False)
print(222222, res)


# print(nlp.ner(sentence))
# print(nlp.parse(sentence))
# print(nlp.dependency_parse(sentence))
nlp.close()

