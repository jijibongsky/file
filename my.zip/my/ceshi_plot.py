import matplotlib.pyplot as plt
# x = list(range(10))
# y = list(range(10))
# plt.plot(x, y)
# plt.show()

# plt.hist(x)
# plt.show()

a = [[1192, 1862], [2424, 1895], [2405, 2428], [1185, 2366]]
x = []
y = []
for term in a:
    x.append(term[0])
    y.append(term[1])

plt.plot(x, y)
plt.show()