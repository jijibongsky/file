# https://github.com/letiantian/TextRank4ZH
import codecs
import os
from textrank4zh import TextRank4Keyword, TextRank4Sentence


text = codecs.open(os.path.join('ceshi.txt'), 'r', 'utf-8').read()
# print(text)
# input()
tr4w = TextRank4Keyword()

tr4w.analyze(text=text, lower=True, window=2)  # py2中text必须是utf8编码的str或者unicode对象，py3中必须是utf8编码的bytes或者str对象

print('关键词：')
for item in tr4w.get_keywords(20, word_min_len=1):
    print(item.word, item.weight)

print('===========')
print( '关键短语：' )
for phrase in tr4w.get_keyphrases(keywords_num=20, min_occur_num= 2):
    print(phrase)

tr4s = TextRank4Sentence()
tr4s.analyze(text=text, lower=False, source='all_filters')
print('摘要：')
k = 0
for item in tr4s.get_key_sentences(num=5):
    k+=1
    print("第{}个句子".format(k))
    print(item.index, item.weight, item.sentence)  # index是语句在文本中位置，weight是权重
