# coding:utf-8
# CreatDate: 2021/1/29 16:45 by ZTE
# Author: Kangkang Sun

# 求多边形面积，周长。
import numpy as np
from shapely.geometry import Polygon
# line = [1, 1, 4, 1, 4, 4, 1, 4]
# polygon = np.array(line).reshape(4, 2)
line = [1, 1, 4, 1, 4, 3, 2, 4, 1, 4]
polygon = np.array(line).reshape(5, 2)
print(111111, polygon)
polygon_shape = Polygon(polygon)
print(222222, polygon_shape.area)
print(333333, polygon_shape.length)
