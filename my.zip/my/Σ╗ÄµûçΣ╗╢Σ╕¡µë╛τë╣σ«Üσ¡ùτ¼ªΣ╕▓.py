# coding:utf-8
# CreatDate: 2020/12/28 21:49 by ZTE
# Author: Kangkang Sun

import os
import re

# 遍历获取所有文件（这里只保留 .py 文件）
def walkFile(file):
    all_file = []
    for root, dirs, files in os.walk(file):
        # root 表示当前正在访问的文件夹路径
        # dirs 表示该文件夹下的子目录名list
        # files 表示该文件夹下的文件list
        # print(11111, root)
        # print(22222, dirs)
        # print(33333, files)
        # print()

        # 遍历文件
        for f in files:
            if f[-3:] == ".py":
                # print(os.path.join(root, f))
                all_file.append(os.path.join(root, f))
        # 遍历所有的文件夹
        # for d in dirs:
        #     print(os.path.join(root, d))
    return all_file

# 判断是否包含需要的字符串
def panduan(file_name, name):
    fr = open(file_name, "r", encoding="utf8")
    for line in fr:
        line = line.strip()
        # if re.findall("def +{}\(".format(name), line):
        # if re.findall("def +{}".format(name), line):
        if re.findall("{}".format(name), line):
            return True
        else:
            continue
    return False


def find_def(root_dir, name):
    all_file = walkFile(root_dir)
    for file_name in all_file:
        flag = panduan(file_name, name)
        if flag:
            print(file_name)

root_dir = "/home/skk/ceshi/database/code/src/"
# name = "load_dataset"
name = "rest Evaluat"
find_def(root_dir, name)
