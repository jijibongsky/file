import math
from collections import Counter
from nltk.util import ngrams


def bleu(candidate, references, weights):
    p_ns = []
    for i in range(len(weights)):
        a = modified_precision(candidate, references, i + 1)
        p_ns.append(a)
    if sum(p_ns) == 0:
        return 0

    s = 0
    for w, p_n in zip(weights, p_ns):
        if p_n > 0:
            s += w * math.log(p_n)
    bp = brevity_penalty(candidate, references)
    return bp * math.exp(s)


def modified_precision(candidate, references, n):
    counts = Counter(ngrams(candidate, n))
    if not counts:
        # print("句子太短")
        return 0
    max_counts = {}
    for reference in references:
        reference_counts = Counter(ngrams(reference, n))
        for ngram in counts:
            max_counts[ngram] = max(max_counts.get(ngram, 0), reference_counts[ngram])

    clipped_counts = 0
    for ngram, count in counts.items():
        clipped_counts += min(count, max_counts[ngram])
    return clipped_counts / sum(counts.values())


def brevity_penalty(candidate, references):
    c = len(candidate)
    ref_lens = [len(reference) for reference in references]
    r = min(ref_lens, key=lambda ref_len: abs(ref_len - c))
    if c > r:
        return 1
    else:
        return math.exp(1 - r / c)

