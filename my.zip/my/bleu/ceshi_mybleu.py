from my.bleu.en import sentence_bleu
from my.bleu.my_bleu import bleu
from my.bleu.yunyi_bleu import yunyi_bleu
from my.bleu.qinghua_bleu import qinghua_bleu

# hypothesis1 = ['It', 'is', 'a', 'guide', 'to', 'action', 'which','ensures', 'that', 'the', 'military', 'always','obeys', 'the', 'commands', 'of', 'the', 'party']
# hypothesis2 = ['It', 'is', 'to', 'insure', 'the', 'troops','forever', 'hearing', 'the', 'activity', 'guidebook', 'that', 'party', 'direct']
# reference1 = ['It', 'is', 'a', 'guide', 'to', 'action', 'that', 'ensures', 'that', 'the', 'military', 'will', 'forever','heed', 'Party', 'commands']
# reference2 = ['It', 'is', 'the', 'guiding', 'principle', 'which', 'guarantees', 'the', 'military', 'forces', 'always', 'being', 'under', 'the', 'command', 'of', 'the','Party']
# reference3 = ['It', 'is', 'the', 'practical', 'guide', 'for', 'the', 'army', 'always', 'to', 'heed', 'the', 'directions', 'of', 'the', 'party']
# a = sentence_bleu([reference1, reference2, reference3], hypothesis2)  # doctest: +ELLIPSIS
# b = bleu(hypothesis2,[reference1, reference2, reference3],weights = [0.25, 0.25, 0.25, 0.25])  # doctest: +ELLIPSIS


# reference = [['成', '都', '市', '温', '江', '区', '电', '信', '宽', '带', '如', '何', '移', '机']]
# candidate = ['成', '都', '市', '温', '江', '区', '电', '信', '宽', '带', '移', '机', '方', '法']
# a = sentence_bleu(reference, candidate)  # doctest: +ELLIPSIS
# b = bleu(candidate,reference,weights = [0.25, 0.25, 0.25, 0.25])  # doctest: +ELLIPSIS


# candidate = ['宽', '带', '移', '机', '可', '以', '吗']
# reference = [['机', '顶', '盒', '可', '以', '移', '机', '吗'], ['IPTV', '可', '以', '迁', '移', '吗'], ['电', '信', '电', '视', '能', '办', '理', '移', '机', '吗'], ['电', '信', '电', '视', '能', '否', '办', '理', '移', '机']]

# candidate = ['移', '机', '是', '什', '么', '设', '备']
# reference = [['机', '顶', '盒', '可', '以', '移', '机', '吗'], ['I','P','T','V','可', '以', '迁', '移', '吗'], ['电', '信', '电', '视', '能', '办', '理', '移', '机', '吗'], ['电', '信', '电', '视', '能', '否', '办', '理', '移', '机']]

candidate = ['移', '机', '是', '什', '么', '设', '备']
reference = [['移', '机', '是', '什', '么', '设', '备'], ['I','P','T','V','可', '以', '迁', '移', '吗'], ['电', '信', '电', '视', '能', '办', '理', '移', '机', '吗'], ['电', '信', '电', '视', '能', '否', '办', '理', '移', '机']]

a = sentence_bleu(reference, candidate)  # doctest: +ELLIPSIS
b = bleu(candidate, reference, weights=[0.25, 0.25, 0.25, 0.25])  # doctest: +ELLIPSIS
c = yunyi_bleu(candidate, reference, n=4)  # doctest: +ELLIPSIS
d = qinghua_bleu(candidate, reference, n=4)
print(a, b, c, d)
