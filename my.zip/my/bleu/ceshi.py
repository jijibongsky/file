# coding=utf-8
# Copyright 2020/5/28 15:55 by ZTE
# Author: Kangkang Sun
from my.bleu.my_bleu import bleu
from nltk.translate.bleu_score import sentence_bleu

reference = [['this', 'is', 'small', 'test']]
candidate = ['this', 'is', 'a', 'test']
b = sentence_bleu(reference, candidate, weights=[0.25, 0.25, 0.25, 0.25])
print(b)
