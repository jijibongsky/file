from nltk.translate.bleu_score import sentence_bleu


def count_blue(reference_file, prediction_file):
    references = open(reference_file, "r", encoding="utf8")
    predictions = open(prediction_file, "r", encoding="utf8")
    total_score = 0
    k = 0
    for reference, prediction in zip(references, predictions):
        reference = reference.strip()
        prediction = prediction.strip()
        reference = reference.replace("@@ ", "").replace(" ", "")
        prediction = prediction.replace("@@ ", "").replace(" ", "")
        # reference = [w for w in reference]
        # prediction = [w for w in prediction]
        print("===", reference)
        print("---", prediction)
        k += 1
        score = sentence_bleu([reference], prediction)
        total_score += score
    print("平均bleu值：", total_score/k)

reference_file = "/home/sun/deep_learning/THUMT/data_file/eval_decode.bpe32k.txt"
prediction_file = "/home/sun/deep_learning/THUMT/data_file/result.txt"
count_blue(reference_file, prediction_file)
