# coding=utf-8
# Copyright 2019/3/5 16:00 by ZTE
# Author: Kangkang Sun
import random
import codecs

def shuffle_data(input_file, output__file):
    with codecs.open(input_file, 'r', encoding='utf-8_sig') as rfile:
        with codecs.open(output__file, 'w', encoding='utf-8_sig') as wfile:
            lines = rfile.readlines()
            for _ in range(10):  # 随机打乱10次
                random.shuffle(lines)
            for line in lines:
                wfile.write(line)

input_file = "ceshi.txt"
output__file = "ceshi1.txt"
shuffle_data(input_file, output__file)

