# coding=utf-8
# Copyright 2020/7/16 9:29 by ZTE
# Author: Kangkang Sun
from flashtext import KeywordProcessor


# Extract keywords
def extract_keywords():
    keyword_processor = KeywordProcessor()
    # keyword_processor.add_keyword(<unclean name>, <standardised name>)
    keyword_processor.add_keyword('Big Apple', 'New York')
    keyword_processor.add_keyword('Bay Area')
    keywords_found = keyword_processor.extract_keywords('I love Big Apple and Bay Area.')
    print(keywords_found)  # ['New York', 'Bay Area']


def replace_keywords():
    keyword_processor = KeywordProcessor()
    keyword_processor.add_keyword('New Delhi', 'NCR region')
    new_sentence = keyword_processor.replace_keywords('I love Big Apple and new delhi.')
    print(new_sentence)  # 'I love New York and NCR region.'


def case_sensitive_example():
    keyword_processor = KeywordProcessor(case_sensitive=True)  # 区分大小写
    keyword_processor.add_keyword('Big Apple', 'New York')
    keyword_processor.add_keyword('Bay Area')
    keywords_found = keyword_processor.extract_keywords('I love big Apple and Bay Area.')
    print(keywords_found)  # ['Bay Area']


def span_of_keywords_extracted():
    keyword_processor = KeywordProcessor()
    keyword_processor.add_keyword('Big Apple', 'New York')
    keyword_processor.add_keyword('Bay Area')
    keywords_found = keyword_processor.extract_keywords('I love big Apple and Bay Area.', span_info=True)  # 位置信息
    print(keywords_found)  # [('New York', 7, 16), ('Bay Area', 21, 29)]


def get_Extra_information_with_keywords_extracted():
    kp = KeywordProcessor()
    kp.add_keyword('Taj Mahal', ('Monument', 'Taj Mahal'))
    kp.add_keyword('Delhi', ('Location', 'Delhi'))
    result = kp.extract_keywords('Taj Mahal is in Delhi.')
    print(result)  # [('Monument', 'Taj Mahal'), ('Location', 'Delhi')]


def No_clean_name_for_Keywords():
    keyword_processor = KeywordProcessor()
    keyword_processor.add_keyword('Big Apple')
    keyword_processor.add_keyword('Bay Area')
    keywords_found = keyword_processor.extract_keywords('I love big Apple and Bay Area.')
    print(keywords_found)  # ['Big Apple', 'Bay Area']


def To_check_if_term_is_present_in_KeywordProcessor():
    keyword_processor = KeywordProcessor()
    keyword_processor.add_keyword('j2ee', 'Java')
    print('j2ee' in keyword_processor)  # output: True
    print(keyword_processor.get_keyword('j2ee'))  # output: Java
    keyword_processor['colour'] = 'color'
    print(keyword_processor['colour'])  # output: color


if __name__ == '__main__':
    # 其他例子见 https://github.com/vi3k6i5/flashtext
    # extract_keywords()
    # replace_keywords()
    # case_sensitive_example()
    # span_of_keywords_extracted()
    # get_Extra_information_with_keywords_extracted()
    # No_clean_name_for_Keywords()
    To_check_if_term_is_present_in_KeywordProcessor()
