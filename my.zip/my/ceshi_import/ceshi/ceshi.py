import os
import sys

root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__),"../../"))
sys.path.append(root_dir)
print(root_dir)

import ceshi_import.ceshi1.ceshi1 as ceshi
a = ceshi.my_mat(2, 3)
print(a)


root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__),"../"))
sys.path.append(root_dir)
print(root_dir)

import ceshi2.ceshi2 as ceshi
a = ceshi.my_sum(1,2)
print(a)