def my_mat(a, b):
    return a*b
