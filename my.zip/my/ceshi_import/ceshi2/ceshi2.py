def my_sum(a, b):
    return a + b

