# coding=utf-8
# Copyright 2019/8/13 15:52 by ZTE
# Author: Kangkang Sun

import os
from time import time

begin_time = time()
root_dir = "/home/data/deep_learning"
# root_dir = "/home/sun/"
for child_dir in os.listdir(root_dir):
    dir = os.path.join(root_dir, child_dir)
    os.system("du -sh " + dir)
    # print(child_dir, " : ", time() - begin_time)

# print("total time: ", time() - begin_time)
# 340G	/home/data/ASR
# 24G	/home/data/Tencent_ChineseEmbedding
# 31G	/home/data/OCR
# 267G	/home/data/deep_learning

# 50G	/home/data/OCR
# 281G	/home/data/deep_learning



# 71M	/home/data/redis-4.0.8
# redis-4.0.8  :  0.004006624221801758
# 340G	/home/data/ASR
# ASR  :  75.45580554008484
# 10M	/home/data/serving
# serving  :  75.46532249450684
# 44K	/home/data/docker
# docker  :  75.46669387817383
# 75G	/home/data/text_matching
# text_matching  :  75.46794557571411
# 24G	/home/data/Tencent_ChineseEmbedding
# Tencent_ChineseEmbedding  :  75.46924757957458
# 1.2G	/home/data/kibana-7.6.0-linux-x86_64
# kibana-7.6.0-linux-x86_64  :  78.05700659751892
# 144G	/home/data/fanyi_data
# fanyi_data  :  78.06264424324036
# 26G	/home/data/temp
# temp  :  86.77537369728088
# 45M	/home/data/brat
# brat  :  87.17521142959595
# 1.4G	/home/data/stanford-corenlp-full-2018-10-05
# stanford-corenlp-full-2018-10-05  :  87.21014428138733
# 31G	/home/data/OCR
# OCR  :  264.8410813808441
# 614M	/home/data/elasticsearch-7.6.0
# elasticsearch-7.6.0  :  265.1172595024109
# 1.7M	/home/data/redis-4.0.8.tar.gz
# redis-4.0.8.tar.gz  :  265.12288308143616
# 267G	/home/data/deep_learning
# deep_learning  :  352.00265669822693
# total time:  352.0028884410858
