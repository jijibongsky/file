# coding=utf-8
# Copyright 2019/5/6 14:52 by ZTE
# Author: Kangkang Sun
import os

data_dir = "/home/skk/ceshi/my"

for child_file in os.listdir(data_dir):
    teacher_label = []
    if child_file[-2:] != "py":
        # print("||||", child_file)
        continue
    child_file = os.path.join(data_dir, child_file)
    print("---", child_file)
