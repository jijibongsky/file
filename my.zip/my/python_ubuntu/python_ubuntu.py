import os

# # python 中运行 Ubuntu 命令
# data1 = "/home/data/OCR/images"
# all_files = os.listdir(data1)
# k = 0
# for file in all_files:
#     k += 1
#     if k > 1000:
#         break
#     os.system('scp -r /home/data/OCR/images/{} /home/sun/deep_learning/deeplearning/chinese_ocr/test_images_line/ceshi'.format(file))


