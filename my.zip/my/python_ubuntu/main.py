import os

os.system("python ceshi1.py")
os.system("python ceshi2.py")
