# coding=utf-8
# Copyright 2019/2/14 16:51 by ZTE
# Author: Kangkang Sun

import os

retval = os.getcwd()
print("当前工作目录为 %s" % retval)

# 修改当前工作目录
path = "/tmp"
os.chdir(path)
retval = os.getcwd()
print("目录修改成功 %s" % retval)