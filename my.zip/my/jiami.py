# coding=utf-8
import hashlib
import re

#对字典中的值进行加密
def md5value(s):
    md5 = hashlib.md5()
    md5.update(s)
    return md5.hexdigest()


sentence = '你好，12你叫什么名字'
sentence = re.findall(u'[\u4e00-\u9fa5]+', sentence)
print("sentence====", sentence)
temp = "".join(sentence)
result = md5value(temp.encode())
print("result===", result)
