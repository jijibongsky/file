from pypinyin import lazy_pinyin, Style

style = Style.TONE3
tone_number = {"1", "2", "3", "4"}


def my_pinyin(sentence):
    result = lazy_pinyin(sentence, style=style)
    new_result = []
    for term in result:
        if term[-1] not in tone_number:
            term += "5"
        new_result.append(term)
    return " ".join(new_result)

sentence = '聪明的小兔子'
result = my_pinyin(sentence)
print(result)
