
# cd D:\Program Files\Anaconda3\Scripts
# python 2to3-script.py -w D:/ceshi.py