
# def get_len(x):
#     return len(x)
#
# mylist = ['青海省','内蒙古自治区','西藏自治区','新疆维吾尔自治区','广西壮族自治区']
# mylist1 = sorted(mylist, key=get_len)
# mylist2 = sorted(mylist, key=lambda x:len(x))
# print(mylist1)
# print(mylist2)

c = 10
ref_lens = [6, 7, 8, 9, 10, 11]
r = min(ref_lens, key=lambda ref_len: abs(ref_len-c))
print(r)
