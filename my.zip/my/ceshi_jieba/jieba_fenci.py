import jieba
import re

def jieba_fenci(sentence):
    sentence = re.sub(" +", " ", sentence)
    words = jieba.lcut(sentence)
    result = " ".join(words)
    result = re.sub(" +", " ", result)
    return result

# jieba.load_userdict()
sentence = "怎么办理  移机"
a = jieba_fenci(sentence)
print(a)
