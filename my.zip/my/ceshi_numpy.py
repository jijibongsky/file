# coding=utf-8
# Copyright 2019/3/20 10:39 by ZTE
# Author: Kangkang Sun
import numpy as np

a = np.array(0.123456789, dtype=np.float32)
print(a)

a = np.array([[1, 2, 3], [2, 3, 4]], dtype=np.float32)
b = np.array([3, 4, 5], dtype=np.float32)
c = np.row_stack((a, b))
d = np.zeros(shape=(2, 3), dtype=np.float32)
e = np.row_stack((c, d))
print(e)
h = np.delete(e, list(range(2, 5)), axis=0)
# print(c)
print(h)

f = np.array([1, 2])
g = np.array([3, 4])
h = np.hstack((f, g))
aaa = np.concatenate((f, g), axis=0)
print(f.shape, g)
print(h)
print(1111, aaa)
