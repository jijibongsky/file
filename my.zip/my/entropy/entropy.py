import math
import os
from time import time


def list2txt(data_dir, filename, wordlist):
    fh = open(os.path.join(data_dir, filename), 'w', encoding='utf8')
    for i in range(len(wordlist)):
        fh.write(wordlist[i][0] + '\t' + str(wordlist[i][1]) + '\n')
    fh.close()


def load_data(data_dir, type='forward'):
    fobj = open(data_dir, 'r', encoding='utf8')
    if type == "forward":
        for line in fobj:
            yield line.strip().split(' ')
    elif type == "reverse":
        for line in fobj:
            yield list(reversed(line.strip().split(' ')))
    else:
        print("数据输入有误。。。")
        exit(1)


# 计算信息熵
def get_entropy(words_dict):
    values = list(words_dict.values())
    if len(values) == 1:
        return 0
    s = sum(values)
    P = [v/s for v in values]
    entropy = -sum([p * math.log(p) for p in P])
    return entropy


def get_entropy1(words_dict):
    values = list(words_dict.values())
    if len(values) == 1:
        return 0
    s = sum(values)
    entropy = math.log(s)-sum([(value/s)*math.log(value) for value in values])
    return entropy


def main(input_data):
    words_fre_right = {}  # 记录一阶单词词频
    for words in input_data:
        for i in range(len(words) - 1):
            if words[i] in words_fre_right:
                if words[i+1] in words_fre_right[words[i]]:
                    words_fre_right[words[i]][words[i + 1]] += 1
                else:
                    words_fre_right[words[i]][words[i + 1]] = 1
            else:
                words_fre_right[words[i]] = {}
                words_fre_right[words[i]][words[i + 1]] = 1

    # print("words_fre_right===", words_fre_right)
    right_entropy = {}
    for key in words_fre_right:
        right_entropy[key] = get_entropy(words_fre_right[key])
        # print("===", key, words_fre_right[key])
        # print("===", right_entropy[key])
        # input()
    return right_entropy


if __name__ == '__main__':
    t = time()
    data_dir = '中华人民共和国婚姻法.txt'

    result_dir = 'result'
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)

    data_forward = load_data(data_dir)
    right_entropy = main(data_forward)
    right_entropy_list = sorted(right_entropy.items(), key=lambda d: d[1], reverse=True)
    list2txt(result_dir, '右熵.txt', right_entropy_list)

    data_backward = load_data(data_dir, "reverse")
    left_entropy = main(data_backward)
    left_entropy_list = sorted(left_entropy.items(), key=lambda d: d[1], reverse=True)
    list2txt(result_dir, '左熵.txt', left_entropy_list)
    print(time()-t)
