# coding=utf-8
# Copyright 2020/2/27 13:01 by ZTE
# Author: Kangkang Sun

import itertools

def get_permutations(XX, n):
    bbb = itertools.permutations(XX, n)
    # bbb = itertools.combinations(aaa, 3)# 组合,没有重复
    # bbb = itertools.combinations_with_replacement(aaa, 3)# 组合,有重复
    bbb = list(bbb)
    return bbb

# aaa = 'ABCD'
aaa = list(range(10))

result = get_permutations(aaa, 2)
for line in result:
    print(line)