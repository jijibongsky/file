# coding=utf-8
# Copyright 2019/8/30 14:53 by ZTE
# Author: Kangkang Sun

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from flask import Flask
from flask import send_file
from flask import request
from flask import json
import json


def ceshi(sentence, type_model):
    return sentence + "_" + type_model


app = Flask(__name__)
@app.route('/')
def hello_world():
    return send_file("templates/html.html")


@app.route('/login', methods=['POST'])
def login():
    # print(11111111, request.get_data())
    # a = request.get_data()
    # b = a.decode("utf-8")
    # print(1111111111, b)
    # c = json.loads(b)
    # print(222222, c)
    # data = json.loads(request.get_data().decode("utf-8"))
    # data = json.loads(request.json)

    data = json.loads(request.form.get('data2'))
    aaa = request.form.getlist('data1')
    # print(111111111111, request.form)
    # print(222222222222, aaa)
    # for key in request.form:
    #     print(111, key, request.form[key])

    contents = data["content"]
    type_model = data["type_model"]
    contents = contents.strip()
    result = ceshi(contents, type_model)
    return result


if __name__ == "__main__":
    # app.run(host='0.0.0.0', port='8801')
    app.run(host='0.0.0.0', port=8801)
    # 192.168.2.100:8801

