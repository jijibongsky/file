import json
data_dict = {'a': 'Runoob', 'b': 7}
print(json.dumps(data_dict, sort_keys=True, indent=4, separators=('。', ':')))


import json

# data = [ { 'a': 1, 'b' : 2, 'c' : 3, 'd' : 4, 'e' : 5 } ]
# data = { 'a': 1, 'b' : 2, 'c' : 3, 'd' : 4, 'e' : 5 }
data = ['母婴', '房产', '美容', '娱乐', '交通', '健身', '美食', '闲聊', '旅游', '教育']
a = json.dumps(data, ensure_ascii=False)
b = json.loads(a)

print("a===", type(a))
print("a===", a)
print("b===", type(b))
print("b===", b)