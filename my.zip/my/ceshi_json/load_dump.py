import json

my_dict = {"a": "我", "b": "吃了吗"}
file_name = 'test.json'
with open(file_name, 'w', encoding="utf8") as fw:
    json.dump(my_dict, fw, ensure_ascii=False)

with open(file_name, 'r', encoding="utf8") as fr:
    data = json.load(fr)

print(data)
