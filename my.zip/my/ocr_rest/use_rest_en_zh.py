import requests
import json
import base64
import os


def encoded_picture(path):
    with open(path, 'rb') as f:
        img_byte = base64.b64encode(f.read())
    img_str = img_byte.decode('ascii')
    return img_str

# 中文
image_dir = "/home/skk/ceshi/a_task/chinese_ocr/test_images/zh_g"
file_name = '1.jpg'
# file_name = '2.PNG'
file_path = os.path.join(image_dir, file_name)
data = {'recognize_img': encoded_picture(file_path), 'file_name': file_name, "type": "zh"}
res = requests.post(url='http://10.46.169.214:8816/ocr', json=json.dumps(data))
result = json.loads(res.text)
print("result:\n", result["result"])


# 英文
# image_dir = "/home/skk/ceshi/a_task/chinese_ocr/test_images/en"
# file_name = '3.PNG'
# file_path = os.path.join(image_dir, file_name)
# data = {'recognize_img': encoded_picture(file_path), 'file_name': file_name, "type": "en"}
# res = requests.post(url='http://10.46.169.214:8816/ocr', json=json.dumps(data))
# result = json.loads(res.text)
# print("result:\n", result["result"])


# from PIL import Image
# import numpy as np
# import cv2
# image_dir = "/home/skk/ceshi/a_task/chinese_ocr/test_images/"
# file_name = image_dir + 'demo.jpg'
# ####
# img_str = getByte(file_name)
# img_decode_ = img_str.encode('ascii')  # ascii编码
# img_decode = base64.b64decode(img_decode_)  # base64解码
# img_np = np.frombuffer(img_decode, np.uint8)  # 从byte数据读取为np.array形式
# img = cv2.imdecode(img_np, cv2.COLOR_RGB2BGR)  # 转为OpenCV形式   , cv2.COLOR_RGB2BGR
# ####
# image = np.array(Image.open(file_name).convert('RGB'))
# image = np.array([image[:, :, 2], image[:, :, 1], image[:, :, 0]], dtype="uint8").transpose((1, 2, 0))
# ####
# print(img == image)
# print(image.shape)
