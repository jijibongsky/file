# coding=utf-8
# Copyright 2020/1/9 18:24 by ZTE
# Author: Kangkang Sun
import numpy as np

# B = np.arange(1, 9).reshape((2, 2, 2))  # 原始输入数组B
# print(B)
# # a = np.pad(B, ((1, 2), (2, 1)), 'edge')
# a = np.pad(B, pad_width=((0, 0), (0, 2), (0, 0)), mode='edge')  # , (0, 0)
# a = np.pad(B, pad_width=((0, 0), (0, 0), (0, 2)), mode='edge')  # , (0, 0)
# print(a)


B = np.arange(1, 5).reshape((2, 2))  # 原始输入数组B
print(1111111111, B)
# a = np.pad(B, ((1, 2), (2, 1)), 'edge')
a = np.pad(B, pad_width=((0, 2), (0, 0)), mode='edge')  # , (0, 0)
# a = np.pad(B, pad_width=((0, 0), (0, 2)), mode='edge')  # , (0, 0)
print(222222222, a)

feat = np.random.random((2, 3))
max_feature_length = 5
feat_len = 2
# 第一维前面 padding 0，后面 padding   max_feature_length - feat_len
# 第二维前面 padding 1，后面 padding   2
y = np.pad(feat, ((0, max_feature_length - feat_len), (1, 2)), mode='constant', constant_values=0.0)
print(333333333, y)

# max_nodes = 7
# mapping_batch = [[1, 2, 2, 3], [1], [1, 2, 2, 3, 3, 4, 4], [1, 2, 2, 3, 3, 4], [1, 2, 2, 3, 3], [1, 2, 2, 3, 3, 4]]
# c = [np.pad(v, (0, max_nodes - len(v)), 'constant', constant_values=0.0) for v in mapping_batch]
# print(4444444444, c)
