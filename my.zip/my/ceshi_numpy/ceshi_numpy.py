# coding=utf-8
# Copyright 2019/3/20 10:39 by ZTE
# Author: Kangkang Sun
import numpy as np

feature1 = np.random.random((100, 19))
feature2 = np.random.random((100, 10))
new_features1 = np.hstack((feature1, feature2))
print(111111, new_features1.shape)

feature1 = np.random.random((19, 100))
feature2 = np.random.random((10, 100))
new_features2 = np.vstack((feature1, feature2))
print(222222, new_features2.shape)

a = np.array([[1, 2, 3, 4], [2, 3, 4, 5]], dtype=np.float32)
d = np.zeros(shape=(2, 3), dtype=np.float32)
h = np.delete(a, list(range(1, 3)), axis=1)
print(33333333, h)

a = np.array([[[1, 2], [3, 4]], [[1, 2], [3, 4]]])
b = np.array([[[5, 6], [7, 8]], [[5, 6], [7, 8]]])
c = np.concatenate((a, b), axis=0)
print(44444444, a.shape, b.shape, c.shape, c)
