import os
import numpy as np
import librosa


def add_noise(n_name):
    # path=output_path+"{}_noise.wav".format(my_path[0])
    my_path = ""  # 原始音频数据
    path_noise = ""  # 噪声数据
    path_voice = ""  # 保存的文件
    if os.path.exists(path_voice) and os.path.getsize(path_voice) != 0:
        return
    n, sr_n = librosa.load(path_noise, sr=16000)
    x, sr_x = librosa.load(my_path, sr=16000)
    if x.size < n.size:
        # 计算叠加噪声的随机区间
        header_pointer = np.random.random_integers(0, n.size - x.size - 1)
        orig_noise = n[header_pointer:x.size + header_pointer]
        # 计算噪声和音频强度
        SNR = np.random.uniform(snr_low, snr_high)  # 随机在定义的区间选择信噪比
        trimed_x = x[librosa.amplitude_to_db(x, ref=1.0) > db_thresh]  # 计算音频强度
        P_signal = np.sum(trimed_x ** 2) / trimed_x.size
        trimed_n = orig_noise[librosa.amplitude_to_db(orig_noise, ref=1.0) > db_thresh] # 计算噪声强度
        P_noise = np.sum(trimed_n ** 2) / trimed_n.size
        noise = orig_noise * (P_signal / (10 ** (SNR / 10) * P_noise)).astype("float32")
    else:
        SNR = np.random.uniform(snr_low, snr_high)  # 随机在定义的区间选择信噪比
        trimed_x = x[librosa.amplitude_to_db(x, ref=1.0) > db_thresh]  # 计算音频强度
        P_signal = np.sum(trimed_x ** 2) / trimed_x.size
        trimed_n = n[librosa.amplitude_to_db(n, ref=1.0) > db_thresh]# 计算噪声强度
        P_noise = np.sum(trimed_n ** 2) / trimed_n.size

        len_slice_noise = int(n.size * cutoff_rate)  # 每一次随机选择的噪声长度
        raw_noise = np.array([]).astype("float32")
        for i in range(x.size // len_slice_noise + 2):
            header_pointer = np.random.random_integers(0, int(n.size - len_slice_noise) - 2)
            raw_noise = np.append(raw_noise, n[header_pointer:len_slice_noise + header_pointer])  # 每一步截取的噪声的区间

        header_pointer = np.random.random_integers(0, raw_noise.size - x.size - 1)
        orig_noise = raw_noise[header_pointer:x.size + header_pointer]

        # 生成含有噪声的信号。
        noise = orig_noise * (P_signal / (10 ** (SNR / 10) * P_noise))

    librosa.output.write_wav(path_voice, x + noise, 16000)
    return


snr_low = -8  # 信噪比下限
snr_high = 4  # 信噪比上限
db_thresh = -45  # 信号强度阈值，大于阈值的信号才会被计算信号强度。
cutoff_rate = 0.4  # 在噪声小于信号强度时，采用截断选择信号的比例（小于0.5）
