# coding=utf-8
# Copyright 2019/9/10 16:33 by ZTE
# Author: Kangkang Sun

import os
from PIL import Image
import numpy as np
from time import time


def ceshi(root_dir):
    a = []
    len_dict = {}
    k = 0
    for file in os.listdir(root_dir):
        k += 1
        if k % 10000 == 0:
            print(k)
        data_file = os.path.join(root_dir, file)
        img1 = Image.open(data_file).convert('L')  # 图像类型
        img = np.array(img1, 'f') / 255.0 - 0.5  # 读出来的原始值在[0, 255] 之间
        # print(img.shape)
        a.append(img.shape[1])
        len_a = img.shape[1]
        if len_a not in len_dict:
            len_dict[len_a] = 1
        else:
            len_dict[len_a] += 1
    print(1111111111, max(a))
    # a = sorted(a)
    # print(111111, sum(a)/len(a))
    # print(222222, max(a))
    # print(333333, min(a))

    print("len_dict==", len_dict)
    len_dict = sorted(len_dict.items(), key=lambda d: d[1], reverse=True)
    for line in len_dict:
        print(line)


def create_voc(data_dir, voc_file):
    fw_voc = open(voc_file,"w",encoding="utf8")
    word_dict = {}
    char_dict = {}
    word_len = []
    for file in os.listdir(data_dir):
        if "\t" in file:
            print("hhhhhhhhhh")
            continue
        sentence = file.split("_")
        if len(sentence) > 2:
            words = []
            for i in range(len(sentence)-1):
                words.append(sentence[i])
            words = "_".join(words)
        else:
            words = sentence[0]
        for word in words:
            if word not in word_dict:
                word_dict[word] = 1
            else:
                word_dict[word] += 1
        word_len.append(len(words))

    word_len = sorted(word_len)
    word_len_dict = {}
    for i in word_len:
        if i in word_len_dict:
            word_len_dict[i] += 1
        else:
            word_len_dict[i] = 1
    print(word_len_dict)

    for key in word_dict:
        num = word_dict[key]
        for w in key:
            if w not in char_dict:
                char_dict[w] = num
            else:
                char_dict[w] += num

    char_dict = sorted(char_dict.items(), key=lambda d: d[1], reverse=True)
    for pair in char_dict:
        if pair[1] >= 50:
            fw_voc.write(pair[0] + "\t" + str(pair[1]) + "\n")
    # print(char_dict)


def load_voc(voc_file):
    fr_voc = open(voc_file, "r", encoding="utf8")
    words = []
    word_dict= {}
    for line in fr_voc:
        line = line.strip("\n")
        line = line.split("\t")
        if len(line) != 2:
            print("aaaaaaa", line)
            continue
        words.append(line[0])
    # print(111, "".join(words))
    # input()
    for i in range(len(words)):
        word_dict[words[i]] = i
        # print(words[i], i)
    return word_dict


def reshape_jpg(dir_in, dir_out, file, fw_data_id=None, word_dict=None, reshape=False):
    if "\t" in file:
        print("bbbbb")
        return

    sentence = file.split("_")
    if len(sentence) > 2:
        words = []
        for i in range(len(sentence)-1):
            words.append(sentence[i])
        words = "_".join(words)
    else:
        words = sentence[0]
    # if len(words) != 40:
    #     return

    data_file_in = os.path.join(dir_in, file)
    data_file_out = os.path.join(dir_out, file)

    im = Image.open(data_file_in)
    if reshape:
        # (x, y) = im.size
        im = im.resize((420, 32), Image.ANTIALIAS)   # resize image with high-quality
    im.save(data_file_out)

    word_id = []
    for w in words:
        # id = word_dict.get(w, word_dict[" "])
        id = word_dict.get(w, 0)
        word_id.append(id)
    word_id = [str(i) for i in word_id]
    word_id = " ".join(word_id)
    fw_data_id.write(file + "\t" + word_id + "\n")\


def main(root_dir,dir_in):
    if not os.path.exists(root_dir):
        os.makedirs(root_dir)

    data_id = root_dir + "all_data.txt"
    fw_data_id = open(data_id, "w", encoding="utf8")

    dir_out = root_dir + "images"
    voc_file = root_dir + "char_std.txt"

    create_voc(dir_in, voc_file)
    word_dict = load_voc(voc_file)

    if not os.path.exists(dir_out):
        os.makedirs(dir_out)

    begin_time = time()
    k = 0
    for file in os.listdir(dir_in):
        k += 1
        # if k < 3380275:
        #     continue

        # if k > 10000:
        #     break

        if k % 10000 == 0:
            print(k, time() - begin_time)
        reshape_jpg(dir_in, dir_out, file, fw_data_id, word_dict, reshape=False)


if __name__ == '__main__':
    # root_dir = "/home/skk/ceshi/my/create_ocr_data/ai_en_30_35_shuf_20wan/images"
    # dir_in = "/home/skk/ceshi/my/create_ocr_data/beifen/ai_en_30_35_shuf_20wan"   #  最大 568
    # ceshi(root_dir)

    root_dir = "/home/skk/ceshi/my/create_ocr_data/ai_en_30_35_shuf_20wan/"
    dir_in = "/home/skk/ceshi/my/create_ocr_data/beifen/ai_en_30_35_shuf_20wan"
    main(root_dir, dir_in)
