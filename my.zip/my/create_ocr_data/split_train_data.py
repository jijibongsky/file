# coding=utf-8
# Copyright 2019/9/12 10:57 by ZTE
# Author: Kangkang Sun
import os
import random
random.seed(1)


def split_train_data(dir_in, dir_out_train, dir_out_test):
    fr = open(dir_in, "r", encoding="utf8")
    fw_train = open(dir_out_train, "w", encoding="utf8")
    fw_test = open(dir_out_test, "w", encoding="utf8")
    lines = []
    for line in fr:
        line = line.strip("\n")
        lines.append(line)
    for i in range(5):
        random.shuffle(lines)
    L = len(lines)
    for i in range(L):
        if i <= 0.95 * L:
            fw_train.write(lines[i] + "\n")
        else:
            fw_test.write(lines[i] + "\n")


if __name__ == '__main__':
    root_dir = "/home/skk/ceshi/my/create_ocr_data/ai_en_30_35_shuf_20wan/"
    dir_in = root_dir + "all_data.txt"
    dir_out_train = root_dir + "data_train.txt"
    dir_out_test = root_dir + "data_test.txt"
    split_train_data(dir_in, dir_out_train, dir_out_test)
