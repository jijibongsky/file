# coding=utf-8
# Copyright 2019/9/10 16:26 by ZTE
# Author: Kangkang Sun
import re
import random
random.seed(1)


def cut_sentence_words(line, max_len=60):
    line = line.split(" ")
    new_sentences = []
    temp_sentence = ""
    for word in line:
        if len(temp_sentence) + len(word) < max_len:
            temp_sentence += word + " "
        else:
            if temp_sentence == "":
                new_sentences.append(word)
            else:
                new_sentences.append(temp_sentence)
                temp_sentence = word + " "
    if temp_sentence != "":
        new_sentences.append(temp_sentence)
    return new_sentences

def cut_sentence(line, max_len=60):
    new_sentences = []
    temp_sentence = ""
    for word in line:
        temp_sentence += word
        if len(temp_sentence) == max_len:
            new_sentences.append(temp_sentence)
            temp_sentence = ""
    return new_sentences


def split_str(data_in, data_out, max_len, len_range=None, language="zh"):
    fr = open(data_in, "r", encoding="utf8")
    fw = open(data_out, "w", encoding="utf8")
    k = 0
    kk = 0
    for line in fr:
        k += 1
        if k % 100000 == 0:
            print(k)
        # if k > 10000:
        #     break
        line = line.strip()
        if "/" in line:
            continue

        if language == "zh":
            line = line.replace(" ", "")
        else:
            line = re.sub(" +", " ", line)

        # lines = cut_sentence_words(line, max_len=35)
        # for a in lines:
        #     a = a.strip()
        #     if len(a) >= 30 and len(a) <= 35:
        #         fw.write(a + "\n")

        if len_range:
            temp_max_len = random.choice(len_range)
            lines = cut_sentence(line, max_len=temp_max_len)
        else:
            lines = cut_sentence(line, max_len=max_len)

        for a in lines:
            a = a.strip()
            if len_range:
                fw.write(a + "\n")
                continue
            if len(a) == max_len:
                # print(a)
                fw.write(a + "\n")
            else:
                kk += 1
                # print(a)
    print("===", kk)


def shuff_data(data_in, data_out, data_out2=None):
    fr = open(data_in, "r", encoding="utf8")
    fw = open(data_out, "w", encoding="utf8")

    lines = []
    for line in fr:
        lines.append(line)
    for i in range(5):
        random.shuffle(lines)

    len_lines = len(lines)
    len_train = 0.9*len_lines

    if data_out2:
        fw2 = open(data_out2, "w", encoding="utf8")
        k = 0
        for line in lines:
            k += 1
            if k < len_train:
                fw.write(line)
            else:
                fw2.write(line)
    else:
        for line in lines:
            fw.write(line)


if __name__ == '__main__':
    data_in = "ai_en.txt"
    data_out = "ai_en_201.txt"
    data_out_shuf = "ai_en_201_shuf.txt"
    data_out_shuf_test = "ai_en_201_shuf_test.txt"

    # data_in = "6M_zh.txt"
    # data_out = "zh_10.txt"
    # data_out_shuf = "zh_10_shuf.txt"
    # data_out_shuf_test = "zh_10_shuf_test.txt"
    split_str(data_in, data_out, max_len=10, len_range=list(range(20, 21)), language="en")

    # data_out = "ai_en_30_35.txt"
    # data_out_shuf = "ai_en_30_35_shuf.txt"
    shuff_data(data_out, data_out_shuf, data_out_shuf_test)
