# coding=utf-8
# Copyright 2019/9/10 16:27 by ZTE
# Author: Kangkang Sun
import os
from time import time


# data_in = 'ai_en_30_35_shuf.txt'
# data_out = 'ai_en_30_35_shuf_20wan111'
#
# fr = open(data_in, "r", encoding="utf8")
# k = 0
# for line in fr:
#     k += 1
# fr.close()
#
# begin_time = time()
# os.system("trdg -i {} --output_dir {} -c {} -w 10 -f 32 -t 8".format(data_in, data_out, 20))
# print(time() - begin_time)

data_out = 'out_random'
begin_time = time()
os.system("trdg --output_dir {} -c {} -w 4 -f 32".format(data_out, 20))
print(time() - begin_time)  # 1000  18.718831777572632
