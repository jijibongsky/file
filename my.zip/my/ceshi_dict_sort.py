my_dict = {"a": 1, "b": 3, "c": 2}
for term in my_dict.items():
    print(term)

my_dict = sorted(my_dict.items(), key=lambda d: d[1], reverse=True)
for line in my_dict:
    print(line)
