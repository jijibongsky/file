# 求多边形面积，周长
from shapely.geometry import Polygon
import numpy as np

line = [1, 1, 4, 1, 4, 3, 2, 4, 1, 4]
polygon = np.array(line).reshape(5, 2)
print(111, polygon)
polygon_shape = Polygon(polygon)
print(22222, polygon_shape.area)
print(22222, polygon_shape.length)
