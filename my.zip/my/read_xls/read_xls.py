import xlrd

def read_xls(data_file):
    readbook = xlrd.open_workbook(data_file, 'r')
    sheet = readbook.sheet_by_name("Sheet1")
    nrows = sheet.nrows
    for i in range(nrows):
        a = sheet.cell(i, 0).value
        b = sheet.cell(i, 1).value
        c = sheet.cell(i, 2).value
        print(a, b, c)

data_file = "ceshi.xlsx"
read_xls(data_file)
