from time import time
# 过滤掉一些包含很多奇怪符号或者不想关语言的数据, 把长度相差太多的删掉

def is_chinese(uchar):
    """判断一个unicode是否是汉字"""
    if uchar >= u'\u4e00' and uchar<=u'\u9fa5':
        return True
    else:
        return False


def is_number(uchar):
    """判断一个unicode是否是数字"""
    if uchar >= u'\u0030' and uchar<=u'\u0039':
        return True
    else:
        return False


def is_alphabet(uchar):
    """判断一个unicode是否是英文字母"""
    if (uchar >= u'\u0041' and uchar<=u'\u005a') or (uchar >= u'\u0061' and uchar<=u'\u007a'):
        return True
    else:
        return False


def is_other(uchar):
    """判断是否非汉字，数字和英文字符"""
    if not (is_chinese(uchar) or is_number(uchar) or is_alphabet(uchar)):
        return True
    else:
        return False


def load_punc(file_punc):
    rf = open(file_punc, 'r', encoding='utf8')
    puncs = []
    for line in rf:
        line = line.strip()
        line = line.split(" ")
        puncs.append(line[0])
        puncs.append(line[1])
    puncs.append("{")
    puncs.append("}")
    puncs.append("/")
    puncs.append("\\")
    puncs.append("%")
    puncs.append("=")
    puncs.append(">")
    puncs.append("<")
    puncs.append("+")
    puncs.append("$")
    puncs.append("°")
    puncs.append("–")
    puncs.append("_")
    puncs.append("─")
    puncs.append("—")
    puncs.append("*")
    puncs.append("…")
    puncs.append("|")
    puncs.append("£")
    puncs.append("€")
    puncs.append("〔")
    puncs.append("〕")

    puncs.append("•")
    puncs.append("·")
    puncs.append("∗")
    puncs.append("&")
    puncs.append("#")
    puncs.append("@")
    puncs.append("′")
    puncs.append("`")
    puncs.append("±")
    puncs.append("℃")
    puncs.append("α")
    puncs.append("β")
    puncs.append("×")
    puncs.append("∶")
    return set(puncs)


def judge_special_symbol(line, puncs):
    k_b = 0
    k_s = 0
    len_sen = len(line)
    for w in line:
        if w == " ":
            k_s += 1
            continue
        if w not in puncs and is_other(w):
            k_b += 1
    if len_sen - k_s == 0:
        return 1
    else:
        return k_b/(len_sen-k_s)


def judge_len(en, zh):
    len_en = len(en.split(" "))
    len_zh = len(zh)
    if len_en / len_zh > 0.1 and len_en / len_zh < 5:
        return True
    else:
        return False


def delete_useless(sentence):
	if sentence.count('@') < 9 and sentence.count('&') < 9 and sentence.count('#') < 9 and '""' not in sentence and '\'\'' not in sentence:
		return False
	else:
		return True


def find_specile_sentence(file_in, file_out_good, file_out_bad, file_punc):
    puncs = load_punc(file_punc)
    fr = open(file_in, 'r', encoding='utf8')
    fw_good = open(file_out_good, 'w', encoding='utf8')
    fw_bad = open(file_out_bad, 'w', encoding='utf8')
    begin_time = time()
    k = 0
    for line in fr:
        k += 1
        if k % 100000 == 0:
            print("line：{}，time{}".format(k, time() - begin_time))
        line = line.strip()
        line = line.split("|||||")
        en = line[0].strip()
        zh = line[1].strip()
        if zh == "" or en == "":
            continue

        if delete_useless(en) or delete_useless(zh):
            fw_bad.write(en + "|||||" + zh + "\n")
            continue

        rate_en = judge_special_symbol(en, puncs)
        rate_zh = judge_special_symbol(zh, puncs)
        if rate_en < 0.2 and rate_zh < 0.2 and judge_len(en, zh):
            fw_good.write(en + "|||||" + zh + "\n")
        else:
            fw_bad.write(en + "|||||" + zh + "\n")


if __name__ == '__main__':
    file_punc = "/home/data/fanyi_data/punc_zh_en.txt"

    root_dir = "/home/data/fanyi_data/all_data/"

    file_in = root_dir + "all_data_pro.txt"
    file_out_good = root_dir + "all_data_pro_good.txt"
    file_out_bad = root_dir + "all_data_pro_bad.txt"
    find_specile_sentence(file_in, file_out_good, file_out_bad, file_punc)
