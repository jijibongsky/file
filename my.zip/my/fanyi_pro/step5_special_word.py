import random
import re
from time import time


def select_chinese(a):
    return ("".join(re.findall(u'[\u4e00-\u9fa5]+', a)))


def sep_tihuan(sentence1, sentence2):
	index = [str(i) for i in list(range(20))]
	random.shuffle(index)
	temp = sentence1.split()
	flag = 0
	for i in range(len(temp)):
		if temp[i] in sentence2 and temp[i] not in ["."]:
			sentence1 = sentence1.replace(temp[i], '&SEP' + index[flag] + ';', 1)
			sentence2 = sentence2.replace(temp[i], '&SEP' + index[flag] + ';', 1)
			flag += 1
			flag = flag % 20
	return sentence1, sentence2, flag


def main(data_in_en, data_in_zh, data_out_en, data_out_zh):
	fr_en = open(data_in_en, "r", encoding="utf8")
	fr_zh = open(data_in_zh, "r", encoding="utf8")
	fw_en = open(data_out_en, "w", encoding="utf8")
	fw_zh = open(data_out_zh, "w", encoding="utf8")
	begin_time = time()
	k = 0
	kk = 0
	for en, zh in zip(fr_en, fr_zh):
		k += 1
		if k % 100000 == 0:
			print("step:{},time:{}".format(k, time()-begin_time))
		en = en.strip()
		zh = zh.strip()
		# print(en)
		# print(zh)
		fw_en.write(en + "\n")
		fw_zh.write(zh + "\n")

		new_en, new_zh, flag = sep_tihuan(en, zh)
		if flag:
			kk += 1
			# print("===")
			fw_en.write(new_en + "\n")
			fw_zh.write(new_zh + "\n")
	print("sep", kk)


def ceshi():
	a = 'i want to tell you i have 1232 dollars yuan ,do you want to 嫁给我 ？'
	b = '我 想 告诉 你 我 有 1232 美元 ， 你想 嫁给我 吗 ？'
	c, d, flag = sep_tihuan(a, b)
	print(c)
	print('********')
	print(d)


def email0():
	if re.match(r'[a-zA-z]+://[^\s]*', 'http://www.baidu.com'):
		print('right')
	else:
		print('wrong')


def email():
	text = "1581045885@qq.com"
	if re.match(r'^[0-9a-zA-Z_]{0,19}@[0-9a-zA-Z]{1,13}\.[com,cn,net]{1,3}$', text):
		print('Email address is Right!')
	else:
		print('Please reset your right Email address!')


def email1():
	email = "我有一个邮箱skk 12345678@qq.com 哈哈哈"
	# email = "12345678@qq.com"
	# regular = re.compile(r'[0-9a-zA-Z.]+@[0-9a-zA-Z.]+?com')
	regular = re.compile(r'^[0-9a-zA-Z_]{0,19}@[0-9a-zA-Z]{1,13}\.[com,cn,net]{1,3}$')
	a = re.findall(regular, email)
	print(a)


def email2():
	email = "我有一个邮箱skk 12345678@qq.com 哈哈哈"
	# email = "12345678@qq.com"
	a = re.findall(r'[0-9a-zA-Z.]+@[0-9a-zA-Z.]+?com', email)
	print(a)


if __name__ == '__main__':
	# ceshi()
	root_dir = "/home/data/fanyi_data/all_data/"
	data_in_en = root_dir + "en_pro_good_seg_quchong.txt"
	data_in_zh = root_dir + "zh_pro_good_seg_quchong.txt"
	data_out_en = root_dir + "en_pro_good_seg_quchong_tihuan.txt"
	data_out_zh = root_dir + "zh_pro_good_seg_quchong_tihuan.txt"
	main(data_in_en, data_in_zh, data_out_en, data_out_zh)
