import os


# 合并所有训练数据
def merge():
    def save_zh_en(data_file, fw_en, fw_zh):
        fr_en = open(os.path.join(data_file, "en.txt"), "r", encoding="utf8")
        fr_zh = open(os.path.join(data_file, "zh.txt"), "r", encoding="utf8")
        for en, zh in zip(fr_en, fr_zh):
            fw_en.write(en)
            fw_zh.write(zh)
        fr_en.close()
        fr_zh.close()

    root_dir = "/home/data/fanyi_data/"
    file_out_en = root_dir + "en.txt"
    file_out_zh = root_dir + "zh.txt"
    fw_en = open(file_out_en, "w", encoding="utf8")
    fw_zh = open(file_out_zh, "w", encoding="utf8")

    for child_file in ["ChallengerAI2017", "small_data", "tmx", "UM-Corpus", "UNv1.0.en-zh", "cwmt"]:
        data_file = os.path.join(root_dir, child_file)
        print(data_file)
        save_zh_en(data_file, fw_en, fw_zh)


def yanzheng():
    root_dir = "/home/data/fanyi_data/all_data/"
    file_out_en = root_dir + "en.txt"
    file_out_zh = root_dir + "zh.txt"

    # root_dir = "/home/data/fanyi_data/all_data_beifen/BPE/"
    # file_out_en = root_dir + "encode.txt"
    # file_out_zh = root_dir + "decode.txt"

    fw_en = open(file_out_en, "r", encoding="utf8")
    fw_zh = open(file_out_zh, "r", encoding="utf8")
    k = 0
    for en, zh in zip(fw_en, fw_zh):
        k += 1
        if k % 1000000 == 0:
            print(en + zh)

    print(k)


if __name__ == '__main__':
    # merge()
    yanzheng()
