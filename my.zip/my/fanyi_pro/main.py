#coding:utf-8

import codecs
import re
import random


pun = '!()-+=-\';:"/.,<>?！，。、？；：“”‘’】【、\{\}'


def select_chinese(a):
	return ("".join(re.findall(u'[\u4e00-\u9fa5]+', a)))


def read_punc_list(file_word, file_punc):
	fr_word = open(file_word, 'r', encoding='utf-8')
	fr_pucn = open(file_punc, 'r', encoding='utf-8')
	punc_src, punc_tgt, word_src, word_tgt = [], [], [], []
	for line in fr_word:
		line = line.strip().split('|')
		word_src.append(line[0])
		word_tgt.append(line[1])
	for line in fr_pucn:
		line = line.strip().split('|')
		punc_src.append(line[0].strip())
		punc_tgt.append(line[1].strip())
	return punc_src, punc_tgt, word_src, word_tgt


def html_punc_change(sen):
	sen = sen.replace('&apos;', '\'')
	sen = sen.replace("@-@", "-")
	sen = sen.replace("\xa0", " ")   # \xa0 是不间断的空格
	sen = sen.replace("&nbsp;", " ")   # 不断行的空白
	sen = sen.replace("&#160;", " ")  # 空格
	sen = sen.replace("&#39;", "'")    # 引文单引号
	sen = sen.replace("&quot;", '"')   # 英文双引号
	sen = sen.replace("&rsquo;", '’')   # 中文引号
	sen = sen.replace("&#45;", '-')      # 减号
	sen = sen.replace("&#124;", "|")  # 竖线
	sen = sen.replace("&lt;", "<")   # 小于号
	sen = sen.replace("&gt;", ">")  # 大于号
	sen = sen.replace("&amp;", "&")
	sen = sen.replace("`", "'")
	return sen


def strQ2B(a):
	rstring = ""
	for uchar in a:
		inside_code = ord(uchar)
		if inside_code == 12288:
			inside_code = 32
		elif (inside_code >= 65281 and inside_code <= 65374):
			inside_code -= 65248
		rstring += chr(inside_code)
	return rstring


def Punctuation_normalization(sentence, punc_src, punc_tgt):
	for i in range(len(punc_src)):
		if punc_src[i] in sentence:
			sentence = sentence.replace(punc_src[i], punc_tgt[i])
	return sentence


def word_normalization(sentence, word_src, word_tgt):
	for i in range(len(word_src)):
		if word_src[i] in sentence:
			sentence = sentence.replace(word_src[i], word_tgt[i])
	return sentence


def judge_punc_pair(sen):
	punc_pair = ["[]", "{}", "()", "【】", "《》", "（）", "‘’", "“”"]
	puncs = ['"']   #  "'"  有可能是 She's
	for pair in punc_pair:
		if sen.count(pair[0]) != sen.count(pair[1]):
			sen = sen.replace(pair[0], "")
			sen = sen.replace(pair[1], "")
	for punc in puncs:
		if sen.count(punc) % 2 != 0:
			sen = sen.replace(punc, "")
	return sen


def change_first_wrong_punc(aa, bb):
	pp = '!@#&*:;,./'
	if (aa[0] in pp) and (bb[0] in pp) and (aa[0] != bb[0]):
		aa = aa.replace(aa[0], '', 1)
		bb = bb.replace(bb[0], '', 1)
	return aa.strip(), bb.strip()


def delete_useless(sentence):
	if sentence.count('@') < 9 and sentence.count('&') < 9 and sentence.count('#') < 9 and '""' not in sentence and '\'\'' not in sentence:
		return False
	else:
		return True


# 还没用
def delete_single_and_change_juhao(A):
	def change_the_last_punc(a):
		if a[-1] == '.':
			a = a.replace(a[-1], '。')
		return a

	result = []
	for i in range(len(A)):
		a = A[i].split('|||||')[1].strip()
		b = A[i].split('|||||')[0].strip()
		b = change_the_last_punc(b)
		if a.count('"') % 2 != 0:
			a = a.replace('"', '')
		result.append(b.strip() + '|||||' + a.strip())
	return result


# 还没用
def zh_punc_to_en(a):
	a = a.replace('。', '.')
	a = a.replace('，', ',')
	a = a.replace('；', ';')
	a = a.replace('：', ':')
	a = a.replace('【', '[')
	a = a.replace('】', ']')
	a = a.replace('《', '<')
	a = a.replace('》', '>')
	a = a.replace('！', '!')
	a = a.replace('？', '?')
	return a


# 暂时没用
def sep_tihuan(sentence1, sentence2):
	index = [str(i) for i in list(range(20))]
	random.shuffle(index)
	temp = sentence1.split()
	flag = 0
	for i in range(len(temp)):
		if temp[i] in sentence2:
			sentence1 = sentence1.replace(temp[i], '&SEP' + index[flag] + ';', 1)
			sentence2 = sentence2.replace(temp[i], '&SEP' + index[flag] + ';', 1)
			flag += 1
			flag = flag % 20
	return sentence1, sentence2


def ceshi():
	a = 'i want to tell you i have 1232 dollars yuan ,do you want to 嫁给我 ？'
	b = '我 想 告诉 你 我 有 1232 美元 ， 你想 嫁给我 吗 ？'
	c, d = sep_tihuan(a, b)
	print(c)
	print('********')
	print(d)


def file_handle(file_input_en, file_input_zh, file_output, file_word, file_punc):
	punc_src, punc_tgt, word_src, word_tgt = read_punc_list(file_word, file_punc)
	fr_en = open(file_input_en, 'r', encoding='utf8')
	fr_zh = open(file_input_zh, 'r', encoding='utf8')
	data_out = open(file_output, 'w', encoding='utf8')

	k = 0
	for en, zh in zip(fr_en, fr_zh):
		k += 1
		en = en.strip()
		zh = zh.strip()
		if en == "" or zh == "":
			continue
		en = strQ2B(en)
		zh = strQ2B(zh)
		en = html_punc_change(en)
		zh = html_punc_change(zh)

		en = Punctuation_normalization(en, punc_src, punc_tgt)
		zh = Punctuation_normalization(zh, punc_src, punc_tgt)
		zh = word_normalization(zh, word_src, word_tgt)
		en = judge_punc_pair(en)
		zh = judge_punc_pair(zh)
		en, zh = change_first_wrong_punc(en, zh)
		if delete_useless(en) or delete_useless(zh):
			continue

		data_out.write(zh + "|||||" + en + '\n')
	print('done')


if __name__ == '__main__':
	file_word = 'data/word_same.txt'
	file_punc = 'data/punc_same.txt'

	# punc_src, punc_tgt, word_src, word_tgt = read_punc_list(file_word, file_punc)
	# for i, j in zip(word_src, word_tgt):
	# 	print(i, j)
	root_dir = "/home/data/fanyi_data/"
	file_input_en = root_dir + 'test_en.txt'
	file_input_zh = root_dir + 'test_zh.txt'
	file_output = root_dir + 'all_data.txt'
	file_handle(file_input_en,file_input_zh, file_output, file_word, file_punc)
