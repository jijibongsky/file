# coding=utf-8
# Copyright 2019/8/14 17:03 by ZTE
# Author: Kangkang Sun

root_dir = "/home/data/fanyi_data/all_data/"
data_dir = root_dir + "zh_pro_good_seg_quchong_tihuan.txt"  # 43082794
# data_dir = root_dir + "all_data_pro_bad.txt"
# data_dir = root_dir + "all_data_pro_good.txt"
fr = open(data_dir, "r", encoding="utf8")

# 33891518

k = 0
for line in fr:
    k += 1
    if k % 1000000 == 0:
        print(line)
print(k)
