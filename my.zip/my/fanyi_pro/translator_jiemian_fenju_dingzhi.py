#!/usr/bin/env python
# coding=utf-8
# Copyright 2017-2019 The THUMT Authors


from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import operator
import argparse
import itertools
import os
import six
import numpy as np
import tensorflow as tf
import jieba
import codecs
import re
import sys
root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../"))
root_dir1 = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../"))
sys.path.append(root_dir)
print("root_dir", root_dir)


import thumt.data.dataset as dataset
import thumt.data.vocab as vocabulary
import thumt.models as models
import thumt.utils.inference as inference
import thumt.utils.parallel as parallel
import thumt.utils.sampling as sampling
from thumt.utils.apply_bpe import bpe_Interface


# os.environ["CUDA_VISIBLE_DEVICES"] = "0"


def jieba_fenci(content):
    seg_list = jieba.cut(content)
    corpus = ""
    for word in seg_list:
        corpus += word + " "
    return corpus[:-1]


def create_bpe_parser(root_dir):
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="learn BPE-based word segmentation")

    parser.add_argument(
        '--codes', '-c', type=argparse.FileType('r'), metavar='PATH',default=os.path.join(root_dir1,"bpe32768"),
        help="File with BPE codes (created by learn_bpe.py).")
    parser.add_argument(
        '--vocabulary', type=argparse.FileType('r'), default=os.path.join(root_dir1, "vocab.en"),
        metavar="PATH",
        help="Vocabulary file (built with get_vocab.py). If provided, this script reverts any merge operations that produce an OOV.")
    parser.add_argument(
        '--merges', '-m', type=int, default=-1,
        metavar='INT',
        help="Use this many BPE operations (<= number of learned symbols)"+
             "default: Apply all the learned merge operations")
    parser.add_argument(
        '--separator', '-s', type=str, default='@@', metavar='STR',
        help="Separator between non-final subword units (default: '%(default)s'))")
    parser.add_argument(
        '--vocabulary-threshold', type=int, default=50,
        metavar="INT",
        help="Vocabulary threshold. If vocabulary is provided, any word with frequency < threshold will be treated as OOV")
    parser.add_argument(
        '--glossaries', type=str, nargs='+', default=None,
        metavar="STR",
        help="Glossaries. Words matching any of the words/regex provided in glossaries will not be affected "+
             "by the BPE (i.e. they will neither be broken into subwords, nor concatenated with other subwords. "+
             "Can be provided as a list of words/regex after the --glossaries argument. Enclose each regex in quotes.")
    return parser.parse_args()


def parse_args():
    parser = argparse.ArgumentParser(
        description="Translate using existing NMT models",
        usage="translator.py [<args>] [-h | --help]"
    )

    # input files
    parser.add_argument("--input", type=str, required=True,
                        help="Path of input file")
    parser.add_argument("--output", type=str, required=True,
                        help="Path of output file")
    parser.add_argument("--checkpoints", type=str, nargs="+", required=True,
                        help="Path of trained models")
    parser.add_argument("--vocabulary", type=str, nargs=2, required=True,
                        help="Path of source and target vocabulary")

    # model and configuration
    parser.add_argument("--models", type=str, required=True, nargs="+",
                        help="Name of the model")
    parser.add_argument("--parameters", type=str,
                        help="Additional hyper parameters")
    parser.add_argument("--verbose", action="store_true",
                        help="Enable verbose output")

    return parser.parse_args()


def parse_args_transformer():
    parser = argparse.ArgumentParser(
        description="Translate using existing NMT models",
        usage="translator.py [<args>] [-h | --help]"
    )
    parser.add_argument("--checkpoints", type=str, nargs="+", default=[os.path.join(root_dir1, "../machine_translation/train_thu/eval/average1")],
                        help="Path of trained models")
    parser.add_argument("--vocabulary", type=str, nargs=2,
                        default=[os.path.join(root_dir1, "demo/", "vocab.shared32768.txt.bak"),
                                 os.path.join(root_dir1, "demo/", "vocab.shared32768.txt.bak")],
                        help="Path of source and target vocabulary")
    # model and configuration
    parser.add_argument("--models", type=str, nargs="+", default=["transformer"],
                        help="Name of the model")
    parser.add_argument("--parameters", type=str,
                        help="Additional hyper parameters")
    parser.add_argument("--verbose", action="store_true", # default=1,
                        help="Enable verbose output")
    return parser.parse_args()



def parse_args_rnnsearch():
    parser = argparse.ArgumentParser(
        description="Translate using existing NMT models",
        usage="translator.py [<args>] [-h | --help]"
    )
    parser.add_argument("--checkpoints", type=str, nargs="+", default=[os.path.join(root_dir, "train_rnnsearch/eval")],
                        help="Path of trained models")
    parser.add_argument("--vocabulary", type=str, nargs=2,
                        default=[os.path.join(root_dir1, "demo/", "vocab.shared32768.txt.bak"),
                                 os.path.join(root_dir1, "demo/", "vocab.shared32768.txt.bak")],
                        help="Path of source and target vocabulary")
    # model and configuration
    parser.add_argument("--models", type=str, nargs="+", default=["rnnsearch"],
                        help="Name of the model")
    parser.add_argument("--parameters", type=str,
                        help="Additional hyper parameters")
    parser.add_argument("--verbose", action="store_true", # default=1,
                        help="Enable verbose output")
    return parser.parse_args()


def parse_args_transformer_punc():
    parser = argparse.ArgumentParser(
        description="Translate using existing NMT models",
        usage="translator.py [<args>] [-h | --help]"
    )
    data_folder = "data_folder_punc"
    parser.add_argument("--checkpoints", type=str, nargs="+", default=[os.path.join(root_dir1, "zengliang2")],
                        help="Path of trained models")
    parser.add_argument("--vocabulary", type=str, nargs=2,
                        default=[os.path.join(root_dir1, "", "vocab.shared32768.txt"),
                                 os.path.join(root_dir1, "", "vocab.shared32768.txt")],
                        help="Path of source and target vocabulary")
    # model and configuration
    parser.add_argument("--models", type=str, nargs="+", default=["transformer"],
                        help="Name of the model")
    parser.add_argument("--parameters", type=str,
                        help="Additional hyper parameters")
    parser.add_argument("--verbose", action="store_true", # default=1,
                        help="Enable verbose output")
    return parser.parse_args()


def parse_args_rnnsearch_punc():
    parser = argparse.ArgumentParser(
        description="Translate using existing NMT models",
        usage="translator.py [<args>] [-h | --help]"
    )
    data_folder = "data_folder_punc"
    parser.add_argument("--checkpoints", type=str, nargs="+", default=[os.path.join(root_dir1, "train_rnnsearch_punc/eval")],
                        help="Path of trained models")
    parser.add_argument("--vocabulary", type=str, nargs=2,
                        default=[os.path.join(root_dir1, "", "vocab.shared32768.txt"),
                                 os.path.join(root_dir1, "", "vocab.shared32768.txt")],
                        help="Path of source and target vocabulary")
    # model and configuration
    parser.add_argument("--models", type=str, nargs="+", default=["rnnsearch"],
                        help="Name of the model")
    parser.add_argument("--parameters", type=str,
                        help="Additional hyper parameters")
    parser.add_argument("--verbose", action="store_true", # default=1,
                        help="Enable verbose output")
    return parser.parse_args()


def default_parameters():
    params = tf.contrib.training.HParams(
        input=None,
        output=None,
        vocabulary=None,
        # vocabulary specific
        pad="<pad>",
        bos="<bos>",
        eos="<eos>",
        unk="<unk>",
        mapping=None,
        append_eos=False,
        device_list=[0],
        num_threads=1,
        # decoding
        top_beams=1,
        beam_size=4,
        decode_alpha=0.6,
        decode_length=50,
        decode_batch_size=None,
        # sampling
        generate_samples=False,
        num_samples=1,
        min_length_ratio=0.0,
        max_length_ratio=1.5,
        min_sample_length=0,
        max_sample_length=0,
        sample_batch_size=32
    )

    return params


def merge_parameters(params1, params2):
    params = tf.contrib.training.HParams()

    for (k, v) in six.iteritems(params1.values()):
        params.add_hparam(k, v)

    params_dict = params.values()

    for (k, v) in six.iteritems(params2.values()):
        if k in params_dict:
            # Override
            setattr(params, k, v)
        else:
            params.add_hparam(k, v)

    return params


def import_params(model_dir, model_name, params):
    if model_name.startswith("experimental_"):
        model_name = model_name[13:]

    model_dir = os.path.abspath(model_dir)
    m_name = os.path.join(model_dir, model_name + ".json")

    if not tf.gfile.Exists(m_name):
        return params

    with tf.gfile.Open(m_name) as fd:
        tf.logging.info("Restoring model parameters from %s" % m_name)
        json_str = fd.readline()
        params.parse_json(json_str)

    return params


def override_parameters(params, args):
    if args.parameters:
        params.parse(args.parameters)

    params.vocabulary = {
        "source": vocabulary.load_vocabulary(args.vocabulary[0]),
        "target": vocabulary.load_vocabulary(args.vocabulary[1])
    }
    params.vocabulary["source"] = vocabulary.process_vocabulary(
        params.vocabulary["source"], params
    )
    params.vocabulary["target"] = vocabulary.process_vocabulary(
        params.vocabulary["target"], params
    )

    control_symbols = [params.pad, params.bos, params.eos, params.unk]

    params.mapping = {
        "source": vocabulary.get_control_mapping(
            params.vocabulary["source"],
            control_symbols
        ),
        "target": vocabulary.get_control_mapping(
            params.vocabulary["target"],
            control_symbols
        )
    }

    return params


def session_config(params):
    optimizer_options = tf.OptimizerOptions(opt_level=tf.OptimizerOptions.L1,
                                            do_function_inlining=False)
    graph_options = tf.GraphOptions(optimizer_options=optimizer_options)
    config = tf.ConfigProto(allow_soft_placement=True,
                            graph_options=graph_options)
    if params.device_list:
        device_str = ",".join([str(i) for i in params.device_list])
        config.gpu_options.visible_device_list = device_str

    return config


def set_variables(var_list, value_dict, prefix, feed_dict):
    ops = []
    for var in var_list:
        for name in value_dict:
            var_name = "/".join([prefix] + list(name.split("/")[1:]))

            if var.name[:-2] == var_name:
                tf.logging.debug("restoring %s -> %s" % (name, var.name))
                placeholder = tf.placeholder(tf.float32,
                                             name="placeholder/" + var_name)
                with tf.device("/cpu:0"):
                    op = tf.assign(var, placeholder)
                    ops.append(op)
                feed_dict[placeholder] = value_dict[name]
                break

    return ops


def shard_features(features, placeholders, predictions):
    num_shards = len(placeholders)
    feed_dict = {}
    n = 0

    for name in features:
        feat = features[name]
        batch = feat.shape[0]
        shard_size = (batch + num_shards - 1) // num_shards

        for i in range(num_shards):
            shard_feat = feat[i * shard_size:(i + 1) * shard_size]

            if shard_feat.shape[0] != 0:
                feed_dict[placeholders[i][name]] = shard_feat
                n = i + 1
            else:
                break

    if isinstance(predictions, (list, tuple)):
        predictions = [item[:n] for item in predictions]

    return predictions, feed_dict


def sort_input(inputs, reverse=True):
    input_lens = [
        (i, len(line.strip().split())) for i, line in enumerate(inputs)
    ]
    sorted_input_lens = sorted(input_lens, key=operator.itemgetter(1),
                               reverse=reverse)
    sorted_keys = {}
    sorted_inputs = []

    for i, (index, _) in enumerate(sorted_input_lens):
        sorted_inputs.append(inputs[index])
        sorted_keys[index] = i

    return sorted_keys, sorted_inputs


def load_model(args):
    tf.logging.set_verbosity(tf.logging.INFO)
    # Load configs
    model_cls_list = [models.get_model(model) for model in args.models]
    params_list = [default_parameters() for _ in range(len(model_cls_list))]
    params_list = [
        merge_parameters(params, model_cls.get_parameters())
        for params, model_cls in zip(params_list, model_cls_list)
    ]
    params_list = [
        import_params(args.checkpoints[i], args.models[i], params_list[i])
        for i in range(len(args.checkpoints))
    ]
    params_list = [
        override_parameters(params_list[i], args)
        for i in range(len(model_cls_list))
    ]

    # Build Graph
    with tf.Graph().as_default():
        model_var_lists = []
        # Load checkpoints
        for i, checkpoint in enumerate(args.checkpoints):
            tf.logging.info("Loading %s" % checkpoint)
            var_list = tf.train.list_variables(checkpoint)
            values = {}
            reader = tf.train.load_checkpoint(checkpoint)
            for (name, shape) in var_list:
                if not name.startswith(model_cls_list[i].get_name()):
                    continue
                if name.find("losses_avg") >= 0:
                    continue
                tensor = reader.get_tensor(name)
                values[name] = tensor
            model_var_lists.append(values)

        # Build models
        model_list = []
        for i in range(len(args.checkpoints)):
            name = model_cls_list[i].get_name()
            model = model_cls_list[i](params_list[i], name + "_%d" % i)
            model_list.append(model)

        params = params_list[0]



        # Create placeholders
        placeholders = []

        for i in range(len(params.device_list)):
            placeholders.append({
                "source": tf.placeholder(tf.int32, [None, None],
                                         "source_%d" % i),
                "source_length": tf.placeholder(tf.int32, [None],
                                                "source_length_%d" % i)
            })

        # A list of outputs
        if params.generate_samples:
            inference_fn = sampling.create_sampling_graph
        else:
            inference_fn = inference.create_inference_graph

        predictions = parallel.data_parallelism(
            params.device_list, lambda f: inference_fn(model_list, f, params),
            placeholders)

        # Create assign ops
        assign_ops = []
        feed_dict = {}

        all_var_list = tf.trainable_variables()
        for i in range(len(args.checkpoints)):
            un_init_var_list = []
            name = model_cls_list[i].get_name()
            for v in all_var_list:
                if v.name.startswith(name + "_%d" % i):
                    un_init_var_list.append(v)
            ops = set_variables(un_init_var_list, model_var_lists[i],
                                name + "_%d" % i, feed_dict)
            assign_ops.extend(ops)
        assign_op = tf.group(*assign_ops)
        init_op = tf.tables_initializer()
        results = []

        tf.get_default_graph().finalize()

        # Create session
        sess = tf.Session(config=session_config(params))
        # Restore variables
        sess.run(assign_op, feed_dict=feed_dict)
        sess.run(init_op)
    source_word2id = {}
    for i in range(len(params.vocabulary["source"])):
        source_word2id[params.vocabulary["source"][i]] = i
        # print(params.vocabulary["source"][i], i)
    return sess, placeholders, predictions, params, args, source_word2id


def main(sess, placeholders, predictions, params, args, inputs, source_word2id, pad_length):
    sorted_keys, sorted_inputs = sort_input(inputs)
    sorted_inputs = [sorted_input.split(" ") for sorted_input in sorted_inputs]
    source_length = [len(sorted_input) for sorted_input in sorted_inputs]
    feats = my_look_up_tabel(params, source_word2id, sorted_inputs, source_length, pad_length)
    op, feed_dict = shard_features(feats, placeholders, predictions)
    results = []
    results.append(sess.run(op, feed_dict=feed_dict))
    message = "Finished batch %d" % len(results)
    # tf.logging.log(tf.logging.INFO, message)

    # Convert to plain text
    vocab = params.vocabulary["target"]
    outputs = []
    scores = []

    for result in results:
        for item in result[0]:
            outputs.append(item.tolist())
        for item in result[1]:
            scores.append(item.tolist())

    outputs = list(itertools.chain(*outputs))
    scores = list(itertools.chain(*scores))

    restored_inputs = []
    restored_outputs = []
    restored_scores = []

    for index in range(len(sorted_inputs)):
        restored_inputs.append(sorted_inputs[sorted_keys[index]])
        restored_outputs.append(outputs[sorted_keys[index]])
        restored_scores.append(scores[sorted_keys[index]])
    trans = []
    count = 0
    for outputs, scores in zip(restored_outputs, restored_scores):
        decodeds = ""
        for output, score in zip(outputs, scores):
            decoded = []
            for idx in output:
                if idx == params.mapping["target"][params.eos]:
                    break
                decoded.append(vocab[idx])
            decoded = " ".join(decoded)
            if not args.verbose:
                decodeds = decodeds + decoded + "||"
            else:
                pattern = "%d ||| %s ||| %s ||| %f"
                source = restored_inputs[count]
                values = (count, source, decoded, score)
                trans.append(pattern % values)

        if not args.verbose:
            trans.append(decodeds[:-2])
        count += 1
    # print("trans:", trans)
    return trans


def my_look_up_tabel(params, source_word2id, sorted_inputs, source_length, pad_length):
    ids = []
    if len(source_length) >0:
        max_len = source_length[0]
    else:
        max_len = 1
    for sentence in sorted_inputs:
        inputs = sentence
        id = []
        for word in inputs:
            if word == " ":
                pass
            elif word in source_word2id:
                id.append(source_word2id[word])
            else:
                id.append(source_word2id[params.unk])
        id.append(source_word2id[params.eos])
        for i in range(max_len + pad_length - len(inputs)):
            id.append(source_word2id[params.pad])
        ids.append(id)
    feats = {}
    feats["source"] = np.array(ids)
    feats["source_length"] = np.array(source_length) + 1 + pad_length
    return feats


# def count_first_A(a):
#     k = 0
#     alpha = 'QWERTYUIOPLKJHGFDSAZXCVBNM'
#     w = a.strip().split()
#     for cnt in w:
#         if cnt[0] in alpha:
#             k+=1
#     p = k*1.0/len(w)
#     return p

# def countdian(a):
#     c = 0
#     for i in a:
#         if i == '.':
#             c+=1
#     return c
def one_sentence_input(sess, placeholders, predictions, params, args, source_word2id, bpe, pad_length):
    dic_en = codecs.open('dict_enen.txt', 'r', 'utf-8-sig').readlines()
    dic_zh = codecs.open('dict_zhzh.txt', 'r', 'utf-8-sig').readlines()
    look_up_dict = {}
    for i in range(len(dic_en)):
        look_up_dict[dic_en[i].strip()] = dic_zh[i].strip()
    while True:
        inputs = input("请输入：")
        if inputs == '' or inputs == 'exit':
            break
        inputs = inputs.strip()
        if (len(inputs.split())) == 1 and inputs.lower() in look_up_dict:
            out_put = look_up_dict[inputs]
        else:
            inputs_, before, result_ = file_handle(inputs)
            inputs_temp = inputs_.split()
            for i in range(len(inputs_temp)):
                if len(inputs_temp[i])>3 and ('&SEP' not in inputs_temp[i]) and ('\'s' not in inputs_temp[i]):
                    inputs_temp[i] = inputs_temp[i].lower()
            inputs = ' '.join(inputs_temp)
            inputs = inputs.strip()
            # print('www', inputs)
            inputs = bpe.process_line(inputs)
            # print("inputs", inputs)
            if '.' in inputs and inputs[-1] == '.':
                temp = inputs.split('.')
                inputs = [(temp_cnt+'.') for temp_cnt in temp[0:-1]]
                nnote = len(inputs)
            else:
                temp = inputs.split('.')
                inputs = [(temp_cnt+'.') for temp_cnt in temp[0:-1]]
                inputs.append(temp[-1])
                nnote = len(inputs)
            trans = main(sess, placeholders, predictions, params, args, inputs, source_word2id, pad_length=2)
            trans = [tran.replace("@@ ", "").replace(" ", "") for tran in trans]
            temp = ' '.join(trans)
            if len(result_):
                for j in range(len(result_)):
                    temp = temp.replace(result_[j], before[j])
            temp = temp.replace(';','；')
            # print("outputs：", temp)


def count_A(a):
    k = 0
    alpha = 'QWERTYUIOPLKJHGFDSAZXCVBNM'
    for cnt in a:
        if cnt in alpha:
            k+=1
    return k

def IsNumber(a):
    aaa = ['1','2','3','4','5','6','7','8','9','0','.',',']
    if a == '.' or a == ',':
        return False
    for num in a:
        if num not in aaa:
            return False
    return True

def al2num(a, b):
    p = {'hundred': 100., 'thousand': 1000. , 'million': 1000000., 'billion': 1000000000.}
    try:
        qq = float(a)
    except:
        a = a.replace(",", "")
        qq = float(a)
    try:
        ww = p[b]
    except:
        ww = p[b.lower()]

    res = qq*ww
    if res<10000:
        return str(res)
    if res<100000000:
        w = res/10000
        c = str(w)+'万'
        return c
    else:
        w = res/100000000
        c = str(w)+'亿'
        return c

def file_handle(a):
    p = {'hundred': 100., 'thousand': 1000. , 'million': 1000000., 'billion': 1000000000.,'Hundred': 100., 'Thousand': 1000. , 'Million': 1000000., 'Billion': 1000000000.}
    b = a.strip()
    c = b.split()
    after_num = []  # 替换后的 &SEP1;
    before_num = []  # 替换后的具体数字
    before = []   # 中文
    result_ = []   # 替换后的&SEP1
    num = 1
    num1 = 8
    for i in range(len(c)-1):
        if IsNumber(c[i]) and (c[i+1] in p):
            a = a.replace(c[i]+' '+c[i+1], '&SEP'+str(num1)+';')
            after_num.append('&SEP'+str(num1)+';')
            # print("====", c[i], c[i+1])
            numb = al2num(c[i], c[i+1])
            # print('*****数字处理的部分:',numb)
            before_num.append(numb)
            num1 = num1-1
    b = a.strip()
    c = b.split()

    for i in range(len(c)):
        if len("".join(re.findall(u'[\u4e00-\u9fa5]+', c[i])))>0:
            # print('有汉字')
            before.append(c[i])
            c[i] = '&SEP'+str(num)+';'
            result_.append(c[i])
            num+=1
    result = ' '.join(c)
    # print('待翻译的句子', result)

    return result, before, result_, after_num, before_num

def change_punc_input(a):
    b = a.strip()
    b = b.replace('”','"')
    b = b.replace('“','"')
    b = b.replace('’','\'')
    b = b.replace('‘','\'')
    b = b.replace('。','.')
    b = b.replace('，',',')
    b = b.replace('（','(')
    b = b.replace('）',')')
    b = b.replace('？','?')
    b = b.replace('！','!')
    b = b.replace('【','[')
    b = b.replace('】',']')
    b = b.replace('：',':')
    return b

def change_punc(a):
    b = a.strip()
    if b != '' and len(b)>3:
        if b[-1] == '.' and b[-2] != '.':
            b = b[0:-1]
            b = b+'。'
    b = b.replace(',','，')
    b = b.replace('(','（')
    b = b.replace(')','）')
    b = b.replace('?','？')
    b = b.replace('!','！')
    b = b.replace('[','【')
    b = b.replace(']','】')
    b = b.replace('"','“')
    b = b.replace(':','：')
    b = b.replace('\'','‘')
    return b

def aboutdian(a):
    qq = '.,;?!'
    if len(a)>2:
        if a[-1] in qq and a[-2] not in qq:
            a = a[0:-1]+' '+a[-1]
        a = a.split()
        result = []
        for cnt in a:
            if cnt[-1] in qq:
                cnt = cnt[0:-1]+' '+cnt[-1]
            result.append(cnt)
        a = ' '.join(result)
        return a
    else:
        return a

def shuzizailibu(a):
    q = '1234567890,./;:"[]()~!@#$%^&*'
    for cnt in a:
        if cnt in q:
            return True
    return False

def one_sentence_input1(inputs, sess, placeholders, predictions, params, args, source_word2id, bpe, look_up_dict,pad_length):

    wwwww = len(inputs)
    all_len = len(inputs)
    translate_need = []
    translate_need_label = []
    no_translate = []
    no_translate_label = []
    eee = []
    for i in range(len(inputs)):
        eee.append(inputs[i])
    for q in range(len(eee)):
        teom = eee[q]
        if len(teom.split()) == 1:
            inputs = teom
            if len("".join(re.findall(u'[\u4e00-\u9fa5]+', inputs)))>0:
                no_translate.append(inputs)
                no_translate_label.append(q)
            else:
                if inputs.lower() in look_up_dict:
                    inputs = inputs.lower()
                    out_put = look_up_dict[inputs]
                    no_translate.append(out_put)
                    no_translate_label.append(q)
                else:
                    if shuzizailibu(inputs):
                        no_translate.append(inputs)
                        no_translate_label.append(q)
                    else:
                        translate_need.append(inputs)
                        translate_need_label.append(q)
        else:   
            translate_need.append(teom)
            translate_need_label.append(q)
    inputs = translate_need
    inputs_1 = []
    for cnt in inputs:
        if (count_A(cnt)*1.0)>(0.5*len(cnt)):
            cnt1 = cnt.lower()
            inputs_1.append(cnt1)
        else:
            inputs_1.append(cnt)
    #inputs = [inputs_cnt.lower() for inputs_cnt in inputs if (count_A(inputs)*1.0)>(0.5*len(inputs)) else inputs_cnt for inputs_cnt in inputs]
    inputs = [change_punc_input(inputs_cnt) for inputs_cnt in inputs_1]
    inputs = [aboutdian(inputs_cnt) for inputs_cnt in inputs]
    inputs_temp = []
    before_temp = []
    result_temp = []
    after_num_temp = []
    before_num_temp = []
    for inputs_cnt in inputs:
        if '\'' in inputs_cnt:
            temp_input = inputs_cnt.strip().split()
            for i in range(len(temp_input)):
                if '\'' in temp_input[i]:
                    temp_input[i] = temp_input[i].split('\'')[0] + ' ' + '\''+temp_input[i].split('\'')[1]
            inputs_cnt = ' '.join(temp_input)

        inputs_, before, result_, after_num, before_num = file_handle(inputs_cnt)
        # print('特殊字符替换后')
        inputs_temp.append(inputs_)
        before_temp.append(before)
        result_temp.append(result_)
        after_num_temp.append(after_num)
        before_num_temp.append(before_num)
    # print('bpe之前:',inputs_temp)
    inputs_temp = [bpe.process_line(inputs_temp_cnt) for inputs_temp_cnt in inputs_temp]
    flag = []
    input_final = []
    for inputs_cnt in inputs_temp:
        temp = inputs_cnt.split(' . ')
        inputs = [(temp_cnt.strip()+' . ') for temp_cnt in temp[0:-1]]
        inputs.append(temp[-1])
        flag.append(len(inputs))
        input_final.extend(inputs)
    inputs = input_final
    # print('进去之前:',inputs)
    trans = main(sess, placeholders, predictions, params, args, inputs, source_word2id, pad_length=2)
    trans = [tran.replace("@@ ", "").replace(" ", "") for tran in trans]
    trans = [change_punc(tran.strip()) for tran in trans]

    clock = 0
    out_result = []
    final_out = []
    for i in range(len(flag)):
        temp = []
        for j in range(clock,clock+flag[i]):
            temp.append(trans[j])
        clock+=flag[i]
        out_result.append(''.join(temp))
    for i in range(len(out_result)):
        temp1 = out_result[i]
        after_num = after_num_temp[i]
        before_num = before_num_temp[i]
        result_ = result_temp[i]
        before = before_temp[i]
        # print('before',before)
        if len(after_num):
            for j in range(len(after_num)):
                temp1 = temp1.replace(after_num[j], before_num[j])
        if len(result_):
            for j in range(len(result_)):
                temp1 = temp1.replace(result_[j], before[j])
        if '&SEP' in temp1:
            for j in range(len(result_)):
                temp1 = temp1.replace(result_[j], before[j])
        if '&SEP' in temp1:
            for j in range(len(result_)):
                temp1 = temp1.replace(result_[j], before[j])
        if '&SEP' in temp1:
            temp1 = temp1.replace('&SEP1;', '')
            temp1 = temp1.replace('&SEP2;', '')
            temp1 = temp1.replace('&SEP3;', '')
            temp1 = temp1.replace('&SEP4;', '')
            temp1 = temp1.replace('&SEP5;', '')
            temp1 = temp1.replace('&SEP6;', '')
            temp1 = temp1.replace('&SEP', '')
        temp1 = temp1.replace(';','；')
        temp1 = temp1.replace(',','，')
        if temp1 != '':
            if temp1[-1] == '.':
                temp1 = temp1[0:-1]+'。'
        final_out.append(temp1) 
        final_out_temp = []
        for cnt in final_out:
            ddaisy = cnt.strip()
            if ddaisy[-5:] == '<unk>':
                ddaisy = ddaisy[:-5] + '。'
            ddaisy = ddaisy.replace('<unk>','，')
            final_out_temp.append(ddaisy)
    final_out_temp1 = []
    if len(translate_need)>0:
        awq = no_translate + final_out_temp
    else:
        awq = no_translate
    bwq = no_translate_label + translate_need_label
    for i in range(all_len):
        for j in range(len(bwq)):
            if bwq[j] == i:
                final_out_temp1.append(awq[j])
    return final_out_temp1


class rest():
    def __init__(self, bpe_params, model_params):
        self.bpe, self.sess, self.placeholders, self.predictions, self.params, self.args, self.source_word2id = \
            self.one_sentence_rest_Initialization(bpe_params, model_params)

    def one_sentence_rest_Initialization(self, bpe_params, model_params):
        bpe = bpe_Interface(bpe_params)  # create_bpe_parser(root_dir)
        # dir_userdict = os.path.join(root_dir, "data_folder/userdict/userdict.txt")
        # jieba.load_userdict(dir_userdict)
        sess, placeholders, predictions, params, args, source_word2id = load_model(model_params)  # parse_args(root_dir)
        return bpe, sess, placeholders, predictions, params, args, source_word2id

    def one_sentence_rest_interface(self, inputs):
        inputs = [jieba_fenci(input) for input in inputs]
        inputs = [self.bpe.process_line(input) for input in inputs]
        decoded = main(self.sess, self.placeholders, self.predictions, self.params, self.args, inputs, self.source_word2id, pad_length=2)
        decoded = [one.replace("@@ ", "").replace(" ", "") for one in decoded]
        return decoded


if __name__ == "__main__":
    model = "transformer"
    if model == "rnnsearch":
        model_args = parse_args_rnnsearch_punc()
    elif model == "transformer":
        model_args = parse_args_transformer_punc()
    else:
        raise print("模型有误：")
    dic_en = codecs.open('dict_enen.txt', 'r', 'utf-8-sig').readlines()
    dic_zh = codecs.open('dict_zhzh.txt', 'r', 'utf-8-sig').readlines()
    look_up_dict = {}
    for i in range(len(dic_en)):
        look_up_dict[dic_en[i].strip()] = dic_zh[i].strip()
    bpe = bpe_Interface(create_bpe_parser(root_dir1))
    # dir_userdict = os.path.join(root_dir,"data_folder/userdict/userdict.txt")
    # jieba.load_userdict(dir_userdict)
    sess, placeholders, predictions, params, args, source_word2id = load_model(model_args)
    while True:
        inputs = input("请输入：")
        if inputs == '' or inputs == 'exit':
            break
        www = inputs.strip()
        wwww = []
        wwww.append(www)
        print(www)
        aa= one_sentence_input1(wwww, sess, placeholders, predictions, params, args, source_word2id, bpe, look_up_dict,pad_length=2)
        print(aa)
