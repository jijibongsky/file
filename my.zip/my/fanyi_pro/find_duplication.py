# 找出连续几个一样的字符

a = open('en.txt', 'r', encoding='utf-8')
b = open('zh.txt', 'r', encoding='utf-8')
c = open('zazhi.txt', 'w', encoding='utf-8')


def find(a):
    #a = a.replace(' ','')
    w = '0123456789.'
    flag = 0
    for i in range(len(a)-2):
        if a[i] not in w and a[i] == a[i+1] and a[i] == a[i+2]:
            flag += 1
    return flag

def file_handle():
    k = 0
    for line1,line2 in zip(a, b):
        k += 1
        if k % 10000 == 0:
            print(k)
        if find(line1) == 1:
            c.write(line1.strip() + '|||||' + line2.strip()+'\n')

file_handle()
