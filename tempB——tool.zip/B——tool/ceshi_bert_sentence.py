import json
import collections
import numpy as np
from time import time
import sys
import os
root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(root_dir)

from my_extract_features import Bert_one_sentence

model = Bert_one_sentence()


def load_run(file_in):
    # 平均0.0071795772871068265秒 一条， 每次1000句
    # 12501*2 条 179.50379133224487s
    rfile = open(file_in,"r",encoding="utf8")
    sens = []
    k = 0
    for line in rfile:
        k += 1
        if k == 1:
            continue
        line = line.strip()
        new_line = line.split("\t")
        if len(new_line) != 3:
            print(line)
        else:
            sens.append(new_line[0])
            sens.append(new_line[1])
        if len(sens) > 1000:
            print("k=====", k)
            result = model.one_sentence(sens)
            sens = []
    rfile.close()
    print("k===", k)


def load_run1(file_in):
    # 平均 0.012325469040601751 一条
    # 12501*2 条 179.50379133224487s
    rfile = open(file_in, "r", encoding="utf8")
    k = 0
    for line in rfile:
        k += 1
        if k == 1:
            continue
        if k % 1000 == 0:
            print("k===", k)
        line = line.strip()
        new_line = line.split("\t")
        if len(new_line) != 3:
            print(line)
        else:
            result = model.one_sentence(new_line[0])
            result = model.one_sentence(new_line[1])
    rfile.close()
    print("k===", k)



if __name__ == "__main__":
    # begin = time()
    # file_in = "/home/sun/deep_learning/text_matching/data/lcqmc/test.tsv"
    # load_run(file_in)
    # print("花费时间：", time()-begin)


    input_data = []
    input_data.append("怎么办理移机\t怎么办理移机啊")
    input_data.append("怎么办理移机")
    input_data.append("请告诉我怎么办理移机")
    outputs = model.one_sentence(input_data[0])
    print("outputs=======", outputs)

    # begin = time()
    # for sen in input_data:
    #   outputs = model.one_sentence(sen)
    #   print("=========", outputs[0].shape, outputs[0])
    #   print(time()-begin)

    # begin = time()
    # for i in range(10000):
    #     outputs = model.one_sentence(input_data[i%3])
    # #     print("=========", outputs[0].shape, outputs[0])
    # print("花费时间", time() - begin)
