import json
import collections
import numpy as np
from time import time
import sys
import os
root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(root_dir)

from my_extract_features import Bert_one_sentence

model = Bert_one_sentence()

total_sens = set()


def save_matrix(sen, res, wfile):
    Tdict = {}
    new_res = []
    for word in res:
        new_res.append([round(float(x), 6) for x in word.flat])
    Tdict["sen"] = sen
    Tdict["matrix"] = new_res
    J = json.dumps(Tdict)
    wfile.write(J + "\n")

def load_save(file_in, file_out):
    rfile = open(file_in,"r",encoding="utf8")
    wfile = open(file_out,"w",encoding="utf8")
    sens = []
    k = 0
    for line in rfile:
        k += 1
        if k == 1:
            continue
        line = line.strip()
        new_line = line.split("\t")
        if len(new_line) != 3:
            print(line)
        else:
            if new_line[0] not in total_sens:
                sens.append(new_line[0])
                total_sens.add(new_line[0])
            if new_line[1] not in total_sens:
                sens.append(new_line[1])
                total_sens.add(new_line[1])
        if len(sens) > 1000:
            print("k=====", k)
            print("===", len(total_sens))
            result = model.one_sentence(sens)
            if len(sens) != len(result):
                print("=======")
                exit(1)
            for sen, res in zip(sens, result):
                save_matrix(sen, res, wfile)
            sens = []
    rfile.close()
    wfile.close()

    print("k===", k)
    print("len(total_sens)=====", len(total_sens))


def load_dict(input_file):
    embedding_dict={}
    rfile = open(input_file, "r", encoding="utf8")
    for line in rfile:
        new_dict = json.loads(line)
        embedding_dict[new_dict["sen"]] = np.array(new_dict["matrix"])
    return embedding_dict


if __name__ == "__main__":
    begin = time()
    file_in = "/home/sun/deep_learning/text_matching/data/lcqmc/test.tsv"
    file_out = "/home/data/text_matching/bert/one_sentence/test.json"
    load_save(file_in, file_out)
    print("花费时间：", time()-begin)

# test  339.9696834087372s


    # embedding_dict = load_dict(file_out)

    # for key in embedding_dict:
    #     print("===", key)
    #     print(embedding_dict[key])
