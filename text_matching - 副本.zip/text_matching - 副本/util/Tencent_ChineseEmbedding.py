from time import time


def load_vocab_embedding(filepath):
    rfile = open(filepath, 'r', encoding='utf8')
    vocab = []
    k=0
    for line in rfile:
        k += 1
        if k == 1:
            continue
        new_line = line.strip().split(" ")
        if len(new_line) == 201:
            vocab.append(new_line[0])
        else:
            print(line.strip())
    print("单词总数：", k)
    return vocab


def save_vocab(file, vocab):
    wfile = open(file, 'w', encoding='utf8')
    for word in vocab:
        wfile.write(word + "\n")
    wfile.close()


begin = time()
root_dir = "/home/data/Tencent_ChineseEmbedding/"
filepath = root_dir + "Tencent_AILab_ChineseEmbedding.txt"
vocab = load_vocab_embedding(filepath)
print(time()-begin)

file_vocab = root_dir + "vocab.txt"
save_vocab(file_vocab, vocab)
