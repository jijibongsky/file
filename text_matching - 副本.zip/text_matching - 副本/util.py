from models.Ranking import Ranking
from models.dsa import DSA

class MODEL(object):
    def __init__(self, FLAGS, vocab):
        self.FLAGS = FLAGS
        self.vocab = vocab

    def choose_model(self, model):
        if model=="rk":
            self.Model = Ranking(
                max_len_left=self.FLAGS.max_len_left,
                max_len_right=self.FLAGS.max_len_right,
                vocab_size=len(self.vocab),
                embedding_size=self.FLAGS.embedding_dim,
                filter_sizes=list(map(int, self.FLAGS.filter_sizes.split(","))),
                num_filters=self.FLAGS.num_filters,
                num_hidden=self.FLAGS.num_hidden,
                l2_reg_lambda=self.FLAGS.l2_reg_lambda)
        elif model=="dsa":
            self.Model = DSA(
                max_len_left=self.FLAGS.max_len_left,
                max_len_right=self.FLAGS.max_len_right,
                vocab_size=len(self.vocab),
                embedding_size=300,
                d_1=150,
                d_l=75,
                k_1=3,
                k_2=5,
                num_layers=4,
                d_c=300,
                num_atttentions=8,
                d_o=300,
                num_iter=3,
                num_hidden=self.FLAGS.num_hidden,
                mu=1e-2,
                l2_reg_lambda=0.0)
        return self.Model