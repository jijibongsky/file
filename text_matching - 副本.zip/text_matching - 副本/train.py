import time
import datetime
import numpy as np
import tensorflow as tf
from data_helps import load_data
from data_helps import batch_iter
from util import MODEL


import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# Model Hyperparameters
tf.flags.DEFINE_string("model", "dsa", "model")
tf.flags.DEFINE_integer("embedding_dim", 64, "Dimensionality of character embedding (default: 64)")
tf.flags.DEFINE_string("filter_sizes", "2,3,4", "Comma-separated filter sizes (default: '2,3')")
tf.flags.DEFINE_integer("num_filters", 64, "Number of filters per filter size (default: 64)")
tf.flags.DEFINE_integer("num_hidden", 100, "Number of hidden layer units (default: 100)")
tf.flags.DEFINE_float("dropout_keep_prob", 0.9, "Dropout keep probability (default: 0.5)")
tf.flags.DEFINE_float("learning_ret", 0.001, "L2 learning_ret")
tf.flags.DEFINE_float("l2_reg_lambda", 0.0005, "L2 regularizaion lambda (default: 0.0)")
# Data Parameter
tf.flags.DEFINE_integer("max_len_left", 21, "max document length of left input")
tf.flags.DEFINE_integer("max_len_right", 21, "max document length of right input")
# tf.flags.DEFINE_integer("most_words", 40000, "Most number of words in vocab (default: 300000)")

# Training parameters
tf.flags.DEFINE_integer("seed", 123, "Random seed (default: 123)")
tf.flags.DEFINE_string("train_dir", "./", "Training dir root")
tf.flags.DEFINE_integer("batch_size", 64, "Batch Size (default: 64)")
tf.flags.DEFINE_integer("num_epochs", 200, "Number of training epochs (default: 200)")
tf.flags.DEFINE_float("eval_split", 0.1, "Use how much data for evaluating (default: 0.1)")
tf.flags.DEFINE_integer("evaluate_every", 2000, "Evaluate model on dev set after this many steps (default: 100)")
tf.flags.DEFINE_integer("checkpoint_every", 2000, "Save model after this many steps (default: 100)")
# Misc Parameters
tf.flags.DEFINE_boolean("allow_soft_placement", True, "Allow device soft device placement")
tf.flags.DEFINE_boolean("log_device_placement", False, "Log placement of ops on devices")

FLAGS = tf.flags.FLAGS
FLAGS.flag_values_dict()
# print("\nParameters:")
# for attr, value in sorted(FLAGS.__flags.items()):
#     print("{}={}".format(attr.upper(), value))
# print("")


def main():
    '''
    # Randomly shuffle data
    np.random.seed(FLAGS.seed)
    shuffle_indices = np.random.permutation(np.arange(len(data_label)))
    data_left = data_left[shuffle_indices]
    data_right = data_right[shuffle_indices]
    data_label = data_label[shuffle_indices]
    # Split train/test set
    # TODO: This is very crude, should use cross-validation
    split_num = int(len(data_label) * FLAGS.eval_split)
    x_left_train, x_left_dev = data_left[:-split_num], data_left[-split_num:]
    x_right_train, x_right_dev = data_right[:-split_num], data_right[-split_num:]
    y_train, y_dev = data_label[:-split_num], data_label[-split_num:]
    print("Vocabulary Size: {:d}".format(len(vocab)))
    print("Train/Dev split: {:d}/{:d}".format(len(y_train), len(y_dev)))
    print("Pos/Neg: {:d}/{:d}".format(num_pos, len(data_label)-num_pos))
    '''

    print("Loading data...")
    # x_left_train, x_right_train, y_train, vocab, vocab_inv, num_pos = load_data(os.path.join(FLAGS.train_dir, 'data/train.txt'), FLAGS.max_len_left, FLAGS.max_len_right)
    # x_left_dev, x_right_dev, y_dev, vocab, vocab_inv, num_pos = load_data(os.path.join(FLAGS.train_dir, 'data/test.txt'), FLAGS.max_len_left, FLAGS.max_len_right, (vocab, vocab_inv))

    x_left_train, x_right_train, y_train, vocab, num_pos = load_data(os.path.join(FLAGS.train_dir, 'data/lcqmc/train.txt'), FLAGS.max_len_left, FLAGS.max_len_right)
    x_left_dev, x_right_dev, y_dev, vocab, num_pos = load_data(os.path.join(FLAGS.train_dir, 'data/lcqmc/dev.txt'), FLAGS.max_len_left, FLAGS.max_len_right)
    x_left_test, x_right_test, y_test, vocab, num_pos = load_data(os.path.join(FLAGS.train_dir, 'data/lcqmc/test.txt'), FLAGS.max_len_left, FLAGS.max_len_right)
    # print("x_left_train=======", x_left_train)
    # print("x_right_train=======", x_right_train)
    # print("y_train=======", y_train)
    # print("vocab_inv=======", vocab_inv)

    with tf.Graph().as_default():
        session_conf = tf.ConfigProto(
        allow_soft_placement=FLAGS.allow_soft_placement,
        log_device_placement=FLAGS.log_device_placement)
        sess = tf.Session(config=session_conf)
        with sess.as_default():
            Model = MODEL(FLAGS, vocab)
            print("========", len(vocab))
            model = Model.choose_model(FLAGS.model)

            # Define Training procedure
            global_step = tf.Variable(0, name="global_step", trainable=False)
            optimizer = tf.train.AdamOptimizer(FLAGS.learning_ret)
            grads_and_vars = optimizer.compute_gradients(model.loss)
            train_op = optimizer.apply_gradients(grads_and_vars, global_step=global_step)
            saver = tf.train.Saver(tf.global_variables(), max_to_keep=5)
            sess.run(tf.global_variables_initializer())

            # Checkpoint directory. Tensorflow assumes this directory already exists so we need to create it
            timestamp = str(int(time.time()))
            out_dir = os.path.abspath(os.path.join(FLAGS.train_dir, "runs", FLAGS.model, timestamp))
            if not os.path.exists(out_dir):
                os.makedirs(out_dir)
            print("Writing to {}\n".format(out_dir))
            checkpoint_prefix = os.path.join(out_dir, "model")

            def train_step(x_left_batch, x_right_batch, y_batch):
                feed_dict = {
                model.input_left: x_left_batch,
                model.input_right: x_right_batch,
                model.input_y: y_batch,
                model.dropout_keep_prob: FLAGS.dropout_keep_prob
                }
                _, step, loss, accuracy = sess.run(
                    [train_op, global_step, model.loss, model.accuracy],
                    feed_dict)
                time_str = datetime.datetime.now().isoformat()
                if step % 500 == 0:
                    print("{}: step {}, loss {:g}, acc {:g}".format(time_str, step, loss, accuracy))

            # def dev_step(x_left_batch_dev, x_right_batch_dev, y_batch_dev):
            #     feed_dict = {
            #     model.input_left: x_left_batch_dev,
            #     model.input_right: x_right_batch_dev,
            #     model.input_y: y_batch_dev,
            #     model.dropout_keep_prob: 1.0
            #     }
            #     step, loss, accuracy, pres = sess.run(
            #             [global_step, model.loss, model.accuracy, model.scores],
            #             feed_dict)
            #     return loss,accuracy
            #
            # def dev_whole(x_left_dev, x_right_dev, y_dev):
            #     batches_dev = batch_iter(
            #         list(zip(x_left_dev, x_right_dev, y_dev)), FLAGS.batch_size*2, 1, shuffle=False)
            #     losses = []
            #     accuracies = []
            #     for idx, batch_dev in enumerate(batches_dev):
            #         x_left_batch, x_right_batch, y_batch = zip(*batch_dev)
            #         loss, accurary = dev_step(x_left_batch, x_right_batch, y_batch)
            #         losses.append(loss)
            #         accuracies.append(accurary)
            #     return np.mean(np.array(losses)), np.mean(np.array(accuracies))

            def dev_step(x_left_batch, x_right_batch, y_batch):
                feed_dict = {
                model.input_left: x_left_batch,
                model.input_right: x_right_batch,
                model.input_y: y_batch,
                model.dropout_keep_prob: 1.0
                }
                step, loss, accuracy, pres = sess.run(
                        [global_step, model.loss, model.accuracy, model.scores],
                        feed_dict)
                return loss,accuracy

            def dev_whole(x_left, x_right, y):
                batches = batch_iter(
                    list(zip(x_left, x_right, y)), FLAGS.batch_size*2, 1, shuffle=False)
                losses = []
                accuracies = []
                for idx, batch in enumerate(batches):
                    x_left_batch, x_right_batch, y_batch = zip(*batch)
                    loss, accurary = dev_step(x_left_batch, x_right_batch, y_batch)
                    losses.append(loss)
                    accuracies.append(accurary)
                return np.mean(np.array(losses)), np.mean(np.array(accuracies))


            # Generate batches
            batches = batch_iter(list(zip(x_left_train, x_right_train, y_train)), FLAGS.batch_size, FLAGS.num_epochs)

            # for batch in batches:
            #     for x1, x2, y in batch:
            #         print(''.join([vocab_inv[x] for x in x1]))
            #         print(''.join([vocab_inv[x] for x in x2]))
            #         print(y)
            #     break

            # Training loop. For each batch...
            dev_loss = []
            test_loss = []
            for batch in batches:
                x1_batch, x2_batch, y_batch = zip(*batch)
                train_step(x1_batch, x2_batch, y_batch)
                current_step = tf.train.global_step(sess, global_step)
                if current_step % FLAGS.evaluate_every == 0:
                    print("\nEvaluation:")
                    loss_dev, accuracy_dev = dev_whole(x_left_dev, x_right_dev, y_dev)
                    loss_test, accuracy_test = dev_whole(x_left_test, x_right_test, y_test)
                    time_str = datetime.datetime.now().isoformat()
                    print("{}: dev-test, dev {:g}, test {:g}".format(time_str, accuracy_dev, accuracy_test))
                    dev_loss.append(accuracy_dev)
                    test_loss.append(accuracy_test)
                    print("\nRecently accuracy:")
                    print(dev_loss[-10:])
                    print(test_loss[-10:])

                if current_step % FLAGS.checkpoint_every == 0:
                    path = saver.save(sess, checkpoint_prefix, global_step=current_step)
                    print("Saved model checkpoint to {}\n".format(path))


if __name__ == '__main__':
    main()

