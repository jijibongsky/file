import jieba
import re
from time import time
import nltk


# 分词，并做一些简单的处理，比如连续\t 变成空格，连续空格变成一个空格，
# 开头还没有处理，需要去掉数字加点开头的标记（序列如㈠ 、(b)、(i)、C.）


def jieba_fenci(sentence):
    sentence = re.sub(" +", " ", sentence)
    words = jieba.cut(sentence)
    result = " ".join(words)
    result = re.sub(" +", " ", result)
    return result


def en_split_words(sentence):
    sentence = re.sub(" +", " ", sentence)
    tokens = nltk.word_tokenize(sentence)
    result = " ".join(tokens)
    return result


def main(dir_in_en, dir_in_zh, dir_out_en, dir_out_zh):
    fr_en = open(dir_in_en, "r", encoding="utf8")
    fr_zh = open(dir_in_zh, "r", encoding="utf8")
    fw_en = open(dir_out_en, "w", encoding="utf8")
    fw_zh = open(dir_out_zh, "w", encoding="utf8")
    k = 0
    begin_time = time()
    for en, zh in zip(fr_en, fr_zh):
        k += 1
        if k % 100000 == 0:
            print("{}行，花费时间：{}".format(k, time() - begin_time))
        en = en.strip()
        en = re.sub("\t+", " ", en)
        en = re.sub(" +", " ", en)
        zh = zh.strip()
        zh = re.sub("\t+", " ", zh)
        zh = re.sub(" +", " ", zh)

        zh = jieba_fenci(zh)
        en = en_split_words(en)
        fw_en.write(en + "\n")
        fw_zh.write(zh+"\n")


if __name__ == '__main__':
    root_dir = "/home/data/fanyi_data/"
    dir_in_en = root_dir + "test_en.txt"
    dir_in_zh = root_dir + "test_zh.txt"
    dir_out_en = root_dir + "test_en_seg.txt"
    dir_out_zh = root_dir + "test_zh_seg.txt"
    main(dir_in_en, dir_in_zh, dir_out_en, dir_out_zh)
