import nltk
import jieba
import re


def en_split_sentence(line):
    sentencesToken = nltk.sent_tokenize(line)
    # for sentence in sentencesToken:
    #     print(sentence)
    return sentencesToken


def en_split_words(line):
    tokens = nltk.word_tokenize(line)
    new_line = " ".join(tokens)
    return new_line


def jieba_fenci(sentence):
    sentence = re.sub(" +", " ", sentence)
    words = jieba.cut(sentence)
    result = " ".join(words)
    result = re.sub(" +", " ", result)
    return result


if __name__ == '__main__':
    line = """we are introduced to the narrator, a pilot, and his ideas about grown-ups Once when I was six years old I saw a magnificent picture in a book, called True Stories from Nature, about the primeval forest. It was a picture of a boa constrictor in the act of swallowing an animal. Here is a copy of the drawing. """
    # result = en_split_sentence(line)
    result = en_split_words(line)
    # result = jieba_fenci(line)   # 分英文效果不好 比如 grown-ups 会被拆开
    print(result)
