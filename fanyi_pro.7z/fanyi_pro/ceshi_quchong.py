from time import time

data_in_en = "/home/data/fanyi_data/all_data_beifen/BPE/en_pro_good_seg.txt"
data_in_zh = "/home/data/fanyi_data/all_data_beifen/BPE/zh_pro_good_seg.txt"
fr_en = open(data_in_en, "r", encoding="utf8")
fr_zh = open(data_in_zh, "r", encoding="utf8")
lines = []
k = 0
for en, zh in zip(fr_en, fr_zh):
    en = en.strip()
    zh = zh.strip()
    lines.append(en + "|||||" + zh)

print(len(lines))
begin = time()
lines = set(lines)
print(time() - begin)
print(len(lines))

data_out_en = "/home/data/fanyi_data/all_data_beifen/BPE/encode.txt"
data_out_zh = "/home/data/fanyi_data/all_data_beifen/BPE/decode.txt"
fw_en = open(data_out_en, "w", encoding="utf8")
fw_zh = open(data_out_zh, "w", encoding="utf8")
for line in lines:
    line = line.split("|||||")
    en = line[0]
    zh = line[1]
    fw_en.write(en + "\n")
    fw_zh.write(zh + "\n")

