import jieba
import re


def jieba_fenci(sentence):
    sentence = re.sub(" +", " ", sentence)
    words = jieba.cut(sentence)
    result = " ".join(words)
    result = re.sub(" +", " ", result)
    return result


sentence = "一对 亲密 的 美国 兄妹 ，"
result = jieba_fenci(sentence)
print(result)
