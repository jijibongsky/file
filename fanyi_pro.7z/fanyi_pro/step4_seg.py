import jieba
import re
from time import time
import nltk


# 分词，并做一些简单的处理，比如连续\t 变成空格，连续空格变成一个空格，
# 开头还没有处理，需要去掉数字加点开头的标记（序列如㈠ 、(b)、(i)、C.）


def jieba_fenci(sentence):
    sentence = re.sub(" +", " ", sentence)
    words = jieba.cut(sentence)
    result = " ".join(words)
    result = re.sub(" +", " ", result)
    return result


def en_split_words(sentence):
    sentence = re.sub(" +", " ", sentence)
    tokens = nltk.word_tokenize(sentence)
    result = " ".join(tokens)
    return result


def main(dir_in, dir_out_en, dir_out_zh):
    fr = open(dir_in, "r", encoding="utf8")
    fw_en = open(dir_out_en, "w", encoding="utf8")
    fw_zh = open(dir_out_zh, "w", encoding="utf8")
    k = 0
    begin_time = time()
    for line in fr:
        k += 1
        if k % 100000 == 0:
            print("{}行，花费时间：{}".format(k, time() - begin_time))
        line = line.strip()
        line = re.sub("\t+", " ", line)
        line = re.sub(" +", " ", line)
        line = line.split("|||||")
        if len(line) != 2:
            print(k, line)
        en = line[0]
        zh = line[1]
        zh = jieba_fenci(zh)
        en = en_split_words(en)
        fw_en.write(en + "\n")
        fw_zh.write(zh+"\n")


if __name__ == '__main__':
    root_dir = "/home/data/fanyi_data/all_data/"
    dir_in = root_dir + "all_data_pro_good.txt"
    dir_out_en = root_dir + "en_pro_good_seg.txt"
    dir_out_zh = root_dir + "zh_pro_good_seg.txt"
    main(dir_in, dir_out_en, dir_out_zh)
