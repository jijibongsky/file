import random
import re


def select_chinese(a):
    return ("".join(re.findall(u'[\u4e00-\u9fa5]+', a)))


def sep_tihuan(sentence1, sentence2):
	index = [str(i) for i in list(range(20))]
	random.shuffle(index)
	temp = sentence1.split()
	flag = 0
	for i in range(len(temp)):
		if temp[i] in sentence2:
			sentence1 = sentence1.replace(temp[i], '&SEP' + index[flag] + ';', 1)
			sentence2 = sentence2.replace(temp[i], '&SEP' + index[flag] + ';', 1)
			flag += 1
			flag = flag % 20
	return sentence1, sentence2


def main():
	a = 'i want to tell you i have 1232 dollars yuan ,do you want to 嫁给我 ？'
	b = '我 想 告诉 你 我 有 1232 美元 ， 你想 嫁给我 吗 ？'
	c, d = sep_tihuan(a, b)
	print(c)
	print('********')
	print(d)


def ceshi():
	if re.match(r'[a-zA-z]+://[^\s]*', 'http://www.baidu.com'):
		print('right')
	else:
		print('wrong')


def email():
	text = "1581045885@qq.com"
	if re.match(r'^[0-9a-zA-Z_]{0,19}@[0-9a-zA-Z]{1,13}\.[com,cn,net]{1,3}$', text):
		print('Email address is Right!')
	else:
		print('Please reset your right Email address!')


def email1():
	email = "我有一个邮箱skk 12345678@qq.com 哈哈哈"
	# email = "12345678@qq.com"
	# regular = re.compile(r'[0-9a-zA-Z.]+@[0-9a-zA-Z.]+?com')
	regular = re.compile(r'^[0-9a-zA-Z_]{0,19}@[0-9a-zA-Z]{1,13}\.[com,cn,net]{1,3}$')
	a = re.findall(regular, email)
	print(a)


def email2():
	email = "我有一个邮箱skk 12345678@qq.com 哈哈哈"
	# email = "12345678@qq.com"
	a = re.findall(r'[0-9a-zA-Z.]+@[0-9a-zA-Z.]+?com', email)
	print(a)


if __name__ == '__main__':
	# main()
	# ceshi()
	# email()
	email1()
	# email2()
