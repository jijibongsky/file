import os
from time import time


def read_txt(data_file):
    fr = open(data_file, "r", encoding="utf8")
    for line in fr:
        line += line.strip()
        return line


def get_all_data(data_dir):
    text_dict = {}
    wav_dict = {}
    k = 0
    for file in os.listdir(data_dir):
        k += 1
        # if k % 10000 == 0:
        #     print(k, time() - begin_time)
        id = file.split(".")[0]
        id_type = file.split(".")[1]
        if id_type == "txt":
            content = read_txt(data_dir + file)
            text_dict[id] = content
        elif id_type == "wav":
            wav_dict[id] = data_dir + file
        elif id_type == "metadata":
            pass
        else:
            print(1111111111, file)
    print("总数据：{}".format(k / 3))
    return text_dict, wav_dict


def compare_dict(text_dict, wav_dict):
    for key in text_dict:
        if key not in wav_dict:
            print(11111, key)
    for key in wav_dict:
        if key not in text_dict:
            print(22222, key)


if __name__ == '__main__':
    data_dir = "/home/data/ASR/ST-CMDS-20170001/ST-CMDS-20170001_1-OS/"
    begin_time = time()
    text_dict, wav_dict = get_all_data(data_dir)
    compare_dict(text_dict, wav_dict)

    # for key in text_dict:
    #     print(key, text_dict[key], wav_dict[key])
    #     input(11)

    # my_dict = file_name = "20170001P00413A0027"
    # a = [data_dir + file_name + "." + i for i in ["metadata", "txt", "wav"]]
    # os.system("scp {} {}".format(a[0], "/home/data/ASR/ST-CMDS-20170001"))
    # os.system("scp {} {}".format(a[1], "/home/data/ASR/ST-CMDS-20170001"))
    # os.system("scp {} {}".format(a[2], "/home/data/ASR/ST-CMDS-20170001"))
