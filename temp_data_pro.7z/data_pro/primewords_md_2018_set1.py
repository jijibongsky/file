import json
import os


# 可以先把所有文件名取出来，然后用文件名做 key，分别用 wav 路径和文本内容做 value  .可以用 user_id 区分不同人


def get_all_txt(json_file):
    text_dict = {}
    user_dict = {}
    with open(json_file, "r", encoding="utf8") as f:
        data = json.load(f)
    print("总数据：{}".format(len(data)))
    # keys = ['id', 'file', 'user_id', 'text', 'length']
    # data1 = ["\t".join([key + "\t" + term[key] for key in keys]) for term in data]
    # print(11111111, len(data1))
    # print(11111111, len(list(set(data1))))

    for term in data:
        file = term["file"]
        id = file.split(".")[0]
        # if id in text_dict or id in user_dict:
            # print("重复：", file)
            # print(111111, text_dict[id], user_dict[id])
            # print(222222, term)
            # print()
        text_dict[id] = term["text"]
        user_dict[id] = term["user_id"]
    return text_dict, user_dict


def get_wav_txt(wav_dir):
    wav_dict = {}
    for dir1 in os.listdir(wav_dir):
        child_dir1 = os.path.join(wav_dir, dir1)
        for dir2 in os.listdir(child_dir1):
            child_dir2 = os.path.join(child_dir1, dir2)
            # print(1111111, child_dir2)
            for file in os.listdir(child_dir2):
                file_path = os.path.join(child_dir2, file)
                id = file.split(".")[0]
                if id in wav_dict:
                    print("重复{}".format(file))
                wav_dict[id] = file_path
                # input(11)
    return wav_dict

def compare_dict(txt_dict, wav_dict):
    for key in txt_dict:
        if key not in wav_dict:
            print(11111, key)
    for key in wav_dict:
        if key not in txt_dict:
            print(22222, key)

if __name__ == '__main__':
    data_dir = "/home/data/ASR/primewords_md_2018/primewords_md_2018_set1/"
    json_file = data_dir + "set1_transcript.json"
    wav_dir = data_dir + "audio_files"
    text_dict, user_dict = get_all_txt(json_file)
    wav_dict = get_wav_txt(wav_dir)
    compare_dict(text_dict, wav_dict)
