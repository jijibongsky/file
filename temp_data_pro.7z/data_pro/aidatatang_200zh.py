import os
import sys


# 解压稍微麻烦一点
def up_zip(data_dir):
    for term in ["train", "dev", "test"]:
        data_dir1 = os.path.join(data_dir, term)
        for file in os.listdir(data_dir1):
            if file[-7:] != ".tar.gz":
                print(111111111111)
                continue
            data_file_in = os.path.join(data_dir1, file)
            os.system("tar -xzvf {} -C {}".format(data_file_in, data_dir1))


def get_all_wav_txt(temp_data_dir):
    text_dict = {}
    wav_dict = {}
    for dir in os.listdir(temp_data_dir):
        child_dir = os.path.join(temp_data_dir, dir)
        if child_dir[-7:] == ".tar.gz":
            # print(111111111, child_dir)
            continue
        for file in os.listdir(child_dir):
            file_path = os.path.join(child_dir, file)
            id = file.split(".")[0]
            id_type = file.split(".")[1]

            if id_type == "txt":
                if id in text_dict:
                    print("重复：", id)
                text_dict[id] = file_path
            elif id_type == "wav":
                if id in wav_dict:
                    print("重复：", id)
                wav_dict[id] = file_path
            elif id_type in ["metadata", "trn"]:
                pass
            else:
                print(111111111)
    return text_dict, wav_dict


def compare_dict(text_dict, wav_dict):
    for key in text_dict:
        if key not in wav_dict:
            print(11111, key)
    for key in wav_dict:
        if key not in text_dict:
            print(22222, key)


if __name__ == '__main__':
    data_dir = "/home/data/ASR/aidatatang_200zh/aidatatang_200zh/corpus/"
    # up_zip(data_dir)
    text_dict, wav_dict = get_all_wav_txt(data_dir + "train")
    compare_dict(text_dict, wav_dict)
