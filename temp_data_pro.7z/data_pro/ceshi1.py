import os
# cmd = "du -h /home/data/ASR/aidatatang_200zh/readme.txt"
cmd = "du -h /home/data/ASR/aidatatang_200zh/aidatatang_200zh.tgz"
result = os.system(cmd)
print(type(result), result)
