import random

# a = random.randint(32, 42)
# print(a)

for i in range(100):
    b = random.uniform(0, 1)
    if b < 0:
        print(b)
