from flask import request
from flask import Flask
from flask import abort
import json

app = Flask(__name__)

@app.route("/")
def hello():
    return '<h1 style="color:blue">Hello There!</h1>'

@app.route('/resttest', methods=['POST'])
def create_task():
    if not request.json or not 'sentence' in request.json:
        abort(401)
    data_dict = json.loads(request.json)  # request.json 是字符串  json.loads 加载字符串
    sentence = data_dict['sentence']
    result = sentence + "aaa"
    RESULT = {"result": result}
    RESULT = json.dumps(RESULT)  # 把字典穿换成 json 格式
    return RESULT


if __name__ == '__main__':
    # app.run(host='196.168.2.100', port=8815)
    app.run(host='0.0.0.0', port=8815)

    # 直接用 uwsgi启动
    # uwsgi --socket 0.0.0.0:8815 --protocol=http -p 3 -w python_create_rest:app

    # uwsgi --ini /home/data/deep_learning/my/python_rest/uwsgi_nginx/uwsgi.ini
    # nginx -c /home/data/deep_learning/my/python_rest/uwsgi_nginx/nginx.conf
