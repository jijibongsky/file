#-*- coding:utf-8 -*-
import os
from time import time
import numpy as np
from PIL import Image
from densenet.model import predict as keras_densenet


def sudu():
    data1 = "/home/sun/deep_learning/deeplearning/chinese_ocr/test_images_line/ceshi"
    all_files = os.listdir(data1)
    k = 0
    for file in all_files:
        k+=1
        if k%100 == 0:
            print(k)
        image_file = os.path.join(data1, file)
        image = Image.open(image_file).convert('L')
        text = keras_densenet(image)
        # print("text=====", text)

if __name__ == '__main__':
    root_dir = "/home/sun/deep_learning/deeplearning/chinese_ocr"
    image_file = os.path.join(root_dir, "test_images_line", "1111.jpg")
    image = Image.open(image_file).convert('L')
    text = keras_densenet(image)

    begin = time()
    sudu()
    print("花费时间：", time()-begin)

    while 0:
        im_file = input("请输入文件名：")
        if im_file == "" or im_file=="q":
            break

        image_file = os.path.join(root_dir, "test_images_line", im_file)
        try:
            image = Image.open(image_file).convert('L')
        except:
            print("文件有误，请重新输入")
            continue
        text = keras_densenet(image)
        print("text=====", text)
