import json
import collections
import numpy as np
from time import time
import sys
import os
root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(root_dir)

from my_extract_features import Bert_one_sentence

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

model = Bert_one_sentence()

total_sens = set()


def save_matrix(sen, res, wfile):
    Tdict = {}
    new_res = []
    for word in res:
        new_res.append([round(float(x), 6) for x in word.flat])
    Tdict["sen"] = sen
    Tdict["matrix"] = new_res
    J = json.dumps(Tdict)
    wfile.write(J + "\n")


def load_save(file_in, file_out):
    rfile = open(file_in, "r", encoding="utf8")
    wfile = open(file_out, "w", encoding="utf8")
    sen_pairs = []
    k = 0
    for line in rfile:
        k += 1
        if k == 1:
            continue
        line = line.strip()
        new_line = line.split("\t")
        if len(new_line) != 3:
            print(line)
        else:
            sen_pair = new_line[0] + "\t" + new_line[1]
            if sen_pair not in total_sens:
                sen_pairs.append(sen_pair)
                total_sens.add(sen_pair)

        if len(sen_pairs) > 1000:
            print("k=====", k)
            print("===", len(total_sens))
            result = model.one_sentence(sen_pairs)
            if len(sen_pairs) != len(result):
                print("=======")
                exit(1)
            for sen, res in zip(sen_pairs, result):
                save_matrix(sen, res, wfile)
            sen_pairs = []

    result = model.one_sentence(sen_pairs)
    if len(sen_pairs) != len(result):
        print("=======")
        exit(1)
    for sen, res in zip(sen_pairs, result):
        save_matrix(sen, res, wfile)

    rfile.close()
    wfile.close()

    print("k===", k)
    print("len(total_sens)=====", len(total_sens))


def load_dict(input_file):
    embedding_dict={}
    rfile = open(input_file, "r", encoding="utf8")
    for line in rfile:
        new_dict = json.loads(line)
        embedding_dict[new_dict["sen"]] = np.array(new_dict["matrix"])
    return embedding_dict


if __name__ == "__main__":
    begin = time()
    file_in = "/home/sun/deep_learning/text_matching/data/lcqmc/train.tsv"
    file_out = "/home/data/text_matching/bert/sentence_pair/train.json"
    load_save(file_in, file_out)
    print("花费时间：", time()-begin)

# test  339.9696834087372s

    # embedding_dict = load_dict(file_out)
    # for key in embedding_dict:
    #     print("===", key)
    #     print(embedding_dict[key])
