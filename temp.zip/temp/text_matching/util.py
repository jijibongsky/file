from models.Ranking import Ranking
from models.dsa import DSA
from models.esim import ESIM

def choose_model(name, FLAGS, vocab):
    model = None
    if name=="rk":
        model = Ranking(
            max_len_left=FLAGS.max_len_left,
            max_len_right=FLAGS.max_len_right,
            vocab_size=len(vocab),
            embedding_size=FLAGS.embedding_dim,
            filter_sizes=list(map(int, FLAGS.filter_sizes.split(","))),
            num_filters=FLAGS.num_filters,
            num_hidden=FLAGS.num_hidden,
            l2_reg_lambda=FLAGS.l2_reg_lambda)
    elif name=="dsa":
        model = DSA(
            max_len_left=FLAGS.max_len_left,
            max_len_right=FLAGS.max_len_right,
            vocab_size=len(vocab),
            embedding_size=300,
            d_1=150,
            d_l=75,
            k_1=3,
            k_2=5,
            num_layers=4,
            d_c=300,
            num_atttentions=8,
            d_o=300,
            num_iter=3,
            num_hidden=128,
            mu=FLAGS.mu,
            l2_reg_lambda=FLAGS.l2_reg_lambda)
    elif name == "esim":
        model = ESIM(
            max_len_left=FLAGS.max_len_left,
            max_len_right=FLAGS.max_len_right,
            vocab_size=len(vocab),
            embedding_size=300,
            rnn_size=300,
            num_hidden=300,
            l2_reg_lambda=FLAGS.l2_reg_lambda)
    return model