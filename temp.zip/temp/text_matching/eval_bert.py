import time
import numpy as np
import tensorflow as tf
from data_helps import load_data_str
from data_helps import batch_iter
from util_bert import choose_model
from load_sentence_embedding import load_sentence_embedding_dict


import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# Model Hyperparameters
tf.flags.DEFINE_string("model_name", "bert_dsa", "model")
tf.flags.DEFINE_string("model_save_path", "runs/bert/result/bert_dsa_0.5_2e-05_0.0005/checkpoints", "model_save_path")
tf.flags.DEFINE_integer("embedding_dim", 128, "Dimensionality of character embedding (default: 64)")
tf.flags.DEFINE_string("filter_sizes", "2,3,4", "Comma-separated filter sizes (default: '2,3')")
tf.flags.DEFINE_integer("num_filters", 128, "Number of filters per filter size (default: 64)")
tf.flags.DEFINE_integer("num_hidden", 128, "Number of hidden layer units (default: 100)")
tf.flags.DEFINE_integer("output_dim", 16, "Number of output units (default: 100)")

tf.flags.DEFINE_float("mu", 0.01, "mu")
tf.flags.DEFINE_float("l2_reg_lambda", 0.0005, "L2 regularizaion lambda (default: 0.0)")

# Data Parameter
tf.flags.DEFINE_integer("max_len_left", 24, "max document length of left input")
tf.flags.DEFINE_integer("max_len_right", 24, "max document length of right input")
tf.flags.DEFINE_integer("batch_size", 64, "Batch Size (default: 64)")

tf.flags.DEFINE_integer("seed", 123, "Random seed (default: 123)")
tf.flags.DEFINE_integer("num_checkpoints", 5, "number of checkpoints saved")
# Misc Parameters
tf.flags.DEFINE_boolean("allow_soft_placement", True, "Allow device soft device placement")
tf.flags.DEFINE_boolean("log_device_placement", False, "Log placement of ops on devices")

FLAGS = tf.flags.FLAGS
FLAGS.flag_values_dict()


def get_sentence_embedding(embedding_dict, x1_batch, x2_batch, y_batch):
    x1_batch = [embedding_dict[sen] for sen in x1_batch]
    x2_batch = [embedding_dict[sen] for sen in x2_batch]
    y_batch = [label for label in y_batch]
    x1_len = np.array([sen.shape[0] for sen in x1_batch], dtype="int32")
    x2_len = np.array([sen.shape[0] for sen in x2_batch], dtype="int32")
    max_len1 = max(x1_len)
    max_len2 = max(x2_len)
    x1_batch_embedding = np.array(
        [np.vstack((sen, np.zeros([max_len1 - len(sen), 768], dtype="float32"))) for sen in x1_batch], dtype="float32")
    x2_batch_embedding = np.array(
        [np.vstack((sen, np.zeros([max_len2 - len(sen), 768], dtype="float32"))) for sen in x2_batch], dtype="float32")
    y_batch_embedding = np.array(y_batch, dtype="int32")
    return x1_batch_embedding, x2_batch_embedding, x1_len, x2_len, y_batch_embedding


def main():
    tf.logging.set_verbosity(tf.logging.INFO)
    print("Loading data...")
    x_left, x_right, y = load_data_str('data/lcqmc/test.tsv')
    test_embedding_dict = load_sentence_embedding_dict("/home/data/text_matching/bert/one_sentence/test.json")

    graph = tf.Graph()
    with graph.as_default():
        session_conf = tf.ConfigProto(
        gpu_options=tf.GPUOptions(allow_growth=True),
        # gpu_options=tf.GPUOptions(per_process_gpu_memory_fraction=0.5),
        allow_soft_placement=FLAGS.allow_soft_placement,
        log_device_placement=FLAGS.log_device_placement)
        sess = tf.Session(config=session_conf)
        with sess.as_default():
            model = choose_model(FLAGS.model_name, FLAGS)
            saver = tf.train.Saver(tf.global_variables(), max_to_keep=FLAGS.num_checkpoints)
            ckpt = tf.train.get_checkpoint_state(FLAGS.model_save_path)
            saver.restore(sess, ckpt.model_checkpoint_path)

            all_weights = {v.name: v for v in tf.trainable_variables()}
            total_size = 0
            for v_name in sorted(list(all_weights)):
                v = all_weights[v_name]
                tf.logging.info("%s\tshape    %s", v.name[:-2].ljust(80),
                                str(v.shape).ljust(20))
                v_size = np.prod(np.array(v.shape.as_list())).tolist()
                total_size += v_size
            tf.logging.info("Total trainable variables size: %d", total_size)

            num_test = 0
            num_correct = 0.0
            batches = batch_iter(list(zip(x_left, x_right, y)), FLAGS.batch_size*2, 1, shuffle=False)
            for idx, batch in enumerate(batches):
                x_left_batch, x_right_batch, y_batch = zip(*batch)
                x1_batch_embedding, x2_batch_embedding, x1_len, x2_len, y_batch \
                    = get_sentence_embedding(test_embedding_dict, x_left_batch, x_right_batch, y_batch)
                feed_dict = {
                    model.emb_left: x1_batch_embedding,
                    model.emb_right: x2_batch_embedding,
                    model.length_left: x1_len,
                    model.length_right: x2_len,
                    model.input_y: y_batch,
                    model.dropout_keep_prob: 1.0
                }
                betch_accuracy, batch_socres = sess.run([model.accuracy, model.scores], feed_dict)
                num_test += len(batch_socres)
                num_correct += len(batch_socres)*betch_accuracy
            acc = num_correct/num_test
            print("test accuracy:", acc)


if __name__ == '__main__':
    main()
