import json
import numpy as np


def load_sentence_embedding_dict(input_file, max_len=None):
    embedding_dict = {}
    rfile = open(input_file, "r", encoding="utf8")
    k = 0
    for line in rfile:
        k += 1
        if k % 10000 == 0:
            print(k)
        new_dict = json.loads(line)
        if max_len:
            Tlen = min(len(new_dict["matrix"]), max_len)
            embedding_dict[new_dict["sen"]] = np.array(new_dict["matrix"][:Tlen])
        else:
            embedding_dict[new_dict["sen"]] = np.array(new_dict["matrix"])
    return embedding_dict


if __name__ == '__main__':
    embedding_dict = load_sentence_embedding_dict("/home/data/text_matching/bert/one_sentence/dev.json1")
    for key in embedding_dict:
        print("===", key, embedding_dict[key])
        print()
