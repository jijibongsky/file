import itertools
import numpy as np
from collections import Counter


sentences = []
sentences.append(['谁', '会', '玩', '新石器', '时代', '？', '<PAD/>', '<PAD/>', '<PAD/>'])
sentences.append(['上海', '有', '什么', '好玩', '的', '地方', '？', '<PAD/>'])
sentences.append(['高数', '不定积分', '<PAD/>', '<PAD/>', '<PAD/>', '<PAD/>', '<PAD/>', '<PAD/>'])
sentences.append(['郑州', '哪里', '租', '衣服', '<PAD/>', '<PAD/>', '<PAD/>', '<PAD/>', '<PAD/>', '<PAD/>'])

word_counts = Counter(itertools.chain(*sentences))

# for word in word_counts:
#     print(word)
# for word in word_counts.most_common(50000):
#     print(word)

vocabulary_inv = [x[0] for x in word_counts.most_common(50000)]
vocabulary_inv = list(sorted(vocabulary_inv))
vocabulary_inv.append('<UNK/>')
vocabulary = {x: i for i, x in enumerate(vocabulary_inv)}
print(vocabulary)
