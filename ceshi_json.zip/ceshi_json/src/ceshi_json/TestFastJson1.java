package ceshi_json;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;


public class TestFastJson1 {

	public static void main(String args[]) {
		
		Worker tfj = new Worker("jijibongsky", "男", 30);
		
		String json = getJsonString(tfj);

		System.out.println("json=" + json);
		
		System.out.println("name=" + getJsonValueObj(json, "name", String.class));
		
		System.out.println("sex=" + getJsonValueObj(json, "sex", String.class));
	
		System.out.println("age=" + getJsonValueObj(json, "age", Integer.class));
	}

	/**
	 * 
	 * 将对象转换成json
	 */
	public static String getJsonString(Object obj) {
		String json = JSON.toJSONString(obj);
		return json;
	}

	
	/**
	 * 根据对象的类型，自动识别获取该对象的值
	 */
	public static Object getJsonValueObj(String json, String key, Class clazz) {
		JSONObject jo = JSON.parseObject(json);
		if (clazz.getSimpleName().equals("String")) {
			String value = jo.getString(key);
			return value;
		} else if (clazz.getSimpleName().equals("Integer")) {
			Integer value = jo.getInteger(key);
			return value;
		} else if (clazz.getSimpleName().equals("Boolean")) {
			Boolean value = jo.getBoolean(key);
			return value;
		} else if (clazz.getSimpleName().equals("JSONArray")) {
			JSONArray array = jo.getJSONArray(key);
			return array;
		} else {
			return "error, 暂不支持的类型:" + clazz.toString();
		}
	}
	
}
