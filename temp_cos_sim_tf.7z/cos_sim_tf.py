import tensorflow as tf
import os
import numpy as np
from time import time

os.environ["CUDA_VISIBLE_DEVICES"] = ""


def cosine_np(vec1, vec2):
    dot_val = np.dot(vec1, vec2.T)
    modulus1 = np.linalg.norm(vec1, axis=-1, keepdims=True)
    modulus2 = np.linalg.norm(vec2, axis=-1, keepdims=True)
    cos_val = dot_val / (np.dot(modulus1, modulus2.T) + 1e-8)
    return cos_val


def cosine_tf(vec1, vec2):
    dot_val = tf.matmul(vec1, tf.transpose(vec2, [1, 0]), name="dot_val")
    modulus1 = tf.norm(vec1, ord=2, axis=-1, keepdims=True)
    modulus2 = tf.norm(vec2, ord=2, axis=-1, keepdims=True)
    cos_val = dot_val / (tf.matmul(modulus1, tf.transpose(modulus2, [1, 0]), name="dot_val") + 1e-8)
    return cos_val


# dim = 500
# len1 = 1000
# len2 = 2000
dim = 200
len1 = 3
len2 = 100
placeholder1 = tf.placeholder(dtype=tf.float32, shape=(len1, dim))
placeholder2 = tf.placeholder(dtype=tf.float32, shape=(len2, dim))
cos_val = cosine_tf(placeholder1, placeholder2)
vec1_n = np.random.random((len1, dim))
vec2_n = np.random.random((len2, dim))
result1 = cosine_np(vec1_n, vec2_n)

sess = tf.Session()
result2 = sess.run(cos_val, feed_dict={placeholder1: vec1_n, placeholder2: vec2_n})

# difference = result1 - result2
# for line in difference:
#     for ss in line:
#         if ss > 1e-6:
#             print(11111111, ss)

# 测试速度
begin_time = time()
for i in range(10000):
    vec1_n = np.random.random((len1, dim))
    vec2_n = np.random.random((len2, dim))
    # result = cosine_np(vec1_n, vec2_n)
    result = sess.run(cos_val, feed_dict={placeholder1: vec1_n, placeholder2: vec2_n})
print("花费时间：", time() - begin_time)
