# -*- coding: utf-8 -*-

# https://github.com/taoshen58/DiSAN/blob/master/SST_disan/src/model/model_disan.py