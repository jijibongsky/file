git add *.py
git add models/*.py
git add dataloader/*.py
git commit -m $1
git pull
git push

