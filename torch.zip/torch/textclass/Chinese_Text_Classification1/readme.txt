python run.py --model TextCNN --word True


# 训练并测试：
# FastText, embedding层是随机初始化的
python run.py --model FastText --embedding random

# TextCNN
python run.py --model TextCNN

# TextRNN
python run.py --model TextRNN

# TextRCNN
python run.py --model TextRCNN

# TextRNN_Att
python run.py --model TextRNN_Att

# DPCNN
python run.py --model DPCNN

# Transformer
python run.py --model Transformer