import torch
import numpy as np

np_data = np.arange(6).reshape((2, 3))
torch_data = torch.from_numpy(np_data)
tensor2array = torch_data.numpy()
print('numpy array:', np_data)  # [[0 1 2], [3 4 5]]
print('torch tensor:', type(torch_data), torch_data)  # 0  1  2  3  4  5    [torch.LongTensor of size 2x3]
print('tensor to array:', type(tensor2array), tensor2array)  # [[0 1 2], [3 4 5]]

# abs 绝对值计算
data = [-1, -2, 1, 2]
tensor = torch.FloatTensor(data)  # 转换成32位浮点 tensor
print('abs', np.abs(data), torch.abs(tensor))

# sin   三角函数 sin
print('sin', np.sin(data), torch.sin(tensor))

# mean  均值
print('mean', np.mean(data), torch.mean(tensor))

# matrix multiplication 矩阵点乘
data = [[1, 2], [3, 4]]
tensor = torch.FloatTensor(data)  # 转换成32位浮点 tensor
print('matrix multiplication (matmul)')
print(np.matmul(data, data))  # 正常的矩阵乘法
print(torch.mm(tensor, tensor))

