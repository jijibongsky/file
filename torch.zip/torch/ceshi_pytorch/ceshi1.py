from __future__ import print_function
import torch

# 构造一个5×3矩阵，不初始化。
x = torch.empty(2, 3)
x1 = torch.rand(2, 3)
x2 = torch.zeros(2, 3, dtype=torch.long)
x3 = torch.tensor([5.5, 3])
x4 = x.new_ones(2, 3, dtype=torch.double)
x5 = torch.randn_like(x, dtype=torch.float)
print("x===", x)
print("x1===", x1)
print("x2===", x2)
print("x3===", x3)
print("x4===", x4)
print("x5===", x5)

print(x5.size())
print(x5[:, 1])
x = torch.randn(2, 3)
y = x.view(6)
z = x.view(-1, 3)  # the size -1 is inferred from other dimensions
print(x, y, z)
print(x.size(), y.size(), z.size())
