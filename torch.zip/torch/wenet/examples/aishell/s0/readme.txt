
语言模型环境
ngram-count  SRILM  1.7.3
export PATH=/home/data/deep_learning/torch/wenet/lm/srilm/bin/i686-m64/:/home/data/deep_learning/torch/wenet/lm/srilm/bin:$PATH

fstcompile  openfst
export PATH=/home/data/deep_learning/torch/wenet/lm/openfst-1.7.2/bin/:/home/data/deep_learning/torch/wenet/lm/srilm/bin:$PATH


wget http://mobvoi-speech-public.ufile.ucloud.cn/public/wenet/aishell2/20210602_unified_transformer_server.tar.gz
tar -xf 20210602_unified_transformer_server.tar.gz
docker run --rm -it -p 10086:10086 -v /Users/sunkangkang/Downloads/20210602_unified_transformer_server:/home/wenet/model mobvoiwenet/wenet:mini bash /home/run.sh
ws://localhost:10086

