from speechcolab.datasets.gigaspeech import GigaSpeech

subset = "{XL}"
download_eval = True
with_dict = False
PASSWORD = ".5/ei5.YwglJbQTrPF4yDMoktSepkm4D5"
host = "tsinghua"
gigaspeech = GigaSpeech('/home/data/ASR/GigaSpeech/data')
if download_eval and subset != '{DEV}' and subset != '{TEST}':
    gigaspeech.download(PASSWORD, subset='{DEV}', host=host, with_dict=with_dict)
    gigaspeech.download(PASSWORD, subset='{TEST}', host=host, with_dict=with_dict)
gigaspeech.download(PASSWORD, subset=subset, host=host, with_dict=with_dict)
