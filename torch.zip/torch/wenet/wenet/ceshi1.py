# coding:utf-8
# CreatDate: 2020/12/28 21:01 by ZTE
# Author: Kangkang Sun

import os
import re


def walkFile(file):
    all_file = []
    for root, dirs, files in os.walk(file):
        # root 表示当前正在访问的文件夹路径
        # dirs 表示该文件夹下的子目录名list
        # files 表示该文件夹下的文件list
        # print(11111, root)
        # print(22222, dirs)
        # print(33333, files)
        # print()
        # 遍历文件
        for f in files:
            if f[-3:] == ".py":
                # print(os.path.join(root, f))
                all_file.append(os.path.join(root, f))
        # 遍历所有的文件夹
        # for d in dirs:
        #     print(os.path.join(root, d))
    return all_file


def panduan(file_name, name):
    if file_name[-4:] in [".png", ".jpg", ".pyc", ".JPG", ".PNG", ".gif", ".bmp", "jpeg", "jfif", ".tar", ".GIF"]:
        return False
    try:
        fr = open(file_name, "r", encoding="utf8")
        for line in fr:
            line = line.strip()
            # if re.findall("def +{}\(".format(name), line):
            # if re.findall("def +{}".format(name), line):
            if re.findall("{}".format(name), line):
                return True
            else:
                continue
        return False
    except:
        # print(11111111, file_name)
        return False


def panduan1(file_name, name):
    if re.findall("{}".format(name), file_name):
        return True
    else:
        return False


def find_def(root_dir, name):
    all_file = walkFile(root_dir)
    for file_name in all_file:
        flag = panduan(file_name, name)
        # flag = panduan1(file_name, name)
        if flag:
            print(file_name)


root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__)))
name = "is_distributed"
find_def(root_dir, name)
