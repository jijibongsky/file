import torch


def Weighted_Averaging(model_dir, check_paths, out_put_path):
    model_paths = [model_dir + check_point for check_point in check_paths]
    checkpoints = [torch.load(model_path) for model_path in model_paths]
    N = len(check_paths)
    canshu = checkpoints[0]['model']
    for key in canshu:
        # print(111111111111111, key, type(canshu[key]), canshu[key].shape)
        # print(222222222222222, canshu[key])
        temp_tensor = canshu[key] / N
        for check_point in checkpoints[1:]:
            canshu1 = check_point['model']
            temp_tensor += canshu1[key] / N
        canshu[key] = temp_tensor
        # print(333333333333333, temp_tensor.shape)
        # print()
    checkpoints[0]['model'] = canshu
    torch.save(checkpoints[0], out_put_path)


if __name__ == '__main__':
    model_dir = "/home/data/deep_learning/torch/OpenTransformer/egs/aishell/exp/transformer/"
    check_paths = ["model.epoch.0.pt", "model.epoch.1.pt", "model.epoch.2.pt"]
    out_put_path = model_dir + "weightedAveraging.pt"
    Weighted_Averaging(model_dir, check_paths, out_put_path)

    # check_path = "/home/data/deep_learning/torch/Speech_Transformer/egs/aishell/exp/temp/final.pth30.tar"
    # checkpoint = torch.load(check_path, map_location='cpu')
    # state_dict = checkpoint['state_dict']
    # for key in state_dict:
    #     print(key, state_dict[key].shape)
