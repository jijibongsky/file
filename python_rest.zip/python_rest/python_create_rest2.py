from flask import request
from flask import Flask
from flask import abort
import json
import numpy as np
import cv2
from PIL import Image


app = Flask(__name__)
@app.route('/resttest', methods=['POST'])
def create_task():
    # if not request.json or not 'sentence' in request.json:
    #     abort(401)

    f = request.files["image"]
    data = f.read()
    # print("data====", data)
    # print("data====", len(data))
    img_np = np.frombuffer(data, np.uint8)  # 从byte数据读取为np.array形式

    img = cv2.imdecode(img_np, cv2.COLOR_RGB2BGR)
    img = np.array([img[:, :, 2], img[:, :, 1], img[:, :, 0]], dtype="uint8").transpose((1, 2, 0))
    # Image.fromarray(img).save("3333.jpg")
    print("img====", img)

    RESULT = {"result": "aaaa"}
    RESULT = json.dumps(RESULT)     # 把字典穿换成 json 格式
    return RESULT


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8815)

