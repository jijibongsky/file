import requests
import json
import base64


# 由于要发送json，所以需要对byte进行str解码
def getByte(path):
    with open(path, 'rb') as f:
        img_byte = base64.b64encode(f.read())
    img_str = img_byte.decode('ascii')
    return img_str


img_str = getByte('1111.jpg')
url = 'http://127.0.0.1:8815/resttest'
data = {'recognize_img': img_str, 'type': '0', 'useAntiSpoofing': '0'}
json_mod = json.dumps(data, ensure_ascii=False)
res = requests.post(url=url, json=json_mod)
print("====", res.text)

# from PIL import Image
# import numpy as np
# image = np.array(Image.open("1111.jpg").convert('RGB'))
# # image = np.array([image[:, :, 2], image[:, :, 1], image[:, :, 0]], dtype="uint8").transpose((1, 2, 0))
# print(image)
# print(image.shape)

