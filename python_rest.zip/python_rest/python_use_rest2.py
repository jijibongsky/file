import requests
import json


url = 'http://127.0.0.1:8815/resttest'
# files = {'image':('test.png', open('1111.jpg', 'rb'), 'image/png')}
files = {'image':open('1111.jpg', 'rb')}
requests.post(url, files=files)



