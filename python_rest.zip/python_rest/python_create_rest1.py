from flask import request
from flask import Flask
from flask import abort
import json
import cv2
import base64
import numpy as np
from PIL import Image


app = Flask(__name__)
@app.route('/resttest', methods=['POST'])
def create_task():
    if not request.json or not 'recognize_img' in request.json:
        abort(401)
    data_dict = json.loads(request.json)  #  request.json 是字符串  json.loads 加载字符串
    img_str = data_dict['recognize_img']

    print("img_str===", len(img_str))

    img_decode_ = img_str.encode('ascii')  # ascii编码
    img_decode = base64.b64decode(img_decode_)  # base64解码
    img_np = np.frombuffer(img_decode, np.uint8)  # 从byte数据读取为np.array形式

    # print("img_np===", img_np)
    # print("img_np===", img_np.shape)

    img = cv2.imdecode(img_np, cv2.COLOR_RGB2BGR)  # 转为OpenCV形式   , cv2.COLOR_RGB2BGR
    # 显示图像
    # cv2.imshow('img', img)
    # cv2.waitKey()
    # cv2.destroyAllWindows()

    img = np.array([img[:, :, 2], img[:, :, 1], img[:, :, 0]], dtype="uint8").transpose((1, 2, 0))
    Image.fromarray(img).save("3333.jpg")

    RESULT = {"result": img_str}
    RESULT = json.dumps(RESULT)     # 把字典穿换成 json 格式
    return RESULT


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8815)