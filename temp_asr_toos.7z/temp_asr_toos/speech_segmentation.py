import os
# !/usr/bin/env python3
# encoding: utf-8

from pydub import AudioSegment
from pydub.silence import split_on_silence
import os

audiotype = "wav"

wav_in_path = '1_1.wav'
wav_out_dir = 'chunks/'
if not os.path.exists(wav_out_dir):
    os.mkdir(wav_out_dir)

wav_audio = AudioSegment.from_file(wav_in_path, format=audiotype)
chunks = split_on_silence(wav_audio, min_silence_len=600, silence_thresh=-50)
for j in range(len(chunks)):
    new = chunks[j]
    save_name = wav_out_dir + '{}.{}'.format(j, audiotype)
    new.export(save_name, format=audiotype)
